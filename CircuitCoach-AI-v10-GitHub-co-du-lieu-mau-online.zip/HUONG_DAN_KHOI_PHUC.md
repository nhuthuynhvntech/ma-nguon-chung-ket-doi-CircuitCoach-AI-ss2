# CircuitCoach AI · Bản dự án mới

Bản sao độc lập của CircuitCoach AI v6, lấy mã nguồn từ commit `cdf3de9`. Dữ liệu local và bản trích xuất online được giữ riêng để có thể đối chiếu từng nguồn.

## Chạy chương trình

1. Bấm đúp `CHAY_CIRCUITCOACH.cmd`.
2. Mở [CircuitCoach tại cổng 3190](http://127.0.0.1:3190/#/home). Bản dựng đã có sẵn trong `dist`.
3. Khi chuyển sang máy Windows khác, dùng Node.js 24. Khi sửa mã nguồn, chạy `npm ci` và `npm run build` trước khi mở lại ứng dụng.

Bản sao dùng các tài khoản local trong cơ sở dữ liệu đã chép. Trên Windows, mở **Cấu hình OpenAI** từ trang đăng nhập hoặc **Cấu hình** trên thanh điều hướng để lưu khóa dùng chung trên máy. Mục này mở được trước khi đăng nhập. Khóa mới có hiệu lực từ yêu cầu AI tiếp theo. Khi chọn **Dùng khóa mặc định**, chương trình đọc dòng `OPENAI_API_KEY=` trong tệp `%LOCALAPPDATA%\CircuitCoach\local-3190\.env` rồi dùng biến môi trường `OPENAI_API_KEY` nếu dòng đó trống. Khi máy chưa cấu hình khóa, giao diện có chế độ mô phỏng.

## Dữ liệu ở đâu?

| Nơi lưu | Nội dung |
|---|---|
| `.data/circuitcoach.sqlite` | 28 lượt làm, 4 lớp, 5 nhóm, 3 tài khoản và dữ liệu nhận xét, nhãn, A/B đã lưu. |
| `.data/images` | 58 tệp ảnh đang được cơ sở dữ liệu liên kết, gồm ảnh bài làm và ảnh tham chiếu. Bản local có 11 mục tham chiếu, trong đó 10 ảnh đã duyệt có thể xem ở kho công khai của bản local. |
| `public/images` | Sơ đồ và ảnh mẫu có sẵn của 5 bài học. Số ảnh mẫu riêng do giáo viên tải vào thư viện từng lớp trong bản local tại thời điểm sao lưu là 0. |
| `backups/du-lieu-online` | Bản trích xuất riêng gồm 7 lượt làm, 14 ảnh bài nộp và 1 ảnh tham chiếu online. Tệp JSON kèm báo cáo, phạm vi lớp, thông tin tài khoản dạng danh sách và nhãn đã lấy qua ứng dụng. |
| `backups/du-lieu-du-an-cu` | Dữ liệu lớp học dạng cũ từ thư mục dự án trước, gồm một tệp dữ liệu và hai ảnh. |

Bản trích xuất online là dữ liệu nghiệp vụ lấy qua các trang của ứng dụng. Cơ sở dữ liệu online đầy đủ vẫn nằm trên OpenAI Sites. Các ảnh chỉ lưu trong trình duyệt gắn với địa chỉ đã mở, chẳng hạn cổng 3187, vẫn được đọc trên trình duyệt và địa chỉ đó. Ảnh và lượt làm đã đồng bộ thuộc bản sao máy chủ tương ứng.

## Sao lưu và phục hồi

- Bấm đúp `SAO_LUU_DU_LIEU.cmd` để tạo một bản sao mới của SQLite và ảnh trong `backups/du-lieu-local`. Mỗi bản sao có thời điểm và `manifest.json` để kiểm tra tính toàn vẹn.
- ZIP mã nguồn gồm ứng dụng và bản dựng sẵn. ZIP dữ liệu gồm cơ sở dữ liệu và ảnh local, bản trích xuất online và dữ liệu legacy. Các ZIP dùng để khôi phục vào thư mục khác.
- Khi phục hồi, giải nén ZIP mã nguồn và ZIP dữ liệu vào cùng thư mục mới. Giữ tên `.data` để ứng dụng đọc đúng SQLite và kho ảnh. Khởi động lại rồi đăng nhập. Khi cần đọc ảnh chỉ lưu trong trình duyệt từ địa chỉ cũ, chạy bản sao ở cổng 3187 sau khi tiến trình cũ đã dừng. Có thể đặt `LOCAL_PORT=3187` trước khi chạy trình mở.
- Tệp `.data/local-credentials.json` của thư mục làm việc giữ khóa phiên local. Nếu phục hồi từ ZIP trên máy khác, chương trình tạo khóa phiên local mới và học sinh vào lại nhóm để mở lịch sử. Giữ ZIP dữ liệu riêng vì có ảnh và bài làm của học sinh.
- Bản mới chạy riêng ở cổng 3190. Cấu hình đóng gói của thư mục này dành cho local và có thể được gắn với một Site riêng khi cần.

## Đã kiểm tra

- SQLite qua `integrity_check` và `foreign_key_check`.
- Đã đối chiếu 58 đối tượng ảnh trong cơ sở dữ liệu. Kho ảnh local có đủ ảnh và tệp mô tả cho từng đối tượng.
- Trang chủ, ảnh mẫu HC-SR04 và ảnh tham chiếu đã phản hồi thành công khi chạy thử từ thư mục mới.
- Đã đối chiếu dữ liệu lượt làm online trước và sau khi tải ảnh. Tất cả ảnh được tham chiếu trong phạm vi bản trích xuất đều tải thành công.
