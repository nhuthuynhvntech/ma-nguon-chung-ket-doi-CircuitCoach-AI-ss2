# AI tracking

Sign in as a teacher and open the AI tracking tab. Select a lesson and
period to see accuracy by lane, the difference in percentage points,
missed safety errors, labeled images, and saved comparisons. Export
daily totals as CSV.

Save definite teacher labels before running A/B on a synchronized
attempt. B must use at least one approved reference. New runs save the
paired scores, exact labels, lesson criteria, model and configuration
in the same database transaction as the two AI results. Older runs
remain in the history and are shown without a score snapshot.

Each repeat is a new measurement. Day-to-day results may use different
attempts. The report measures the added reference examples and does not
provide a fixed benchmark across configurations.

The SQLite database remains in .data/circuitcoach.sqlite and library
images remain under .data/images. Keep both for a full data backup.

Local deployment applied migration 0005 and the teacher API opened
successfully. An isolated SQLite run with mock AI confirmed score
history, image access and the original label after a later edit.

The shared navigation and welcome page link to /#/ai-progress.
Guests can see class-independent totals by lesson and day, download
aggregate CSV data, and open the built-in lesson reference images.
Class histories, individual runs and submitted photos stay on the
teacher route. Both views read the same saved comparison scores.

Both views now provide a dedicated tab and link for each lesson, such
as /#/ai-progress/servo. Switching lessons keeps the selected period.
The summary, history, images and CSV are scoped to the selected lesson.
