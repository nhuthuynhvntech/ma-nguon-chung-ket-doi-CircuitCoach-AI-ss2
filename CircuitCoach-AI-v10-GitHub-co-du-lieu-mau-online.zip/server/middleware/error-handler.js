import multer from "multer";
import { ZodError } from "zod";

export function notFoundHandler(request, response) {
  response.status(404).json({ error: { code: "NOT_FOUND", message: `Không tìm thấy ${request.method} ${request.path}.` } });
}

export function errorHandler(error, _request, response, _next) {
  console.error("[CircuitCoach]", error.code || error.name, error.message);
  if (error instanceof multer.MulterError) {
    const message = error.code === "LIMIT_FILE_SIZE" ? "Một ảnh vượt quá giới hạn dung lượng." : error.code === "LIMIT_FILE_COUNT" ? "Chỉ được gửi tối đa 3 ảnh." : "Không thể đọc ảnh tải lên.";
    response.status(400).json({ error: { code: error.code, message } });
    return;
  }
  if (error instanceof ZodError) {
    response.status(400).json({ error: { code: "INVALID_DATA", message: "Dữ liệu không đúng định dạng.", details: error.issues } });
    return;
  }
  const status = Number(error.status) || (error.name === "AbortError" ? 504 : 500);
  const safeMessage = status >= 500 && !error.code ? "CircuitCoach chưa thể hoàn tất yêu cầu. Vui lòng thử lại." : error.message;
  response.status(status).json({ error: { code: error.code || "INTERNAL_ERROR", message: safeMessage } });
}
