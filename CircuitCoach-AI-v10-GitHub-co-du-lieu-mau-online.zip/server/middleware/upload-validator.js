import multer from "multer";

const allowedTypes = new Set(["image/jpeg", "image/png", "image/webp"]);
const maxFileSize = Number(process.env.MAX_IMAGE_MB || 8) * 1024 * 1024;

export const uploadImages = multer({
  storage: multer.memoryStorage(),
  limits: { files: 6, fileSize: maxFileSize },
  fileFilter(_request, file, callback) {
    if (!allowedTypes.has(file.mimetype)) {
      const error = new Error("Chỉ hỗ trợ ảnh JPEG, PNG hoặc WEBP.");
      error.status = 415;
      error.code = "UNSUPPORTED_IMAGE_TYPE";
      callback(error);
      return;
    }
    callback(null, true);
  },
});
