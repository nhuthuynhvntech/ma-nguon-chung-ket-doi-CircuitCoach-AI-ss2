export const UNO_HEADER_LAYOUTS = {
  digital_high: ["SCL", "SDA", "AREF", "GND", "D13", "D12", "D11", "D10", "D9", "D8"],
  digital_low: ["D7", "D6", "D5", "D4", "D3", "D2", "D1", "D0"],
  power: ["NC", "IOREF", "RESET", "3.3V", "5V", "GND_5V", "GND_VIN", "VIN"],
  analog: ["A0", "A1", "A2", "A3", "A4", "A5"],
};

const unoImageCoordinate = { type: "number", minimum: 0, maximum: 100 };
const unoImagePoint = {
  type: "object", additionalProperties: false, required: ["x", "y"],
  properties: { x: unoImageCoordinate, y: unoImageCoordinate },
};
export const UNO_PIN_GEOMETRY_SCHEMA = {
  anyOf: [
    { type: "null" },
    ...Object.entries(UNO_HEADER_LAYOUTS).map(([header, pins]) => ({
      type: "object", additionalProperties: false, required: ["header", "contact", "anchors", "printedLabel"],
      properties: {
        header: { type: "string", enum: [header] },
        contact: unoImagePoint,
        printedLabel: { anyOf: [{ type: "string" }, { type: "null" }] },
        anchors: {
          type: "array", minItems: 2, maxItems: 3,
          items: {
            ...unoImagePoint, required: ["x", "y", "pin"],
            properties: {
              ...unoImagePoint.properties,
              pin: { type: "string", enum: pins },
            },
          },
        },
      },
    })),
  ],
};

function isUnoImagePoint(point) {
  return [point?.x, point?.y].every(value => Number.isFinite(value) && value >= 0 && value <= 100);
}

export function resolveArduinoUnoPin(geometry) {
  const layout = Object.hasOwn(UNO_HEADER_LAYOUTS, geometry?.header) ? UNO_HEADER_LAYOUTS[geometry.header] : null;
  const { contact, anchors } = geometry || {};
  if (!layout || !isUnoImagePoint(contact) || !Array.isArray(anchors) || ![2, 3].includes(anchors.length)
    || anchors.some(anchor => !isUnoImagePoint(anchor) || !layout.includes(anchor.pin))
    || new Set(anchors.map(anchor => anchor.pin)).size !== anchors.length) return null;

  const ordered = anchors.map(anchor => ({ ...anchor, index: layout.indexOf(anchor.pin) }))
    .sort((a, b) => a.index - b.index);
  const start = ordered[0];
  const end = ordered.at(-1);
  const span = end.index - start.index;
  if (ordered.length === 2 && span !== 1) return null;
  const pitchX = (end.x - start.x) / span;
  const pitchY = (end.y - start.y) / span;
  const pitch = Math.hypot(pitchX, pitchY);
  if (pitch < 0.45) return null;
  if (ordered.length === 3) {
    const middle = ordered[1];
    const middleOffset = middle.index - start.index;
    const middleError = Math.hypot(middle.x - start.x - middleOffset * pitchX, middle.y - start.y - middleOffset * pitchY);
    if (middleError > 0.35 * pitch) return null;
  }

  const deltaX = contact.x - start.x;
  const deltaY = contact.y - start.y;
  const offset = (deltaX * pitchX + deltaY * pitchY) / (pitch * pitch);
  const slot = Math.round(offset);
  const offRow = Math.abs(deltaX * pitchY - deltaY * pitchX) / pitch;
  if (slot < 0 || slot > span || Math.abs(offset - slot) > 0.27 || offRow > 0.38 * pitch) return null;
  if (ordered.length === 2 && Math.hypot(contact.x - ordered[slot].x, contact.y - ordered[slot].y) > 0.25 * pitch) return null;

  const pin = layout[start.index + slot];
  const radius = Math.max(0.9, Math.min(3, pitch * 0.48));
  const x = Math.max(0, contact.x - radius);
  const y = Math.max(0, contact.y - radius);
  return {
    pin: pin.startsWith("GND_") ? "GND" : pin,
    anchors: ordered.map(anchor => anchor.pin),
    region: { x, y, width: Math.min(100, contact.x + radius) - x, height: Math.min(100, contact.y + radius) - y },
  };
}

export function mergeArduinoPinDetailReview(lessonId, reviewed, detail, crops, criterionIds) {
  if (detail?.lessonId !== lessonId || !Array.isArray(detail.checks)) return reviewed;
  const requested = new Set(criterionIds);
  const previous = Array.isArray(reviewed?.checks) && reviewed.lessonId === lessonId ? reviewed.checks : [];
  const replacements = new Map();
  const seen = new Set();
  for (const row of detail.checks) {
    const id = row?.criterionId;
    if (!requested.has(id)) continue;
    if (seen.has(id)) { replacements.delete(id); continue; }
    seen.add(id);
    const previousObservation = previous.find(item => item.criterionId === id)?.observation;
    if (previousObservation?.photoReviews?.some(photo => photo.assessment === "conflicting")) continue;
    const observation = row.observation;
    if (!Number.isInteger(observation?.imageIndex) || !crops[observation.imageIndex]) continue;
    const geometry = observation.pinGeometry;
    if (!resolveArduinoUnoPin(geometry)) continue;
    const bounds = crops[observation.imageIndex].bounds;
    const project = point => ({
      ...point,
      x: (100 * bounds.left + point.x * bounds.width) / bounds.imageWidth,
      y: (100 * bounds.top + point.y * bounds.height) / bounds.imageHeight,
    });
    const translated = bounds ? { ...geometry, contact: project(geometry.contact), anchors: geometry.anchors.map(project) } : geometry;
    if (!resolveArduinoUnoPin(translated)) continue;
    replacements.set(id, { criterionId: id, observation: { ...observation, pinGeometry: translated, pinCropRead: Boolean(bounds) } });
  }
  if (!replacements.size) return reviewed;
  return { ...detail, checks: [...previous.filter(row => !replacements.has(row.criterionId)), ...replacements.values()] };
}
