const UNCERTAIN_STATUSES = new Set(["uncertain", "not_visible"]);

export function applySafetyPolicy(lesson, analysis) {
  const definitions = new Map(lesson.checkList.map((check) => [check.id, check]));
  const ids = analysis.checks.map((check) => check.id);
  const missingIds = lesson.checkList.filter((check) => !ids.includes(check.id)).map((check) => check.id);
  const duplicateIds = [...new Set(ids.filter((id, index) => ids.indexOf(id) !== index))];
  const checks = analysis.checks.map((check) => {
    const definition = definitions.get(check.id);
    return {
      ...check,
      category: definition?.category === "safety" ? "safety" : "standard",
      safetyKind: definition?.safetyKind || null,
    };
  });
  const safetyChecks = checks.filter((check) => check.category === "safety");
  const unknownSafety = safetyChecks.filter((check) => UNCERTAIN_STATUSES.has(check.status));
  const failedSafety = safetyChecks.filter((check) => check.status !== "correct" && !UNCERTAIN_STATUSES.has(check.status));
  const imageQualitySufficient = analysis.analysisStatus === "ok" && unknownSafety.length === 0 && missingIds.length === 0 && duplicateIds.length === 0;
  const allSafetyPassed = safetyChecks.length > 0 && safetyChecks.every((check) => check.status === "correct");
  const allChecksPassed = checks.every((check) => check.status === "correct" || check.status === "not_applicable");
  const verdict = imageQualitySufficient && allSafetyPassed && allChecksPassed ? "pass" : "review";

  return {
    ...analysis,
    checks,
    verdict,
    safety: {
      imageQualitySufficient,
      allSafetyPassed,
      failedIds: failedSafety.map((check) => check.id),
      unknownIds: unknownSafety.map((check) => check.id),
      missingIds,
      duplicateIds,
      teacherCheckRequired: true,
    },
  };
}
