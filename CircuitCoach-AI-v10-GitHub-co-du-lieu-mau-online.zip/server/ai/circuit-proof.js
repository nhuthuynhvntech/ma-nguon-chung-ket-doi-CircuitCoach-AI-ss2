import { ANNOTATION_REGION_JSON_SCHEMA, isValidRegion } from "./annotation-policy.js";

const visualParts = [
  "component", "lead_start", "lead_end", "wire_path", "cathode_cup", "anode_electrode",
  "feed_terminal", "return_terminal", "feed_anchor", "return_anchor", "resistor_bands", "printed_value", "positive_terminal",
  "negative_terminal", "bridge", "lit_led", "open_terminal", "probe_ports",
];

export const CIRCUIT_VISUAL_PROOF_SCHEMA = {
  type: "array", maxItems: 6,
  items: {
    type: "object", additionalProperties: false, required: ["part", "imageIndex", "region", "text"],
    properties: {
      part: { type: "string", enum: visualParts },
      imageIndex: { type: "integer", minimum: 0, maximum: 2 },
      region: ANNOTATION_REGION_JSON_SCHEMA.anyOf[0],
      text: { anyOf: [{ type: "string" }, { type: "null" }] },
    },
  },
};

export const CIRCUIT_VISUAL_PROOF_INSTRUCTIONS = `ĐIỀU KIỆN KẾT LUẬN TỪ ẢNH
Với mỗi giá trị quan sát, điền tối đa sáu mục visualProof, gồm vai trò part, imageIndex và vùng nhỏ nhất chỉ ra chi tiết. Tọa độ bằng phần trăm trên ẢNH GỐC của học sinh, kể cả khi ảnh cận giúp tìm vị trí. Chỉ dùng vùng nằm trong ảnh có photoReviews assessment supports. text để null, trừ khi chép nguyên ký hiệu hoặc trị số nhìn rõ. Viết detail và từng nhận xét ảnh ngắn gọn, chỉ ghi chi tiết quyết định.
- Nhìn thấy linh kiện: component. Thiếu linh kiện: lead_start, lead_end và wire_path nhìn rõ toàn đoạn.
- Nối dây và mắc nối tiếp: lead_start (đầu dây ở linh kiện), lead_end (đầu cắm thực tế) và wire_path (đường lần dây). Chân linh kiện cắm trực tiếp được xem là dây nối. Ghi lead_start ở chỗ chân đi ra từ linh kiện, lead_end ở nơi chân đi vào lỗ và wire_path dọc đoạn chân kim loại. Có thể dùng component khoanh thân linh kiện nằm ngay đầu đoạn chân. Các bộ phận có thể thấy qua nhiều ảnh. Màu dây đơn lẻ không chứng minh đường nối.
- Chiều LED: trước hết tìm chén kim loại đỡ chip LED để phân biệt cathode với bản cực anode. Lần từ bản cực qua mép vỏ tới điểm nối nhìn thấy và ghi vào ledTrace. Trên Arduino, đọc nhãn chân thực tế và ưu tiên chân nối về GND nếu dễ lần. Với pin và công tắc, đối chiếu hai nhánh RESISTOR và SWITCH nếu dấu cực pin bị che. Có thể ghép các góc khi thấy rõ cùng một chân LED. Kết luận đúng có thể để visualProof rỗng nếu không định vị được vùng chính xác. Để cảnh báo mắc ngược, lần đủ hai chân và đánh dấu cathode_cup, anode_electrode, feed_terminal, return_terminal, feed_anchor và return_anchor. Điền "anode" hoặc "cathode" cho text của hai terminal và ghi nhãn in trên ảnh cho hai anchor (8/D8 và GND, hoặc + và − khi dùng pin). Các tiêu chí khác dùng ledTrace null nếu trường này có trong cấu trúc.
- Trị số điện trở: resistor_bands trên góc đọc rõ vạch, hoặc printed_value nếu đọc rõ trị số có đơn vị Ω/kΩ/MΩ trên thân. Nếu đã lần đúng điện trở khi kiểm tra mắc nối tiếp, dùng lại vùng wire_path đã thấy cho tiêu chí trị số. Chỉ dùng đường nối đó khi hai tiêu chí đang xem cùng điện trở.
- Điện áp ghi trên nguồn: printed_value chứa nguyên số và đơn vị V trên nguồn đang nối, cùng wire_path. Cực pin: positive_terminal có dấu +, negative_terminal có dấu − hoặc -, cùng wire_path.
- Nghi chập: bridge chỉ vùng cầu nối thật, kèm feed_terminal và return_terminal. Ghi uncertain khi chỉ thấy các dây tách nhau trên ảnh; cần kiểm tra mạch thật để loại trừ chập.
- Đường mạch qua công tắc: wire_path cùng lit_led nếu thấy LED thực sự phát sáng, hoặc open_terminal nếu thấy chỗ đứt rõ. Vị trí cần gạt đơn lẻ không chứng minh thông mạch.
- Đầu dò: probe_ports và lead_end cho thấy các đầu dây ở cổng.
Nếu thiếu phần thiết yếu, ghi uncertain và visualProof có thể giữ những chi tiết đã thấy. Không dùng nhãn ảnh mẫu hay mức tự tin để bù phần ảnh còn thiếu.`;

function requiredParts(rule, observed, hasBands) {
  const tracedPath = ["lead_start", "lead_end", "wire_path"];
  switch (rule.type) {
    case "visibility": return ["component"];
    case "presence": return observed === "missing" ? tracedPath : ["component"];
    case "series": return tracedPath;
    case "pin": return observed === "open" ? ["lead_start", "open_terminal"] : tracedPath;
    case "led_polarity": return ["cathode_cup", "anode_electrode", "feed_terminal", "return_terminal"];
    case "resistance": return observed === "missing" ? tracedPath : [hasBands ? "resistor_bands" : "printed_value", "wire_path"];
    case "voltage": return ["printed_value", "wire_path"];
    case "battery_polarity": return ["positive_terminal", "negative_terminal", "wire_path"];
    case "short": return observed === "bridged" ? ["bridge", "feed_terminal", "return_terminal"] : null;
    case "continuity": return [observed === "closed_visible" ? "lit_led" : "open_terminal", "wire_path"];
    case "probe": return ["probe_ports", "lead_end"];
    default: return null;
  }
}

function overlapProof(a, b) {
  const intersectionWidth = Math.max(0, Math.min(a.x + a.width, b.x + b.width) - Math.max(a.x, b.x));
  const intersectionHeight = Math.max(0, Math.min(a.y + a.height, b.y + b.height) - Math.max(a.y, b.y));
  return intersectionWidth * intersectionHeight;
}

function distinctLedRegions(cup, anode) {
  if (cup.imageIndex !== anode.imageIndex) return false;
  const a = cup.region;
  const b = anode.region;
  const center = region => ({ x: region.x + region.width / 2, y: region.y + region.height / 2 });
  const smaller = Math.min(a.width * a.height, b.width * b.height);
  return overlapProof(a, b) <= 0.25 * smaller
    && !regionContainsProofPoint(a, center(b), 0) && !regionContainsProofPoint(b, center(a), 0);
}

function findLedElectrodeView(spots) {
  const cathodes = spots.filter(spot => spot.part === "cathode_cup");
  const anodes = spots.filter(spot => spot.part === "anode_electrode");
  return cathodes.find(cup => anodes.some(anode => distinctLedRegions(cup, anode)))?.imageIndex;
}

export function verifyLedElectrodeEvidence(observation, photoReviews) {
  const proof = observation?.visualProof;
  if (!Array.isArray(proof) || proof.length > 6 || photoReviews?.some(photo => photo.assessment === "conflicting")) return undefined;
  const supporting = new Set(photoReviews?.filter(photo => photo.assessment === "supports").map(photo => photo.imageIndex));
  return findLedElectrodeView(proof.filter(spot => spot && supporting.has(spot.imageIndex)
    && isValidRegion(spot.region) && spot.region.width * spot.region.height <= 2500));
}

function sameProofSpot(a, b, rule) {
  if (a.part !== b.part || a.imageIndex !== b.imageIndex) return false;
  const areaA = a.region.width * a.region.height;
  const areaB = b.region.width * b.region.height;
  const small = Math.min(areaA, areaB);
  const overlap = overlapProof(a.region, b.region);
  if (a.part === "wire_path") return overlap >= 0.55 * small;
  if (rule.type === "visibility" && a.part === "component") return overlap >= 0.8 * small;
  return Math.max(areaA, areaB) <= 5 * small && overlap >= 0.35 * small;
}

function matchesPrintedValue(text, type, value) {
  const pattern = type === "voltage" ? /^(\d+(?:[.,]\d+)?)\s*V$/i : /^(\d+(?:[.,]\d+)?)\s*([kKmM]?[ΩΩ])$/u;
  const match = typeof text === "string" ? text.trim().match(pattern) : null;
  if (!match) return false;
  const unit = match[2] || "";
  const multiplier = /^[kK]/.test(unit) ? 1000 : unit.startsWith("M") ? 1_000_000 : unit.startsWith("m") ? 0.001 : 1;
  return Number(match[1].replace(",", ".")) * multiplier === value;
}

function readVisualProof(observation, checked, rule, ledWarningEndpoints) {
  const { visualProof } = observation || {};
  const observed = checked.ruleEvidence.observed;
  const required = observed === null ? null : requiredParts(rule, observed, Boolean(checked.ruleEvidence.resistorBands));
  const parts = ledWarningEndpoints && required ? [...required, "feed_anchor", "return_anchor"] : required;
  if (!parts || !Array.isArray(visualProof) || visualProof.length > 6) return null;
  const supporting = new Set(checked.photoReviews?.filter(photo => photo.assessment === "supports").map(photo => photo.imageIndex));
  const spots = visualProof.filter(spot => spot && parts.includes(spot.part) && supporting.has(spot.imageIndex)
    && isValidRegion(spot.region) && spot.region.width * spot.region.height <= (spot.part === "wire_path" ? 6000 : 2500));
  if (!parts.every(part => spots.some(spot => spot.part === part))) return null;
  const hasSpot = (part, matches) => spots.some(spot => spot.part === part && matches(spot));
  if (parts.includes("printed_value") && !hasSpot("printed_value", spot =>
    spot.imageIndex === observation.imageIndex && matchesPrintedValue(spot.text, rule.type, observed))) return null;
  if (parts.includes("resistor_bands") && !hasSpot("resistor_bands", spot => spot.imageIndex === observation.imageIndex)) return null;
  if (rule.type === "pin" && !hasSpot(observed === "open" ? "open_terminal" : "lead_end", spot => spot.imageIndex === observation.imageIndex)) return null;
  if (observed === "digital_output" && !hasSpot("lead_start", spot => spot.text === "DO")) return null;
  if (rule.type === "battery_polarity" && (!hasSpot("positive_terminal", spot => typeof spot.text === "string" && spot.text.trim() === "+")
    || !hasSpot("negative_terminal", spot => typeof spot.text === "string" && ["-", "−", "–"].includes(spot.text.trim())))) return null;
  if (rule.type === "led_polarity" && findLedElectrodeView(spots) === undefined) return null;
  return { parts, spots, supporting };
}

function regionContainsProofPoint(region, point, margin = 1) {
  return point.x >= region.x - margin && point.x <= region.x + region.width + margin
    && point.y >= region.y - margin && point.y <= region.y + region.height + margin;
}

function leadProofContainsContact(proof, imageIndex, contact) {
  return proof.spots.some(({ part, imageIndex: index, region }) => part === "lead_end" && index === imageIndex
    && regionContainsProofPoint(region, contact));
}

function normalizeArduinoPrintedPin(text) {
  const printed = typeof text === "string" ? text.trim().toUpperCase() : "";
  const digital = printed.match(/^~?(\d{1,2})$/);
  return digital ? `D${digital[1]}` : printed;
}

function withDirectComponentLead(observation, contact) {
  const { imageIndex, visualProof } = observation;
  if (!Array.isArray(visualProof)) return null;
  const spots = visualProof.filter(spot => spot?.imageIndex === imageIndex && isValidRegion(spot.region));
  const port = spots.find(spot => spot.part === "lead_end" && regionContainsProofPoint(spot.region, contact));
  if (!port) return null;

  for (const { region } of spots.filter(spot => spot.part === "wire_path")) {
    const vertical = region.height >= region.width * 2;
    if (!vertical && region.width < region.height * 2) continue;
    const first = vertical ? { x: region.x + region.width / 2, y: region.y }
      : { x: region.x, y: region.y + region.height / 2 };
    const last = vertical ? { x: first.x, y: region.y + region.height }
      : { x: region.x + region.width, y: first.y };
    const portAtFirst = regionContainsProofPoint(port.region, first);
    const portAtLast = regionContainsProofPoint(port.region, last);
    if (portAtFirst === portAtLast) continue;
    const sourcePoint = portAtFirst ? last : first;
    const source = spots.find(spot => spot.part === "component"
      && spot.region.width * spot.region.height <= 650
      && overlapProof(spot.region, port.region) === 0
      && regionContainsProofPoint(spot.region, sourcePoint, 0.25));
    if (source) return { ...observation, visualProof: visualProof.map(spot => spot === source ? { ...spot, part: "lead_start" } : spot) };
  }
  return null;
}

function hasDistinctCircuitParts(rule, parts, spots, contact) {
  if (!parts.every(part => spots.some(spot => spot.part === part))) return false;
  for (const [start, end] of [
    ["lead_start", "lead_end"], ["feed_terminal", "return_terminal"], ["feed_anchor", "return_anchor"], ["positive_terminal", "negative_terminal"],
  ]) {
    if (!parts.includes(start) || !parts.includes(end)) continue;
    if (!spots.some(a => a.part === start && spots.some(b => {
      if (b.part !== end) return false;
      if (a.imageIndex !== b.imageIndex) return true;
      const overlap = overlapProof(a.region, b.region);
      if (!overlap) return true;
      return rule.type === "pin" && contact && regionContainsProofPoint(b.region, contact)
        && !regionContainsProofPoint(a.region, contact, 0.25)
        && overlap <= 0.15 * a.region.width * a.region.height
        && overlap <= 0.25 * b.region.width * b.region.height;
    }))) return false;
  }
  return rule.type !== "led_polarity" || findLedElectrodeView(spots) !== undefined;
}

function ledProofWithTracedLegs(spots, observed, endpoints) {
  const expectedLegs = observed === "anode_to_feed"
    ? { feed_terminal: "anode", return_terminal: "cathode" }
    : { feed_terminal: "cathode", return_terminal: "anode" };
  const leg = spot => typeof spot.text === "string" ? spot.text.trim().toLowerCase() : "";
  const isTerminal = spot => Object.hasOwn(expectedLegs, spot.part);
  if (spots.some(spot => isTerminal(spot) && leg(spot) && leg(spot) !== expectedLegs[spot.part])) return [];
  const electrodes = spots.filter(spot => ["cathode_cup", "anode_electrode"].includes(spot.part));
  const outside = (spot, others) => others.every(other => spot.imageIndex !== other.imageIndex || distinctLedRegions(spot, other));
  const traced = spots.filter(spot => !isTerminal(spot) || (leg(spot) === expectedLegs[spot.part] && outside(spot, electrodes)));
  if (!endpoints) return traced;
  const anchors = { feed_anchor: endpoints[0], return_anchor: endpoints[1] };
  const ledBodyAndLegs = [...electrodes, ...traced.filter(isTerminal)];
  return traced.filter(spot => !Object.hasOwn(anchors, spot.part) || (
    normalizeArduinoPrintedPin(spot.text).replace(/[−–]/g, "-") === anchors[spot.part] && outside(spot, ledBodyAndLegs)
  ));
}

export function verifiedArduinoPortSpots(observation, check, contact) {
  const index = observation.imageIndex;
  if (!check.photoReviews?.some(photo => photo.imageIndex === index && photo.assessment === "supports")
    || !Array.isArray(observation.visualProof)) return [];
  const ports = observation.visualProof.filter(spot => spot?.part === "lead_end" && spot.imageIndex === index
    && isValidRegion(spot.region) && spot.region.width * spot.region.height <= 2500
    && regionContainsProofPoint(spot.region, contact));
  if (!ports.length) return [];
  const labelInputs = [observation.pinGeometry?.printedLabel, ...ports.map(port => port.text)];
  const labels = labelInputs.map(normalizeArduinoPrintedPin).filter(Boolean);
  if (labels.some(label => label !== check.ruleEvidence.observed)) return [];
  return observation.pinGeometry?.anchors?.length === 3 || labels.length > 0 ? ports : [];
}

export function validateCircuitPhotoProof(rule, check, observation, contact, ledWarningEndpoints) {
  function verifiedSpots(candidate) {
    if (!candidate) return null;
    const proof = readVisualProof(candidate, check, rule, ledWarningEndpoints);
    if (!proof) return null;
    let spots = candidate.method === "single_photo"
      ? proof.spots.filter(spot => spot.imageIndex === candidate.imageIndex) : proof.spots;
    if (rule.type === "led_polarity") spots = ledProofWithTracedLegs(spots, check.ruleEvidence.observed, ledWarningEndpoints);
    if (!hasDistinctCircuitParts(rule, proof.parts, spots, contact)) return null;
    if (!spots.some(spot => spot.imageIndex === candidate.imageIndex)
      || (candidate.otherImageIndex !== null && !spots.some(spot => spot.imageIndex === candidate.otherImageIndex))) return null;
    return contact && !verifiedArduinoPortSpots(candidate, check, contact).length ? null : spots;
  }
  const proof = verifiedSpots(observation);
  if (proof || !contact || rule.type !== "pin") return proof;
  return verifiedSpots(withDirectComponentLead(observation, contact));
}

export function corroborateCircuitProof(rule, first, firstObservation, second, secondObservation, { firstContact, secondContact } = {}) {
  const firstProof = readVisualProof(firstObservation, first, rule);
  const secondProof = readVisualProof(secondObservation, second, rule);
  if (!firstProof || !secondProof) return null;
  const matched = secondProof.spots.filter(spot => firstProof.spots.some(earlier => sameProofSpot(earlier, spot, rule)));
  if (hasDistinctCircuitParts(rule, secondProof.parts, matched)
    && (!secondContact || [firstProof, secondProof].every(proof => leadProofContainsContact(proof, second.imageIndex, secondContact)))) return matched;

  if (first.status !== "correct" || second.status !== "correct" || first.ruleEvidence.observed !== second.ruleEvidence.observed
    || first.imageIndex === second.imageIndex || firstObservation.method !== "single_photo" || secondObservation.method !== "single_photo"
    || !firstProof.supporting.has(second.imageIndex) || !secondProof.supporting.has(first.imageIndex)) return null;

  const firstView = firstProof.spots.filter(spot => spot.imageIndex === first.imageIndex);
  const secondView = secondProof.spots.filter(spot => spot.imageIndex === second.imageIndex);
  if (!hasDistinctCircuitParts(rule, firstProof.parts, firstView) || !hasDistinctCircuitParts(rule, secondProof.parts, secondView)) return null;
  if (rule.type === "pin" && (!firstContact || !secondContact
    || !leadProofContainsContact(firstProof, first.imageIndex, firstContact)
    || !leadProofContainsContact(secondProof, second.imageIndex, secondContact))) return null;
  return [...firstView, ...secondView];
}

export function verifiedCircuitRegion(region, imageIndex, proof) {
  return isValidRegion(region) && region.width * region.height < 2500
    && proof.some(spot => spot.imageIndex === imageIndex
      && overlapProof(region, spot.region) >= 0.5 * spot.region.width * spot.region.height)
    ? region : null;
}
