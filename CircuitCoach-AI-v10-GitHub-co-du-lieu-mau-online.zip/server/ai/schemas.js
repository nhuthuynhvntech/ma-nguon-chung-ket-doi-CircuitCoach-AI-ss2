import { z } from "zod";

export const checkStatusSchema = z.enum(["correct", "possible_error", "uncertain", "not_visible", "not_applicable"]);
export const certaintySchema = z.enum(["high", "medium", "low"]);

export const tutorRequestSchema = z.object({
  lessonId: z.enum(["led", "hcsr04", "servo", "battery-led-switch", "soil-moisture"]),
  problem: z.object({
    id: z.string().min(1),
    status: checkStatusSchema,
    certainty: certaintySchema,
    evidence: z.string().min(1).max(600),
  }),
  studentContext: z.object({
    previousCount: z.number().int().min(0).max(1000),
    hintLevel: z.number().int().min(1).max(3),
  }),
});

export const tutorResponseSchema = z.object({
  title: z.string().min(1).max(160),
  hint: z.string().min(1).max(600),
  question: z.string().min(1).max(300),
  reviewTopic: z.string().min(1).max(120),
});

export const tutorJsonSchema = {
  type: "object",
  additionalProperties: false,
  required: ["title", "hint", "question", "reviewTopic"],
  properties: {
    title: { type: "string" },
    hint: { type: "string" },
    question: { type: "string" },
    reviewTopic: { type: "string" },
  },
};
