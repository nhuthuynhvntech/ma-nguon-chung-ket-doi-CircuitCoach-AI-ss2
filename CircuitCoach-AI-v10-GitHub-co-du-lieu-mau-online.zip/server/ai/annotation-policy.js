export const ANNOTATION_CONFIDENCE_THRESHOLD = 0.65;
export const ANNOTATION_REGION_JSON_SCHEMA = {
  anyOf: [{
    type: "object",
    additionalProperties: false,
    required: ["x", "y", "width", "height"],
    properties: Object.fromEntries(["x", "y", "width", "height"].map(key => [key, { type: "number", minimum: 0, maximum: 100 }])),
  }, { type: "null" }],
};

export function isValidRegion(region) {
  if (!region || typeof region !== "object") return false;
  const values = [region.x, region.y, region.width, region.height];
  if (!values.every(Number.isFinite)) return false;
  return region.x >= 0 && region.y >= 0
    && region.width > 0 && region.height > 0
    && region.x <= 100 && region.y <= 100
    && region.x + region.width <= 100
    && region.y + region.height <= 100;
}

const reviewProofParts = {
  led_polarity: ["cathode_cup", "anode_electrode", "feed_terminal", "return_terminal"],
  resistance: ["resistor_bands", "printed_value", "component"],
  voltage: ["printed_value", "positive_terminal", "component"],
  battery_polarity: ["positive_terminal", "negative_terminal", "component"],
  pin: ["lead_end", "open_terminal", "lead_start"],
  continuity: ["open_terminal", "lit_led", "component"],
  short: ["bridge"],
  series: ["lead_end", "lead_start", "component"],
  probe: ["probe_ports", "lead_end"],
  presence: ["lead_end", "component"],
  visibility: ["component"],
};

function validArea(candidate, imageCount) {
  return Number.isInteger(candidate?.imageIndex) && candidate.imageIndex >= 0 && candidate.imageIndex < imageCount
    && isValidRegion(candidate.region) && candidate.region.width * candidate.region.height <= 2500;
}

function areaFromProof(spots, type, imageCount, allowed = () => true) {
  if (!Array.isArray(spots)) return null;
  for (const part of Object.hasOwn(reviewProofParts, type) ? reviewProofParts[type] : []) {
    const match = spots.find(spot => spot?.part === part && validArea(spot, imageCount) && allowed(spot.imageIndex));
    if (match) return { imageIndex: match.imageIndex, region: match.region };
  }
  return null;
}

export function findReviewArea(check, observation, imageCount) {
  if (!observation || check.ruleEvidence?.physicalCheckRequired ||
    !["possible_error", "uncertain", "not_visible"].includes(check.status)) return null;
  const seen = index => Array.isArray(observation.photoReviews)
    && observation.photoReviews.some(photo => photo?.imageIndex === index
      && ["supports", "context", "unclear", "conflicting"].includes(photo.assessment));
  const target = observation.reviewTarget;
  if (validArea(target, imageCount) && seen(target.imageIndex)) return { imageIndex: target.imageIndex, region: target.region };
  return areaFromProof(observation.visualProof, check.ruleEvidence?.type, imageCount, seen);
}

export function circuitAnnotation(check, imageCount, confidenceThreshold = ANNOTATION_CONFIDENCE_THRESHOLD) {
  const { imageIndex, region, status, ruleEvidence } = check;
  if (ruleEvidence?.physicalCheckRequired || !["possible_error", "uncertain", "not_visible"].includes(status)) return null;
  if (status === "possible_error" && check.confidence >= confidenceThreshold && check.certainty !== "low") {
    if (validArea(check, imageCount)) return { kind: "error", imageIndex, region };
    const verified = areaFromProof(ruleEvidence?.visualProof, ruleEvidence?.type, imageCount);
    if (verified) return { kind: "error", ...verified };
  }
  return validArea(check.reviewArea, imageCount) ? { kind: "review", ...check.reviewArea } : null;
}

export function normalizeAnnotations(analysis, { imageCount, confidenceThreshold = ANNOTATION_CONFIDENCE_THRESHOLD }) {
  return {
    ...analysis,
    checks: analysis.checks.map((check) => {
      const confidence = Number.isFinite(check.confidence) ? check.confidence : 0;
      const imageIndexValid = Number.isInteger(check.imageIndex) && check.imageIndex >= 0 && check.imageIndex < imageCount;
      const evidenceImage = check.status === "possible_error" && imageIndexValid ? check.imageIndex : null;
      const canLocate = evidenceImage !== null && check.certainty !== "low" && isValidRegion(check.region)
        && check.region.width * check.region.height < 8_000;

      if (["correct", "possible_error"].includes(check.status) && confidence < confidenceThreshold) {
        return {
          ...check,
          status: "uncertain",
          certainty: "low",
          confidence,
          imageIndex: null,
          region: null,
          evidence: `Ảnh chưa đủ căn cứ để kết luận về tiêu chí “${check.label}”. Khi cần, hãy chụp lại cận cảnh bộ phận liên quan.`,
        };
      }

      return {
        ...check,
        confidence,
        imageIndex: evidenceImage,
        region: canLocate ? check.region : null,
      };
    }),
  };
}
