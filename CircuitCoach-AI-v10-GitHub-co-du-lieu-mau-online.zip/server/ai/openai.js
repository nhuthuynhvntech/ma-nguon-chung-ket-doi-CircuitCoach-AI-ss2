import OpenAI from "openai";
import { buildGuideChatRequest, readGuideChatReply } from "./guide-chat.js";
import { tutorJsonSchema, tutorResponseSchema } from "./schemas.js";
import { buildCircuitFocusSchema, circuitAnalysisTimedOut } from "./circuit-observations.js";
import { buildAnalyzeInput, buildLedDetailInput, buildLedPhotoInstructions, buildPrimaryAnalysisInstructions, buildStudentImageInput, studentImageDetail } from "./analyze-prompt.js";
import { TUTOR_DEVELOPER_PROMPT, buildTutorInput } from "./tutor-prompt.js";

function createClient() {
  if (!process.env.OPENAI_API_KEY) {
    const error = new Error("OpenAI API chưa được cấu hình.");
    error.status = 503;
    error.code = "OPENAI_NOT_CONFIGURED";
    throw error;
  }
  return new OpenAI({ apiKey: process.env.OPENAI_API_KEY, timeout: 60_000, maxRetries: 1 });
}

function toDataUrl(file) {
  return `data:${file.mimetype};base64,${file.buffer.toString("base64")}`;
}

export async function analyzeCircuit({ lesson, files, referenceFiles = [] }) {
  const client = createClient();
  const model = process.env.OPENAI_ANALYZE_MODEL || "gpt-5.6-terra";
  const detail = studentImageDetail(lesson, model);
  const studentInput = buildStudentImageInput(files.map((file) => ({ type: "input_image", image_url: toDataUrl(file), detail })));
  const ledDetailInput = await buildLedDetailInput(lesson, files.map(file => new Blob([file.buffer], { type: file.mimetype })),
    async photo => toDataUrl({ mimetype: photo.type, buffer: Buffer.from(await photo.arrayBuffer()) }), detail);
  const content = [
    { type: "input_text", text: buildAnalyzeInput(lesson, referenceFiles.length) },
    ...(referenceFiles.length ? [{ type: "input_text", text: "ẢNH MẠCH CHUẨN ĐÃ KIỂM DUYỆT — dùng để đối chiếu, không chấm điểm:" }] : []),
    ...referenceFiles.map((file) => ({ type: "input_image", image_url: toDataUrl(file), detail: "high" })),
    ...studentInput,
    ...buildLedPhotoInstructions(lesson),
    ...ledDetailInput,
  ];
  const criterionIds = lesson.checkList.map(criterion => criterion.id);
  try {
    const response = await client.responses.create({
      model, instructions: buildPrimaryAnalysisInstructions(lesson), input: [{ role: "user", content }],
      text: { format: { type: "json_schema", name: "circuit_analysis", strict: true, schema: buildCircuitFocusSchema(lesson, criterionIds) } }, store: false,
    }, { timeout: 58_000, maxRetries: 0 });
    return JSON.parse(response.output_text);
  } catch (error) {
    if (error instanceof OpenAI.APIConnectionTimeoutError) return circuitAnalysisTimedOut(lesson);
    throw error;
  }
}

export async function createTutorHint({ lesson, problem, studentContext, knowledge }) {
  const client = createClient();
  const response = await client.responses.create({
    model: process.env.OPENAI_TUTOR_MODEL || "gpt-5.6-luna",
    instructions: TUTOR_DEVELOPER_PROMPT,
    input: buildTutorInput({ lesson, problem, studentContext, knowledge }),
    text: { format: { type: "json_schema", name: "circuit_tutor_hint", strict: true, schema: tutorJsonSchema } },
    store: false,
  });
  return tutorResponseSchema.parse(JSON.parse(response.output_text));
}

export async function createGuideChatReply(input) {
  const payload = buildGuideChatRequest(process.env.OPENAI_TUTOR_MODEL || "gpt-5.6-luna", input);
  const response = await createClient().responses.create(payload, { timeout: 25_000, maxRetries: 0 });
  return readGuideChatReply(JSON.parse(response.output_text));
}
