import { getTargetedCaptureAdvice } from "../../src/data/capture-tips.js";
import { CIRCUIT_LESSON_SPECS } from "../../src/data/circuit-rules.js";
import { findReviewArea, normalizeAnnotations } from "./annotation-policy.js";
import { scoreCircuitObservations, validateSingleCircuitRead } from "./circuit-observations.js";
import { applySafetyPolicy } from "./safety-policy.js";

function summarizeBasicLedChecks(lesson, checks) {
  if (lesson.id !== "led") return "";
  const evidenceLabels = {
    led_orientation: "chiều LED",
    power_connection: "chân D8",
    ground_connection: "chân GND",
  };
  const confirmed = checks.filter(check => check.status === "correct" && Object.hasOwn(evidenceLabels, check.id))
    .map(check => evidenceLabels[check.id]);
  if (!confirmed.length) return "";
  const pending = checks.filter(check => ["uncertain", "not_visible"].includes(check.status)
    && !check.ruleEvidence?.physicalCheckRequired).map(check => check.label);
  const pendingText = pending.length ? ` Còn cần đối chiếu ${pending.join(", ").toLocaleLowerCase("vi")}.` : "";
  return `Ảnh xác nhận đúng ${confirmed.join(", ")}.${pendingText}`;
}

export function finalizeCircuitAnalysis(lesson, analysis, imageCount, { singleRead = false, strictEvidence = singleRead, markedViews = [] } = {}) {
  const ids = new Set(lesson.checkList.map(check => check.id));
  if (analysis?.lessonId !== lesson.id || !["ok", "insufficient_image"].includes(analysis.analysisStatus)
      || !Array.isArray(analysis.checks) || !analysis.checks.length || analysis.checks.length > 10
      || analysis.checks.some(check => !ids.has(check?.criterionId))) {
    throw Object.assign(new Error("Kết quả AI không khớp với bài học đã chọn."), { status: 502, code: "AI_SCHEMA_MISMATCH" });
  }
  const rows = strictEvidence ? lesson.checkList.map(check => {
    const matches = analysis.checks.filter(row => row.criterionId === check.id);
    return matches.length === 1 ? matches[0] : { criterionId: check.id };
  }) : analysis.checks;
  const observations = singleRead ? validateSingleCircuitRead(lesson, rows, imageCount, markedViews) : rows;
  const rules = CIRCUIT_LESSON_SPECS[lesson.id].rules;
  const checks = scoreCircuitObservations(lesson, observations, imageCount, { strictEvidence, singleRead }).map(check => {
    if (!strictEvidence || !["uncertain", "not_visible"].includes(check.status)) return check;
    const rule = rules[check.id];
    const physicalCheck = rule.type === "short"
      ? "Cần giáo viên kiểm tra mạch thật để loại trừ chập trước khi cấp nguồn."
      : rule.physicalCheck;
    if (!physicalCheck) return check;
    const conflict = observations.find(row => row.criterionId === check.id)?.recheckOutcome === "conflicting"
      || check.photoReviews?.some(photo => photo.assessment === "conflicting");
    return { ...check, status: "uncertain", evidence: conflict ? `${check.evidence} ${physicalCheck}` : physicalCheck,
      ruleEvidence: { ...check.ruleEvidence, physicalCheckRequired: true } };
  });
  const visibleCount = new Set(checks.filter(check => ["correct", "possible_error"].includes(check.status)).map(check => check.id)).size;
  const photoChecks = checks.filter(check => !check.ruleEvidence.physicalCheckRequired);
  const analysisStatus = strictEvidence
    ? (visibleCount * 2 < photoChecks.length ? "insufficient_image" : "ok")
    : (analysis.analysisStatus === "insufficient_image" || visibleCount * 2 < ids.size ? "insufficient_image" : "ok");
  const rawByCriterion = new Map(rows.map(row => [row.criterionId, row.observation]));
  const localized = singleRead ? checks.map(check => {
    const reviewArea = findReviewArea(check, rawByCriterion.get(check.id), imageCount);
    return reviewArea ? { ...check, reviewArea } : check;
  }) : checks;
  const normalized = normalizeAnnotations({ lessonId: lesson.id, analysisStatus, checks: localized }, { imageCount });
  const result = applySafetyPolicy(lesson, normalized);
  const flagged = [...new Set(result.checks.filter(check => check.status === "possible_error").map(check => check.label))];
  const basicLedSummary = singleRead ? summarizeBasicLedChecks(lesson, result.checks) : "";
  let summary = "Một số tiêu chí chưa đủ bằng chứng để kết luận từ ảnh.";
  if (strictEvidence && analysis.readTimedOut && !visibleCount) summary = singleRead
    ? "AI chưa hoàn tất phân tích trong thời gian chờ. Em vẫn có thể xem các tiêu chí cần kiểm tra."
    : "AI chưa trả đủ hai lượt đọc trong thời gian chờ. Em vẫn có thể xem các tiêu chí cần kiểm tra.";
  else if (flagged.length) summary = `Cần kiểm tra: ${flagged.join(", ")}.`;
  else if (result.verdict === "pass") summary = "Các tiêu chí quan sát được phù hợp với sơ đồ của bài.";
  else if (visibleCount === photoChecks.length && photoChecks.length < checks.length) {
    summary = "Các tiêu chí quan sát được phù hợp với sơ đồ. Cần giáo viên kiểm tra trực tiếp trước khi cấp nguồn.";
  }
  if (!flagged.length && basicLedSummary) {
    summary = basicLedSummary + (result.safety.teacherCheckRequired ? " Cần giáo viên kiểm tra trực tiếp trước khi cấp nguồn." : "");
  }
  const advice = !strictEvidence && Array.isArray(analysis.captureAdvice)
    ? analysis.captureAdvice.filter(tip => typeof tip === "string" && tip.trim()).slice(0, 5).map(tip => tip.trim().slice(0, 240))
    : [];
  return { ...result, summary, ...(strictEvidence ? { evidencePolicy: singleRead ? "single_read" : "direct_only" } : {}),
    captureAdvice: getTargetedCaptureAdvice(lesson, photoChecks, advice) };
}
