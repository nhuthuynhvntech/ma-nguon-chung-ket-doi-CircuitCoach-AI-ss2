import { getLesson } from "../../src/data/lessons.js";

export const STUDENT_GUIDE_WINDOW = 24;

function guideCriterionStatus(attempt, criterionId) {
  const label = attempt.teacherCriterionLabels?.[criterionId];
  if (["correct", "incorrect", "uncertain"].includes(label)) return { status: label, source: "teacher" };
  if (attempt.teacherVerification === "incorrect") return null;
  const match = Array.isArray(attempt.problems)
    ? attempt.problems.find(problem => (problem?.criterionId || problem?.id) === criterionId) : null;
  if (match?.status === "possible_error") return { status: "incorrect", source: "ai" };
  if (["uncertain", "not_visible"].includes(match?.status)) return { status: "uncertain", source: "ai" };
  return null;
}

export function summarizeStudentGuide(recent, selectedLesson) {
  const attempts = recent.filter(attempt => attempt && !attempt.demo && getLesson(attempt.lessonId));
  const lesson = selectedLesson || getLesson(attempts[0]?.lessonId);
  if (!lesson) return null;
  const inLesson = attempts.filter(attempt => attempt.lessonId === lesson.id);
  const [latest, ...earlier] = inLesson;
  if (!latest) return null;

  const criteria = lesson.checks.map(([id, label, category]) => ({
    id, label, category, result: guideCriterionStatus(latest, id),
  }));
  const priority = criteria.find(item => item.category === "safety" && item.result?.status === "incorrect")
    || criteria.find(item => item.result?.source === "teacher" && item.result.status === "incorrect")
    || criteria.find(item => item.category === "safety" && item.result?.status === "uncertain")
    || criteria.find(item => item.result?.status === "incorrect")
    || criteria.find(item => item.result?.status === "uncertain");
  const improved = criteria.find(({ id }) => latest.teacherCriterionLabels?.[id] === "correct"
    && earlier.find(attempt => attempt.teacherCriterionLabels?.[id])?.teacherCriterionLabels[id] === "incorrect");
  const teacherChecked = latest.teacherPhysicallyChecked === true;
  let next = { type: "review" };
  if (teacherChecked && latest.teacherSafetyCheck === "unsafe") {
    next = { type: "unsafe" };
  } else if (teacherChecked && latest.teacherSafetyCheck === "uncertain") {
    next = { type: "safety_review" };
  } else if (priority) {
    const { id, label, category, result } = priority;
    const repeated = earlier.filter(attempt => guideCriterionStatus(attempt, id)?.status === result.status).length;
    next = { type: result.status === "incorrect" ? "check" : "evidence", label, category, source: result.source, repeated };
  } else if (latest.teacherVerification === "incorrect") {
    next = { type: "ai_review" };
  } else if (!teacherChecked || latest.teacherSafetyCheck !== "safe_to_power") {
    next = { type: "teacher_review" };
  }

  return {
    lessonId: lesson.id,
    lessonTitle: lesson.title,
    attemptCount: inLesson.length,
    latestAttemptId: latest.id,
    next,
    improvedLabel: improved?.label || null,
    teacherComment: latest.teacherCommentAt && typeof latest.teacherComment === "string"
      ? latest.teacherComment.trim().slice(0, 1000) : "",
  };
}

export function studentGuideForModel(guide) {
  if (!guide) return null;
  const { lessonId, lessonTitle, attemptCount, next, improvedLabel } = guide;
  return {
    bai: lessonTitle, soLuotGanDayTrongBai: attemptCount, viecCanLam: next,
    tieuChiTienBoTheoNhanGiaoVien: improvedLabel, ketNoiChuanCuaBaiGanDay: getLesson(lessonId).expectedConnections,
  };
}
