import { CIRCUIT_LESSON_SPECS } from "../../src/data/circuit-rules.js";
import { ANNOTATION_CONFIDENCE_THRESHOLD, ANNOTATION_REGION_JSON_SCHEMA } from "./annotation-policy.js";
import { resolveArduinoUnoPin, UNO_PIN_GEOMETRY_SCHEMA } from "./arduino-pin-geometry.js";
import { CIRCUIT_VISUAL_PROOF_SCHEMA, corroborateCircuitProof, validateCircuitPhotoProof, verifiedArduinoPortSpots, verifyLedElectrodeEvidence, verifiedCircuitRegion } from "./circuit-proof.js";

export const CIRCUIT_OBSERVATION_VERSION = "circuit-observations-v17";
const circuitPhotoIndex = { anyOf: [{ type: "integer", minimum: 0, maximum: 2 }, { type: "null" }] };
const photoAssessments = ["supports", "context", "unclear", "not_visible", "conflicting"];
const ledTraceSchema = {
  anyOf: [{
    type: "object", additionalProperties: false, required: ["electrodesImageIndex", "connections"],
    properties: {
      electrodesImageIndex: { type: "integer", minimum: 0, maximum: 2 },
      connections: {
        type: "array", minItems: 1, maxItems: 2,
        items: {
          type: "object", additionalProperties: false, required: ["electrode", "imageIndex", "terminalLabel"],
          properties: {
            electrode: { type: "string", enum: ["anode", "cathode"] },
            imageIndex: { type: "integer", minimum: 0, maximum: 2 },
            terminalLabel: { type: "string" },
          },
        },
      },
    },
  }, { type: "null" }],
};
const resistorDigits = ["đen", "nâu", "đỏ", "cam", "vàng", "lục", "lam", "tím", "xám", "trắng"];
const resistorTolerances = new Map([
  ["nâu", 1], ["đỏ", 2], ["lục", 0.5], ["lam", 0.25], ["tím", 0.1], ["xám", 0.05],
  ["vàng kim", 5], ["bạc", 10],
]);
export const CIRCUIT_ANALYSIS_JSON_SCHEMA = {
  type: "object",
  additionalProperties: false,
  required: ["lessonId", "analysisStatus", "checks", "captureAdvice"],
  properties: {
    lessonId: { type: "string", enum: Object.keys(CIRCUIT_LESSON_SPECS) },
    analysisStatus: { type: "string", enum: ["ok", "insufficient_image"] },
    checks: {
      type: "array",
      minItems: 1,
      maxItems: 10,
      items: {
        type: "object",
        additionalProperties: false,
        required: ["criterionId", "observation"],
        properties: {
          criterionId: { type: "string" },
          observation: {
            type: "object",
            additionalProperties: false,
            required: ["method", "value", "imageIndex", "otherImageIndex", "region", "confidence", "detail", "photoReviews", "resistorBands", "visualProof", "reviewTarget"],
            properties: {
              method: { type: "string", enum: ["single_photo", "overlapping_views", "matching_marker", "uncertain", "not_visible"] },
              value: { anyOf: [{ type: "string" }, { type: "number" }, { type: "null" }] },
              imageIndex: circuitPhotoIndex,
              otherImageIndex: circuitPhotoIndex,
              region: ANNOTATION_REGION_JSON_SCHEMA,
              reviewTarget: { anyOf: [{ type: "object", additionalProperties: false, required: ["imageIndex", "region"],
                properties: { imageIndex: { type: "integer", minimum: 0, maximum: 2 }, region: ANNOTATION_REGION_JSON_SCHEMA.anyOf[0] },
              }, { type: "null" }] },
              confidence: { type: "number", minimum: 0, maximum: 1 },
              detail: { type: "string" },
              visualProof: CIRCUIT_VISUAL_PROOF_SCHEMA,
              resistorBands: { anyOf: [{ type: "array", minItems: 4, maxItems: 5,
                items: { type: "string", enum: [...resistorDigits, "vàng kim", "bạc"] },
              }, { type: "null" }] },
              photoReviews: {
                type: "array", minItems: 1, maxItems: 3,
                items: {
                  type: "object", additionalProperties: false, required: ["imageIndex", "assessment", "detail"],
                  properties: {
                    imageIndex: { type: "integer", minimum: 0, maximum: 2 },
                    assessment: { type: "string", enum: photoAssessments },
                    detail: { type: "string" },
                  },
                },
              },
            },
          },
        },
      },
    },
    captureAdvice: { type: "array", maxItems: 5, items: { type: "string" } },
  },
};

const circuitArduinoPins = new Set([
  ...Array.from({ length: 14 }, (_, i) => `D${i}`), ...Array.from({ length: 6 }, (_, i) => `A${i}`),
  "5V", "3.3V", "GND", "VIN", "AREF", "RESET", "IOREF", "SDA", "SCL",
]);

const circuitObservationWords = {
  visibility: { visible: "thấy được các bộ phận cần quan sát" },
  presence: { present: "có linh kiện", missing: "thiếu linh kiện trên đoạn mạch nhìn rõ" },
  series: { series: "mắc nối tiếp", bypassed: "có dây nối vòng qua linh kiện", missing: "thiếu linh kiện trên đường nối" },
  led_polarity: { anode_to_feed: "anode về phía cấp điện và cathode về đường hồi", cathode_to_feed: "cathode về phía cấp điện và anode về đường hồi" },
  battery_polarity: { positive_to_resistor: "cực dương nối về phía điện trở", negative_to_resistor: "cực âm nối về phía điện trở" },
  short: { separate: "các đường nguồn quan sát được tách nhau", bridged: "có đoạn nối trực tiếp giữa hai đường nguồn" },
  probe: { two_wires_in_port: "hai dây đầu dò nối vào cổng hai chân", open_or_wrong_port: "đầu dò thiếu dây hoặc cắm sai cổng" },
  continuity: { closed_visible: "nhìn thấy đường mạch khép kín khi bật", open_visible: "nhìn thấy chỗ đứt trên đường mạch khi bật" },
};

function describeCircuitValue(rule, value) {
  if (rule.type === "pin") {
    if (value === "open") return "chân ở đầu linh kiện đang bỏ trống";
    if (value === "digital_output") return "dây lấy tín hiệu ở ngõ số DO của module";
    return `chân ${value} trên Arduino`;
  }
  if (rule.type === "resistance") return value === "missing" ? "thiếu điện trở trên đoạn mạch nhìn rõ" : `${value} Ω`;
  if (rule.type === "voltage") return `nhãn nguồn ${value} V`;
  return circuitObservationWords[rule.type][value];
}

function expectedCircuitValue(rule) {
  return rule.type === "resistance" ? `${rule.min}–${rule.max} Ω` : describeCircuitValue(rule, rule.expected);
}

function decodeResistorBands(bands) {
  if (!Array.isArray(bands) || (bands.length !== 4 && bands.length !== 5)) return null;
  const digits = bands.slice(0, -2).map(color => resistorDigits.indexOf(color));
  const multiplierColor = bands.at(-2);
  const exponent = resistorDigits.indexOf(multiplierColor);
  const tolerance = resistorTolerances.get(bands.at(-1));
  if (digits[0] <= 0 || digits.includes(-1) || tolerance === undefined
    || (exponent < 0 && multiplierColor !== "vàng kim" && multiplierColor !== "bạc")) return null;
  const significant = Number(digits.join(""));
  const ohms = exponent >= 0 ? significant * 10 ** exponent : significant / (multiplierColor === "vàng kim" ? 10 : 100);
  return { ohms, tolerance };
}

export function circuitRuleInstructions(lessonId, checkId) {
  const rule = CIRCUIT_LESSON_SPECS[lessonId].rules[checkId];
  let values;
  if (rule.type === "pin") {
    values = "Tên chân Arduino như D8, D10, A0, GND hoặc 5V. Dùng open khi thấy rõ chân ở đầu linh kiện đang bỏ trống.";
    if (rule.wrongSource) values += " Dùng digital_output nếu thấy dây tín hiệu thực tế lấy từ chân DO của module.";
  } else if (rule.type === "resistance") {
    values = "Dùng resistorBands nếu đọc rõ đủ vạch màu của điện trở này. Nếu có chữ in trị số, ghi số Ω vào value. Dùng missing nếu nhìn rõ toàn bộ đoạn nối và thấy đoạn nối trực tiếp thiếu điện trở.";
  } else if (rule.type === "voltage") {
    values = "Số vôn ghi trên nguồn thực tế đang nối hoặc nhãn chân đang cấp nguồn. Số này là nhãn, không phải điện áp đo thực tế. Không suy từ tên bo hoặc từ sơ đồ.";
  } else if (rule.type === "short") {
    values = "Ghi bridged khi thấy cầu nối trực tiếp giữa hai đường nguồn. Trường hợp khác ghi uncertain để kiểm tra mạch thật.";
  } else {
    values = Object.entries(circuitObservationWords[rule.type]).map(([key, title]) => `${key} = ${title}`).join(" | ");
    if (rule.type === "continuity") values += ". Công tắc tắt hoặc trạng thái bị che thì chưa xác định. Ảnh chỉ dùng để lần đường dây.";
  }
  return `${rule.target}. Giá trị quan sát hợp lệ: ${values}`;
}

function validCircuitValue(rule, value) {
  if (rule.type === "pin") return circuitArduinoPins.has(value) || value === "open" || value === (rule.wrongSource || "open");
  if (rule.type === "resistance") return value === "missing" || (Number.isFinite(value) && value > 0);
  if (rule.type === "voltage") return Number.isFinite(value) && value > 0;
  return Object.hasOwn(circuitObservationWords[rule.type], value);
}

function circuitObservedCorrectly(rule, value) {
  if (rule.type === "resistance") return typeof value === "number" && value >= rule.min && value <= rule.max;
  return value === rule.expected;
}

function readPhotoReviews(raw, imageCount) {
  if (!Array.isArray(raw)) return [];
  const reviews = new Map();
  for (const row of raw) {
    const index = row?.imageIndex;
    if (!Number.isInteger(index) || index < 0 || index >= imageCount || reviews.has(index)
      || !photoAssessments.includes(row.assessment) || typeof row.detail !== "string" || !row.detail.trim()) return [];
    reviews.set(index, { imageIndex: index, assessment: row.assessment, detail: row.detail.trim().slice(0, 200) });
  }
  return [...reviews.values()].sort((a, b) => a.imageIndex - b.imageIndex);
}

function validCircuitEvidence(observation, value, rule, imageCount) {
  if (!observation || !validCircuitValue(rule, value) || !Number.isFinite(observation.confidence)
      || observation.confidence < ANNOTATION_CONFIDENCE_THRESHOLD || observation.confidence > 1
      || typeof observation.detail !== "string" || !observation.detail.trim()) return false;
  const isPhotoIndex = index => Number.isInteger(index) && index >= 0 && index < imageCount;
  if (!isPhotoIndex(observation.imageIndex)) return false;
  if (observation.method === "single_photo") return observation.otherImageIndex === null;
  return (observation.method === "overlapping_views" || observation.method === "matching_marker")
    && observation.confidence >= 0.8 && isPhotoIndex(observation.otherImageIndex)
    && observation.otherImageIndex !== observation.imageIndex;
}

function scoreCircuitObservation(criterion, rule, observation, imageCount) {
  const check = { ...criterion, criterionId: criterion.id };
  const expected = expectedCircuitValue(rule);
  const photoReviews = readPhotoReviews(observation?.photoReviews, imageCount);
  if (photoReviews.length) check.photoReviews = photoReviews;
  const complete = photoReviews.length === imageCount;
  const conflicting = photoReviews.some(photo => photo.assessment === "conflicting");
  const supporting = photoReviews.filter(photo => photo.assessment === "supports").map(photo => photo.imageIndex);
  const photosAgree = complete && supporting.includes(observation?.imageIndex)
    && (observation.otherImageIndex === null || supporting.includes(observation.otherImageIndex));
  const legacySingle = imageCount === 1 && observation?.photoReviews === undefined;
  const hasBands = rule.type === "resistance" && observation?.resistorBands != null;
  const bandReading = hasBands ? decodeResistorBands(observation.resistorBands) : null;
  const value = hasBands ? bandReading?.ohms : observation?.value;
  const contradictoryBands = hasBands && observation.value === "missing";
  if (conflicting || contradictoryBands || !(photosAgree || legacySingle) || !validCircuitEvidence(observation, value, rule, imageCount)) {
    const notVisible = !hasBands && observation?.method === "not_visible" && observation.value === null
      && (legacySingle || (complete && photoReviews.every(photo => photo.assessment === "not_visible")));
    const evidence = conflicting ? "Các góc chụp cho thấy chi tiết mâu thuẫn. Cần đối chiếu lại trước khi kết luận."
      : imageCount > 1 && !complete ? "Chưa có nhận xét đầy đủ cho tất cả góc chụp ở tiêu chí này."
        : notVisible ? `Ảnh chưa cho thấy ${rule.target.toLowerCase()}.`
          : `Ảnh chưa đủ căn cứ để kiểm tra ${rule.target.toLowerCase()}.`;
    return {
      ...check, status: notVisible ? "not_visible" : "uncertain", certainty: "low", confidence: 0,
      imageIndex: null, region: null,
      evidence,
      ruleEvidence: { type: rule.type, expected, observed: null },
    };
  }
  const { method, imageIndex, otherImageIndex, confidence, region } = observation;
  const observed = describeCircuitValue(rule, value);
  const detail = observation.detail.trim().slice(0, 280);
  const supportingViews = supporting.filter(index => index !== imageIndex);
  const photo = supportingViews.length
    ? `Ảnh ${imageIndex + 1} đối chiếu với ${supportingViews.map(index => `ảnh ${index + 1}`).join(" và ")}`
    : `Ảnh ${imageIndex + 1}`;
  const photoNote = imageCount > 1 && supporting.length === 1
    ? ` Chỉ 1 trong ${imageCount} góc chụp có đủ bằng chứng cho chi tiết này.`
    : "";
  const jointDetail = otherImageIndex !== null ? ` ${detail}` : "";
  const bandDetail = bandReading
    ? ` Mã màu ${observation.resistorBands.join("–")} có dung sai ±${bandReading.tolerance}%.`
    : "";
  return {
    ...check, status: circuitObservedCorrectly(rule, value) ? "correct" : "possible_error",
    certainty: confidence >= 0.9 ? "high" : "medium", confidence, imageIndex, region,
    evidence: `${photo} cho thấy ${observed}.${bandDetail}${jointDetail} Tiêu chí ${criterion.label.toLowerCase()} yêu cầu ${expected}.${photoNote}`,
    ruleEvidence: { type: rule.type, expected, observed: value, method, imageIndex, otherImageIndex, detail,
      ...(bandReading ? { resistorBands: observation.resistorBands, tolerance: bandReading.tolerance } : {}),
    },
  };
}

const circuitRecheckMessages = {
  conflicting: "Hai lượt đối chiếu hoặc các góc ảnh cho thấy bằng chứng mâu thuẫn. Chưa thể kết luận hoặc khoanh vùng chính xác ở tiêu chí này.",
  unconfirmed: "Lượt đọc lại chưa xác minh được chi tiết mà AI từng nhận diện sai ở tiêu chí này.",
  pin_unlocated: "Chưa xác định được lỗ cắm theo các mốc trên hàng chân Arduino Uno. Cần nhìn rõ điểm đầu dây đi vào và các lỗ kế bên.",
  pin_mark_conflict: "Lỗ cắm AI xác định nằm ngoài vùng giáo viên đã khoanh trên ảnh này. Cần đối chiếu lại trước khi kết luận.",
  insufficient_proof: "Hai lượt đọc chưa xác nhận được cùng chi tiết cần thiết trên ảnh. Tiêu chí này cần kiểm tra thêm.",
  missing_photo_proof: "Chưa thấy đủ chi tiết bắt buộc trên ảnh để kết luận tiêu chí này.",
  missing_pin_path: "Chưa có bằng chứng nối được chân linh kiện với đúng lỗ cắm và nhãn đã đọc.",
  missing_resistor_proof: "Chưa đối chiếu được vạch màu hoặc trị số ghi trên thân với điện trở nằm trên nhánh đang kiểm tra.",
  missing_led_path: "Chưa lần được hai bản cực LED qua các chân tới nhánh cấp và nhánh hồi.",
  unconfirmed_led_reversal: "Chưa đủ bằng chứng từ hai chân LED đến các điểm cắm để kết luận mắc ngược.",
  pin_label_conflict: "Nhãn chân đọc được chưa khớp với vị trí đầu dây trên hàng lỗ cắm. Cần xem lại đầu dây và nhãn cạnh lỗ đó.",
};

export function requiresArduinoPinGeometry(lesson, criterionId) {
  return lesson.board === "Arduino Uno" && CIRCUIT_LESSON_SPECS[lesson.id].rules[criterionId]?.type === "pin";
}

export function requiresLedTrace(lesson, criterionId) {
  return CIRCUIT_LESSON_SPECS[lesson.id]?.rules[criterionId]?.type === "led_polarity";
}

export function buildCircuitFocusSchema(lesson, criterionIds) {
  const properties = CIRCUIT_ANALYSIS_JSON_SCHEMA.properties;
  const items = properties.checks.items;
  const observation = items.properties.observation;
  const added = {
    ...(criterionIds.some(id => requiresArduinoPinGeometry(lesson, id)) ? { pinGeometry: UNO_PIN_GEOMETRY_SCHEMA } : {}),
    ...(criterionIds.some(id => requiresLedTrace(lesson, id)) ? { ledTrace: ledTraceSchema } : {}),
  };
  const focusObservation = {
    ...observation, required: [...observation.required, ...Object.keys(added)],
    properties: { ...observation.properties, ...added },
  };
  return {
    ...CIRCUIT_ANALYSIS_JSON_SCHEMA,
    properties: {
      ...properties,
      lessonId: { type: "string", enum: [lesson.id] },
      checks: {
        ...properties.checks, minItems: criterionIds.length, maxItems: criterionIds.length,
        items: { ...items, properties: { criterionId: { type: "string", enum: criterionIds }, observation: focusObservation } },
      },
    },
  };
}

export function circuitAnalysisTimedOut(lesson) {
  return {
    lessonId: lesson.id, analysisStatus: "insufficient_image", readTimedOut: true,
    checks: lesson.checkList.map(criterion => ({ criterionId: criterion.id })),
    captureAdvice: [],
  };
}

function resolveObservedArduinoPin(observation) {
  return observation?.confidence >= 0.85 && observation.value !== "digital_output" && observation.value !== "open"
    ? resolveArduinoUnoPin(observation.pinGeometry) : null;
}

function withArduinoPinLayout(observation, layout) {
  return {
    ...observation, value: layout.pin, region: layout.region,
    detail: "Đầu dây được lần tới lỗ cắm đã xác định theo dãy chân.",
    photoReviews: observation.photoReviews.map(photo => photo.imageIndex === observation.imageIndex && photo.assessment === "supports"
      ? { ...photo, detail: `Vị trí đầu dây khớp lỗ ${layout.pin} khi đối chiếu các mốc trên hàng chân.` } : photo),
  };
}

function ledCircuitEndpoints(lesson) {
  return lesson.id === "led"
    ? [CIRCUIT_LESSON_SPECS.led.rules.power_connection.expected, CIRCUIT_LESSON_SPECS.led.rules.ground_connection.expected]
    : ["+", "-"];
}

function readLedTrace(lesson, observation, imageCount) {
  const trace = observation?.ledTrace;
  const validIndex = index => Number.isInteger(index) && index >= 0 && index < imageCount;
  if (!validIndex(trace?.electrodesImageIndex) || !Array.isArray(trace?.connections)
    || trace.connections.length < 1 || trace.connections.length > 2
    || !Number.isFinite(observation.confidence) || observation.confidence < ANNOTATION_CONFIDENCE_THRESHOLD || observation.confidence > 1) return null;
  if (Array.isArray(observation.photoReviews) && observation.photoReviews.some(photo =>
    validIndex(photo?.imageIndex) && photo.assessment === "conflicting")) return { conflict: true };
  const [feed, back] = ledCircuitEndpoints(lesson);
  const branchEndpoints = lesson.id === "battery-led-switch" ? { RESISTOR: "anode", SWITCH: "cathode" } : {};
  const connections = [];
  const directions = new Set();
  for (const link of trace.connections) {
    if (!["anode", "cathode"].includes(link?.electrode) || !validIndex(link.imageIndex)
      || typeof link.terminalLabel !== "string") return null;
    const label = link.terminalLabel.trim().toUpperCase().replace(/[−–]/g, "-");
    const terminal = /^~?\d{1,2}$/.test(label) ? `D${label.replace("~", "")}` : label;
    const expected = terminal === feed ? "anode" : terminal === back ? "cathode"
      : Object.hasOwn(branchEndpoints, terminal) ? branchEndpoints[terminal] : null;
    if (!expected) return null;
    directions.add(link.electrode === expected ? "anode_to_feed" : "cathode_to_feed");
    if (!connections.some(item => item.electrode === link.electrode && item.terminalLabel === terminal)) {
      connections.push({ electrode: link.electrode, imageIndex: link.imageIndex, terminalLabel: terminal });
    }
  }
  if (directions.size !== 1) return { conflict: true };
  const reachesSource = connections.some(link => link.terminalLabel === feed || link.terminalLabel === back);
  if (!reachesSource && new Set(connections.map(link => link.electrode)).size < 2) return null;
  return { electrodesImageIndex: trace.electrodesImageIndex, connections, value: [...directions][0] };
}

function scoreLedTrace(criterion, rule, observation, trace, imageCount) {
  const reviews = readPhotoReviews(observation.photoReviews, imageCount);
  const terminalNames = { RESISTOR: "điện trở", SWITCH: "công tắc", "+": "cực dương của pin", "-": "cực âm của pin" };
  const explanations = [`Ảnh ${trace.electrodesImageIndex + 1} cho thấy hai bản cực LED.`,
    ...trace.connections.map(({ electrode, imageIndex, terminalLabel }) =>
      `Ảnh ${imageIndex + 1} cho thấy chân ${electrode} nối về ${terminalNames[terminalLabel] || terminalLabel}.`)];
  const evidenceViews = new Set([trace.electrodesImageIndex, ...trace.connections.map(link => link.imageIndex)]);
  const photoReviews = Array.from({ length: imageCount }, (_, imageIndex) => {
    if (evidenceViews.has(imageIndex)) {
      return { imageIndex, assessment: "supports", detail: explanations.filter(text => text.startsWith(`Ảnh ${imageIndex + 1} `)).join(" ") };
    }
    return { imageIndex, assessment: reviews.find(photo => photo.imageIndex === imageIndex)?.assessment === "not_visible" ? "not_visible" : "context",
      detail: "Góc này bổ sung bối cảnh cho mạch." };
  });
  return {
    ...criterion, criterionId: criterion.id, status: "correct",
    confidence: observation.confidence, certainty: observation.confidence >= 0.9 ? "high" : "medium",
    imageIndex: trace.electrodesImageIndex, region: null, photoReviews,
    evidence: explanations.join(" "),
    ruleEvidence: { type: rule.type, expected: expectedCircuitValue(rule), observed: trace.value, ledTrace: trace },
  };
}

export function validateSingleCircuitRead(lesson, observations, imageCount, markedViews = []) {
  const rules = CIRCUIT_LESSON_SPECS[lesson.id].rules;
  const criteria = new Map(lesson.checkList.map(check => [check.id, check]));
  const markedRegions = new Map(markedViews.map(mark => [`${mark.imageIndex}:${mark.criterionId}`, mark.region]));
  const polarity = observations.find(row => row.criterionId === "led_orientation")?.observation;
  const basicLedTrace = lesson.id === "led" ? readLedTrace(lesson, polarity, imageCount) : null;
  const ledLinks = basicLedTrace?.value === "anode_to_feed" ? basicLedTrace.connections : [];
  return observations.map(row => {
    const id = row.criterionId;
    const rule = rules[id];
    const observation = row.observation;
    const trace = rule.type === "led_polarity" ? readLedTrace(lesson, observation, imageCount) : null;
    if (trace?.conflict) return markCircuitRecheckUncertain(row, "conflicting");
    if (trace && trace.value === rule.expected) return { criterionId: id, observation, verifiedLedTrace: trace };
    const check = scoreCircuitObservation(criteria.get(id), rule, observation, imageCount);
    const value = check.ruleEvidence.observed;
    if (trace?.value && value === rule.expected && trace.value !== value) {
      return markCircuitRecheckUncertain(row, "unconfirmed_led_reversal");
    }
    const ledElectrodeView = rule.type === "led_polarity" && check.photoReviews?.length === imageCount
      ? verifyLedElectrodeEvidence(observation, check.photoReviews) : undefined;
    if (value === null) {
      if (ledElectrodeView !== undefined) return { criterionId: id, observation, ledElectrodeView, recheckOutcome: "missing_led_path" };
      return { criterionId: id, observation };
    }
    let layout;
    if (requiresArduinoPinGeometry(lesson, id) && circuitArduinoPins.has(value)) {
      layout = resolveObservedArduinoPin(observation);
      if (!layout) return markCircuitRecheckUncertain({ criterionId: id, observation }, "pin_unlocated");
      if (layout.pin !== value) return markCircuitRecheckUncertain({ criterionId: id, observation }, "pin_label_conflict");
      const mark = markedRegions.get(`${observation.imageIndex}:${id}`);
      const { x, y } = observation.pinGeometry.contact;
      const margin = 2.5;
      if (mark && (x < mark.x - margin || x > mark.x + mark.width + margin
        || y < mark.y - margin || y > mark.y + mark.height + margin)) {
        return markCircuitRecheckUncertain({ criterionId: id, observation }, "pin_mark_conflict");
      }
    }
    const ledWarningEndpoints = rule.type === "led_polarity" && check.status === "possible_error" ? ledCircuitEndpoints(lesson) : null;
    const proof = validateCircuitPhotoProof(rule, check, observation, layout ? observation.pinGeometry.contact : null, ledWarningEndpoints);
    if (!proof) {
      const uncertain = markCircuitRecheckUncertain({ criterionId: id, observation },
        ledWarningEndpoints ? "unconfirmed_led_reversal"
          : rule.type === "pin" ? "missing_pin_path" : rule.type === "resistance" ? "missing_resistor_proof" : "missing_photo_proof");
      if (layout) {
        const portSpots = verifiedArduinoPortSpots(observation, check, observation.pinGeometry.contact);
        if (portSpots.length) {
          uncertain.verifiedPort = layout.pin;
          const electrode = { power_connection: "anode", ground_connection: "cathode" }[id];
          const ledLink = ledLinks.find(link => link.electrode === electrode
            && link.terminalLabel === layout.pin && link.imageIndex === observation.imageIndex);
          if (ledLink) {
            const verified = withArduinoPinLayout({
              ...observation, confidence: Math.min(observation.confidence, polarity.confidence),
            }, layout);
            return { criterionId: id, observation: verified, verifiedProof: portSpots,
              pinLayoutAnchors: layout.anchors, verifiedLedLink: ledLink };
          }
        }
      }
      if (ledElectrodeView !== undefined) {
        uncertain.ledElectrodeView = ledElectrodeView;
        uncertain.recheckOutcome = ledWarningEndpoints ? "unconfirmed_led_reversal" : "missing_led_path";
      }
      return uncertain;
    }
    const verified = layout ? withArduinoPinLayout(observation, layout) : {
      ...observation, region: verifiedCircuitRegion(observation.region, observation.imageIndex, proof),
    };
    return { criterionId: id, observation: verified, verifiedProof: proof, ...(layout ? { pinLayoutAnchors: layout.anchors } : {}) };
  });
}

export function reconcileCircuitRecheck(lesson, primary, reviewed, criterionIds, imageCount, markedViews = [], { strictEvidence = false } = {}) {
  if (!criterionIds.length || !Array.isArray(primary?.checks) || primary.lessonId !== lesson.id) {
    return { analysis: primary, completedIds: [], pinLayoutChecks: 0 };
  }
  const requested = new Set(criterionIds);
  const criteria = new Map(lesson.checkList.map(criterion => [criterion.id, criterion]));
  const rules = CIRCUIT_LESSON_SPECS[lesson.id].rules;
  const observations = new Map();
  if (reviewed?.lessonId === lesson.id && Array.isArray(reviewed.checks)) {
    for (const row of reviewed.checks) {
      if (!requested.has(row?.criterionId)) continue;
      observations.set(row.criterionId, observations.has(row.criterionId) ? null : row.observation);
    }
  }
  const completed = new Set();
  const mappedPins = new Set();
  const markedRegions = new Map(markedViews.map(mark => [`${mark.imageIndex}:${mark.criterionId}`, mark.region]));
  const checks = primary.checks.map(row => {
    const id = row?.criterionId;
    if (!requested.has(id) || !criteria.has(id)) return row;
    const criterion = criteria.get(id);
    const rule = rules[id];
    const verifyPin = requiresArduinoPinGeometry(lesson, id);
    const first = scoreCircuitObservation(criterion, rule, row.observation, imageCount);
    const retry = observations.get(id);
    if (!retry || readPhotoReviews(retry.photoReviews, imageCount).length !== imageCount) {
      return first.ruleEvidence.observed !== null
        ? markCircuitRecheckUncertain(row, verifyPin ? "pin_unlocated" : "unconfirmed") : row;
    }
    completed.add(id);
    const pinLayout = verifyPin ? resolveObservedArduinoPin(retry) : null;
    const verifiedObservation = pinLayout ? withArduinoPinLayout(retry, pinLayout) : retry;
    const second = scoreCircuitObservation(criterion, rule, verifiedObservation, imageCount);
    const firstValue = first.ruleEvidence.observed;
    const secondValue = second.ruleEvidence.observed;
    const photoConflict = first.photoReviews?.some(photo => photo.assessment === "conflicting")
      || second.photoReviews?.some(photo => photo.assessment === "conflicting");
    if (photoConflict) return markCircuitRecheckUncertain(row, "conflicting");
    if (pinLayout && secondValue !== null) {
      const firstLayout = strictEvidence && firstValue !== null ? resolveObservedArduinoPin(row.observation) : null;
      if (firstLayout && firstLayout.pin !== pinLayout.pin) return markCircuitRecheckUncertain(row, "conflicting");
      const firstWithLayout = firstLayout
        ? { ...first, ruleEvidence: { ...first.ruleEvidence, observed: firstLayout.pin },
          status: circuitObservedCorrectly(rule, firstLayout.pin) ? "correct" : "possible_error" }
        : first;
      const markedRegion = markedRegions.get(`${second.imageIndex}:${id}`);
      if (markedRegion) {
        const { x, y } = retry.pinGeometry.contact;
        const margin = 2.5;
        if (x < markedRegion.x - margin || x > markedRegion.x + markedRegion.width + margin
          || y < markedRegion.y - margin || y > markedRegion.y + markedRegion.height + margin) {
          return markCircuitRecheckUncertain(row, "pin_mark_conflict");
        }
      }
      const proof = strictEvidence ? corroborateCircuitProof(rule, firstWithLayout, row.observation, second, verifiedObservation, {
        firstContact: firstLayout ? row.observation.pinGeometry.contact : undefined,
        secondContact: retry.pinGeometry.contact,
      }) : null;
      if (strictEvidence && !proof) return markCircuitRecheckUncertain(row, "insufficient_proof");
      mappedPins.add(id);
      return {
        ...row, observation: verifiedObservation, pinLayoutAnchors: pinLayout.anchors, pinCropRead: retry.pinCropRead === true,
        ...(proof ? { verifiedProof: proof } : {}),
      };
    }
    if (firstValue !== null && secondValue !== null && firstValue !== secondValue) {
      return markCircuitRecheckUncertain(row, "conflicting");
    }
    if (verifyPin && (circuitArduinoPins.has(firstValue) || circuitArduinoPins.has(secondValue) || retry.pinGeometry)) {
      return markCircuitRecheckUncertain(row, "pin_unlocated");
    }
    if (firstValue === null && secondValue === null) return row;
    if (strictEvidence) {
      const proof = firstValue !== null && firstValue === secondValue
        ? corroborateCircuitProof(rule, first, row.observation, second, retry) : null;
      if (!proof) return markCircuitRecheckUncertain(row, "insufficient_proof");
      return { ...row, verifiedProof: proof, observation: { ...retry, region: verifiedCircuitRegion(retry.region, retry.imageIndex, proof) } };
    }
    if (secondValue === null || (firstValue === null && second.confidence < 0.85)) {
      return markCircuitRecheckUncertain(row, "unconfirmed");
    }
    return { ...row, observation: retry };
  });
  return { analysis: { ...primary, checks }, completedIds: [...completed], pinLayoutChecks: mappedPins.size };
}

function markCircuitRecheckUncertain(row, recheckOutcome) {
  return {
    ...row, recheckOutcome,
    observation: {
      ...row.observation,
      method: "uncertain", value: null, imageIndex: null, otherImageIndex: null, confidence: 0, region: null, resistorBands: null,
    },
  };
}

function strictPhotoReviews(photoReviews, proof, singleRead) {
  if (!photoReviews) return undefined;
  const views = new Set(proof?.map(spot => spot.imageIndex));
  const descriptions = {
    supports: singleRead ? "Góc này có chi tiết dùng làm bằng chứng." : "Hai lượt đọc cùng xác nhận tiêu chí dựa trên các chi tiết quan sát được.",
    context: "Ảnh giúp định hướng đường nối hoặc bố cục.",
    unclear: "Chưa xác nhận được chi tiết thiết yếu từ góc ảnh này.",
    not_visible: "Góc ảnh này chưa cho thấy chi tiết cần kiểm tra.",
    conflicting: "Chi tiết của góc ảnh này cần đối chiếu lại.",
  };
  return photoReviews.map(photo => {
    const assessment = views.has(photo.imageIndex) ? "supports" : photo.assessment === "supports" ? "unclear" : photo.assessment;
    return { imageIndex: photo.imageIndex, assessment, detail: descriptions[assessment] };
  });
}

export function scoreCircuitObservations(lesson, observations, imageCount, { strictEvidence = false, singleRead = false } = {}) {
  const rules = CIRCUIT_LESSON_SPECS[lesson.id].rules;
  const criteria = new Map(lesson.checkList.map(check => [check.id, check]));
  const seen = new Map();
  for (const row of observations) {
    seen.set(row.criterionId, seen.has(row.criterionId) ? null : row.observation);
  }
  const checks = observations.map(row => {
    const id = row.criterionId;
    const rule = rules[id];
    const proof = row.verifiedProof;
    const raw = seen.get(id);
    if (singleRead && row.verifiedLedTrace && raw) {
      return scoreLedTrace(criteria.get(id), rule, raw, row.verifiedLedTrace, imageCount);
    }
    const observation = strictEvidence && proof ? {
      ...raw, detail: singleRead ? "Đã xác minh bằng chứng trên ảnh." : "Hai lượt đọc cùng chỉ ra chi tiết trên ảnh.",
      ...(singleRead ? { photoReviews: strictPhotoReviews(raw.photoReviews, proof, true) } : {}),
    } : raw;
    let check = scoreCircuitObservation(criteria.get(id), rule, observation, imageCount);
    if (strictEvidence) {
      check = { ...check, photoReviews: strictPhotoReviews(check.photoReviews, proof, singleRead) };
      if (check.ruleEvidence.observed !== null && !proof) {
        check = {
          ...check, status: "uncertain", certainty: "low", confidence: 0, imageIndex: null, region: null,
          evidence: circuitRecheckMessages.insufficient_proof,
          ruleEvidence: { type: rule.type, expected: check.ruleEvidence.expected, observed: null },
        };
      } else if (check.ruleEvidence.observed !== null) {
        check.ruleEvidence.visualProof = proof.map(({ part, imageIndex, region, text }) => ({
          part, imageIndex, region,
          ...(singleRead && rule.type === "led_polarity" && typeof text === "string"
            && ["feed_terminal", "return_terminal", "feed_anchor", "return_anchor"].includes(part) ? { text: text.trim() } : {}),
        }));
      }
    }
    if (check.status === "uncertain" && Object.hasOwn(circuitRecheckMessages, row.recheckOutcome)) {
      if (singleRead && Number.isInteger(row.ledElectrodeView)) {
        const note = row.recheckOutcome === "unconfirmed_led_reversal" ? circuitRecheckMessages.unconfirmed_led_reversal
          : "Chưa xác minh được từng chân nối về nhánh nào.";
        return {
          ...check, evidence: `Ảnh ${row.ledElectrodeView + 1} cho thấy cathode dạng chén và anode nhỏ. ${note}`,
          ruleEvidence: { ...check.ruleEvidence, electrodesImageIndex: row.ledElectrodeView },
          photoReviews: check.photoReviews?.map(photo => photo.imageIndex === row.ledElectrodeView
            ? { ...photo, assessment: "context", detail: "Ảnh này cho thấy rõ hai bản cực của LED." } : photo),
        };
      }
      if (singleRead && row.verifiedPort) {
        return { ...check, evidence: `Đã xác minh vị trí lỗ ${row.verifiedPort}. Chưa lần đủ đường nối từ linh kiện tới lỗ này.`,
          ruleEvidence: { ...check.ruleEvidence, verifiedPort: row.verifiedPort } };
      }
      return { ...check, evidence: circuitRecheckMessages[row.recheckOutcome] };
    }
    if (check.ruleEvidence.observed !== null && row.pinLayoutAnchors) {
      const cropNote = row.pinCropRead ? " Vị trí được xác minh lại trên ảnh cắt cận." : "";
      const link = row.verifiedLedLink;
      const linkNote = link ? ` Ảnh ${link.imageIndex + 1} cho thấy đường nối từ ${link.electrode} tới đúng lỗ ${link.terminalLabel} đã xác minh.` : "";
      return {
        ...check,
        evidence: `${check.evidence} Lỗ cắm được đối chiếu theo các mốc ${row.pinLayoutAnchors.join(", ")} trên hàng chân Arduino Uno.${cropNote}${linkNote}`,
        ruleEvidence: { ...check.ruleEvidence, pinLayout: { anchors: row.pinLayoutAnchors, ...(row.pinCropRead ? { closeup: true } : {}) },
          ...(link ? { ledConnection: link } : {}) },
      };
    }
    return check;
  });
  return checks.map(check => {
    const required = rules[check.id].requires;
    if (!required || check.status !== "correct") return check;
    const dependency = checks.find(item => item.id === required);
    if (dependency?.status === "correct") return check;
    if (dependency?.status === "possible_error") {
      if (strictEvidence) {
        return { ...check, status: "uncertain", certainty: "low", confidence: 0, imageIndex: null, region: null,
          evidence: "Chưa thể đánh giá mức nguồn khi điện trở đi kèm cần kiểm tra.",
          ruleEvidence: { type: rules[check.id].type, expected: check.ruleEvidence.expected, observed: null, requiredCriterion: required } };
      }
      return { ...check, status: "possible_error", certainty: dependency.certainty, confidence: dependency.confidence,
        imageIndex: dependency.imageIndex, region: dependency.region,
        evidence: `${check.evidence} Cần kiểm tra điện trở đi kèm. ${dependency.evidence}`,
        ruleEvidence: { ...check.ruleEvidence, requiredCriterion: required } };
    }
    return { ...check, status: "uncertain", certainty: "low", confidence: 0, imageIndex: null, region: null,
      evidence: `${check.evidence} Cần nhìn rõ trị số điện trở để đánh giá cả tiêu chí này.`,
      ruleEvidence: strictEvidence
        ? { type: rules[check.id].type, expected: check.ruleEvidence.expected, observed: null, requiredCriterion: required }
        : { ...check.ruleEvidence, requiredCriterion: required } };
  });
}
