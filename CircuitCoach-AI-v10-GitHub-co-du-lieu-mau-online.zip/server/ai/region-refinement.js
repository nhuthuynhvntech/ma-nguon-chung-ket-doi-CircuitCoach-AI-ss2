import regionJpegCodec from "jpeg-js";
import { ANNOTATION_REGION_JSON_SCHEMA, isValidRegion } from "./annotation-policy.js";
import { REGION_REVIEW_INSTRUCTIONS } from "./region-review-prompt.js";

export const REGION_REVIEW_SCHEMA = {
  type: "object",
  additionalProperties: false,
  required: ["checks"],
  properties: {
    checks: {
      type: "array",
      maxItems: 8,
      items: {
        type: "object",
        additionalProperties: false,
        required: ["criterionId", "status", "confidence", "region"],
        properties: {
          criterionId: { type: "string" },
          status: { type: "string", enum: ["localized", "not_visible"] },
          confidence: { type: "number", minimum: 0, maximum: 1 },
          region: ANNOTATION_REGION_JSON_SCHEMA,
        },
      },
    },
  },
};

export async function buildRegionReviewRequest(model, crops, photoToDataUrl) {
  const groups = await Promise.all(crops.map(async (crop, index) => [
    { type: "input_text", text: `ẢNH CẮT ${index + 1}\n${crop.checks.map(check =>
      `- ${check.id} (${check.label}): ${check.evidence}`).join("\n")}` },
    { type: "input_image", image_url: await photoToDataUrl(crop.photo), detail: "high" },
  ]));
  return {
    model,
    instructions: REGION_REVIEW_INSTRUCTIONS,
    input: [{ role: "user", content: groups.flat() }],
    text: { format: { type: "json_schema", name: "circuit_region_review", strict: true, schema: REGION_REVIEW_SCHEMA } },
  };
}

export function getRegionReviewTimeout(started) {
  return Math.max(0, Math.min(22_000, 65_000 - (Date.now() - started)));
}

function regionCropBounds(region, imageWidth, imageHeight) {
  const cropWidth = Math.max(25, 1.7 * region.width);
  const cropHeight = Math.max(25, 1.7 * region.height);
  const centerX = region.x + region.width / 2;
  const centerY = region.y + region.height / 2;
  const left = Math.floor(imageWidth * Math.max(0, centerX - cropWidth / 2) / 100);
  const top = Math.floor(imageHeight * Math.max(0, centerY - cropHeight / 2) / 100);
  const right = Math.ceil(imageWidth * Math.min(100, centerX + cropWidth / 2) / 100);
  const bottom = Math.ceil(imageHeight * Math.min(100, centerY + cropHeight / 2) / 100);
  return { left, top, width: right - left, height: bottom - top, imageWidth, imageHeight };
}

function encodeRegionCrop(image, bounds, quality = 87) {
  const { left, top, width, height } = bounds;
  const data = new Uint8Array(width * height * 4);
  for (let row = 0; row < height; row += 1) {
    const start = ((top + row) * image.width + left) * 4;
    data.set(image.data.subarray(start, start + width * 4), row * width * 4);
  }
  const jpeg = regionJpegCodec.encode({ width, height, data }, quality);
  return new Blob([jpeg.data], { type: "image/jpeg" });
}

async function readRegionJpeg(photo) {
  try {
    const bytes = new Uint8Array(await photo.arrayBuffer());
    return regionJpegCodec.decode(bytes, { useTArray: true, maxResolutionInMP: 8, maxMemoryUsageInMB: 64 });
  } catch {
    return null;
  }
}

export async function cropMarkedReference(photo, region) {
  if (photo.type !== "image/jpeg" || !isValidRegion(region)) return null;
  const decoded = await readRegionJpeg(photo);
  if (!decoded) return null;
  return encodeRegionCrop(decoded, regionCropBounds(region, decoded.width, decoded.height));
}

function ledDetailWindow(image) {
  const shortEdge = Math.min(image.width, image.height);
  if (shortEdge < 640) return null;
  const step = Math.max(1, Math.round(shortEdge / 120));
  const width = Math.floor(image.width / step);
  const height = Math.floor(image.height / step);
  const light = new Float32Array(width * height);
  const neutral = new Uint8Array(light.length);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const offset = ((y * step + (step >> 1)) * image.width + x * step + (step >> 1)) * 4;
      const red = image.data[offset];
      const green = image.data[offset + 1];
      const blue = image.data[offset + 2];
      const index = y * width + x;
      light[index] = 0.2126 * red + 0.7152 * green + 0.0722 * blue;
      neutral[index] = Number(light[index] >= 106 && Math.max(red, green, blue) - Math.min(red, green, blue) <= 42);
    }
  }
  const edge = new Float32Array(light.length);
  const horizontal = new Float32Array(light.length);
  const vertical = new Float32Array(light.length);
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const i = y * width + x;
      if (!neutral[i]) continue;
      const dx = Math.abs(light[i + 1] - light[i - 1]);
      const dy = Math.abs(light[i + width] - light[i - width]);
      if (dx + dy < 12) continue;
      horizontal[i] = Math.min(dx, 45);
      vertical[i] = Math.min(dy, 45);
      edge[i] = Math.min(dx + dy, 45);
    }
  }
  const side = Math.round(Math.min(width, height) / 4);
  const stride = Math.max(1, Math.floor(side / 5));
  const area = side * side;
  let best = null;
  // Prefer detail with edges in both directions on a neutral background.
  // This proposes a crop. It does not identify a component or decide how the circuit is wired.
  for (let y = 0; y < height - side + stride; y += stride) {
    for (let x = 0; x < width - side + stride; x += stride) {
      const left = Math.min(x, width - side);
      const top = Math.min(y, height - side);
      let coverage = 0;
      let detail = 0;
      let totalX = 0;
      let totalY = 0;
      for (let dy = 0; dy < side; dy++) {
        for (let dx = 0; dx < side; dx++) {
          const i = (top + dy) * width + left + dx;
          coverage += neutral[i];
          totalX += horizontal[i];
          totalY += vertical[i];
          const distance = Math.hypot(dx / side - 0.5, dy / side - 0.5);
          detail += edge[i] * (1 - distance);
        }
      }
      if (coverage / area < 0.67 || detail / area < 1.1) continue;
      const balance = Math.sqrt(Math.min(totalX, totalY) / Math.max(totalX, totalY));
      const score = detail / area * balance * (coverage / area) ** 3;
      if (!best || score > best.score) best = { left, top, score };
    }
  }
  if (!best) return null;
  const margin = Math.ceil(side * 0.15);
  const cropWidth = Math.min(image.width, (side + 2 * margin) * step);
  const cropHeight = Math.min(image.height, (side + 2 * margin) * step);
  return {
    left: Math.max(0, Math.min((best.left - margin) * step, image.width - cropWidth)),
    top: Math.max(0, Math.min((best.top - margin) * step, image.height - cropHeight)),
    width: cropWidth, height: cropHeight, imageWidth: image.width, imageHeight: image.height, score: best.score,
  };
}

export async function cropLedPhotoDetails(images) {
  const candidates = [];
  for (const [imageIndex, photo] of images.entries()) {
    if (photo.type !== "image/jpeg") continue;
    const image = await readRegionJpeg(photo);
    const bounds = image && ledDetailWindow(image);
    if (!bounds) continue;
    candidates.push({ imageIndex, bounds, photo: encodeRegionCrop(image, bounds, 92) });
  }
  return candidates.sort((a, b) => b.bounds.score - a.bounds.score).slice(0, 2)
    .sort((a, b) => a.imageIndex - b.imageIndex);
}

function projectRegionToOriginal(region, crop) {
  const x = (100 * crop.left + region.x * crop.width) / crop.imageWidth;
  const y = (100 * crop.top + region.y * crop.height) / crop.imageHeight;
  return {
    x,
    y,
    width: Math.min(100 - x, region.width * crop.width / crop.imageWidth),
    height: Math.min(100 - y, region.height * crop.height / crop.imageHeight),
  };
}

function getRegionCropGroups(checks, images) {
  const groups = new Map();
  const prioritized = [...checks].sort((a, b) => Number(b.id === "no_short_circuit") - Number(a.id === "no_short_circuit"));
  for (const check of prioritized) {
    const image = images[check.imageIndex];
    if (check.status !== "possible_error" || check.ruleEvidence?.pinLayout || check.ruleEvidence?.visualProof
      || !isValidRegion(check.region) || image?.type !== "image/jpeg") continue;
    const { x, y, width, height } = check.region;
    const key = [check.imageIndex, x, y, width, height].join(":");
    if (!groups.has(key)) {
      if (groups.size >= 3) continue;
      groups.set(key, { imageIndex: check.imageIndex, region: check.region, checks: [] });
    }
    groups.get(key).checks.push(check);
  }
  return [...groups.values()];
}

async function prepareRegionCrops(checks, images) {
  const groups = getRegionCropGroups(checks, images);
  const crops = [];
  for (const index of new Set(groups.map(group => group.imageIndex))) {
    const decoded = await readRegionJpeg(images[index]);
    if (!decoded) continue;
    for (const group of groups.filter(item => item.imageIndex === index)) {
      const bounds = regionCropBounds(group.region, decoded.width, decoded.height);
      const photo = encodeRegionCrop(decoded, bounds);
      crops.push({ photo, bounds, checks: group.checks });
    }
  }
  return crops;
}

function applyRegionReview(analysis, crops, raw) {
  if (!Array.isArray(raw?.checks)) return analysis;
  const cropById = new Map(crops.flatMap(crop => crop.checks.map(check => [check.id, crop.bounds])));
  const latest = new Map();
  const duplicateIds = new Set();
  for (const review of raw.checks) {
    const id = review?.criterionId;
    if (!cropById.has(id)) continue;
    if (latest.has(id)) duplicateIds.add(id);
    latest.set(id, review);
  }
  const metrics = { reviewed: 0, refined: 0, photoOnly: 0 };
  const checks = analysis.checks.map(check => {
    const review = latest.get(check.id);
    if (!review || duplicateIds.has(check.id) || !Number.isFinite(review.confidence)
      || review.confidence < 0.75 || review.confidence > 1) return check;
    const original = check.region;
    if (review.status === "not_visible" && review.region === null) {
      metrics.reviewed += 1;
      metrics.photoOnly += 1;
      return { ...check, region: null, regionRefinement: { outcome: "photo_only", original } };
    }
    if (review.status !== "localized" || !isValidRegion(review.region)) return check;
    metrics.reviewed += 1;
    const refined = projectRegionToOriginal(review.region, cropById.get(check.id));
    if (!isValidRegion(refined) || refined.width * refined.height >= original.width * original.height) return check;
    metrics.refined += 1;
    return { ...check, region: refined, regionRefinement: { outcome: "refined", original } };
  });
  return { ...analysis, checks, regionRefinement: metrics };
}

export async function refineCircuitRegions(analysis, images, { started, reviewCrops }) {
  if (getRegionReviewTimeout(started) < 4_000) return analysis;
  try {
    const crops = await prepareRegionCrops(analysis.checks, images);
    const timeout = getRegionReviewTimeout(started);
    if (!crops.length || timeout < 4_000) return analysis;
    const review = await reviewCrops(crops, AbortSignal.timeout(timeout));
    return applyRegionReview(analysis, crops, review);
  } catch {
    // The first pass remains usable if the optional review times out or fails.
    return analysis;
  }
}
