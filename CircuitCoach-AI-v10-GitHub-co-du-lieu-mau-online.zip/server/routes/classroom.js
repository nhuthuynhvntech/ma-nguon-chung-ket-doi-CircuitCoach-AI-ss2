import { Router } from "express";
import multer from "multer";
import rateLimit from "express-rate-limit";
import { createHmac, timingSafeEqual } from "node:crypto";
import { loadClassroomStore, persistAttemptImages, persistAttempts } from "../storage/classroom-store.js";
import { getLesson } from "../../src/data/lessons.js";
import { parseTeacherAiError } from "../../src/data/ai-error-reasons.js";

export const classroomRouter = Router();
const store = loadClassroomStore();
const attempts = store.attempts;
const attemptImages = store.images;
const CLASS_CODE = /^[A-Z0-9]{4,12}$/;
const TEACHER_VERIFICATIONS = new Set(["correct", "incorrect", "uncertain"]);
const ADMIN_COOKIE = "circuitcoach_admin";
const staffLoginLimiter = rateLimit({ windowMs: 15 * 60_000, limit: 12, standardHeaders: true, legacyHeaders: false, message: { error: "Quá nhiều lần đăng nhập. Hãy thử lại sau 15 phút." } });
const upload = multer({ storage: multer.memoryStorage(), limits: { files: 3, fileSize: 3_000_000 }, fileFilter: (_request, file, callback) => callback(null, ["image/jpeg", "image/png", "image/webp"].includes(file.mimetype)) });

function normalize(value) {
  return String(value || "").trim().toUpperCase();
}

function teacherPasswordConfigured() {
  return typeof process.env.TEACHER_USERNAME === "string" && process.env.TEACHER_USERNAME.length > 0
    && typeof process.env.TEACHER_PASSWORD === "string" && process.env.TEACHER_PASSWORD.length >= 6;
}

function teacherPasswordMatches(request) {
  if (!teacherPasswordConfigured()) return false;
  const suppliedUsername = Buffer.from(String(request.get("x-teacher-username") || ""));
  const expectedUsername = Buffer.from(process.env.TEACHER_USERNAME);
  const supplied = Buffer.from(String(request.get("x-teacher-password") || ""));
  const expected = Buffer.from(process.env.TEACHER_PASSWORD);
  const usernameMatches = suppliedUsername.length === expectedUsername.length && timingSafeEqual(suppliedUsername, expectedUsername);
  const passwordMatches = supplied.length === expected.length && timingSafeEqual(supplied, expected);
  return usernameMatches && passwordMatches;
}

function requireTeacher(request, response) {
  if (!teacherPasswordConfigured()) {
    response.status(503).json({ error: "Tài khoản giáo viên chưa được cấu hình." });
    return false;
  }
  if (!teacherPasswordMatches(request)) {
    response.status(401).json({ error: "Tên đăng nhập hoặc mật khẩu giáo viên không đúng." });
    return false;
  }
  return true;
}

function adminConfigured() {
  return Boolean(process.env.ADMIN_USERNAME)
    && typeof process.env.ADMIN_PASSWORD === "string" && process.env.ADMIN_PASSWORD.length >= 10
    && typeof process.env.ADMIN_SESSION_SECRET === "string" && process.env.ADMIN_SESSION_SECRET.length >= 32;
}

function adminCredentialsMatch(username, password) {
  if (!adminConfigured()) return false;
  const suppliedUsername = Buffer.from(String(username || ""));
  const expectedUsername = Buffer.from(process.env.ADMIN_USERNAME);
  const suppliedPassword = Buffer.from(String(password || ""));
  const expectedPassword = Buffer.from(process.env.ADMIN_PASSWORD);
  const usernameMatches = suppliedUsername.length === expectedUsername.length && timingSafeEqual(suppliedUsername, expectedUsername);
  const passwordMatches = suppliedPassword.length === expectedPassword.length && timingSafeEqual(suppliedPassword, expectedPassword);
  return usernameMatches && passwordMatches;
}

function cookieValue(request, name) {
  const prefix = `${name}=`;
  return String(request.get("cookie") || "").split(";").map((part) => part.trim()).find((part) => part.startsWith(prefix))?.slice(prefix.length) || "";
}

function createAdminSessionToken() {
  const payload = Buffer.from(JSON.stringify({ sub: process.env.ADMIN_USERNAME, exp: Math.floor(Date.now() / 1000) + 30 * 60 })).toString("base64url");
  const signature = createHmac("sha256", process.env.ADMIN_SESSION_SECRET).update(payload).digest("base64url");
  return `${payload}.${signature}`;
}

function adminSessionValid(request) {
  if (!adminConfigured()) return false;
  const [payload, signature] = cookieValue(request, ADMIN_COOKIE).split(".");
  if (!payload || !signature) return false;
  const expected = Buffer.from(createHmac("sha256", process.env.ADMIN_SESSION_SECRET).update(payload).digest("base64url"));
  const actual = Buffer.from(signature);
  if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) return false;
  try {
    const session = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
    return session.sub === process.env.ADMIN_USERNAME && Number(session.exp) > Math.floor(Date.now() / 1000);
  } catch { return false; }
}

function requireAdmin(request, response) {
  if (!adminConfigured()) {
    response.status(503).json({ error: "Tài khoản quản trị chưa được cấu hình đầy đủ." });
    return false;
  }
  if (!adminSessionValid(request)) {
    response.status(401).json({ error: "Phiên quản trị đã hết hạn. Hãy đăng nhập lại." });
    return false;
  }
  return true;
}

function buildAdminSummary(allAttempts) {
  const attempts = [...allAttempts].sort((a, b) => new Date(b.time) - new Date(a.time));
  const classes = new Map();
  const groups = new Set();
  for (const attempt of attempts) {
    const classCode = normalize(attempt.classCode);
    if (!classCode) continue;
    groups.add(`${classCode}:${attempt.studentId}`);
    const current = classes.get(classCode) || { classCode, attemptCount: 0, groupIds: new Set(), latestActivity: null };
    current.attemptCount += 1;
    current.groupIds.add(String(attempt.studentId || attempt.studentName || ""));
    if (!current.latestActivity || new Date(attempt.time) > new Date(current.latestActivity)) current.latestActivity = attempt.time;
    classes.set(classCode, current);
  }
  return {
    stats: {
      classCount: classes.size,
      groupCount: groups.size,
      attemptCount: attempts.length,
      teacherConfirmedCorrect: attempts.filter((item) => item.teacherVerification === "correct").length,
      teacherConfirmedIncorrect: attempts.filter((item) => item.teacherVerification === "incorrect").length,
      awaitingTeacher: attempts.filter((item) => !item.teacherVerification).length,
    },
    classes: [...classes.values()].map(({ groupIds, ...item }) => ({ ...item, groupCount: groupIds.size }))
      .sort((a, b) => (b.latestActivity || "").localeCompare(a.latestActivity || "")),
    attempts: attempts.slice(0, 1000),
    truncated: attempts.length > 1000,
  };
}

classroomRouter.post("/admin-login", staffLoginLimiter, (request, response) => {
  if (!adminConfigured()) return response.status(503).json({ error: "Tài khoản quản trị chưa được cấu hình đầy đủ." });
  if (!adminCredentialsMatch(request.body?.username, request.body?.password)) {
    return response.status(401).json({ error: "Tên đăng nhập hoặc mật khẩu quản trị không đúng." });
  }
  const token = createAdminSessionToken();
  const secure = request.secure || process.env.NODE_ENV === "production" ? "; Secure" : "";
  response.setHeader("Set-Cookie", `${ADMIN_COOKIE}=${token}; HttpOnly; Path=/; SameSite=Strict; Max-Age=1800${secure}`);
  return response.json({ authenticated: true, role: "admin", expiresIn: 1800 });
});

classroomRouter.post("/admin-logout", (_request, response) => {
  response.setHeader("Set-Cookie", `${ADMIN_COOKIE}=; HttpOnly; Path=/; SameSite=Strict; Max-Age=0${process.env.NODE_ENV === "production" ? "; Secure" : ""}`);
  return response.json({ authenticated: false });
});

classroomRouter.get("/admin/summary", (request, response) => {
  if (!requireAdmin(request, response)) return;
  return response.json(buildAdminSummary(attempts.values()));
});

classroomRouter.post("/teacher-login", (request, response) => {
  if (!requireTeacher(request, response)) return;
  response.json({ authenticated: true });
});

classroomRouter.get("/attempts", (request, response) => {
  if (!requireTeacher(request, response)) return;
  const classCode = normalize(request.query.classCode);
  if (!CLASS_CODE.test(classCode)) return response.status(400).json({ error: "Mã lớp không hợp lệ." });
  return response.json({ attempts: [...attempts.values()].filter((item) => item.classCode === classCode).sort((a, b) => new Date(b.time) - new Date(a.time)) });
});

classroomRouter.post("/attempts", (request, response) => {
  const input = request.body;
  const classCode = normalize(input?.classCode);
  if (!CLASS_CODE.test(classCode) || typeof input?.id !== "string" || typeof input?.studentId !== "string" || typeof input?.studentName !== "string" || !Array.isArray(input?.problems)) {
    return response.status(400).json({ error: "Dữ liệu nhóm không hợp lệ." });
  }
  const attempt = {
    ...input,
    classCode,
    verification: null,
    teacherStatus: null,
    teacherComment: "",
    teacherCommentAt: null,
    teacherVerification: null,
    teacherVerificationNote: "",
    teacherAiError: null,
    teacherVerifiedBy: null,
    teacherVerifiedAt: null,
    teacherSafetyCheck: null,
    teacherSafetyNote: "",
    teacherSafetyCheckedBy: null,
    teacherSafetyCheckedAt: null,
    teacherPhysicallyChecked: false,
    teacherCriterionLabels: {},
    teacherImageQuality: null,
    teacherLabelsBy: null,
    teacherLabelsAt: null,
    imageCount: 0,
  };
  attempts.set(attempt.id, attempt);
  persistAttempts(attempts);
  return response.status(201).json({ synced: true, id: attempt.id });
});

classroomRouter.post("/attempts/:id/verify", (request, response) => {
  if (!requireTeacher(request, response)) return;
  const current = attempts.get(request.params.id);
  const classCode = normalize(request.body?.classCode);
  if (!current || current.classCode !== classCode) return response.status(404).json({ error: "Không tìm thấy kết quả." });
  const hasAiLabel = Object.hasOwn(request.body || {}, "teacherVerification");
  const hasAiError = Object.hasOwn(request.body || {}, "teacherAiError");
  const hasSafetyCheck = Object.hasOwn(request.body || {}, "teacherSafetyCheck");
  const hasLabels = Object.hasOwn(request.body || {}, "teacherCriterionLabels") || Object.hasOwn(request.body || {}, "teacherImageQuality");
  const teacherVerification = request.body?.teacherVerification;
  if (!hasAiLabel && !hasSafetyCheck && !hasLabels) {
    return response.status(400).json({ error: "Cần gửi nhãn AI hoặc xác nhận an toàn mạch thật." });
  }
  if (hasAiLabel && !TEACHER_VERIFICATIONS.has(teacherVerification)) {
    return response.status(400).json({ error: "Xác nhận của giáo viên không hợp lệ." });
  }
  let teacherAiError;
  if (hasAiError) {
    if (teacherVerification !== "incorrect") return response.status(400).json({ error: "Chỉ lưu nguyên nhân khi đánh dấu AI sai." });
    try { teacherAiError = parseTeacherAiError(request.body.teacherAiError, getLesson(current.lessonId)); }
    catch (error) { return response.status(400).json({ error: error.message }); }
  }
  if (hasSafetyCheck) {
    const status = request.body.teacherSafetyCheck;
    if (!["not_checked", "safe_to_power", "unsafe", "uncertain"].includes(status)) {
      return response.status(400).json({ error: "Trạng thái kiểm tra an toàn không hợp lệ." });
    }
    const physicallyChecked = status !== "not_checked" && request.body.teacherPhysicalCheck === true;
    if (status !== "not_checked" && !physicallyChecked) {
      return response.status(400).json({ error: "Giáo viên cần xác nhận đã kiểm tra trực tiếp mạch thật." });
    }
    current.teacherSafetyCheck = status;
    current.teacherSafetyNote = String(request.body.teacherSafetyNote || "").trim().slice(0, 500);
    current.teacherSafetyCheckedBy = physicallyChecked ? process.env.TEACHER_USERNAME : null;
    current.teacherSafetyCheckedAt = physicallyChecked ? new Date().toISOString() : null;
    current.teacherPhysicallyChecked = physicallyChecked;
  }
  if (hasAiLabel) {
    if (hasAiError) current.teacherAiError = teacherAiError;
    else if (teacherVerification !== "incorrect") current.teacherAiError = null;
    current.teacherVerification = teacherVerification;
    current.teacherVerificationNote = String(request.body?.teacherVerificationNote || "").trim().slice(0, 500);
    current.teacherVerifiedBy = process.env.TEACHER_USERNAME;
    current.teacherVerifiedAt = new Date().toISOString();
    current.teacherStatus = teacherVerification === "correct" ? "approved" : null;
  }
  if (hasLabels) {
    const labels = request.body.teacherCriterionLabels;
    const quality = request.body.teacherImageQuality;
    const validIds = new Set(current.problems.map((problem) => problem.id || problem.criterionId));
    if (!labels || typeof labels !== "object" || Array.isArray(labels) || Object.keys(labels).length > 30 || !["clear", "blurred", "occluded", "unassessable", null].includes(quality) || Object.entries(labels).some(([id, value]) => !validIds.has(id) || !["correct", "incorrect", "uncertain"].includes(value))) {
      return response.status(400).json({ error: "Nhãn tiêu chí hoặc chất lượng ảnh không hợp lệ." });
    }
    current.teacherCriterionLabels = Object.fromEntries(Object.entries(labels));
    current.teacherImageQuality = quality;
    current.teacherLabelsBy = process.env.TEACHER_USERNAME;
    current.teacherLabelsAt = new Date().toISOString();
  }
  attempts.set(current.id, current);
  persistAttempts(attempts);
  return response.json({ synced: true, attempt: current });
});

classroomRouter.get("/references", (request, response) => {
  const classCode = normalize(request.query.classCode);
  if (!CLASS_CODE.test(classCode)) return response.status(400).json({ error: "Mã lớp không hợp lệ." });
  const lessonId = String(request.query.lessonId || "").trim();
  const references = [...attempts.values()]
    .filter((attempt) => attempt.classCode === classCode && attempt.verdict === "pass" && attempt.teacherVerification === "correct" && attempt.teacherSafetyCheck === "safe_to_power" && attempt.teacherPhysicallyChecked === true && Number(attempt.imageCount) > 0 && (!lessonId || attempt.lessonId === lessonId))
    .sort((a, b) => new Date(b.teacherVerifiedAt || b.time) - new Date(a.teacherVerifiedAt || a.time))
    .map((attempt) => ({
      id: attempt.id,
      attemptId: attempt.id,
      lessonId: attempt.lessonId,
      title: "Mạch đúng đã được giáo viên xác nhận",
      imageCount: Math.min(3, Number(attempt.imageCount) || 0),
      approvedBy: attempt.teacherVerifiedBy || process.env.TEACHER_USERNAME || "Giáo viên",
      approvedAt: attempt.teacherVerifiedAt || null,
      note: attempt.teacherVerificationNote || "",
    }));
  return response.json({ references });
});

classroomRouter.get("/attempts/:id", (request, response) => {
  const current = attempts.get(request.params.id);
  const classCode = normalize(request.query.classCode);
  if (!current || current.classCode !== classCode) return response.status(404).json({ error: "Không tìm thấy kết quả." });
  return response.json({ attempt: current });
});

classroomRouter.post("/attempts/:id/images", upload.array("images", 3), (request, response) => {
  const current = attempts.get(request.params.id);
  const classCode = normalize(request.body?.classCode);
  if (!current || current.classCode !== classCode) return response.status(404).json({ error: "Không tìm thấy kết quả." });
  if (!request.files?.length) return response.status(400).json({ error: "Chưa có ảnh để tải lên." });
  attemptImages.set(current.id, request.files.map((file) => ({ buffer: file.buffer, type: file.mimetype })));
  current.imageCount = request.files.length;
  attempts.set(current.id, current);
  persistAttemptImages(current.id, attemptImages.get(current.id));
  persistAttempts(attempts);
  return response.json({ synced: true, imageCount: current.imageCount });
});

classroomRouter.get("/attempts/:id/images/:index", (request, response) => {
  const current = attempts.get(request.params.id);
  const classCode = normalize(request.query.classCode);
  const image = attemptImages.get(request.params.id)?.[Number(request.params.index)];
  if (!current || current.classCode !== classCode || !image) return response.status(404).json({ error: "Không tìm thấy ảnh." });
  response.set({ "content-type": image.type, "cache-control": "private, no-store", "x-content-type-options": "nosniff" });
  return response.send(image.buffer);
});

classroomRouter.patch("/attempts/:id", (request, response) => {
  const current = attempts.get(request.params.id);
  const classCode = normalize(request.body?.classCode);
  if (!current || current.classCode !== classCode) return response.status(404).json({ error: "Không tìm thấy kết quả." });
  if (("teacherStatus" in request.body || "teacherComment" in request.body) && !requireTeacher(request, response)) return;
  if ("verification" in request.body) current.verification = request.body.verification;
  if ("teacherStatus" in request.body) current.teacherStatus = request.body.teacherStatus;
  if ("teacherComment" in request.body) current.teacherComment = String(request.body.teacherComment || "").trim().slice(0, 1000);
  if ("teacherComment" in request.body) current.teacherCommentAt = new Date().toISOString();
  attempts.set(current.id, current);
  persistAttempts(attempts);
  return response.json({ synced: true, attempt: current });
});
