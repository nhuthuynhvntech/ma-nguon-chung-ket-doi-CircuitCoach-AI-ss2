import { Router } from "express";
import { prepareGuideChat } from "../ai/guide-chat.js";
import { createGuideChatReply } from "../ai/openai.js";

export const guideChatRouter = Router();

guideChatRouter.post("/", async (request, response) => {
  try {
    response.json(await createGuideChatReply(prepareGuideChat(request.body)));
  } catch (error) {
    response.status(error.status || 502).json({ error: {
      code: error.code || "GUIDE_CHAT_FAILED",
      message: error.status === 400 ? error.message : "Trợ lý đang bận. Em có thể dùng các câu hỏi nhanh.",
    } });
  }
});
