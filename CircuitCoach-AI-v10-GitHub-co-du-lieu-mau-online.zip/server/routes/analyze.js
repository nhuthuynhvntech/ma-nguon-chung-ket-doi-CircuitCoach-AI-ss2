import { Router } from "express";
import { getLesson } from "../lessons/index.js";
import { analyzeCircuit } from "../ai/openai.js";
import { applySafetyPolicy } from "../ai/safety-policy.js";
import { normalizeAnnotations } from "../ai/annotation-policy.js";
import { finalizeCircuitAnalysis } from "../ai/finalize-analysis.js";
import { uploadImages } from "../middleware/upload-validator.js";

export const analyzeRouter = Router();

function demoAnalysis(lesson, imageCount) {
  const demoStates = {
    led: { resistor_present: "possible_error", power_connection: "uncertain" },
    hcsr04: { trig_connection: "possible_error", echo_connection: "uncertain" },
    servo: { signal_connection: "possible_error", power_voltage: "uncertain" },
    "battery-led-switch": { switch_in_series: "possible_error", battery_polarity: "uncertain" },
    "soil-moisture": { probe_connection: "possible_error", moisture_signal_connection: "uncertain" },
  };
  const states = demoStates[lesson.id];
  return applySafetyPolicy(lesson, normalizeAnnotations({
    analysisStatus: "ok",
    lessonId: lesson.id,
    summary: "Bản mô phỏng đã kiểm tra riêng từng tiêu chí để minh họa giao diện và luồng học tập.",
    checks: lesson.checkList.map((check) => {
      const status = states[check.id] || "correct";
      return ({
      id: check.id,
      criterionId: check.id,
      label: check.label,
      status,
      certainty: status === "correct" ? "high" : status === "possible_error" ? "medium" : "low",
      confidence: status === "correct" ? 0.94 : status === "possible_error" ? 0.86 : 0.42,
      imageIndex: null,
      region: null,
      evidence: status === "correct"
        ? `Trong dữ liệu mô phỏng, ${check.label.toLowerCase()} phù hợp với mạch chuẩn.`
        : status === "possible_error"
          ? `Dữ liệu mô phỏng cho thấy ${check.label.toLowerCase()} cần được học sinh kiểm tra lại.`
          : `Chưa nhìn rõ ${check.label.toLowerCase()}; hãy chụp cận cảnh bộ phận này và không để dây bị che.`,
      reviewTopic: check.reviewTopic,
    })}),
    captureAdvice: lesson.id === "battery-led-switch"
      ? ["Chụp từ trên xuống để nhìn rõ toàn bộ vòng mạch.", "Chụp cận cảnh cực pin và các chân công tắc."]
      : ["Chụp từ trên xuống để nhìn rõ đường dây.", "Chụp thêm cận cảnh nhãn chân Arduino."],
    demo: true,
  }, { imageCount }));
}

analyzeRouter.post("/", uploadImages.fields([
  { name: "images", maxCount: 3 },
  { name: "referenceImages", maxCount: 3 },
]), async (request, response, next) => {
  try {
    const lesson = getLesson(request.body.lessonId);
    if (!lesson) {
      response.status(400).json({ error: { code: "INVALID_LESSON", message: "Bài học không hợp lệ." } });
      return;
    }
    const studentImages = request.files?.images || [];
    const referenceImages = request.files?.referenceImages || [];
    if (!studentImages.length) {
      response.status(400).json({ error: { code: "NO_IMAGES", message: "Hãy thêm ít nhất một ảnh mạch." } });
      return;
    }
    const wantsDemo = request.body.demo === "true";
    if (wantsDemo) {
      response.json(demoAnalysis(lesson, studentImages.length));
      return;
    }
    if (!process.env.OPENAI_API_KEY) {
      response.status(503).json({ error: { code: "OPENAI_NOT_CONFIGURED", message: "OpenAI API chưa được cấu hình. Bạn có thể bật Chế độ demo để thử luồng sản phẩm." } });
      return;
    }
    const analyzed = await analyzeCircuit({ lesson, files: studentImages, referenceFiles: referenceImages });
    const result = finalizeCircuitAnalysis(lesson, analyzed, studentImages.length, { singleRead: true });
    response.json({ ...result, demo: false });
  } catch (error) {
    next(error);
  }
});
