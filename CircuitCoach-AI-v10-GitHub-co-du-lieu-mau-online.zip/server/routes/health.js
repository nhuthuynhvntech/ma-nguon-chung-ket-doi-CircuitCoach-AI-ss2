import { Router } from "express";

export const healthRouter = Router();

healthRouter.get("/", (_request, response) => {
  response.json({
    status: "ok",
    openaiConfigured: Boolean(process.env.OPENAI_API_KEY),
    demoMode: process.env.DEMO_MODE === "true",
    analyzeModel: process.env.OPENAI_ANALYZE_MODEL || "gpt-5.6-terra",
    tutorModel: process.env.OPENAI_TUTOR_MODEL || "gpt-5.6-luna",
  });
});
