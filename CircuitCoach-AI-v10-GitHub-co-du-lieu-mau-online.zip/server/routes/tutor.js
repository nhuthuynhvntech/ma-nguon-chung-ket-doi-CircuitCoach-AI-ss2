import { Router } from "express";
import { tutorRequestSchema } from "../ai/schemas.js";
import { createTutorHint } from "../ai/openai.js";
import { getLesson } from "../lessons/index.js";
import { knowledgeBase } from "../../src/data/knowledge-base.js";
import { getLocalHint } from "../../src/data/local-hints.js";

export const tutorRouter = Router();

tutorRouter.post("/", async (request, response, next) => {
  try {
    const payload = tutorRequestSchema.parse(request.body);
    const lesson = getLesson(payload.lessonId);
    const check = lesson?.checkList.find((item) => item.id === payload.problem.id);
    if (!lesson || !check) {
      response.status(400).json({ error: { code: "INVALID_PROBLEM", message: "Vấn đề không thuộc bài học đã chọn." } });
      return;
    }
    const knowledge = knowledgeBase[payload.problem.id];
    if (!knowledge) {
      response.status(400).json({ error: { code: "KNOWLEDGE_NOT_FOUND", message: "Chưa có kho kiến thức cho vấn đề này." } });
      return;
    }
    if (request.query.demo === "true") {
      response.json({ ...getLocalHint(payload.problem, payload.studentContext.hintLevel), demo: true });
      return;
    }
    const result = await createTutorHint({ ...payload, lesson, knowledge });
    response.json({ ...result, source: "openai", demo: false });
  } catch (error) {
    next(error);
  }
});
