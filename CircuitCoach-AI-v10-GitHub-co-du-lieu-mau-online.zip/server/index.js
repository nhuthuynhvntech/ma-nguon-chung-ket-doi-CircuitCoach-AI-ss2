import "dotenv/config";
import express from "express";
import rateLimit from "express-rate-limit";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { analyzeRouter } from "./routes/analyze.js";
import { tutorRouter } from "./routes/tutor.js";
import { guideChatRouter } from "./routes/guide-chat.js";
import { healthRouter } from "./routes/health.js";
import { classroomRouter } from "./routes/classroom.js";
import { errorHandler, notFoundHandler } from "./middleware/error-handler.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const rootDirectory = path.resolve(__dirname, "..");

export function createApp() {
  const app = express();
  app.disable("x-powered-by");
  app.use(express.json({ limit: "256kb" }));
  const aiLimitOptions = {
    windowMs: 60_000,
    limit: 12,
    standardHeaders: "draft-8",
    legacyHeaders: false,
    message: { error: { code: "RATE_LIMITED", message: "Bạn thao tác hơi nhanh. Hãy chờ một phút rồi thử lại." } },
  };
  const aiLimiter = rateLimit(aiLimitOptions);
  app.use("/api/health", healthRouter);
  app.use("/api/classroom", classroomRouter);
  app.use("/api/analyze", aiLimiter, analyzeRouter);
  app.use("/api/tutor", aiLimiter, tutorRouter);
  app.use("/api/guide-chat", rateLimit(aiLimitOptions), guideChatRouter);
  app.use(express.static(path.join(rootDirectory, "dist")));
  app.get("/{*path}", (request, response, next) => {
    if (request.path.startsWith("/api/")) {
      next();
      return;
    }
    response.sendFile(path.join(rootDirectory, "dist", "index.html"), (error) => error && next(error));
  });
  app.use(notFoundHandler);
  app.use(errorHandler);
  return app;
}

const app = createApp();
const port = Number(process.env.PORT || 3001);

if (process.env.NODE_ENV !== "test") {
  app.listen(port, () => {
    console.log(`CircuitCoach AI đang chạy tại http://localhost:${port}`);
  });
}
