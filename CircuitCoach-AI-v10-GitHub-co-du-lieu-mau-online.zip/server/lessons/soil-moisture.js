import { CIRCUIT_LESSON_SPECS } from "../../src/data/circuit-rules.js";

export default {
  id: "soil-moisture",
  title: "Cảm biến độ ẩm đất",
  board: "Arduino Uno",
  expectedConnections: CIRCUIT_LESSON_SPECS["soil-moisture"].connections,
  checkList: [
    { id: "moisture_sensor_visibility", label: "Nhìn thấy cảm biến", reviewTopic: "Chụp ảnh mạch", category: "standard" },
    { id: "probe_connection", label: "Đầu dò nối vào module", reviewTopic: "Đầu dò độ ẩm", category: "standard" },
    { id: "moisture_vcc_connection", label: "Kết nối VCC", reviewTopic: "Nguồn điện – VCC – GND", category: "safety", safetyKind: "power_polarity" },
    { id: "moisture_gnd_connection", label: "Kết nối GND", reviewTopic: "Nguồn điện – VCC – GND", category: "safety", safetyKind: "power_ground" },
    { id: "power_voltage", label: "Mức nguồn phù hợp", reviewTopic: "Điện áp nguồn an toàn", category: "safety", safetyKind: "voltage" },
    { id: "no_short_circuit", label: "Không có dấu hiệu chập mạch", reviewTopic: "An toàn chống chập mạch", category: "safety", safetyKind: "short_circuit" },
    { id: "moisture_signal_connection", label: "Kết nối tín hiệu A0", reviewTopic: "Tín hiệu Analog A0", category: "standard" },
  ],
};
