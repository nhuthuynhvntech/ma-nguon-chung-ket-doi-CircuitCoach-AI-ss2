import { CIRCUIT_LESSON_SPECS } from "../../src/data/circuit-rules.js";

export default {
  id: "servo",
  title: "Servo Motor",
  board: "Arduino Uno",
  expectedConnections: CIRCUIT_LESSON_SPECS.servo.connections,
  checkList: [
    { id: "servo_visibility", label: "Nhìn thấy servo", reviewTopic: "Chụp ảnh mạch", category: "standard" },
    { id: "power_connection", label: "Kết nối nguồn", reviewTopic: "Nguồn điện – VCC – GND", category: "safety", safetyKind: "power_polarity" },
    { id: "ground_connection", label: "Kết nối GND", reviewTopic: "Nguồn điện – VCC – GND", category: "safety", safetyKind: "power_ground" },
    { id: "power_voltage", label: "Mức nguồn phù hợp", reviewTopic: "Nguồn ổn định cho Servo", category: "safety", safetyKind: "voltage" },
    { id: "no_short_circuit", label: "Không có dấu hiệu chập mạch", reviewTopic: "An toàn chống chập mạch", category: "safety", safetyKind: "short_circuit" },
    { id: "signal_connection", label: "Kết nối Signal", reviewTopic: "Tín hiệu điều khiển Servo", category: "standard" },
  ],
};
