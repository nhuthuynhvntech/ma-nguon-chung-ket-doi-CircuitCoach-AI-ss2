import led from "./led.js";
import hcsr04 from "./hcsr04.js";
import servo from "./servo.js";
import batteryLedSwitch from "./battery-led-switch.js";
import soilMoisture from "./soil-moisture.js";

const catalog = { led, hcsr04, servo, "battery-led-switch": batteryLedSwitch, "soil-moisture": soilMoisture };

export function getLesson(id) {
  return catalog[id] || null;
}

export function listLessons() {
  return Object.values(catalog);
}
