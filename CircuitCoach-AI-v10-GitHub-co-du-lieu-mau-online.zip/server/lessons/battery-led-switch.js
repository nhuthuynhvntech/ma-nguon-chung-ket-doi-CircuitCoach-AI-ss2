import { CIRCUIT_LESSON_SPECS } from "../../src/data/circuit-rules.js";

export default {
  id: "battery-led-switch",
  title: "Bật/tắt LED bằng pin",
  board: "Pin 9V + công tắc",
  expectedConnections: CIRCUIT_LESSON_SPECS["battery-led-switch"].connections,
  checkList: [
    { id: "battery_visibility", label: "Nhìn thấy pin và cực nguồn", reviewTopic: "Pin 9V và cực nguồn", category: "safety", safetyKind: "power_polarity" },
    { id: "led_orientation", label: "Chiều LED", reviewTopic: "Anode và Cathode", category: "safety", safetyKind: "led_polarity" },
    { id: "resistor_present", label: "Điện trở hạn dòng", reviewTopic: "Điện trở hạn dòng", category: "safety", safetyKind: "current_limiting" },
    { id: "resistor_in_series", label: "Điện trở mắc nối tiếp", reviewTopic: "Mạch nối tiếp", category: "safety", safetyKind: "current_limiting" },
    { id: "switch_present", label: "Có công tắc", reviewTopic: "Công tắc đóng và mở", category: "standard" },
    { id: "switch_in_series", label: "Công tắc mắc nối tiếp", reviewTopic: "Công tắc trong mạch nối tiếp", category: "standard" },
    { id: "battery_polarity", label: "Đúng cực pin", reviewTopic: "Cực tính nguồn và LED", category: "safety", safetyKind: "power_polarity" },
    { id: "power_voltage", label: "Nguồn 9V có điện trở phù hợp", reviewTopic: "Điện áp nguồn và điện trở", category: "safety", safetyKind: "voltage" },
    { id: "no_short_circuit", label: "Không có dấu hiệu chập mạch", reviewTopic: "An toàn chống chập mạch", category: "safety", safetyKind: "short_circuit" },
    { id: "circuit_continuity", label: "Mạch kín khi bật", reviewTopic: "Đường dòng điện khép kín", category: "standard" },
  ],
};
