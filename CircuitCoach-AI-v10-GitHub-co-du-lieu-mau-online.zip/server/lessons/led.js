import { CIRCUIT_LESSON_SPECS } from "../../src/data/circuit-rules.js";

export default {
  id: "led",
  title: "LED cơ bản",
  board: "Arduino Uno",
  expectedConnections: CIRCUIT_LESSON_SPECS.led.connections,
  checkList: [
    { id: "component_visibility", label: "Nhìn thấy linh kiện", reviewTopic: "Chụp ảnh mạch", category: "standard" },
    { id: "led_orientation", label: "Chiều LED", reviewTopic: "Anode và Cathode", category: "safety", safetyKind: "led_polarity" },
    { id: "resistor_present", label: "Điện trở hạn dòng", reviewTopic: "Điện trở hạn dòng", category: "safety", safetyKind: "current_limiting" },
    { id: "resistor_in_series", label: "Điện trở mắc nối tiếp", reviewTopic: "Mạch nối tiếp", category: "safety", safetyKind: "current_limiting" },
    { id: "power_connection", label: "Kết nối nguồn", reviewTopic: "Nguồn điện – VCC – GND", category: "safety", safetyKind: "power_polarity" },
    { id: "ground_connection", label: "Kết nối GND", reviewTopic: "Nguồn điện – VCC – GND", category: "safety", safetyKind: "power_ground" },
    { id: "power_voltage", label: "Mức nguồn phù hợp", reviewTopic: "Nguồn điện – VCC – GND", category: "safety", safetyKind: "voltage" },
    { id: "no_short_circuit", label: "Không có dấu hiệu chập mạch", reviewTopic: "An toàn chống chập mạch", category: "safety", safetyKind: "short_circuit" },
  ],
};
