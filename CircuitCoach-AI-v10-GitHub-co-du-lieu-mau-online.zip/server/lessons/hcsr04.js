import { CIRCUIT_LESSON_SPECS } from "../../src/data/circuit-rules.js";

export default {
  id: "hcsr04",
  title: "Cảm biến HC-SR04",
  board: "Arduino Uno",
  expectedConnections: CIRCUIT_LESSON_SPECS.hcsr04.connections,
  checkList: [
    { id: "sensor_visibility", label: "Nhìn thấy cảm biến", reviewTopic: "Chụp ảnh mạch", category: "standard" },
    { id: "vcc_connection", label: "Kết nối VCC", reviewTopic: "Nguồn điện – VCC – GND", category: "safety", safetyKind: "power_polarity" },
    { id: "gnd_connection", label: "Kết nối GND", reviewTopic: "Nguồn điện – VCC – GND", category: "safety", safetyKind: "power_ground" },
    { id: "power_voltage", label: "Mức nguồn 5V phù hợp", reviewTopic: "Nguồn điện – VCC – GND", category: "safety", safetyKind: "voltage" },
    { id: "no_short_circuit", label: "Không có dấu hiệu chập mạch", reviewTopic: "An toàn chống chập mạch", category: "safety", safetyKind: "short_circuit" },
    { id: "trig_connection", label: "Kết nối TRIG", reviewTopic: "Tín hiệu Trigger", category: "standard" },
    { id: "echo_connection", label: "Kết nối ECHO", reviewTopic: "Tín hiệu Echo", category: "standard" },
  ],
};
