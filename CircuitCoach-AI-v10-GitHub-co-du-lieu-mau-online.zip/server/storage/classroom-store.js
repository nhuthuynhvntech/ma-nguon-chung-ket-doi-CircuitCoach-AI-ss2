import { existsSync, mkdirSync, readFileSync, readdirSync, unlinkSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const moduleDirectory = path.dirname(fileURLToPath(import.meta.url));
const projectDirectory = path.resolve(moduleDirectory, "../..");
const dataDirectory = path.resolve(process.env.CLASSROOM_DATA_DIR || path.join(projectDirectory, ".data", "classroom"));
const attemptsFile = path.join(dataDirectory, "attempts.json");
const imagesDirectory = path.join(dataDirectory, "images");
const persistenceEnabled = process.env.NODE_ENV !== "test" && process.env.CLASSROOM_PERSIST !== "false";
const IMAGE_FILE = /^\d+\.(jpg|png|webp|bin)$/i;

function safeId(value) {
  return String(value || "attempt").replace(/[^A-Za-z0-9_-]/g, "_").slice(0, 120);
}

function imageExtension(type) {
  if (type === "image/png") return "png";
  if (type === "image/webp") return "webp";
  return "jpg";
}

function imageType(extension) {
  if (extension === ".png") return "image/png";
  if (extension === ".webp") return "image/webp";
  return "image/jpeg";
}

export function loadClassroomStore() {
  const attempts = new Map();
  const images = new Map();
  if (!persistenceEnabled) return { attempts, images, persistenceEnabled };
  try {
    if (existsSync(attemptsFile)) {
      const saved = JSON.parse(readFileSync(attemptsFile, "utf8"));
      if (Array.isArray(saved)) {
        saved.forEach((attempt) => {
          if (attempt?.id) attempts.set(attempt.id, attempt);
        });
      }
    }
  } catch (error) {
    console.error("[classroom-store] Không đọc được danh sách bài làm:", error.message);
  }
  try {
    for (const attempt of attempts.values()) {
      const directory = path.join(imagesDirectory, safeId(attempt.id));
      if (!existsSync(directory)) continue;
      const files = readdirSync(directory)
        .filter((file) => IMAGE_FILE.test(file))
        .sort((a, b) => Number.parseInt(a, 10) - Number.parseInt(b, 10));
      const attemptImages = [];
      for (const file of files) {
        const index = Number.parseInt(file, 10);
        if (!Number.isInteger(index) || index < 0 || index > 2) continue;
        attemptImages[index] = {
          buffer: readFileSync(path.join(directory, file)),
          type: imageType(path.extname(file).toLowerCase()),
        };
      }
      if (attemptImages.length) images.set(attempt.id, attemptImages);
    }
  } catch (error) {
    console.error("[classroom-store] Không đọc được ảnh bài làm:", error.message);
  }
  return { attempts, images, persistenceEnabled };
}

export function persistAttempts(attempts) {
  if (!persistenceEnabled) return;
  try {
    mkdirSync(dataDirectory, { recursive: true });
    writeFileSync(attemptsFile, JSON.stringify([...attempts.values()], null, 2), "utf8");
  } catch (error) {
    console.error("[classroom-store] Không ghi được danh sách bài làm:", error.message);
  }
}

export function persistAttemptImages(attemptId, attemptImages = []) {
  if (!persistenceEnabled) return;
  try {
    const directory = path.join(imagesDirectory, safeId(attemptId));
    mkdirSync(directory, { recursive: true });
    for (const file of readdirSync(directory)) {
      if (IMAGE_FILE.test(file)) unlinkSync(path.join(directory, file));
    }
    attemptImages.forEach((image, index) => {
      if (!image?.buffer) return;
      const extension = imageExtension(image.type);
      writeFileSync(path.join(directory, `${index}.${extension}`), image.buffer);
    });
  } catch (error) {
    console.error("[classroom-store] Không ghi được ảnh bài làm:", error.message);
  }
}

export function removeAttemptImages(attemptId) {
  if (!persistenceEnabled) return;
  try {
    const directory = path.join(imagesDirectory, safeId(attemptId));
    if (!existsSync(directory)) return;
    for (const file of readdirSync(directory)) {
      if (IMAGE_FILE.test(file)) unlinkSync(path.join(directory, file));
    }
  } catch (error) {
    console.error("[classroom-store] Không xóa được ảnh bài làm:", error.message);
  }
}

export { dataDirectory };
