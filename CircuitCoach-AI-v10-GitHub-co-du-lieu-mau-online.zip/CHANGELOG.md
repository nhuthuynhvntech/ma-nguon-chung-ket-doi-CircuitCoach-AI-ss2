# Lịch sử cập nhật CircuitCoach AI

## 26/11/2026 · Chọn model phân tích mạch

- Học sinh chọn model ngay cạnh nút **Phân tích mạch**. Danh sách gồm GPT-5.6 Terra, GPT-6.1 Terra và GPT-6.2 Sol. Model mặc định lấy từ cấu hình Site.
- Tên model được lưu cùng lượt làm và dùng lại khi kiểm tra một tiêu chí. Thử nghiệm A/B của giáo viên tiếp tục dùng chung model mặc định ở hai luồng.

## 25/11/2026 · Cấu hình OpenAI trên bản online

- Mở mục **Cấu hình OpenAI** cho khách và mọi vai trò. Có thể lưu khóa OpenAI riêng cho phiên trình duyệt và chuyển về khóa mặc định của Site.
- Khóa riêng áp dụng cho phân tích, kiểm tra lại, so sánh A/B và trợ lý. Đăng xuất sẽ bỏ lựa chọn riêng.

## 25/11/2026 · Đăng nhập online

- Giao diện đăng nhập quản trị chấp nhận mật khẩu từ 6 ký tự để xác thực với máy chủ.
- Hỗ trợ đợt đổi mật khẩu có thời hạn cấu hình cho hai tài khoản gốc trên Site. Thao tác yêu cầu phiên quản trị và cần mật khẩu hiện tại khi đổi tài khoản quản trị. Các phiên cũ của tài khoản được thu hồi sau khi đổi.
- Ngưỡng 12 ký tự tiếp tục áp dụng khi tạo tài khoản và khi đổi mật khẩu sau khi kết thúc đợt đổi.

## 25/11/2026 · Bản hợp nhất để phát hành online

- Đánh giá nhiều góc ảnh trong một lượt. Hệ thống kiểm chứng chi tiết đã thấy, dùng ảnh cận và ghi rõ phần cần kiểm tra thêm.
- Nhận diện chiều LED theo dấu hiệu ở hai bản cực, kết nối Arduino và hai nhánh điện trở, công tắc ở bài dùng pin.
- Kiểm tra lại một tiêu chí ngay dưới kết quả. Báo cáo tổng hợp dùng kết quả mới nhất của tiêu chí và giữ lại lượt phân tích ban đầu trong lịch sử.
- Giáo viên nhận xét, đánh giá AI đúng hoặc sai, khoanh vùng và duyệt ảnh kiểm tra lại vào kho chung. Các lượt sau có thể đọc ảnh, vùng khoanh và dấu hiệu phù hợp.
- Vùng đánh dấu trên ảnh thể hiện bằng chứng lỗi hoặc vị trí cần xem lại. Giáo viên xác nhận an toàn trên mạch thật.
- Bản khôi phục gồm toàn bộ dữ liệu đã đồng bộ của local tại thời điểm sao lưu. Mã nguồn, ảnh mẫu và nhật ký cập nhật có thể đọc ngay. Cơ sở dữ liệu và ảnh lớp được mã hóa.

## 24/11/2026 · Bản local độc lập

- Sao lưu dự án, ảnh và lịch sử đã đồng bộ. Dùng cổng 3190 để chạy bản local.
- Cập nhật luồng đối chiếu lỗi AI, hướng dẫn theo bài, ảnh minh họa và kết quả kiểm tra mạch.

## 18–23/11/2026 · Nâng cấp hệ thống lớp học

- Quản trị viên tạo tài khoản giáo viên. Giáo viên cấp mã lớp và kiểm duyệt kho ảnh theo bài.
- Báo cáo theo bài và lớp, hai luồng thử nghiệm A/B, lịch sử riêng cho từng lần làm và trợ lý hướng dẫn.
- Giao diện theo vai trò, hướng dẫn lắp mạch theo bước, ảnh tham chiếu, ghi chú trực tiếp trên ảnh và phần theo dõi AI.

Thư mục `history/` trong bản đóng gói lưu ghi chú chi tiết và lịch sử commit của kho nguồn Sites.
