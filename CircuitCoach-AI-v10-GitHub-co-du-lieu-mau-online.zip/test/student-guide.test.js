import assert from "node:assert/strict";
import test from "node:test";
import { buildGuideChatRequest } from "../server/ai/guide-chat.js";
import { studentGuideForModel, summarizeStudentGuide } from "../server/ai/student-guide.js";
import { getLesson } from "../src/data/lessons.js";

function servoAttempt(id, fields = {}) {
  return { id, lessonId: "servo", problems: [], ...fields };
}

test("student guide uses the selected lesson and skips simulated attempts", () => {
  const guide = summarizeStudentGuide([
    servoAttempt("demo", { demo: true }),
    servoAttempt("led", { lessonId: "led" }),
    servoAttempt("servo"),
  ], getLesson("servo"));
  assert.equal(guide.latestAttemptId, "servo");
  assert.equal(guide.attemptCount, 1);
  assert.equal(summarizeStudentGuide([servoAttempt("demo", { demo: true })], null), null);
});

test("student guide prefers checked labels and reports improvement between teacher labels", () => {
  const guide = summarizeStudentGuide([
    servoAttempt("new", {
      teacherCriterionLabels: { ground_connection: "correct", signal_connection: "incorrect" },
      problems: [{ id: "ground_connection", status: "possible_error" }],
    }),
    servoAttempt("previous", { teacherCriterionLabels: { ground_connection: "incorrect", signal_connection: "incorrect" } }),
    servoAttempt("wrong-lesson", { lessonId: "led" }),
  ], null);
  assert.deepEqual(guide.next, {
    type: "check", label: "Kết nối Signal", category: "standard", source: "teacher", repeated: 1,
  });
  assert.equal(guide.improvedLabel, "Kết nối GND");
});

test("student guide asks for evidence when photos are unclear, and prioritizes physical safety", () => {
  const problems = [{ id: "signal_connection", status: "not_visible" }];
  assert.equal(summarizeStudentGuide([servoAttempt("new", { problems })], null).next.type, "evidence");
  const unsafe = servoAttempt("unsafe", { problems, teacherSafetyCheck: "unsafe", teacherPhysicallyChecked: true });
  assert.equal(summarizeStudentGuide([unsafe], null).next.type, "unsafe");
});

test("a teacher marking AI incorrect is not counted as a student error", () => {
  const guide = summarizeStudentGuide([servoAttempt("new", {
    teacherVerification: "incorrect",
    problems: [{ id: "ground_connection", status: "possible_error" }],
  })], null);
  assert.equal(guide.next.type, "ai_review");
});

test("personal guide model input has no identifiers or raw teacher comments", () => {
  const guide = summarizeStudentGuide([servoAttempt("private-attempt-id", {
    studentName: "Private group",
    classCode: "PRIVATE123",
    teacherCommentAt: "2026-11-23T00:00:00.000Z",
    teacherComment: "Private teacher note",
    teacherCriterionLabels: { signal_connection: "incorrect" },
  })], null);
  assert.equal(guide.teacherComment, "Private teacher note");
  const request = buildGuideChatRequest("model", {
    lesson: null, messages: [{ role: "user", content: "Em nên làm gì tiếp?" }], studentGuide: studentGuideForModel(guide),
  });
  assert.match(request.input[0].content, /Kết nối Signal/);
  assert.doesNotMatch(JSON.stringify(request), /private-attempt-id|Private group|PRIVATE123|Private teacher note/);
  assert.equal(request.store, false);
});
