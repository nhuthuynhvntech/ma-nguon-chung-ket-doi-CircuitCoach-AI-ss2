import test from "node:test";
import assert from "node:assert/strict";
import { circuitAnnotation, findReviewArea, isValidRegion, normalizeAnnotations } from "../server/ai/annotation-policy.js";
import { buildStudentImageInput } from "../server/ai/analyze-prompt.js";

function analysis(check) {
  return { analysisStatus: "ok", lessonId: "led", summary: "demo", captureAdvice: [], checks: [check] };
}

function problem(overrides = {}) {
  return {
    id: "resistor_present",
    criterionId: "resistor_present",
    label: "Điện trở hạn dòng",
    status: "possible_error",
    certainty: "high",
    confidence: 0.86,
    imageIndex: 0,
    region: { x: 42, y: 31, width: 18, height: 22 },
    evidence: "Có thể thiếu điện trở.",
    reviewTopic: "Điện trở",
    ...overrides,
  };
}

test("giữ vùng phần trăm hợp lệ trên đúng ảnh", () => {
  const result = normalizeAnnotations(analysis(problem({ imageIndex: 2 })), { imageCount: 3 });
  assert.deepEqual(result.checks[0].region, { x: 42, y: 31, width: 18, height: 22 });
  assert.equal(result.checks[0].imageIndex, 2);
});

test("bỏ vùng vượt ra ngoài ảnh và giữ ảnh liên quan", () => {
  assert.equal(isValidRegion({ x: 90, y: 20, width: 18, height: 22 }), false);
  const result = normalizeAnnotations(analysis(problem({ region: { x: 90, y: 20, width: 18, height: 22 } })), { imageCount: 1 });
  assert.equal(result.checks[0].region, null);
  assert.equal(result.checks[0].imageIndex, 0);
});

test("không vẽ vùng nếu imageIndex không thuộc tối đa ba ảnh đã gửi", () => {
  const result = normalizeAnnotations(analysis(problem({ imageIndex: 2 })), { imageCount: 2 });
  assert.equal(result.checks[0].region, null);
  assert.equal(result.checks[0].imageIndex, null);
});

test("confidence thấp chuyển thành chưa xác định và yêu cầu chụp lại", () => {
  const result = normalizeAnnotations(analysis(problem({ confidence: 0.49 })), { imageCount: 1 });
  assert.equal(result.checks[0].status, "uncertain");
  assert.equal(result.checks[0].region, null);
  assert.match(result.checks[0].evidence, /chụp lại/i);
});

test("kết luận đúng nhưng confidence thấp cũng phải chuyển thành chưa xác định", () => {
  const result = normalizeAnnotations(analysis(problem({ status: "correct", confidence: 0.5, region: null, imageIndex: null })), { imageCount: 1 });
  assert.equal(result.checks[0].status, "uncertain");
  assert.match(result.checks[0].evidence, /chụp lại/i);
});

test("không tạo vùng giả khi AI không trả tọa độ", () => {
  const result = normalizeAnnotations(analysis(problem({ region: null, imageIndex: null })), { imageCount: 1 });
  assert.equal(result.checks[0].region, null);
  assert.equal(result.checks[0].imageIndex, null);
});

test("cảnh báo trên ảnh có thể giữ vị trí theo ảnh khi vùng quá rộng hoặc độ chắc chắn thấp", () => {
  for (const overrides of [
    { region: { x: 0, y: 0, width: 95, height: 95 } },
    { certainty: "low" },
    { region: null },
  ]) {
    const result = normalizeAnnotations(analysis(problem({ ...overrides, imageIndex: 1 })), { imageCount: 2 });
    assert.equal(result.checks[0].status, "possible_error");
    assert.equal(result.checks[0].imageIndex, 1);
    assert.equal(result.checks[0].region, null);
  }
});

test("vùng lỗi lấy tọa độ từ bằng chứng đã xác minh khi kết quả không có vùng chính", () => {
  const region = { x: 40, y: 48, width: 10, height: 7 };
  const check = problem({ region: null, imageIndex: null,
    ruleEvidence: { type: "resistance", visualProof: [{ imageIndex: 2, part: "resistor_bands", region }] } });
  assert.deepEqual(circuitAnnotation(check, 3), { kind: "error", imageIndex: 2, region });
  assert.equal(circuitAnnotation(check, 2), null);
});

test("vùng xem lại cần tọa độ hợp lệ và ảnh cho thấy bộ phận liên quan", () => {
  const region = { x: 42, y: 34, width: 11, height: 15 };
  const check = problem({ status: "uncertain", confidence: 0, imageIndex: null, region: null,
    ruleEvidence: { type: "resistance" } });
  const raw = { reviewTarget: { imageIndex: 1, region }, photoReviews: [{ imageIndex: 1, assessment: "unclear" }] };
  const reviewArea = findReviewArea(check, raw, 2);
  assert.deepEqual(circuitAnnotation({ ...check, reviewArea }, 2), { kind: "review", imageIndex: 1, region });
  assert.equal(findReviewArea(check, { ...raw, photoReviews: [{ imageIndex: 1, assessment: "not_visible" }] }, 2), null);
  assert.equal(findReviewArea(check, { ...raw, reviewTarget: { imageIndex: 1, region: { ...region, width: 90 } } }, 2), null);
  assert.equal(findReviewArea({ ...check, ruleEvidence: { physicalCheckRequired: true } }, raw, 2), null);
});

test("mọi ảnh học sinh có chỉ số riêng ngay trước ảnh", () => {
  const images = ["first", "second", "third"].map(image_url => ({ type: "input_image", image_url }));
  const content = buildStudentImageInput(images);
  for (const [index, image] of images.entries()) {
    assert.match(content[index * 2].text, new RegExp(`imageIndex=${index}\\b`));
    assert.deepEqual(content[index * 2 + 1], image);
  }
  assert.match(content.at(-1).text, /Đã gửi đủ 3 góc chụp.*photoReviews/);
});
