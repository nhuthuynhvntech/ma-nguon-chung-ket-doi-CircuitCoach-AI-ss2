import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile, readdir } from "node:fs/promises";
import { DatabaseSync } from "node:sqlite";
import test from "node:test";
import worker from "../worker/runtime.js";
import { reportProblems, reportSummary } from "../src/data/attempt-rechecks.js";
import { renderTeacherRechecks } from "../src/views/criterion-recheck.js";

test("kiểm tra lại một tiêu chí, lưu ảnh riêng và giữ kết quả gốc", async t => {
  const db = new DatabaseSync(":memory:");
  t.after(() => db.close());
  db.exec("PRAGMA foreign_keys=ON");
  const migrations = new URL("../drizzle/", import.meta.url);
  for (const name of (await readdir(migrations)).filter(name => name.endsWith(".sql")).sort()) {
    db.exec(await readFile(new URL(name, migrations), "utf8"));
  }
  const digest = value => createHash("sha256").update(value).digest("base64url");
  const owner = "a".repeat(43);
  const teacher = "b".repeat(43);
  const now = new Date().toISOString();
  const original = JSON.stringify({ lessonId: "led", verdict: "review", analysisModel: "gpt-6.2-sol", teacherComment: "Giữ nhận xét đã lưu.",
    problems: [
      { id: "led_orientation", status: "uncertain" },
      { id: "power_connection", status: "correct" },
      { id: "power_voltage", status: "uncertain", ruleEvidence: { physicalCheckRequired: true } },
    ] });
  db.prepare(`INSERT INTO classroom_attempts (id,class_code,student_id,student_name,created_at,payload_json,updated_at,local_owner_hash)
    VALUES ('attempt','DEMO921','group','Nhóm 1',?,?,?,?)`).run(now, original, now, digest(owner));
  db.prepare("INSERT INTO platform_users (id,username,password_hash,created_at) VALUES ('u','teacher','fixture',?)").run(now);
  db.prepare("INSERT INTO platform_classes (code,created_by,created_at) VALUES ('DEMO921','u',?)").run(now);
  db.exec("INSERT INTO platform_roles VALUES ('u','teacher'); INSERT INTO platform_class_members VALUES ('DEMO921','u','teacher')");
  db.prepare("INSERT INTO platform_sessions VALUES (?,'u',?,?)")
    .run(digest(teacher), new Date(Date.now() + 60_000).toISOString(), now);

  const objects = new Map();
  const env = {
    LOCAL_PERSONAL_ACCOUNTS: true,
    LOCAL_OPENAI_SETTINGS: { read: async () => ({ defaultKey: "fixture" }) },
    DB: {
      prepare: sql => ({ bind: (...args) => ({
        first: async () => db.prepare(sql).get(...args),
        all: async () => ({ results: db.prepare(sql).all(...args) }),
        run: async () => ({ meta: db.prepare(sql).run(...args) }),
      }) }),
      batch: async statements => {
        db.exec("BEGIN");
        try {
          const result = await Promise.all(statements.map(statement => statement.run()));
          db.exec("COMMIT");
          return result;
        } catch (error) { db.exec("ROLLBACK"); throw error; }
      },
    },
    BUCKET: {
      put: async (key, body, metadata) => objects.set(key, { ...metadata, body: await new Response(body).arrayBuffer() }),
      get: async key => objects.get(key),
      delete: async key => objects.delete(key),
    },
  };
  const origin = "http://circuitcoach.test";
  const endpoint = origin + "/api/classroom/attempts/attempt/rechecks";
  const image = await readFile(new URL("../public/images/lesson1-reference-closeup.jpg", import.meta.url));
  const source = new Blob([image], { type: "image/jpeg" });
  const savedCookie = `cc_student=${owner}`;
  const teacherCookie = `cc_staff_teacher=${teacher}`;
  function post(criterionId, { cookie = savedCookie, photo = source, from = origin } = {}) {
    const body = new FormData();
    body.set("criterionId", criterionId);
    if (photo) body.set("photo", photo, "circuit.jpg");
    return worker.fetch(new Request(endpoint + "?classCode=DEMO921", {
      method: "POST", headers: { cookie, origin: from, "cf-connecting-ip": "criterion-recheck-test" }, body,
    }), env);
  }
  function get(cookie = savedCookie, photoId = "", code = "DEMO921") {
    const path = photoId ? `/${photoId}/image` : "";
    return worker.fetch(new Request(`${endpoint}${path}?classCode=${code}`, { headers: { cookie } }), env);
  }

  let requests = 0;
  let timesOut = false;
  let lastInput = "";
  let expectedImage = image;
  t.mock.method(globalThis, "fetch", async (url, options) => {
    assert.equal(url, "https://api.openai.com/v1/responses");
    assert.equal(options.headers.authorization, "Bearer fixture");
    requests++;
    const payload = JSON.parse(options.body);
    assert.equal(payload.model, "gpt-6.2-sol");
    const schema = payload.text.format.schema.properties.checks;
    assert.equal(schema.minItems, 1);
    assert.equal(schema.maxItems, 1);
    assert.deepEqual(schema.items.properties.criterionId.enum, ["led_orientation"]);
    const content = payload.input[0].content;
    const sourceIndex = content.findIndex(item => item.text?.startsWith("ẢNH MẠCH HỌC SINH"));
    assert.equal(content[sourceIndex + 1].image_url, `data:image/jpeg;base64,${expectedImage.toString("base64")}`);
    lastInput = content.map(item => item.text || "").join("\n");
    assert.match(lastInput, /ảnh mới để kiểm tra lại đúng một tiêu chí/);
    if (timesOut) throw new DOMException("Timed out", "TimeoutError");
    return Response.json({ output_text: JSON.stringify({ lessonId: "led", analysisStatus: "ok", checks: [{
      criterionId: "led_orientation",
      observation: { value: "anode_to_feed", method: "single_photo", imageIndex: 0, otherImageIndex: null,
        confidence: 0.92, detail: "Chân cathode nối về GND.", region: null, resistorBands: null, visualProof: [],
        photoReviews: [{ imageIndex: 0, assessment: "supports", detail: "Xem được hai bản cực và chân nối." }],
        ledTrace: { electrodesImageIndex: 0, connections: [{ electrode: "cathode", imageIndex: 0, terminalLabel: "GND" }] },
      },
    }], captureAdvice: [] }) });
  });

  assert.deepEqual(await (await get()).json(), { rechecks: [] });
  assert.equal((await post("led_orientation", { cookie: "" })).status, 403);
  assert.equal((await post("led_orientation", { cookie: teacherCookie })).status, 403);
  assert.equal((await post("led_orientation", { from: "https://other.test" })).status, 403);
  assert.equal((await post("power_voltage")).status, 400);
  assert.equal((await post("power_connection")).status, 400);
  assert.equal((await post("led_orientation", { photo: null })).status, 400);
  assert.equal(requests, 0);

  const first = await post("led_orientation");
  assert.equal(first.status, 201, await first.clone().text());
  const { recheck } = await first.json();
  assert.equal(recheck.check.status, "correct");
  assert.equal(recheck.criterionId, "led_orientation");
  assert.equal(requests, 1);
  const photo = await get(savedCookie, recheck.id);
  assert.equal(photo.headers.get("cache-control"), "private, no-store");
  assert.deepEqual(Buffer.from(await photo.arrayBuffer()), image);
  assert.equal((await get("", recheck.id)).status, 403);
  assert.equal((await get(savedCookie, recheck.id, "ABCD")).status, 403);
  assert.equal((await get(teacherCookie, recheck.id)).status, 200);

  const second = await post("led_orientation");
  assert.equal(second.status, 201);
  assert.equal(requests, 2);
  const { rechecks } = await (await get(teacherCookie)).json();
  assert.equal(rechecks.length, 2);
  assert.notEqual(rechecks[0].id, rechecks[1].id);
  const attemptUrl = origin + "/api/classroom/attempts/attempt?classCode=DEMO921";
  const detail = await worker.fetch(new Request(attemptUrl, { headers: { cookie: savedCookie } }), env);
  const current = (await detail.json()).attempt;
  assert.equal(current.problems[0].status, "uncertain");
  assert.equal(current.latestRechecks.length, 1);
  assert.equal(reportProblems(current)[0].status, "correct");
  assert.match(reportSummary(current), /đúng Chiều LED/);
  assert.match(reportSummary(current), /Giáo viên kiểm tra mạch thật/);
  assert.equal(reportProblems(current)[2].ruleEvidence.physicalCheckRequired, true);
  const reportUrl = origin + "/api/classroom/teacher/learning?classCode=DEMO921&lessonId=led";
  const classReport = await worker.fetch(new Request(reportUrl, { headers: { cookie: teacherCookie } }), env);
  assert.equal(classReport.status, 200, await classReport.clone().text());
  const report = await classReport.json();
  assert.deepEqual(report.recheckedCriteria, [{ lessonId: "led", criterionId: "led_orientation", total: 1, correct: 1 }]);
  assert.equal(report.attempts[0].latestRechecks.length, 1);
  assert.equal(report.lessons[0].aiPass, 0);
  const commentPath = endpoint + "/" + recheck.id + "/comment";
  const comment = "Chụp rõ cả hai chân. <Chiều LED đúng>";
  function saveComment({ value = comment, version = 0, cookie = teacherCookie, classCode = "DEMO921", from = origin } = {}) {
    return worker.fetch(new Request(commentPath + "?classCode=" + classCode, {
      method: "PATCH", headers: { cookie, origin: from, "content-type": "application/json" }, body: JSON.stringify({ comment: value, version }),
    }), env);
  }
  assert.equal((await saveComment({ cookie: savedCookie })).status, 403);
  assert.equal((await saveComment({ classCode: "STEM27" })).status, 403);
  assert.equal((await saveComment({ from: "https://other.test" })).status, 403);
  assert.equal((await saveComment({ value: "a".repeat(1001) })).status, 400);
  const saved = await saveComment();
  assert.equal(saved.status, 200, await saved.clone().text());
  assert.equal((await saved.json()).teacherCommentVersion, 1);
  assert.equal((await saveComment({ value: "Bản trước không được ghi đè." })).status, 409);
  const studentEntries = (await (await get()).json()).rechecks;
  const commented = studentEntries.find(entry => entry.id === recheck.id);
  assert.equal(commented.teacherComment, comment);
  assert.equal(commented.teacherCommentBy, "teacher");
  assert.equal(commented.check.status, "correct");
  assert.equal(studentEntries.find(entry => entry.id !== recheck.id).teacherComment, "");
  const teacherMarkup = renderTeacherRechecks(studentEntries, { id: "attempt", classCode: "DEMO921" });
  assert.match(teacherMarkup, /Nhận xét ảnh này/);
  assert.match(teacherMarkup, /&lt;Chiều LED đúng&gt;/);
  assert.match(teacherMarkup, /data-recheck-teacher-photo/);
  assert.equal((await saveComment({ value: "", version: 1 })).status, 200);
  assert.equal((await (await get()).json()).rechecks.find(entry => entry.id === recheck.id).teacherComment, "");
  assert.equal(requests, 2);
  const evidence = "Lòng chén cathode đi theo chân ngang về GND";
  const annotations = [{ kind: "circle", points: [[400, 280], [530, 420]] }];
  const review = { aiVerdict: "incorrect", photoLabel: "correct", aiErrorReason: "wrong_polarity",
    errorType: "", evidence, annotations, version: 0 };
  function evaluate(action, body, cookie = teacherCookie) {
    return worker.fetch(new Request(endpoint + "/" + recheck.id + "/" + action + "?classCode=DEMO921", {
      method: action === "review" ? "PATCH" : "POST",
      headers: { cookie, origin, "content-type": "application/json" }, body: JSON.stringify(body),
    }), env);
  }
  assert.equal((await evaluate("reference", { version: 0 })).status, 400);
  assert.equal((await evaluate("review", review, savedCookie)).status, 403);
  assert.equal((await evaluate("review", { ...review, aiErrorReason: "invalid" })).status, 400);
  const reviewed = await evaluate("review", review);
  assert.equal(reviewed.status, 200, await reviewed.clone().text());
  assert.equal((await reviewed.json()).teacherReviewVersion, 1);
  assert.equal((await evaluate("reference", { version: 1 }, savedCookie)).status, 403);
  assert.equal((await evaluate("reference", { version: 0 })).status, 409);
  const published = await evaluate("reference", { version: 1 });
  assert.equal(published.status, 201, await published.clone().text());
  const referenceId = (await published.json()).id;
  const duplicate = await evaluate("reference", { version: 1 });
  assert.equal((await duplicate.json()).id, referenceId);
  const publishedRow = db.prepare("SELECT * FROM platform_reference_case_catalog WHERE id=?").get(referenceId);
  assert.equal(publishedRow.attempt_id, "attempt");
  assert.equal(publishedRow.label, "correct");
  assert.equal(publishedRow.status, "approved");
  assert.deepEqual(JSON.parse(publishedRow.annotations_json), annotations);
  const gallery = await worker.fetch(new Request(origin + "/api/reference-cases?lessonId=led"), env);
  assert.ok((await gallery.json()).cases.some(entry => entry.id === referenceId));
  const next = (await (await get()).json()).rechecks.find(item => item.id === recheck.id);
  assert.equal(next.teacherReview.aiVerdict, "incorrect");
  assert.deepEqual(next.teacherReview.annotations, annotations);
  assert.match(renderTeacherRechecks([next], { id: "attempt", classCode: "DEMO921" }), /AI sai/);
  assert.equal(next.referenceId, referenceId);

  const reusedPhoto = await post("led_orientation");
  assert.equal(reusedPhoto.status, 201);
  assert.match(lastInput, /VÙNG GIÁO VIÊN ĐÁNH DẤU TRÊN ẢNH HIỆN TẠI/);
  assert.ok(lastInput.includes(evidence));
  assert.match(lastInput, /Tự kiểm tra chi tiết này trên ảnh/);
  assert.doesNotMatch(lastInput, /ẢNH MẪU ĐỐI CHIẾU/);
  expectedImage = await readFile(new URL("../public/images/lesson1-reference-overview.jpg", import.meta.url));
  const equivalent = new Blob([expectedImage], { type:"image/jpeg" });
  const reanalyzed = await post("led_orientation", { photo: equivalent });
  assert.equal(reanalyzed.status, 201);
  assert.match(lastInput, /ẢNH MẪU ĐỐI CHIẾU/);
  assert.ok(lastInput.includes(evidence));
  assert.match(lastInput, /Điểm AI cần chú ý khi xem ảnh mới/);
  assert.equal(requests, 4);
  timesOut = true;
  assert.equal((await post("led_orientation", { photo: equivalent })).status, 504);
  assert.equal(objects.size, 5);
  assert.equal(db.prepare("SELECT COUNT(*) AS count FROM platform_criterion_rechecks").get().count, 4);
  assert.equal(db.prepare("SELECT COUNT(*) AS count FROM platform_criterion_rechecks WHERE model='gpt-6.2-sol'").get().count, 4);
  assert.equal(db.prepare("SELECT payload_json FROM classroom_attempts").get().payload_json, original);
  const updatedReview = await evaluate("review", { ...review, version: 1, evidence: "Cực nối về GND cần nhìn qua ảnh cận." });
  assert.equal(updatedReview.status, 200);
  const replacement = await evaluate("reference", { version: 2 });
  assert.equal(replacement.status, 201);
  assert.equal(db.prepare("SELECT status FROM platform_uploaded_reference_cases WHERE id=?").get(referenceId).status, "retired");
  assert.equal(db.prepare("SELECT COUNT(*) AS count FROM platform_uploaded_reference_cases WHERE status='approved'").get().count, 1);
});
