import assert from "node:assert/strict";
import test from "node:test";
import { reconcileCircuitRecheck } from "../server/ai/circuit-observations.js";
import { finalizeCircuitAnalysis } from "../server/ai/finalize-analysis.js";
import { circuitAnnotation } from "../server/ai/annotation-policy.js";
import ledLesson from "../server/lessons/led.js";
import batteryLesson from "../server/lessons/battery-led-switch.js";

const policy = { strictEvidence: true };
const photos = [
  { imageIndex: 0, assessment: "supports", detail: "Claim never published verbatim." },
  { imageIndex: 1, assessment: "context", detail: "General view." },
  { imageIndex: 2, assessment: "unclear", detail: "Angle does not show the evidence." },
];
const spot = (part, x, y, text = null) => ({ part, imageIndex: 0, region: { x, y, width: 4, height: 5 }, text });
const electrodes = [
  spot("cathode_cup", 30, 20), spot("anode_electrode", 36, 20),
  spot("feed_terminal", 58, 52), spot("return_terminal", 44, 52),
];
function observation(value, visualProof, options = {}) {
  return {
    value, method: "single_photo", imageIndex: 0, otherImageIndex: null,
    confidence: 0.99, detail: "Claim never published verbatim.",
    region: { x: 30, y: 20, width: 4, height: 5 },
    photoReviews: photos, resistorBands: null, visualProof, ...options,
  };
}
function finalize(id, first, second) {
  const shape = seen => ({
    lessonId: "led", analysisStatus: "ok", checks: [{ criterionId: id, observation: seen }],
    captureAdvice: ["Unverified capture advice"],
  });
  const { analysis } = reconcileCircuitRecheck(ledLesson, shape(first), second ? shape(second) : null, [id], 3, [], policy);
  const result = finalizeCircuitAnalysis(ledLesson, analysis, 3, policy);
  return { result, check: result.checks.find(item => item.id === id) };
}

const otherViews = photos.map(photo => photo.imageIndex === 1 ? { ...photo, assessment: "supports" } : photo);
const leadProof = [spot("lead_start", 18, 20), spot("lead_end", 28, 43), spot("wire_path", 24, 28)];
const inPhoto = (spots, imageIndex) => spots.map(item => ({ ...item, imageIndex }));

test("đối chiếu hai bản cực LED với chân đã lần từ ảnh cận và góc nối dây", () => {
  const cup = { ...spot("cathode_cup", 33.5, 27), imageIndex: 1, region: { x: 33.5, y: 27, width: 8, height: 8 } };
  const small = { ...spot("anode_electrode", 40, 25.5), imageIndex: 1, region: { x: 40, y: 25.5, width: 7, height: 8 } };
  const feed = { ...spot("feed_terminal", 82, 38, "anode"), imageIndex: 2 };
  const back = { ...spot("return_terminal", 74, 30, "cathode"), imageIndex: 2 };
  const photoReviews = photos.map(photo => ({ ...photo, assessment: photo.imageIndex ? "supports" : "context" }));
  const evaluate = (value, visualProof, options = {}) => finalizeCircuitAnalysis(ledLesson, {
    lessonId: "led", analysisStatus: "ok",
    checks: [{ criterionId: "led_orientation", observation: observation(value, visualProof, {
      method: "overlapping_views", imageIndex: 1, otherImageIndex: 2, photoReviews, ...options,
    }) }],
  }, 3, { singleRead: true });
  const led = result => result.checks.find(check => check.id === "led_orientation");

  const accepted = evaluate("anode_to_feed", [cup, small, feed, back]);
  assert.equal(led(accepted).status, "correct");
  assert.equal(accepted.safety.teacherCheckRequired, true);
  assert.deepEqual([...new Set(led(accepted).ruleEvidence.visualProof.map(part => part.imageIndex))], [1, 2]);
  const reversedLegs = [cup, small, { ...feed, text: "cathode" }, { ...back, text: "anode" }];
  const feedAnchor = { ...spot("feed_anchor", 18, 61, "8"), imageIndex: 2 };
  const returnAnchor = { ...spot("return_anchor", 18, 29, "GND"), imageIndex: 2 };
  assert.equal(led(evaluate("cathode_to_feed", reversedLegs)).status, "uncertain");
  const reversed = evaluate("cathode_to_feed", [...reversedLegs, feedAnchor, returnAnchor]);
  assert.equal(led(reversed).status, "possible_error");
  assert.equal(led(reversed).ruleEvidence.visualProof.find(item => item.part === "return_anchor").text, "GND");
  const swappedPins = evaluate("cathode_to_feed", [...reversedLegs, { ...feedAnchor, text: "GND" }, { ...returnAnchor, text: "8" }]);
  assert.equal(led(swappedPins).status, "uncertain");

  const partial = evaluate(null, [cup, small], { method: "uncertain", imageIndex: null, otherImageIndex: null });
  assert.equal(led(partial).status, "uncertain");
  assert.match(led(partial).evidence, /Ảnh 2 cho thấy cathode dạng chén và anode nhỏ/);
  assert.match(led(partial).photoReviews[1].detail, /hai bản cực/);
  assert.ok(partial.captureAdvice.some(tip => tip.includes("đường nối từ mỗi chân LED")));
  assert.equal(led(partial).ruleEvidence.observed, null);

  const wrongLabel = evaluate("anode_to_feed", [cup, small, { ...feed, text: "cathode" }, back]);
  assert.equal(led(wrongLabel).status, "uncertain");
  assert.equal(led(wrongLabel).ruleEvidence.electrodesImageIndex, 1);
  const sameSpot = evaluate("anode_to_feed", [cup, { ...small, region: cup.region }, feed, back]);
  assert.equal(led(sameSpot).status, "uncertain");
  assert.equal(led(sameSpot).ruleEvidence.electrodesImageIndex, undefined);
  const conflict = evaluate("anode_to_feed", [cup, small, feed, back], {
    photoReviews: [{ ...photoReviews[0], assessment: "conflicting" }, ...photoReviews.slice(1)],
  });
  assert.equal(led(conflict).status, "uncertain");
  assert.equal(led(conflict).ruleEvidence.electrodesImageIndex, undefined);
});

test("từ chối cảnh báo mắc ngược khi vùng chân LED trùng bản cực bên trong", () => {
  const marked = (part, x, y, width, height, text = null) => ({ part, imageIndex: 2, region: { x, y, width, height }, text });
  const regions = [
    marked("cathode_cup", 78, 28, 9, 12),
    marked("anode_electrode", 72, 29, 8, 11),
    marked("feed_terminal", 76, 41, 7, 8, "cathode"),
    marked("return_terminal", 72, 31, 7, 7, "anode"),
  ];
  const anchors = [marked("feed_anchor", 18, 61, 4, 4, "D8"), marked("return_anchor", 18, 28, 4, 4, "GND")];
  const photoReviews = photos.map(photo => ({ ...photo, assessment: photo.imageIndex === 2 ? "supports" : "context" }));
  const verify = (visualProof, value = "cathode_to_feed") => finalizeCircuitAnalysis(ledLesson, {
    lessonId: "led", analysisStatus: "ok",
    checks: [{ criterionId: "led_orientation", observation: observation(value, visualProof, { photoReviews, imageIndex: 2 }) }],
  }, 3, { singleRead: true }).checks.find(check => check.id === "led_orientation");
  const result = verify(regions);
  assert.equal(result.status, "uncertain");
  assert.equal(result.region, null);
  assert.match(result.evidence, /Chưa đủ bằng chứng.*mắc ngược/);
  assert.equal(verify([...regions, ...anchors]).status, "uncertain");
  const correctButOverlapping = [...regions.slice(0, 2), { ...regions[2], text: "anode" }, { ...regions[3], text: "cathode" }];
  assert.equal(verify(correctButOverlapping, "anode_to_feed").status, "uncertain");
});

test("một chân LED lần tới nhãn thật đủ để chấm chiều đúng với ảnh rõ hai bản cực", () => {
  const returned = { electrode: "cathode", imageIndex: 2, terminalLabel: "GND" };
  const trace = { electrodesImageIndex: 1, connections: [returned] };
  const verify = (ledTrace, options = {}) => finalizeCircuitAnalysis(ledLesson, {
    lessonId: "led", analysisStatus: "ok",
    checks: [{ criterionId: "led_orientation", observation: observation("cathode_to_feed", [], {
      ledTrace, photoReviews: [{ ...photos[1], assessment: "supports" }], ...options,
    }) }],
  }, 3, { singleRead: true });
  const led = result => result.checks.find(check => check.id === "led_orientation");

  const result = verify(trace);
  assert.equal(led(result).status, "correct");
  assert.equal(result.safety.teacherCheckRequired, true);
  assert.match(result.summary, /Ảnh xác nhận đúng chiều LED/);
  assert.match(result.summary, /Cần giáo viên kiểm tra trực tiếp/);
  assert.match(led(result).evidence, /Ảnh 2 cho thấy hai bản cực LED/);
  assert.match(led(result).evidence, /Ảnh 3 cho thấy chân cathode nối về GND/);
  assert.equal(led(result).ruleEvidence.ledTrace.connections.length, 1);
  assert.equal(led(verify(trace, { method: "uncertain", value: null, imageIndex: null })).status, "correct");
  const feed = { electrode: "anode", imageIndex: 2, terminalLabel: "8" };
  assert.equal(led(verify({ ...trace, connections: [feed] })).status, "correct");
  assert.equal(led(verify({ ...trace, connections: [{ ...feed, terminalLabel: "D12" }] })).status, "uncertain");
  const opposite = { ...returned, electrode: "anode" };
  assert.equal(led(verify({ ...trace, connections: [opposite] })).status, "uncertain");
  const conflict = led(verify({ ...trace, connections: [returned, opposite] }));
  assert.equal(conflict.status, "uncertain");
  assert.match(conflict.evidence, /mâu thuẫn/);
  const inconsistentViews = led(verify(trace, { photoReviews: [{ ...photos[0], assessment: "conflicting" }] }));
  assert.equal(inconsistentViews.status, "uncertain");
});

test("bài 4 xác nhận chiều lắp LED bằng hai nhánh và kiểm tra cực pin riêng", () => {
  const resistor = { electrode: "anode", imageIndex: 2, terminalLabel: "RESISTOR" };
  const toggle = { electrode: "cathode", imageIndex: 2, terminalLabel: "SWITCH" };
  const verify = (connections, photoReviews = photos) => finalizeCircuitAnalysis(batteryLesson, {
    lessonId: batteryLesson.id, analysisStatus: "ok",
    checks: [{ criterionId: "led_orientation", observation: observation(null, [], {
      method: "uncertain", imageIndex: null, photoReviews, ledTrace: { electrodesImageIndex: 1, connections },
    }) }],
  }, 3, { singleRead: true });
  const result = verify([resistor, toggle]);
  const led = data => data.checks.find(check => check.id === "led_orientation");
  assert.equal(led(result).status, "correct");
  assert.match(led(result).evidence, /chân anode nối về điện trở.*chân cathode nối về công tắc/);
  assert.equal(result.checks.find(check => check.id === "battery_polarity").status, "uncertain");
  assert.equal(result.safety.teacherCheckRequired, true);
  assert.equal(led(verify([toggle])).status, "uncertain");
  assert.equal(led(verify([resistor, { ...toggle, electrode: "anode" }])).status, "uncertain");
  assert.equal(led(verify([resistor, toggle], [{ ...photos[0], assessment: "conflicting" }])).status, "uncertain");
  assert.equal(led(verify([{ ...toggle, terminalLabel: "−" }])).status, "correct");
});

test("một lượt giữ được trị số khi ảnh cận và ảnh toàn cảnh bổ sung bằng chứng", () => {
  const proof = [spot("wire_path", 35, 40), ...inPhoto([spot("resistor_bands", 30, 20)], 1)];
  const makeResult = (method, visualProof, photoReviews) => finalizeCircuitAnalysis(ledLesson, {
    lessonId: "led", analysisStatus: "ok", checks: [{ criterionId: "resistor_present", observation:
      observation(null, visualProof, { imageIndex: 1, otherImageIndex: method === "single_photo" ? null : 0,
        method, photoReviews, resistorBands: ["cam", "cam", "nâu", "vàng kim"] }) }],
  }, 3, { singleRead: true });
  const resistor = result => result.checks.find(check => check.id === "resistor_present");
  const result = makeResult("overlapping_views", proof, otherViews);
  assert.equal(result.evidencePolicy, "single_read");
  assert.equal(resistor(result).ruleEvidence.observed, 330);
  assert.equal(result.safety.teacherCheckRequired, true);
  assert.equal(resistor(makeResult("overlapping_views", proof.slice(1), otherViews)).status, "uncertain");
  assert.equal(resistor(makeResult("single_photo", proof, otherViews)).status, "uncertain");
  const samePhoto = makeResult("single_photo", inPhoto(proof, 1), otherViews);
  assert.equal(resistor(samePhoto).status, "correct");
  assert.match(resistor(samePhoto).evidence, /Chỉ 1 trong 3 góc chụp/);
  const conflict = [...otherViews.slice(0, 2), { ...otherViews[2], assessment: "conflicting" }];
  assert.equal(resistor(makeResult("overlapping_views", proof, conflict)).status, "uncertain");
});

test("chân điện trở cắm trực tiếp được xác nhận bằng nhãn đọc rõ và lỗ liền kề", () => {
  const wire = { ...spot("wire_path", 52, 30), region: { x: 52, y: 30, width: 2, height: 13 } };
  const body = { ...spot("component", 50, 23), region: { x: 50, y: 23, width: 5, height: 8 } };
  const terminal = { ...spot("lead_end", 52, 41, "8"), region: { x: 52, y: 41, width: 3, height: 3 } };
  const pinGeometry = {
    header: "digital_high", contact: { x: 53, y: 43 },
    anchors: [{ pin: "D9", x: 48.5, y: 43 }, { pin: "D8", x: 53, y: 43 }],
  };
  const verify = (parts, geometry = pinGeometry) => finalizeCircuitAnalysis(ledLesson, {
    lessonId: "led", analysisStatus: "ok", checks: [{ criterionId: "power_connection",
      observation: observation("D8", parts, { pinGeometry: geometry }) }],
  }, 3, { singleRead: true }).checks.find(check => check.id === "power_connection");
  const check = verify([body, wire, terminal]);
  assert.equal(check.status, "correct");
  assert.equal(check.ruleEvidence.observed, "D8");
  assert.equal(verify([body, wire, { ...terminal, text: null }]).status, "uncertain");
  assert.equal(verify([body, wire, { ...terminal, text: null }], { ...pinGeometry, printedLabel: "8" }).status, "correct");
  assert.equal(verify([body, wire, { ...terminal, text: "12" }]).status, "uncertain");
  assert.equal(verify([{ ...body, region: { ...body.region, x: 60 } }, wire, terminal]).status, "uncertain");
  const separated = { ...pinGeometry, anchors: [{ ...pinGeometry.anchors[0], pin: "D10" }, pinGeometry.anchors[1]] };
  assert.equal(verify([body, wire, terminal], separated).status, "uncertain");
});

test("giữ vị trí GND đã đọc khi đoạn nối thiếu bằng chứng", () => {
  const start = { ...spot("lead_start", 20, 27), region: { x: 20, y: 27, width: 3, height: 48 } };
  const port = { ...spot("lead_end", 20, 74), region: { x: 20, y: 74, width: 3, height: 5 } };
  const pinGeometry = {
    header: "digital_high", contact: { x: 21, y: 78 }, printedLabel: "GND",
    anchors: [{ pin: "GND", x: 21, y: 78 }, { pin: "D13", x: 25, y: 78 }],
  };
  const verify = (proof, geometry = pinGeometry) => finalizeCircuitAnalysis(ledLesson, {
    lessonId: "led", analysisStatus: "ok",
    checks: [{ criterionId: "ground_connection", observation: observation("GND", proof, { pinGeometry: geometry }) }],
  }, 3, { singleRead: true }).checks.find(check => check.id === "ground_connection");
  assert.equal(verify([start, port, { ...start, part: "wire_path" }]).status, "correct");
  const partial = verify([port]);
  assert.equal(partial.status, "uncertain");
  assert.equal(partial.ruleEvidence.observed, null);
  assert.equal(partial.ruleEvidence.verifiedPort, "GND");
  assert.match(partial.evidence, /Đã xác minh vị trí lỗ GND/);
  assert.equal(verify([port], { ...pinGeometry, printedLabel: "12" }).ruleEvidence.verifiedPort, undefined);
});

test("kết nối D8 dùng bằng chứng đường anode khi cùng ảnh đã xác minh đúng lỗ cắm", () => {
  const pinGeometry = {
    header: "digital_high", contact: { x: 53, y: 43 }, printedLabel: "8",
    anchors: [{ pin: "D9", x: 48.5, y: 43 }, { pin: "D8", x: 53, y: 43 }],
  };
  const port = spot("lead_end", 51, 41, "8");
  const link = { electrode: "anode", imageIndex: 0, terminalLabel: "8" };
  const verify = (connections, pin = pinGeometry, lead = port) => finalizeCircuitAnalysis(ledLesson, {
    lessonId: "led", analysisStatus: "ok", checks: [
      { criterionId: "power_connection", observation: observation("D8", [lead], { pinGeometry: pin }) },
      { criterionId: "led_orientation", observation: observation("anode_to_feed", [], {
        ledTrace: { electrodesImageIndex: 1, connections },
      }) },
    ],
  }, 3, { singleRead: true });
  const power = result => result.checks.find(check => check.id === "power_connection");
  const result = verify([link]);
  assert.equal(power(result).status, "correct");
  assert.equal(power(result).ruleEvidence.ledConnection.terminalLabel, "D8");
  assert.match(power(result).evidence, /đường nối từ anode tới đúng lỗ D8/);
  assert.equal(result.safety.teacherCheckRequired, true);
  assert.equal(power(verify([{ ...link, imageIndex: 1 }])).status, "uncertain");
  assert.equal(power(verify([{ ...link, electrode: "cathode" }])).status, "uncertain");
  assert.equal(power(verify([link, { ...link, electrode: "cathode" }])).status, "uncertain");
  assert.equal(power(verify([link], { ...pinGeometry, printedLabel: "12" })).status, "uncertain");
  assert.equal(power(verify([link], pinGeometry, spot("lead_end", 60, 41, "8"))).status, "uncertain");
});

test("hai góc khác nhau có thể cùng xác nhận khi mỗi lượt có bằng chứng trọn vẹn", () => {
  const first = observation("series", leadProof, { photoReviews: otherViews });
  const fromAnotherView = proof => observation("series", inPhoto(proof, 1), { imageIndex: 1, photoReviews: otherViews });
  const accepted = finalize("resistor_in_series", first, fromAnotherView(leadProof)).check;
  assert.equal(accepted.status, "correct");
  assert.deepEqual([...new Set(accepted.ruleEvidence.visualProof.map(item => item.imageIndex))], [0, 1]);
  assert.equal(finalize("resistor_in_series", first, fromAnotherView(leadProof.slice(1))).check.status, "uncertain");
  const unconfirmedAngle = observation("series", leadProof, { photoReviews: photos });
  assert.equal(finalize("resistor_in_series", unconfirmedAngle, fromAnotherView(leadProof)).check.status, "uncertain");
});

test("nhận diện linh kiện chấp nhận vùng rộng chứa cùng chi tiết, giữ vùng rời ở chưa xác định", () => {
  const small = { ...spot("component", 21, 6), region: { x: 21, y: 6, width: 12, height: 11 } };
  const large = { ...small, region: { x: 20, y: 5, width: 38, height: 41 } };
  const first = observation("visible", [small], { photoReviews: otherViews });
  const second = (region) => observation("visible", [{ ...large, region }], { photoReviews: otherViews });
  assert.equal(finalize("component_visibility", first, second(large.region)).check.status, "correct");
  assert.equal(finalize("component_visibility", first, second({ ...large.region, x: 60 })).check.status, "uncertain");
});

test("ba góc bổ sung vẫn đạt khi hai lượt xác nhận hai đầu và các vùng đường dây chồng lên nhau", () => {
  const photoReviews = photos.map(photo => ({ ...photo, assessment: "supports" }));
  const [start, end, wire] = leadProof;
  const source = [{ ...start, imageIndex: 0 }, { ...end, imageIndex: 2 }];
  const options = { method: "overlapping_views", imageIndex: 2, otherImageIndex: 0, photoReviews };
  const first = observation("series", [...source, { ...wire, imageIndex: 1 }], options);
  const wider = { ...wire, imageIndex: 1, region: { x: 22, y: 24, width: 14, height: 20 } };
  const second = observation("series", [...source, wider], options);
  assert.equal(finalize("resistor_in_series", first, second).check.status, "correct");
  const unrelated = { ...wider, region: { ...wider.region, x: 50 } };
  assert.equal(finalize("resistor_in_series", first,
    observation("series", [...source, unrelated], options)).check.status, "uncertain");
});

test("Arduino chỉ chấp nhận hai góc riêng khi cùng xác minh lỗ cắm theo mốc", () => {
  const geometry = {
    header: "digital_high",
    anchors: [{ pin: "GND", x: 30, y: 45 }, { pin: "D13", x: 34, y: 45 }, { pin: "D11", x: 42, y: 45 }],
    contact: { x: 30, y: 45 },
  };
  const first = observation("GND", leadProof, { photoReviews: otherViews, pinGeometry: geometry });
  const fromAnotherView = pinGeometry => observation("GND", inPhoto(leadProof, 1),
    { imageIndex: 1, photoReviews: otherViews, pinGeometry });
  assert.equal(finalize("ground_connection", first, fromAnotherView(geometry)).check.status, "correct");
  assert.equal(finalize("ground_connection", first, fromAnotherView(null)).check.status, "uncertain");
  const disagrees = { ...geometry, contact: { x: 38, y: 45 } };
  assert.equal(finalize("ground_connection", first, fromAnotherView(disagrees)).check.status, "uncertain");
});

test("AI tự tin 99% nhưng chỉ thấy một bản cực thì giữ chưa xác định", () => {
  const incomplete = observation("cathode_to_feed", electrodes.slice(0, 1));
  const { result, check } = finalize("led_orientation", incomplete, incomplete);
  assert.equal(result.evidencePolicy, "direct_only");
  assert.equal(result.checks.length, ledLesson.checkList.length);
  assert.equal(check.status, "uncertain");
  assert.equal(check.region, null);
  assert.equal(check.ruleEvidence.observed, null);
  assert.ok(!JSON.stringify(result).includes("Claim never published verbatim"));
  assert.ok(!result.captureAdvice.includes("Unverified capture advice"));
});

test("xác nhận chiều LED từ cùng một ảnh rõ nếu hai lượt cùng thấy hai bản cực và lần đủ hai chân", () => {
  const visible = observation("anode_to_feed", electrodes);
  const { check } = finalize("led_orientation", visible, visible);
  assert.equal(check.status, "correct");
  assert.equal(check.ruleEvidence.visualProof.length, 4);
  assert.equal(check.photoReviews[0].assessment, "supports");
  assert.equal(check.photoReviews[2].assessment, "unclear");
});

test("hai lượt nhìn hai vùng khác nhau hoặc khoanh ngoài chi tiết thì bỏ tọa độ phỏng đoán", () => {
  const clear = observation("cathode_to_feed", electrodes);
  const shifted = electrodes.map(item => ({ ...item, region: { ...item.region, x: item.region.x + 15 } }));
  const uncertain = finalize("led_orientation", clear, observation("cathode_to_feed", shifted)).check;
  assert.equal(uncertain.status, "uncertain");
  assert.equal(uncertain.region, null);
  const mismatch = finalize("led_orientation", clear,
    observation("cathode_to_feed", electrodes, { region: { x: 1, y: 1, width: 4, height: 5 } })).check;
  assert.equal(mismatch.status, "possible_error");
  assert.equal(mismatch.region, null);
  assert.deepEqual(circuitAnnotation(mismatch, 3), { kind: "error", imageIndex: 0, region: electrodes[0].region });
});

test("lưu vùng cận chưa đọc được trị số mà không đổi kết luận", () => {
  const reviewTarget = { imageIndex: 0, region: { x: 35, y: 40, width: 7, height: 8 } };
  const response = { lessonId: batteryLesson.id, analysisStatus: "insufficient_image", checks: [{
    criterionId: "resistor_present", observation: observation(null, [], {
      method: "uncertain", confidence: 0.35, imageIndex: null, region: null, reviewTarget,
    }),
  }] };
  const result = finalizeCircuitAnalysis(batteryLesson, response, 3, { singleRead: true });
  const check = result.checks.find(item => item.id === "resistor_present");
  assert.equal(check.status, "uncertain");
  assert.equal(check.region, null);
  assert.deepEqual(check.reviewArea, reviewTarget);
  assert.deepEqual(circuitAnnotation(check, 3), { kind: "review", ...reviewTarget });
});

test("điện áp cần trị số và đơn vị thực sự đọc được trên nguồn đang nối", () => {
  const path = spot("wire_path", 35, 55);
  const guessed = observation(5, [spot("printed_value", 20, 60, "9V"), path]);
  assert.equal(finalize("power_voltage", guessed, guessed).check.status, "uncertain");
  const label = observation(5, [spot("printed_value", 20, 60, "5 V"), path]);
  assert.equal(finalize("power_voltage", label, label).check.status, "correct");
});

test("điện trở cần đủ vạch màu hoặc con số in trên thân", () => {
  const path = spot("wire_path", 35, 55);
  const guessed = observation(220, [spot("resistor_bands", 20, 60), path]);
  assert.equal(finalize("resistor_present", guessed, guessed).check.status, "uncertain");
  const readBands = observation(null, [spot("resistor_bands", 20, 60), path],
    { resistorBands: ["đỏ", "đỏ", "nâu", "vàng kim"] });
  assert.equal(finalize("resistor_present", readBands, readBands).check.ruleEvidence.observed, 220);
  const different = observation(null, inPhoto(readBands.visualProof, 1),
    { imageIndex: 1, photoReviews: otherViews, resistorBands: ["cam", "cam", "nâu", "vàng kim"] });
  const discrepancy = finalize("resistor_present", { ...readBands, photoReviews: otherViews }, different).check;
  assert.equal(discrepancy.status, "uncertain");
  assert.match(discrepancy.evidence, /mâu thuẫn/);
});

test("ảnh không dùng để loại trừ chập và một lượt đọc không đủ chấm", () => {
  const image = observation("separate", [spot("feed_terminal", 30, 16), spot("return_terminal", 20, 30)]);
  const noShort = finalize("no_short_circuit", image, image);
  assert.equal(noShort.check.status, "uncertain");
  assert.match(noShort.check.evidence, /kiểm tra mạch thật/);
  assert.equal(noShort.check.ruleEvidence.physicalCheckRequired, true);
  assert.equal(noShort.result.checks.find(check => check.id === "power_voltage").ruleEvidence.physicalCheckRequired, true);
  assert.ok(noShort.result.captureAdvice.every(tip => !/nhãn nguồn|hai đường nguồn và GND/.test(tip)));
  assert.equal(noShort.result.verdict, "review");
  const visible = observation("visible", [spot("component", 20, 30)]);
  assert.equal(finalize("component_visibility", visible, null).check.status, "uncertain");
});
