import assert from "node:assert/strict";
import test from "node:test";
import { mergeArduinoPinDetailReview, resolveArduinoUnoPin, UNO_PIN_GEOMETRY_SCHEMA } from "../server/ai/arduino-pin-geometry.js";
import { reconcileCircuitRecheck } from "../server/ai/circuit-observations.js";
import { finalizeCircuitAnalysis } from "../server/ai/finalize-analysis.js";
import ledLesson from "../server/lessons/led.js";

// Approximate points measured on the close view of the LED submission.
const ledSocket = {
  header: "digital_high",
  anchors: [
    { pin: "GND", x: 34.5, y: 56.4 },
    { pin: "D13", x: 37.6, y: 56.3 },
    { pin: "D11", x: 43.8, y: 56.1 },
  ],
  contact: { x: 40.7, y: 56.2 },
};

test("lần lỗ D12 giữa D13 và D11 trên hàng có GND", () => {
  const mapped = resolveArduinoUnoPin(ledSocket);
  assert.equal(mapped.pin, "D12");
  assert.deepEqual(mapped.anchors, ["GND", "D13", "D11"]);
  assert.ok(mapped.region.x < ledSocket.contact.x && mapped.region.x + mapped.region.width > ledSocket.contact.x);
  assert.ok(mapped.region.width < 3.2);
});

test("đọc theo trật tự chân khi ảnh xoay 180 độ", () => {
  const rotate = ({ x, y, ...rest }) => ({ ...rest, x: 100 - x, y: 100 - y });
  const reversed = { ...ledSocket, anchors: ledSocket.anchors.map(rotate).reverse(), contact: rotate(ledSocket.contact) };
  assert.equal(resolveArduinoUnoPin(reversed).pin, "D12");
});

test("bỏ vị trí giữa hai lỗ, lệch khỏi hàng và ngoài đoạn được quan sát", () => {
  for (const contact of [{ x: 39.2, y: 56.3 }, { x: 40.7, y: 51 }, { x: 47, y: 56 }]) {
    assert.equal(resolveArduinoUnoPin({ ...ledSocket, contact }), null);
  }
});

test("bỏ tọa độ khi ba mốc thuộc các hàng khác nhau hoặc sai thứ tự khoảng cách", () => {
  for (const anchor of [{ pin: "D6", x: 37.6, y: 56.3 }, { pin: "D13", x: 41, y: 56.3 }]) {
    assert.equal(resolveArduinoUnoPin({ ...ledSocket, anchors: [ledSocket.anchors[0], anchor, ledSocket.anchors[2]] }), null);
  }
});

test("schema giới hạn mốc theo đúng cụm Arduino và cho phép xác nhận D8 ở mép", () => {
  const high = UNO_PIN_GEOMETRY_SCHEMA.anyOf.find(schema => schema.properties?.header.enum.includes("digital_high"));
  const allowed = high.properties.anchors.items.properties.pin.enum;
  assert.ok(allowed.includes("D8"));
  assert.ok(!allowed.includes("D7"));
  const edge = {
    header: "digital_high",
    anchors: [{ pin: "D10", x: 20, y: 50 }, { pin: "D9", x: 25, y: 50 }, { pin: "D8", x: 30, y: 50 }],
    contact: { x: 30, y: 50 },
  };
  assert.equal(resolveArduinoUnoPin(edge).pin, "D8");
});

test("cả hai lỗ GND trên hàng nguồn cùng trả về GND", () => {
  const header = "power";
  const anchors = [{ pin: "5V", x: 40, y: 70 }, { pin: "GND_5V", x: 43, y: 70 }, { pin: "VIN", x: 49, y: 70 }];
  for (const x of [43, 46]) {
    assert.equal(resolveArduinoUnoPin({ header, anchors, contact: { x, y: 70 } }).pin, "GND");
  }
});

test("đổi tọa độ ảnh cắt về ảnh gốc và giữ mâu thuẫn có bằng chứng", () => {
  const criterionId = "ground_connection";
  const imageIndex = 0;
  const detail = { lessonId: "led", checks: [{ criterionId, observation: { imageIndex, pinGeometry: ledSocket } }] };
  const crops = [{ bounds: { left: 320, top: 240, width: 960, height: 720, imageWidth: 1600, imageHeight: 1200 } }];
  const merged = mergeArduinoPinDetailReview("led", null, detail, crops, [criterionId]);
  const observation = merged.checks[0].observation;
  assert.equal(observation.imageIndex, imageIndex);
  assert.equal(resolveArduinoUnoPin(observation.pinGeometry).pin, "D12");
  assert.equal(observation.pinGeometry.contact.x, 44.42);
  const conflict = { lessonId: "led", checks: [{ criterionId, observation: { photoReviews: [{ assessment: "conflicting" }] } }] };
  assert.equal(mergeArduinoPinDetailReview("led", conflict, detail, crops, [criterionId]), conflict);
});

test("cùng ảnh đã khoanh thì bỏ kết luận có vị trí nằm ngoài vùng giáo viên kiểm tra", () => {
  const criterionId = "ground_connection";
  const observation = {
    method: "single_photo", value: "GND", confidence: 0.94, imageIndex: 0, otherImageIndex: null,
    region: null, detail: "Dây nhìn được tại hàng chân.", resistorBands: null,
    photoReviews: [{ imageIndex: 0, assessment: "supports", detail: "Thấy chi tiết của hàng chân." }],
  };
  const analysis = { lessonId: "led", analysisStatus: "ok", checks: [{ criterionId, observation }] };
  const reviewed = { ...analysis, checks: [{ criterionId, observation: { ...observation, pinGeometry: ledSocket } }] };
  const marked = [{ imageIndex: 0, criterionId, region: { x: 28, y: 54, width: 6, height: 10 } }];
  const conflicted = reconcileCircuitRecheck(ledLesson, analysis, reviewed, [criterionId], 1, marked);
  const check = finalizeCircuitAnalysis(ledLesson, conflicted.analysis, 1).checks[0];
  assert.equal(check.status, "uncertain");
  assert.match(check.evidence, /nằm ngoài vùng giáo viên đã khoanh/);
  assert.equal(check.region, null);
  assert.equal(conflicted.pinLayoutChecks, 0);
});
