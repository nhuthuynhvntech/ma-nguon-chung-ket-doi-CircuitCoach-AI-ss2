import assert from "node:assert/strict";
import { createHmac } from "node:crypto";
import { readFile, readdir } from "node:fs/promises";
import { DatabaseSync } from "node:sqlite";
import test from "node:test";
import worker from "../worker/runtime.js";

test("Một lượt AI đọc mọi góc, dùng lời nhắc và kiểm tra đầu cắm", async t => {
  const db = new DatabaseSync(":memory:");
  t.after(() => db.close());
  const migrations = new URL("../drizzle/", import.meta.url);
  for (const name of (await readdir(migrations)).filter(name => name.endsWith(".sql")).sort()) {
    db.exec(await readFile(new URL(name, migrations), "utf8"));
  }
  const now = new Date().toISOString();
  const classCode = "STEMTEST";
  const group = "nhóm thử";
  const secret = "local-test-classroom-signing-key-only";
  const cookie = `cc_student=${createHmac("sha256", secret).update(JSON.stringify([classCode, group])).digest("base64url")}`;
  db.prepare(`INSERT INTO classroom_attempts(id,class_code,student_id,student_name,created_at,payload_json,updated_at)
    VALUES ('older',?,'old-group','Nhóm khác',?,?,?)`).run(classCode, now, JSON.stringify({
    lessonId: "led", demo: false, teacherVerification: "incorrect", teacherVerifiedAt: now,
    teacherAiError: { criterionId: "ground_connection", reason: "wrong_pin" },
    teacherVerificationNote: "ghi chú lớp dùng để kiểm tra tính riêng tư",
  }), now);
  const examplePhotos = new Map();
  const env = {
    LOCAL_PERSONAL_ACCOUNTS: true, ADMIN_SESSION_SECRET: secret, OPENAI_API_KEY: "mock-key",
    DB: { prepare: sql => ({ bind: (...values) => ({ all: async () => ({ results: db.prepare(sql).all(...values) }) }) }) },
    BUCKET: { get: async key => examplePhotos.get(key) },
  };
  const images = await Promise.all(["closeup", "overview", "diagram"].map(name =>
    readFile(new URL(`../public/images/lesson1-reference-${name}.jpg`, import.meta.url)),
  ));
  const region = { x: 36, y: 40, width: 8, height: 10 };
  const pinGeometry = {
    header: "digital_high",
    anchors: [{ pin: "GND", x: 35, y: 48 }, { pin: "D13", x: 39, y: 48 }, { pin: "D11", x: 47, y: 48 }],
    contact: { x: 43, y: 48 },
  };
  function answer() {
    return {
      lessonId: "led", analysisStatus: "ok", captureAdvice: [],
      checks: [{
        criterionId: "ground_connection",
        observation: {
          method: "single_photo", value, imageIndex: 1, otherImageIndex: null,
          region, confidence: 0.93, detail: "Lần đầu dây tới hàng chân Arduino.",
          resistorBands: null, pinGeometry,
          visualProof: [
            { part: "lead_start", imageIndex: 1, region: { x: 16, y: 20, width: 4, height: 4 }, text: null },
            { part: "lead_end", imageIndex: 1, region: { x: 40, y: 44, width: 7, height: 9 }, text: null },
            { part: "wire_path", imageIndex: 1, region: { x: 16, y: 20, width: 31, height: 32 }, text: null },
          ],
          photoReviews: images.map((_, imageIndex) => ({
            imageIndex, assessment: imageIndex === 1 ? "supports" : "context", detail: "Góc chụp mạch.",
          })),
        },
      }],
    };
  }
  let value = "D12";
  let timedOut = false;
  const requests = [];
  t.mock.method(globalThis, "fetch", async (url, options) => {
    assert.equal(url, "https://api.openai.com/v1/responses");
    const request = JSON.parse(options.body);
    assert.equal(request.text.format.name, "circuit_analysis");
    requests.push(request);
    if (timedOut) throw new DOMException("Timed out", "TimeoutError");
    return Response.json({ output_text: JSON.stringify(answer()) });
  });
  async function analyze({ authorized = true } = {}) {
    const form = new FormData();
    form.set("lessonId", "led");
    form.set("classCode", classCode);
    form.set("studentName", group);
    for (const bytes of images) form.append("images", new Blob([bytes], { type: "image/jpeg" }), "circuit.jpg");
    const headers = authorized ? { cookie } : {};
    const before = requests.length;
    const response = await worker.fetch(new Request("http://circuitcoach.test/api/analyze", { method: "POST", headers, body: form }), env);
    assert.equal(response.status, 200, await response.clone().text());
    assert.equal(requests.length - before, 1);
    return response.json();
  }

  const ground = result => result.checks.find(check => check.id === "ground_connection");
  const result = await analyze();
  assert.equal(result.evidencePolicy, "single_read");
  assert.equal(result.analysisContext.reviewReminders, 1);
  assert.equal(result.analysisContext.pinLayoutChecks, 1);
  assert.equal(ground(result).status, "possible_error");
  assert.equal(ground(result).ruleEvidence.observed, "D12");
  assert.equal(ground(result).imageIndex, 1);
  assert.equal(result.safety.teacherCheckRequired, true);
  assert.match(requests[0].input[0].content.map(item => item.text || "").join("\n"), /Đọc nhầm chân hoặc đường dây/);
  const firstContent = requests[0].input[0].content;
  const originalPhotos = firstContent.filter((item, index) =>
    item.type === "input_image" && firstContent[index - 1]?.text?.startsWith("ẢNH MẠCH HỌC SINH"));
  assert.deepEqual(originalPhotos.map(item => item.image_url), images.map(bytes => `data:image/jpeg;base64,${bytes.toString("base64")}`));
  assert.ok(originalPhotos.every(item => item.detail === "original"));
  const autoCrops = firstContent.filter((item, index) =>
    item.type === "input_image" && /ẢNH CẮT CẬN TỰ ĐỘNG.*imageIndex=[0-2]/.test(firstContent[index - 1]?.text ?? ""));
  assert.equal(autoCrops.length, 2);
  assert.ok(autoCrops.every(item => !originalPhotos.some(photo => photo.image_url === item.image_url)));
  assert.ok(!JSON.stringify(requests[0]).includes("ghi chú lớp dùng để kiểm tra"));

  value = "GND";
  const disputed = await analyze();
  assert.equal(ground(disputed).status, "uncertain");
  assert.equal(ground(disputed).region, null);
  assert.match(ground(disputed).evidence, /chưa khớp/);
  value = "D12";

  const guest = await analyze({ authorized: false });
  assert.equal(guest.analysisContext.reviewReminders, 0);
  assert.ok(!JSON.stringify(requests.at(-1).input).includes("NHẮC KIỂM TRA TỪ PHẢN HỒI"));

  db.prepare("INSERT INTO platform_users(id,username,password_hash,created_at) VALUES ('teacher','teacher','fixture',?)").run(now);
  const sampleWithMarks = db.prepare(`INSERT INTO platform_uploaded_reference_cases
    (id,class_code,lesson_id,criterion_id,label,error_type,evidence,status,created_by,created_at,source_key,annotations_json)
    VALUES (?,'','led','ground_connection','incorrect','miswired','',?,'teacher',?,?,?)`);
  function addMarkedSample(id, status, bytes) {
    sampleWithMarks.run(id, status, now, id, JSON.stringify([
      { kind: "circle", points: [[400, 420], [460, 550]] },
      { kind: "note", points: [[400, 450]], text: "Văn bản chú thích riêng của ca kiểm thử" },
    ]));
    examplePhotos.set("reviewed-examples/" + id, { body: bytes, httpMetadata: { contentType: "image/jpeg" } });
  }
  addMarkedSample("same-view", "approved", images[1]);
  addMarkedSample("other-view", "approved", await readFile(new URL("../public/images/lesson2-reference-arduino.jpg", import.meta.url)));
  addMarkedSample("retired-view", "retired", images[0]);
  addMarkedSample("pending-view", "pending", images[2]);

  const marked = await analyze();
  assert.equal(marked.analysisContext.approvedExamples, 1);
  assert.equal(marked.analysisContext.markedReferences, 1);
  assert.equal(marked.analysisContext.markedViews, 1);
  const content = requests.at(-1).input[0].content;
  assert.equal(content.filter(item => item.type === "input_image").length, 5 + autoCrops.length);
  const text = content.map(item => item.text || "").join("\n");
  assert.match(text, /ẢNH CẬN CỦA ẢNH GỐC imageIndex=1/);
  assert.match(text, /VÙNG GIÁO VIÊN ĐÁNH DẤU TRÊN ẢNH HIỆN TẠI/);
  assert.ok(!text.includes("Văn bản chú thích riêng"));
  assert.equal(ground(marked).ruleEvidence.observed, "D12");

  timedOut = true;
  const missing = await analyze();
  assert.equal(missing.checks.length, 8);
  assert.ok(missing.checks.every(check => check.status === "uncertain" && check.region === null));
  assert.match(missing.summary, /trong thời gian chờ/);
});
