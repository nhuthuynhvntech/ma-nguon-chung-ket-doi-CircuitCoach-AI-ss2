import test from "node:test";
import assert from "node:assert/strict";
import jpeg from "jpeg-js";
import { buildRegionReviewRequest, refineCircuitRegions } from "../server/ai/region-refinement.js";

const photo = new Blob([jpeg.encode({ width: 200, height: 100, data: new Uint8Array(200 * 100 * 4).fill(180) }, 80).data],
  { type: "image/jpeg" });
const original = { x: 40, y: 30, width: 20, height: 20 };

function warning(id, overrides = {}) {
  return { id, label: id, status: "possible_error", evidence: "Kiểm tra đường nối.", imageIndex: 0, region: original, ...overrides };
}

function withChecks(...checks) {
  return { lessonId: "led", verdict: "review", checks };
}

function decision(criterionId, region, confidence = 0.92) {
  return { criterionId, status: region ? "localized" : "not_visible", region, confidence };
}

test("cắt ảnh thật rồi chiếu vùng tinh chỉnh về đúng ảnh và tọa độ gốc", async () => {
  const raw = withChecks(warning("led_orientation", { imageIndex: 1 }));
  const result = await refineCircuitRegions(raw, [photo, photo], {
    started: Date.now(),
    async reviewCrops(crops, signal) {
      assert.equal(crops.length, 1);
      assert.equal(signal.aborted, false);
      const bytes = new Uint8Array(await crops[0].photo.arrayBuffer());
      const cut = jpeg.decode(bytes, { useTArray: true });
      assert.deepEqual([cut.width, cut.height], [68, 34]);
      const payload = await buildRegionReviewRequest("test-model", crops, async () => "crop-only");
      assert.match(payload.input[0].content[0].text, /led_orientation/);
      assert.equal(payload.input[0].content[1].image_url, "crop-only");
      return { checks: [decision("led_orientation", { x: 25, y: 25, width: 50, height: 50 })] };
    },
  });
  assert.equal(result.verdict, "review");
  assert.equal(result.checks[0].imageIndex, 1);
  assert.deepEqual(result.checks[0].region, { x: 41.5, y: 31.5, width: 17, height: 17 });
  assert.deepEqual(result.checks[0].regionRefinement, { outcome: "refined", original });
  assert.deepEqual(result.regionRefinement, { reviewed: 1, refined: 1, photoOnly: 0 });
});

test("ảnh cắt sát cạnh dưới và phải chiếu tọa độ đúng tới mép ảnh", async () => {
  const raw = withChecks(warning("ground_connection", { region: { x: 90, y: 90, width: 10, height: 10 } }));
  const result = await refineCircuitRegions(raw, [photo], {
    started: Date.now(),
    reviewCrops: async () => ({ checks: [decision("ground_connection", { x: 75, y: 75, width: 25, height: 25 })] }),
  });
  const region = result.checks[0].region;
  assert.equal(region.x + region.width, 100);
  assert.equal(region.y + region.height, 100);
  assert.ok(region.width > 0 && region.width < 10);
});

test("dùng chung ảnh cắt cho hai lỗi cùng vị trí và giữ cảnh báo khi không thấy bằng chứng", async () => {
  const raw = withChecks(warning("resistor_present"), warning("resistor_in_series"));
  const result = await refineCircuitRegions(raw, [photo], {
    started: Date.now(),
    reviewCrops: async crops => {
      assert.deepEqual(crops[0].checks.map(check => check.id), ["resistor_present", "resistor_in_series"]);
      assert.equal(crops.length, 1);
      return { checks: [decision("resistor_present", null), decision("resistor_in_series", null, 0.4)] };
    },
  });
  assert.equal(result.checks[0].region, null);
  assert.equal(result.checks[0].status, "possible_error");
  assert.equal(result.checks[0].imageIndex, 0);
  assert.equal(result.checks[0].regionRefinement.outcome, "photo_only");
  assert.equal(result.checks[1], raw.checks[1]);
});

test("giữ vùng đầu khi vùng mới vượt ảnh, rộng hơn hoặc kết quả tiêu chí bị lặp", async () => {
  const raw = withChecks(warning("power_connection"), warning("ground_connection"), warning("led_orientation"));
  const result = await refineCircuitRegions(raw, [photo], {
    started: Date.now(),
    reviewCrops: async () => ({ checks: [
      decision("power_connection", { x: 95, y: 95, width: 15, height: 15 }),
      decision("ground_connection", { x: 0, y: 0, width: 100, height: 100 }),
      decision("led_orientation", null),
      decision("led_orientation", null),
    ] }),
  });
  assert.deepEqual(result.checks, raw.checks);
});

test("giới hạn tối đa ba vùng mỗi lượt và ưu tiên nguy cơ chập mạch", async () => {
  const raw = withChecks(...["resistor_present", "led_orientation", "power_connection", "no_short_circuit"].map((id, index) =>
    warning(id, { region: { ...original, x: 10 + index * 10 } })));
  await refineCircuitRegions(raw, [photo], {
    started: Date.now(),
    reviewCrops: async crops => {
      assert.equal(crops.length, 3);
      assert.equal(crops[0].checks[0].id, "no_short_circuit");
      return { checks: [] };
    },
  }).then(result => assert.equal(result.regionRefinement?.reviewed, 0));
});

test("bỏ qua khi hết thời gian hoặc ảnh lỗi và giữ kết quả khi dịch vụ cận cảnh có lỗi", async () => {
  const raw = withChecks(warning("resistor_present"));
  const broken = new Blob(["not jpeg"], { type: "image/jpeg" });
  let calls = 0;
  const options = { started: Date.now(), reviewCrops: async () => { calls += 1; throw new Error("timeout"); } };
  assert.equal(await refineCircuitRegions(raw, [photo], { ...options, started: Date.now() - 64_000 }), raw);
  assert.equal(await refineCircuitRegions(raw, [broken], options), raw);
  assert.equal(await refineCircuitRegions(raw, [photo], options), raw);
  assert.equal(calls, 1);
});

test("chạy bước cận cảnh cho HC-SR04 khi đã xác định được vùng gốc", async () => {
  const raw = { ...withChecks(warning("trig_connection")), lessonId: "hcsr04" };
  const result = await refineCircuitRegions(raw, [photo], {
    started: Date.now(),
    reviewCrops: async () => ({ checks: [decision("trig_connection", { x: 25, y: 25, width: 50, height: 50 })] }),
  });
  assert.equal(result.checks[0].regionRefinement.outcome, "refined");
});
