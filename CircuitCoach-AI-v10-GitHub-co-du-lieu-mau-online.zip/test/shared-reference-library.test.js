import assert from "node:assert/strict";
import { createHash, randomBytes, randomUUID } from "node:crypto";
import { readFile, readdir } from "node:fs/promises";
import { DatabaseSync } from "node:sqlite";
import test from "node:test";
import worker from "../worker/runtime.js";

test("Kho chung gộp ảnh đã duyệt và giữ quyền quản lý theo nguồn ảnh", async t => {
  const db = new DatabaseSync(":memory:");
  t.after(() => db.close());
  db.exec("PRAGMA foreign_keys=ON");
  const migrations = new URL("../drizzle/", import.meta.url);
  for (const name of (await readdir(migrations)).filter(name => name.endsWith(".sql")).sort()) {
    db.exec(await readFile(new URL(name, migrations), "utf8"));
  }
  const photos = new Map();
  const jpeg = await readFile(new URL("../public/images/lesson1-reference-closeup.jpg", import.meta.url));
  const now = new Date().toISOString();

  function prepare(sql, values = []) {
    return {
      bind: (...args) => prepare(sql, args),
      first: async () => db.prepare(sql).get(...values),
      all: async () => ({ results: db.prepare(sql).all(...values) }),
      run: async () => ({ meta: db.prepare(sql).run(...values) }),
    };
  }
  const env = {
    LOCAL_PERSONAL_ACCOUNTS: true,
    DB: { prepare, batch: writes => Promise.all(writes.map(write => write.run())) },
    BUCKET: {
      get: async key => photos.get(key),
      put: async (key, body, metadata) => photos.set(key, { body: await new Response(body).arrayBuffer(), ...metadata }),
      delete: async key => photos.delete(key),
    },
  };
  function addStaff(id, role, classCode) {
    db.prepare("INSERT INTO platform_users (id,username,password_hash,created_at) VALUES (?,?,?,?)")
      .run(id, id, "unused", now);
    db.prepare("INSERT INTO platform_roles VALUES (?,?)").run(id, role);
    if (classCode) db.prepare("INSERT INTO platform_class_members VALUES (?,?,'teacher')").run(classCode, id);
    const token = randomBytes(32).toString("base64url");
    const tokenHash = createHash("sha256").update(token).digest("base64url");
    db.prepare("INSERT INTO platform_sessions VALUES (?,?,?,?)")
      .run(tokenHash, id, new Date(Date.now() + 60000).toISOString(), now);
    return `cc_staff_${role}=${token}`;
  }
  function addExample(classCode, teacher, status) {
    const id = randomUUID();
    db.prepare(`INSERT INTO platform_uploaded_reference_cases
      (id,class_code,lesson_id,criterion_id,label,evidence,status,created_by,created_at,source_key)
      VALUES (?,?,'led','led_orientation','correct','Ghi chú kiểm duyệt',?,?,?,?)`)
      .run(id, classCode, status, teacher, now, id);
    photos.set("reviewed-examples/" + id, { body: jpeg, httpMetadata: { contentType: "image/jpeg" } });
    return id;
  }

  const staffA = addStaff("teacher-a", "teacher", "LOPA");
  const staffB = addStaff("teacher-b", "teacher", "LOPB");
  const staffWithoutClass = addStaff("teacher-c", "teacher");
  const admin = addStaff("admin", "admin");
  const approvedA = addExample("LOPA", "teacher-a", "approved");
  const approvedB = addExample("LOPB", "teacher-b", "approved");
  const pendingA = addExample("LOPA", "teacher-a", "pending");
  const pendingB = addExample("LOPB", "teacher-b", "pending");

  const origin = "http://circuitcoach.test";
  function call(path, cookie, body) {
    const headers = new Headers({ origin });
    if (cookie) headers.set("cookie", cookie);
    if (typeof body === "string") headers.set("content-type", "application/json");
    return worker.fetch(new Request(origin + path, { method: body ? "POST" : "GET", headers, body }), env);
  }
  const managePath = "/api/classroom/reference-cases?lessonId=led&scope=all";
  const publicPath = "/api/reference-cases?lessonId=led";
  const photoPath = id => `/api/classroom/ai-tracking/photo/${id}?scope=all`;
  const publicPhotoPath = id => `/api/reference-cases/photo/${id}`;
  const decision = (cookie, id, status) => call("/api/classroom/reference-decision", cookie, JSON.stringify({ scope: "all", id, status }));
  const readCases = async (path, cookie) => {
    const response = await call(path, cookie);
    assert.equal(response.status, 200, await response.clone().text());
    return (await response.json()).cases;
  };
  const caseIds = cases => new Set(cases.map(row => row.id));

  assert.deepEqual(caseIds(await readCases(publicPath)), new Set([approvedA, approvedB]));
  assert.equal((await call(managePath)).status, 403);
  const teacherCases = await readCases(managePath, staffA);
  assert.deepEqual(caseIds(teacherCases), new Set([approvedA, approvedB, pendingA]));
  assert.equal(teacherCases.find(row => row.id === pendingA).canManage, true);
  const visibleOnly = teacherCases.find(row => row.id === approvedB);
  assert.equal(visibleOnly.canManage, false);
  assert.equal(visibleOnly.evidence, null);
  assert.equal((await call(photoPath(approvedB), staffA)).status, 200);
  assert.equal((await call(photoPath(pendingB), staffA)).status, 404);
  assert.equal((await call(publicPhotoPath(pendingB))).status, 404);
  assert.equal((await decision(staffA, approvedB, "retired")).status, 404);
  assert.equal((await call(photoPath(pendingB), admin)).status, 200);
  assert.deepEqual(caseIds(await readCases(managePath, admin)), new Set([approvedA, approvedB, pendingA, pendingB]));
  assert.equal((await decision(admin, pendingB, "approved")).status, 200);
  assert.equal((await decision(admin, pendingB, "approved")).status, 409);
  const oldClassPath = "/api/classroom/reference-cases?lessonId=led&classCode=LOPA";
  assert.deepEqual(caseIds(await readCases(oldClassPath, staffA)), new Set([approvedA, pendingA]));

  const form = new FormData();
  form.set("lessonId", "led");
  form.set("criterionId", "led_orientation");
  form.set("label", "correct");
  form.set("image", new Blob([jpeg], { type: "image/jpeg" }), "circuit.jpg");
  const uploadPath = "/api/classroom/reference-upload?scope=all";
  assert.equal((await call(uploadPath, admin, form)).status, 403);
  const upload = await call(uploadPath, staffWithoutClass, form);
  assert.equal(upload.status, 201, await upload.clone().text());
  const uploaded = (await readCases(managePath, staffWithoutClass)).find(row => row.status === "pending");
  assert.equal(uploaded?.canManage, true);
  assert.equal(db.prepare("SELECT class_code FROM platform_uploaded_reference_cases WHERE id=?").get(uploaded.id).class_code, "");
  assert.equal((await call(photoPath(uploaded.id), staffB)).status, 404);
  assert.equal((await decision(staffWithoutClass, uploaded.id, "approved")).status, 200);
  assert.equal((await call(publicPhotoPath(uploaded.id))).status, 200);
  assert.ok(caseIds(await readCases(managePath, staffB)).has(uploaded.id));
  assert.equal((await decision(staffWithoutClass, uploaded.id, "retired")).status, 200);
  assert.equal((await call(publicPhotoPath(uploaded.id))).status, 404);
  assert.ok(photos.has("reviewed-examples/" + uploaded.id));
});
