import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { analyzeImages } from "../src/services/api.js";
import worker, { sanitizeAttempt } from "../worker/runtime.js";

test("model đã chọn được gửi từ giao diện và giữ lại trong kết quả", async (t) => {
  const image = await readFile(new URL("../public/images/lesson2-reference-arduino.jpg", import.meta.url));
  const file = new File([image], "arduino.jpg", { type: "image/jpeg" });
  const origin = "https://fixture.circuitcoach.test";
  const env = { OPENAI_API_KEY: "fixture", OPENAI_ANALYZE_MODEL: "gpt-configured-fixture" };
  const called = [];
  t.mock.method(globalThis, "fetch", async (url, options) => {
    if (url === "/api/analyze") return worker.fetch(new Request(origin + url, options), env);
    assert.equal(url, "https://api.openai.com/v1/responses");
    const payload = JSON.parse(options.body);
    called.push(payload.model);
    assert.equal(payload.text.format.type, "json_schema");
    return Response.json({ output_text: JSON.stringify({
      lessonId: "hcsr04", analysisStatus: "insufficient_image", checks: [{ criterionId: "trig_connection" }],
    }) });
  });
  const health = await (await worker.fetch(new Request(origin + "/api/health"), env)).json();
  assert.deepEqual(health.analysisModels, ["gpt-configured-fixture", "gpt-5.6-terra", "gpt-6.1-terra", "gpt-6.2-sol"]);
  assert.equal(health.analyzeModel, "gpt-configured-fixture");
  const analyze = (analysisModel) => analyzeImages({ lessonId: "hcsr04", files: [file], analysisModel });
  await assert.rejects(analyze("gpt-6.2-terra"), { code: "INVALID_ANALYSIS_MODEL" });
  assert.deepEqual(called, []);
  assert.equal((await analyze()).analysisModel, health.analyzeModel);
  assert.equal((await analyze("gpt-6.1-terra")).analysisModel, "gpt-6.1-terra");
  const sol = await analyze("gpt-6.2-sol");
  assert.equal(sol.analysisModel, "gpt-6.2-sol");
  assert.deepEqual(called, [health.analyzeModel, "gpt-6.1-terra", "gpt-6.2-sol"]);

  const attempt = { id: "a1", classCode: "DEMO921", studentId: "group1", studentName: "Nhóm 1", lessonId: "hcsr04", problems: sol.checks };
  assert.equal(sanitizeAttempt({ ...attempt, analysisModel: sol.analysisModel }).analysisModel, "gpt-6.2-sol");
  assert.equal(sanitizeAttempt({ ...attempt, analysisModel: "gpt-6.2-terra" }).analysisModel, undefined);
  assert.equal(sanitizeAttempt({ ...attempt, analysisModel: sol.analysisModel, demo: true }).analysisModel, undefined);
  assert.equal(sanitizeAttempt(attempt).analysisModel, undefined);
});
