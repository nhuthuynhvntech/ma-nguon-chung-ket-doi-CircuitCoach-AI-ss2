import test from "node:test";
import assert from "node:assert/strict";
import { sanitizeAttempt } from "../worker/runtime.js";

test("Worker chuẩn hóa mã lớp và giữ dữ liệu cần cho dashboard", () => {
  const result = sanitizeAttempt({ id: "a1", studentId: "g1", studentName: "Nhóm 1", classCode: " demo921 ", lessonId: "led", time: new Date().toISOString(), problems: [], verdict: "review" });
  assert.equal(result.classCode, "DEMO921");
  assert.equal(result.studentName, "Nhóm 1");
});

test("Worker từ chối mã lớp không hợp lệ", () => {
  assert.throws(() => sanitizeAttempt({ id: "a1", studentId: "g1", studentName: "Nhóm 1", classCode: "a!", lessonId: "led", problems: [] }), /Mã lớp/);
});

test("Worker giữ nhận xét giáo viên trong giới hạn an toàn", () => {
  const result = sanitizeAttempt({ id: "a2", studentId: "g2", studentName: "Nhóm 2", classCode: "DEMO921", lessonId: "led", problems: [], teacherComment: "Làm tốt, kiểm tra lại cực LED." });
  assert.equal(result.teacherComment, "Làm tốt, kiểm tra lại cực LED.");
});

test("Worker không nhận xác nhận giáo viên từ dữ liệu học sinh gửi lên", () => {
  const result = sanitizeAttempt({ id: "a2b", studentId: "g2b", studentName: "Nhóm 2B", classCode: "DEMO921", lessonId: "led", problems: [], teacherVerification: "correct", teacherVerifiedBy: "GV", teacherVerifiedAt: new Date().toISOString() });
  assert.equal(result.teacherVerification, null);
  assert.equal(result.teacherVerificationNote, "");
  assert.equal(result.teacherVerifiedBy, null);
  assert.equal(result.teacherVerifiedAt, null);
});

test("Worker không nhận số ảnh tự khai khi học sinh lưu lượt phân tích", () => {
  const result = sanitizeAttempt({ id: "a3", studentId: "g3", studentName: "Nhóm 3", classCode: "DEMO921", lessonId: "led", problems: [], imageCount: 9 });
  assert.equal(result.imageCount, 0);
});

test("Worker chỉ lưu số lượng ngữ cảnh tham chiếu hợp lệ trên lượt thật", () => {
  const input = { id: "a4", studentId: "g4", studentName: "Nhóm 4", classCode: "DEMO921", lessonId: "led", problems: [] };
  const analysisContext = { approvedExamples: 2, reviewReminders: 1, privateNote: "Ghi chú lớp" };
  assert.equal(sanitizeAttempt({ ...input, evidencePolicy: "single_read" }).evidencePolicy, "single_read");
  assert.equal(sanitizeAttempt({ ...input, evidencePolicy: "single_read", demo: true }).evidencePolicy, undefined);
  assert.deepEqual(sanitizeAttempt({ ...input, analysisContext }).analysisContext, { approvedExamples: 2, reviewReminders: 1 });
  assert.equal(sanitizeAttempt({ ...input, analysisContext, demo: true }).analysisContext, undefined);
  assert.equal(sanitizeAttempt({ ...input, analysisContext: { approvedExamples: 4, reviewReminders: 1 } }).analysisContext, undefined);
});
