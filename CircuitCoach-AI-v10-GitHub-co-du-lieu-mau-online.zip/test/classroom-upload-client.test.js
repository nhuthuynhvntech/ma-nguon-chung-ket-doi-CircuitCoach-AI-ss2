import test from "node:test";
import assert from "node:assert/strict";
import { File } from "node:buffer";
import { uploadAttemptImages } from "../src/services/classroom.js";

test("client gửi ảnh bằng multipart tới đúng lượt kiểm tra", async () => {
  const originalFetch = globalThis.fetch;
  let captured;
  globalThis.fetch = async (url, options) => {
    captured = { url, options };
    return new Response(JSON.stringify({ imageCount: 1 }), { status: 200, headers: { "content-type": "application/json" } });
  };
  try {
    const result = await uploadAttemptImages("attempt-1", "DEMO921", [new File([new Uint8Array([1, 2, 3])], "mach.jpg", { type: "image/jpeg" })]);
    assert.equal(result.imagesSynced, true);
    assert.equal(captured.url, "/api/classroom/attempts/attempt-1/images");
    assert.equal(captured.options.method, "POST");
    assert.equal(captured.options.body.get("classCode"), "DEMO921");
    assert.equal(captured.options.body.getAll("images").length, 1);
  } finally {
    globalThis.fetch = originalFetch;
  }
});
