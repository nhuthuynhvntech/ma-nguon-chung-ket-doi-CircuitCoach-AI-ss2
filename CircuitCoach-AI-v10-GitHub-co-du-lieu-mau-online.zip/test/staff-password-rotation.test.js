import assert from "node:assert/strict";
import { createHash, pbkdf2Sync } from "node:crypto";
import { readFile } from "node:fs/promises";
import { DatabaseSync } from "node:sqlite";
import test from "node:test";
import worker from "../worker/runtime.js";

test("đổi mật khẩu ngắn chỉ áp dụng cho hai tài khoản cấu hình khi bật đợt đổi", async t => {
  const db = new DatabaseSync(":memory:");
  t.after(() => db.close());
  db.exec(await readFile(new URL("../drizzle/0001_platform.sql", import.meta.url), "utf8"));
  const currentPassword = "mat-khau-hien-tai";
  const replacement = "564372";
  const salt = Buffer.alloc(16);
  const currentHash = `p100.${salt.toString("base64url")}.${pbkdf2Sync(currentPassword, salt, 100_000, 32, "sha256").toString("base64url")}`;
  const token = "a".repeat(43);
  const now = new Date().toISOString();
  for (const [name, role] of [["admin", "admin"], ["gv", "teacher"], ["gv-khac", "teacher"]]) {
    db.prepare("INSERT INTO platform_users (id,username,password_hash,created_at) VALUES (?,?,?,?)").run(name, name, currentHash, now);
    db.prepare("INSERT INTO platform_roles VALUES (?,?)").run(name, role);
  }
  db.prepare("INSERT INTO platform_sessions VALUES (?,'admin',?,?)")
    .run(createHash("sha256").update(token).digest("base64url"), new Date(Date.now() + 60_000).toISOString(), now);
  const env = {
    CIRCUITCOACH_HOSTED_ACCOUNTS: "true",
    ADMIN_USERNAME: "admin",
    TEACHER_USERNAME: "gv",
    DB: {
      prepare: sql => ({ bind: (...args) => ({
        first: async () => db.prepare(sql).get(...args),
        run: async () => ({ meta: db.prepare(sql).run(...args) }),
      }) }),
      batch: steps => Promise.all(steps.map(step => step.run())),
    },
  };
  const origin = "https://circuitcoach.test";
  const send = (path, method, body) => worker.fetch(new Request(origin + "/api/classroom/" + path, {
    method, body: JSON.stringify(body),
    headers: { origin, "Content-Type": "application/json", cookie: `cc_staff_admin=${token}`, "CF-Connecting-IP": "rotation-fixture" },
  }), env);
  const resetTeacher = id => send("admin/accounts", "PATCH", { id, password: replacement });
  const changeAdmin = previous => send("admin/password", "POST", { currentPassword: previous, password: replacement });

  assert.equal((await resetTeacher("gv")).status, 400);
  assert.equal((await changeAdmin(currentPassword)).status, 400);
  env.CIRCUITCOACH_STAFF_ROTATION_PASSWORD = replacement;
  assert.equal((await resetTeacher("gv-khac")).status, 400);
  assert.equal((await changeAdmin("nhap-sai")).status, 401);
  assert.equal((await resetTeacher("gv")).status, 200);
  assert.equal((await changeAdmin(currentPassword)).status, 200);
  assert.equal(db.prepare("SELECT COUNT(*) AS count FROM platform_sessions").get().count, 0);
  const hashes = db.prepare("SELECT password_hash FROM platform_users WHERE username IN ('admin','gv')").all();
  assert.ok(hashes.every(user => user.password_hash !== currentHash));
  assert.notEqual(hashes[0].password_hash, hashes[1].password_hash);
  assert.equal(db.prepare("SELECT password_hash FROM platform_users WHERE username='gv-khac'").get().password_hash, currentHash);
});
