import test from "node:test";
import assert from "node:assert/strict";
import { saveTeacherComment } from "../src/views/teacher.js";

test("lưu nhận xét không phụ thuộc event.currentTarget sau khi chờ API", async () => {
  const attempts = [{ id: "attempt-1", teacherComment: "" }];
  let received;
  const publish = async (attemptId, classCode, updates, teacherPassword, teacherUsername) => {
    await Promise.resolve();
    received = { attemptId, classCode, updates, teacherPassword, teacherUsername };
    return { attempt: { id: attemptId, teacherComment: updates.teacherComment } };
  };

  await saveTeacherComment({
    attemptId: "attempt-1",
    classCode: "DEMO921",
    teacherUsername: "GV",
    teacherPassword: "Teacher-Test-2026!",
    comment: "Ảnh chụp chưa rõ",
    attempts,
    publish,
  });

  assert.deepEqual(received, {
    attemptId: "attempt-1",
    classCode: "DEMO921",
    updates: { teacherComment: "Ảnh chụp chưa rõ" },
    teacherPassword: "Teacher-Test-2026!",
    teacherUsername: "GV",
  });
  assert.equal(attempts[0].teacherComment, "Ảnh chụp chưa rõ");
});
