import test from "node:test";
import assert from "node:assert/strict";
import { CIRCUIT_LESSON_SPECS } from "../src/data/circuit-rules.js";
import { getLesson as getBrowserLesson } from "../src/data/lessons.js";
import { getLesson, listLessons } from "../server/lessons/index.js";
import { buildAnalyzeInput } from "../server/ai/analyze-prompt.js";
import { CIRCUIT_ANALYSIS_JSON_SCHEMA } from "../server/ai/circuit-observations.js";
import { finalizeCircuitAnalysis } from "../server/ai/finalize-analysis.js";

const region = { x: 28, y: 32, width: 9, height: 14 };

function observed(value, overrides = {}) {
  return { method: "single_photo", value, imageIndex: 0, otherImageIndex: null, confidence: 0.92,
    region, detail: "Chữ và đầu nối nhìn rõ trên ảnh.", ...overrides };
}

function rawAnalysis(lesson, overrides = {}) {
  const { rules } = CIRCUIT_LESSON_SPECS[lesson.id];
  return {
    lessonId: lesson.id, analysisStatus: "ok", captureAdvice: [],
    checks: lesson.checkList.map(({ id }) => ({
      criterionId: id, observation: observed(rules[id].expected ?? rules[id].min, overrides[id]),
    })),
  };
}

const check = (result, id) => result.checks.find(item => item.id === id);
const photoReview = (imageIndex, assessment, detail = "Nhìn thấy phần mạch liên quan.") => ({ imageIndex, assessment, detail });

test("cả 38 tiêu chí dùng cấu hình chung với sơ đồ hiển thị và được chấm theo quan sát hợp lệ", () => {
  assert.deepEqual(CIRCUIT_ANALYSIS_JSON_SCHEMA.properties.checks.items.required, ["criterionId", "observation"]);
  let count = 0;
  for (const lesson of listLessons()) {
    const display = getBrowserLesson(lesson.id);
    const ids = lesson.checkList.map(item => item.id);
    assert.deepEqual(display.expectedConnections, lesson.expectedConnections);
    assert.deepEqual(display.checks.map(item => item[0]), ids);
    assert.deepEqual(Object.keys(CIRCUIT_LESSON_SPECS[lesson.id].rules), ids);
    const prompt = buildAnalyzeInput(lesson);
    assert.ok(ids.every(id => prompt.includes(id)));
    const result = finalizeCircuitAnalysis(lesson, rawAnalysis(lesson), 1);
    assert.equal(result.verdict, "pass");
    assert.equal(result.checks.length, ids.length);
    assert.ok(result.safety.teacherCheckRequired);
    assert.ok(result.checks.every(item => item.status === "correct" && item.ruleEvidence.observed !== null));
    assert.ok(result.checks.every(item => !item.evidence.includes("Chỉ 1 trong")));
    count += ids.length;
  }
  assert.equal(count, 38);
});

test("chân HC-SR04 đổi chỗ được cảnh báo riêng trên đúng ảnh chứa đầu cắm", () => {
  const lesson = getLesson("hcsr04");
  const photoReviews = [photoReview(0, "supports"), photoReview(1, "supports")];
  const result = finalizeCircuitAnalysis(lesson, rawAnalysis(lesson, {
    trig_connection: { value: "D10", method: "overlapping_views", imageIndex: 1, otherImageIndex: 0, photoReviews },
    echo_connection: { value: "D9", method: "matching_marker", otherImageIndex: 1, photoReviews },
  }), 2);
  const trig = check(result, "trig_connection");
  const echo = check(result, "echo_connection");
  assert.deepEqual([trig.status, echo.status], ["possible_error", "possible_error"]);
  assert.deepEqual([trig.imageIndex, echo.imageIndex], [1, 0]);
  assert.deepEqual(trig.region, region);
  assert.equal(trig.ruleEvidence.expected, "chân D9 trên Arduino");
  assert.match(trig.evidence, /Ảnh 2.*D10.*D9/);
  assert.match(result.summary, /TRIG.*ECHO/);
});

test("kiểm tra đúng chân phân biệt D8, D6 và A0 theo từng bài", () => {
  for (const [lessonId, criterion, expected, value] of [
    ["led", "power_connection", "D8", "D10"],
    ["servo", "signal_connection", "D6", "D5"],
    ["soil-moisture", "moisture_signal_connection", "A0", "A1"],
    ["soil-moisture", "moisture_signal_connection", "A0", "digital_output"],
  ]) {
    const lesson = getLesson(lessonId);
    const result = finalizeCircuitAnalysis(lesson, rawAnalysis(lesson, { [criterion]: { value } }), 1);
    const outcome = check(result, criterion);
    assert.equal(result.verdict, "review");
    assert.equal(outcome.status, "possible_error");
    assert.equal(outcome.ruleEvidence.expected, `chân ${expected} trên Arduino`);
    assert.equal(outcome.ruleEvidence.observed, value);
  }
});

test("thiếu đầu dây rõ ràng thì cảnh báo, vùng ngoài ảnh không được vẽ", () => {
  const lesson = getLesson("hcsr04");
  const result = finalizeCircuitAnalysis(lesson, rawAnalysis(lesson, {
    echo_connection: { value: "open", imageIndex: 1, region: { x: 94, y: 32, width: 10, height: 14 },
      photoReviews: [photoReview(0, "context"), photoReview(1, "supports")] },
  }), 2);
  const echo = check(result, "echo_connection");
  assert.equal(echo.status, "possible_error");
  assert.equal(echo.imageIndex, 1);
  assert.equal(echo.region, null);
  assert.match(echo.evidence, /đang bỏ trống/);
});

test("giữ trạng thái chưa xác định nếu bằng chứng yếu, tên chân hoặc chỉ số ảnh sai", () => {
  const lesson = getLesson("servo");
  for (const invalid of [
    { method: "single_photo", otherImageIndex: 1 },
    { method: "overlapping_views", otherImageIndex: 0 },
    { method: "matching_marker", otherImageIndex: 1, confidence: 0.79 },
    { method: "overlapping_views", imageIndex: 2, otherImageIndex: 1 },
    { value: "D99" }, { confidence: 0.62 }, { detail: "" },
    { method: "uncertain", value: "D6" },
  ]) {
    const photoReviews = [photoReview(0, "supports"), photoReview(1, "supports")];
    const result = finalizeCircuitAnalysis(lesson, rawAnalysis(lesson, { signal_connection: { photoReviews, ...invalid } }), 2);
    const signal = check(result, "signal_connection");
    assert.equal(signal.status, "uncertain");
    assert.equal(signal.region, null);
    assert.equal(result.verdict, "review");
  }
});

test("đối chiếu toàn cảnh và hai ảnh cận rồi chỉ khoanh ảnh có đầu cắm đọc được", () => {
  const lesson = getLesson("hcsr04");
  const photoReviews = [
    photoReview(0, "supports", "Toàn cảnh cho thấy đường dây chạy qua phần trùng với hai ảnh cận."),
    photoReview(1, "supports", "Thấy đầu dây cắm vào chân TRIG trên cảm biến."),
    photoReview(2, "supports", "Thấy đầu dây tương ứng cắm vào D10 trên Arduino."),
  ];
  const result = finalizeCircuitAnalysis(lesson, rawAnalysis(lesson, {
    trig_connection: { value: "D10", method: "overlapping_views", imageIndex: 2, otherImageIndex: 1, photoReviews },
  }), 3);
  const trig = check(result, "trig_connection");
  assert.equal(trig.status, "possible_error");
  assert.equal(trig.imageIndex, 2);
  assert.deepEqual(trig.region, region);
  assert.deepEqual(trig.photoReviews, photoReviews);
  assert.match(trig.evidence, /Ảnh 3 đối chiếu với ảnh 1 và ảnh 2/);
  assert.doesNotMatch(trig.evidence, /Chỉ 1 trong/);
});

test("chấp nhận kết quả đúng hoặc có lỗi từ một góc rõ và ghi lưu ý về bằng chứng", () => {
  const lesson = getLesson("led");
  for (const [value, status, expectedRegion] of [["D8", "correct", null], ["D10", "possible_error", region]]) {
    const photoReviews = [
      photoReview(0, "unclear", "Trông như chân D9 nhưng chữ nhòe."),
      photoReview(1, "context", "Thấy đường đi dây nhưng chưa đọc được chữ."),
      photoReview(2, "supports", `Thấy cả đường nối từ điện trở và đầu dây cắm ở ${value}.`),
    ];
    const result = finalizeCircuitAnalysis(lesson, rawAnalysis(lesson, {
      power_connection: { value, imageIndex: 2, photoReviews },
    }), 3);
    const power = check(result, "power_connection");
    assert.equal(power.status, status);
    assert.deepEqual(power.region, expectedRegion);
    assert.equal(power.imageIndex, expectedRegion ? 2 : null);
    assert.deepEqual(power.photoReviews, photoReviews);
    assert.match(power.evidence, /^Ảnh 3 .*Chỉ 1 trong 3 góc chụp có đủ bằng chứng/);
  }
});

test("chấm đúng từ ba phần bằng chứng ghép được, dù ảnh toàn cảnh mờ nhãn chân", () => {
  const lesson = getLesson("hcsr04");
  const photoReviews = [
    photoReview(0, "supports", "Mờ nhãn chân, nhưng vẫn thấy đường dây nối giữa hai đoạn dây trong hai ảnh cận."),
    photoReview(1, "supports", "Thấy đầu dây ở TRIG và đoạn dây dẫn ra phần trùng với ảnh toàn cảnh."),
    photoReview(2, "supports", "Thấy đầu dây ở D9 và đoạn dây dẫn vào phần trùng với ảnh toàn cảnh."),
  ];
  const detail = "Lần từ đầu TRIG ở ảnh 2 qua đoạn dây ở ảnh 1 tới đầu cắm D9 ở ảnh 3.";
  const result = finalizeCircuitAnalysis(lesson, rawAnalysis(lesson, {
    trig_connection: { value: "D9", method: "overlapping_views", imageIndex: 2, otherImageIndex: 0, photoReviews, detail },
  }), 3);
  const trig = check(result, "trig_connection");
  assert.equal(trig.status, "correct");
  assert.equal(trig.region, null);
  assert.deepEqual(trig.photoReviews, photoReviews);
  assert.match(trig.evidence, /Ảnh 3 đối chiếu với ảnh 1 và ảnh 2.*Lần từ đầu TRIG ở ảnh 2 qua đoạn dây ở ảnh 1 tới đầu cắm D9 ở ảnh 3/);
  assert.doesNotMatch(trig.evidence, /Chỉ 1 trong/);
});

test("đọc mã màu 330 Ω từ ảnh cận, đối chiếu vị trí lắp qua hai góc còn lại", () => {
  const lesson = getLesson("led");
  const photoReviews = [
    photoReview(0, "supports", "Thấy điện trở mắc giữa dây xoắn và hàng chân Arduino; vạch màu có thể nhận ra một phần."),
    photoReview(1, "supports", "Ảnh cận cho thấy rõ điện trở với các vạch màu cam–cam–nâu–vàng kim."),
    photoReview(2, "supports", "Thấy điện trở nằm trên nhánh nối từ LED tới hàng chân digital."),
  ];
  const resistorBands = ["cam", "cam", "nâu", "vàng kim"];
  const raw = rawAnalysis(lesson, {
    resistor_present: {
      value: null, method: "overlapping_views", imageIndex: 1, otherImageIndex: 2,
      photoReviews, resistorBands, detail: "Đối chiếu thân điện trở và dây xoắn ở cùng vị trí trên nhánh LED.",
    },
  });
  const result = finalizeCircuitAnalysis(lesson, raw, 3);
  const resistor = check(result, "resistor_present");
  assert.equal(resistor.status, "correct");
  assert.equal(resistor.region, null);
  assert.equal(resistor.ruleEvidence.observed, 330);
  assert.equal(resistor.ruleEvidence.tolerance, 5);
  assert.deepEqual(resistor.ruleEvidence.resistorBands, resistorBands);
  assert.match(resistor.evidence, /Ảnh 2 đối chiếu với ảnh 1 và ảnh 3 cho thấy 330 Ω.*cam–cam–nâu–vàng kim.*±5%/);
  assert.equal(check(result, "power_connection").status, "uncertain");
});

test("mã màu 5 vạch ngoài ngưỡng được cảnh báo, mã đọc thiếu hoặc mâu thuẫn giữ chưa xác định", () => {
  const lesson = getLesson("led");
  for (const [resistorBands, value, status, nominal] of [
    [["vàng", "tím", "đen", "đen", "nâu"], null, "possible_error", 470],
    [["cam", "cam", "nâu"], null, "uncertain", null],
    [["cam", "cam", "nâu", "vàng"], null, "uncertain", null],
    [["cam", "cam", "nâu", "vàng kim"], "missing", "uncertain", null],
  ]) {
    const raw = rawAnalysis(lesson, { resistor_present: { value, resistorBands, photoReviews: [photoReview(0, "supports")] } });
    const resistor = check(finalizeCircuitAnalysis(lesson, raw, 1), "resistor_present");
    assert.equal(resistor.status, status);
    assert.equal(resistor.ruleEvidence.observed, nominal);
  }
});

test("thiếu góc, trùng ảnh, ghép góc thiếu bằng chứng và ảnh mâu thuẫn đều không được khoanh", () => {
  const lesson = getLesson("hcsr04");
  const primary = photoReview(0, "supports");
  const second = photoReview(1, "supports");
  const third = photoReview(2, "unclear", "Chưa đọc được nhãn chân trong ảnh này.");
  for (const [photoReviews, evidence] of [
    [[primary, second], /Chưa có nhận xét đầy đủ/],
    [[primary, second, second], /Chưa có nhận xét đầy đủ/],
    [[primary, photoReview(1, "context"), third], /chưa đủ căn cứ/],
    [[primary, second, photoReview(2, "conflicting", "Ảnh cận cho thấy đầu dây cắm vào chân khác.")], /mâu thuẫn/],
  ]) {
    const raw = rawAnalysis(lesson, {
      trig_connection: { value: "D10", method: "matching_marker", otherImageIndex: 1, photoReviews },
    });
    raw.checks = raw.checks.filter(row => row.criterionId === "trig_connection");
    const result = finalizeCircuitAnalysis(lesson, raw, 3);
    const trig = check(result, "trig_connection");
    assert.equal(trig.status, "uncertain");
    assert.equal(trig.imageIndex, null);
    assert.equal(trig.region, null);
    assert.match(trig.evidence, evidence);
    assert.ok(result.captureAdvice.some(tip => tip.includes("TRIG")));
  }
});

test("pin 9V cần đủ bằng chứng về trị số điện trở", () => {
  const lesson = getLesson("battery-led-switch");
  const wrong = finalizeCircuitAnalysis(lesson, rawAnalysis(lesson, { resistor_present: { value: 220 } }), 1);
  assert.equal(check(wrong, "power_voltage").status, "possible_error");
  assert.equal(check(wrong, "power_voltage").ruleEvidence.requiredCriterion, "resistor_present");
  assert.match(check(wrong, "power_voltage").evidence, /9 V.*220 Ω/);
  const unknown = finalizeCircuitAnalysis(lesson, rawAnalysis(lesson, { resistor_present: { value: null } }), 1);
  assert.equal(check(unknown, "power_voltage").status, "uncertain");
  const withLargerResistor = finalizeCircuitAnalysis(lesson, rawAnalysis(lesson, { resistor_present: { value: 1000 } }), 1);
  assert.equal(check(withLargerResistor, "power_voltage").status, "correct");
});

test("ghi rõ không nhìn thấy và vẫn trả nhận xét khi chỉ vài tiêu chí có bằng chứng", () => {
  const lesson = getLesson("soil-moisture");
  const raw = rawAnalysis(lesson, { probe_connection: { method: "not_visible", value: null },
    moisture_signal_connection: { value: "A1" } });
  raw.checks = raw.checks.filter(row => ["probe_connection", "moisture_signal_connection"].includes(row.criterionId));
  const result = finalizeCircuitAnalysis(lesson, raw, 1);
  assert.equal(result.analysisStatus, "insufficient_image");
  assert.equal(check(result, "probe_connection").status, "not_visible");
  assert.equal(check(result, "moisture_signal_connection").status, "possible_error");
  assert.equal(result.verdict, "review");
  assert.ok(result.safety.missingIds.includes("power_voltage"));
});

test("tiêu chí lặp hoặc thuộc bài khác không thể tạo kết luận đạt", () => {
  const lesson = getLesson("led");
  const raw = rawAnalysis(lesson);
  raw.checks.push(raw.checks[1]);
  const result = finalizeCircuitAnalysis(lesson, raw, 1);
  assert.equal(result.verdict, "review");
  assert.equal(check(result, "led_orientation").status, "uncertain");
  assert.deepEqual(result.safety.duplicateIds, ["led_orientation"]);
  assert.throws(() => finalizeCircuitAnalysis(lesson, { ...raw, checks: [{ criterionId: "echo_connection" }] }, 1),
    { code: "AI_SCHEMA_MISMATCH", status: 502 });
});
