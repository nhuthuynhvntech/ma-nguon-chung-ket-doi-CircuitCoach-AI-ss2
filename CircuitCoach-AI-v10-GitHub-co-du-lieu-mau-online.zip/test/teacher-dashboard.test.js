import test from "node:test";
import assert from "node:assert/strict";
import { buildClassReport, commonErrors, deriveAttemptRows, deriveGroupState } from "../src/services/teacher-dashboard.js";

const now = new Date().toISOString();
const attempt = (studentId, overrides = {}) => ({
  id: `${studentId}-1`, studentId, studentName: `Nhóm ${studentId}`, lessonId: "led", time: now,
  analysisStatus: "ok", verdict: "review", problems: [], ...overrides,
});
const issue = (id, label, safetyKind = null, status = "possible_error") => ({ id, label, status, category: safetyKind ? "safety" : "standard", safetyKind });

test("giữ từng lượt làm và đánh số riêng theo lớp, nhóm và bài học", () => {
  const first = attempt("A", { classCode:"DEMO921", time:"2026-11-20T01:00:00Z" });
  const second = attempt("A", { id:"A-2", classCode:"DEMO921", time:"2026-11-20T02:00:00Z", verdict:"pass" });
  const otherLesson = attempt("A", { id:"A-servo", classCode:"DEMO921", lessonId:"servo" });
  const otherClass = attempt("A", { id:"A-other", classCode:"STEM27" });
  const rows = deriveAttemptRows([second,otherClass,otherLesson,first]);
  assert.equal(rows.length,4);
  assert.deepEqual(Object.fromEntries(rows.map(row => [row.latest.id,row.attemptNumber])),{
    "A-1":1, "A-2":2, "A-servo":1, "A-other":1,
  });
  assert.equal(rows.find(row => row.latest.id === "A-1").latest.verdict,"review");
  assert.equal(rows.find(row => row.latest.id === "A-2").latest.verdict,"pass");
});

test("ưu tiên nguy cơ chập mạch cao nhất", () => {
  const groups = deriveGroupState([
    attempt("A", { problems: [issue("no_short_circuit", "Nguy cơ chập", "short_circuit")] }),
    attempt("B", { verdict: "pass", verification: "incorrect" }),
  ]);
  assert.equal(groups[0].id, "A");
  assert.equal(groups[0].status, "danger");
  assert.equal(groups[0].priorityReason, "Nguy cơ chập mạch hoặc sai nguồn");
});

test("AI báo đạt nhưng giáo viên phát hiện lỗi đứng trước nhóm thử nhiều lần", () => {
  const retryAttempts = [1, 2, 3].map((number) => attempt("C", { id: `C-${number}`, time: new Date(Date.now() - number * 1000).toISOString(), problems: [issue("signal", "Dây tín hiệu")] }));
  const groups = deriveGroupState([attempt("B", { verdict: "pass", verification: "incorrect" }), ...retryAttempts]);
  assert.equal(groups[0].id, "B");
  assert.equal(groups[1].id, "C");
});

test("ảnh không rõ và nhóm chờ giáo viên có đúng trạng thái", () => {
  const groups = deriveGroupState([
    attempt("D", { problems: [issue("power", "Kết nối nguồn", "power_polarity", "uncertain")] }),
    attempt("E", { verdict: "pass" }),
  ]);
  assert.equal(groups.find((group) => group.id === "D").status, "retake");
  assert.equal(groups.find((group) => group.id === "E").status, "awaiting_teacher");
});

test("nhóm đã được giáo viên xác nhận chuyển thành đã đạt", () => {
  const [group] = deriveGroupState([attempt("F", { verdict: "pass", teacherStatus: "approved" })]);
  assert.equal(group.status, "passed");
});

test("giáo viên xác nhận AI đúng từ dashboard cũng chuyển nhóm sang đã đạt", () => {
  const [group] = deriveGroupState([attempt("G", { verdict: "pass", teacherVerification: "correct", teacherVerifiedBy: "GV" })]);
  assert.equal(group.status, "passed");
  assert.equal(group.teacherVerification, "correct");
});

test("giáo viên xác nhận AI sai đưa nhóm lên ưu tiên cao", () => {
  const groups = deriveGroupState([
    attempt("H", { verdict: "pass", teacherVerification: "incorrect", teacherVerificationNote: "Thiếu điện trở." }),
    attempt("I", { verdict: "review", problems: [issue("signal", "Dây tín hiệu")] }),
  ]);
  const group = groups.find((item) => item.id === "H");
  assert.equal(group.status, "error");
  assert.equal(group.priority, 400);
});

test("thống kê lỗi chung theo số nhóm", () => {
  const groups = deriveGroupState([
    attempt("A", { problems: [issue("resistor", "Thiếu điện trở", "current_limiting")] }),
    attempt("B", { problems: [issue("resistor", "Thiếu điện trở", "current_limiting")] }),
  ]);
  assert.deepEqual(commonErrors(groups)[0], { id: "resistor", label: "Thiếu điện trở", count: 2, dangerous: true });
});

test("lần kiểm tra bổ sung mới nhất cập nhật lỗi còn lại mà vẫn chờ giáo viên kiểm tra mạch thật", () => {
  const led = issue("led_orientation", "Chiều LED", "led_polarity", "uncertain");
  const safety = { ...issue("no_short_circuit", "Chập mạch", "short_circuit", "uncertain"),
    ruleEvidence: { physicalCheckRequired: true } };
  const good = { id: "later", criterionId: led.id, createdAt: "2026-11-25T01:02:00Z", check: { ...led, status: "correct" } };
  const older = { id: "earlier", criterionId: led.id, createdAt: "2026-11-25T01:00:00Z", check: { ...led, status: "possible_error" } };
  const saved = attempt("A", { problems: [led, safety], latestRechecks: [good, older] });
  const [group] = deriveGroupState([saved]);
  assert.equal(group.status, "awaiting_teacher");
  assert.deepEqual(commonErrors([group]), []);
  assert.equal(saved.problems[0].status, "uncertain");
  const [regression] = deriveGroupState([{ ...saved, latestRechecks: [good, { ...older, createdAt: "2026-11-25T01:04:00Z" }] }]);
  assert.equal(regression.status, "error");
  assert.equal(regression.problems[0].id, "led_orientation");
});

test("báo cáo giáo viên tổng hợp trạng thái, xác nhận và an toàn", () => {
  const report = buildClassReport([
    attempt("A", { verdict: "review", problems: [issue("no_short_circuit", "Nguy cơ chập", "short_circuit")] }),
    attempt("B", { verdict: "pass", teacherVerification: "correct" }),
    attempt("C", { verdict: "pass", teacherVerification: "incorrect" }),
    attempt("D", { problems: [issue("power", "Kết nối nguồn", "power_polarity", "uncertain")] }),
  ]);
  assert.equal(report.totalGroups, 4);
  assert.equal(report.totalAttempts, 4);
  assert.equal(report.statusCounts.danger, 1);
  assert.equal(report.statusCounts.passed, 1);
  assert.equal(report.statusCounts.error, 1);
  assert.equal(report.statusCounts.retake, 1);
  assert.equal(report.verificationCounts.correct, 1);
  assert.equal(report.verificationCounts.incorrect, 1);
  assert.equal(report.verificationCounts.pending, 2);
  assert.equal(report.safety.dangerousGroups, 1);
  assert.equal(report.safety.unclearGroups, 1);
  assert.equal(report.passRate, 25);
  assert.equal(report.verificationRate, 50);
});

test("báo cáo tách hiệu quả theo từng bài học", () => {
  const report = buildClassReport([
    attempt("A", { lessonId: "led" }),
    attempt("B", { lessonId: "servo" }),
    attempt("C", { lessonId: "servo", verdict: "pass", teacherVerification: "correct" }),
  ]);
  assert.equal(report.lessons.length, 2);
  assert.equal(report.lessons.find((lesson) => lesson.lessonId === "servo").attempts, 2);
  assert.equal(report.lessons.find((lesson) => lesson.lessonId === "servo").passed, 1);
});

test("báo cáo rỗng không chia cho 0", () => {
  const report = buildClassReport([]);
  assert.equal(report.totalGroups, 0);
  assert.equal(report.totalAttempts, 0);
  assert.equal(report.passRate, 0);
  assert.equal(report.verificationRate, 0);
});
