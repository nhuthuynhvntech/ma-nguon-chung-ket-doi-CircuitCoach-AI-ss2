import test from "node:test";
import assert from "node:assert/strict";
import { applySafetyPolicy } from "../server/ai/safety-policy.js";
import { finalizeCircuitAnalysis } from "../server/ai/finalize-analysis.js";
import ledLesson from "../server/lessons/led.js";
import { SAFETY_WARNING } from "../src/data/safety.js";

function analysisWith(overrides = {}) {
  return {
    analysisStatus: "ok",
    lessonId: ledLesson.id,
    summary: "Kết quả kiểm thử chính sách an toàn.",
    checks: ledLesson.checkList.map((check) => ({
      id: check.id,
      label: check.label,
      status: overrides[check.id] || "correct",
      certainty: overrides[check.id] ? "medium" : "high",
      evidence: "Bằng chứng kiểm thử.",
      reviewTopic: check.reviewTopic,
    })),
    captureAdvice: [],
  };
}

test("mạch thiếu điện trở không được kết luận đạt", () => {
  const result = applySafetyPolicy(ledLesson, analysisWith({ resistor_present: "possible_error" }));
  assert.equal(result.verdict, "review");
  assert.equal(result.safety.allSafetyPassed, false);
  assert.ok(result.safety.failedIds.includes("resistor_present"));
});

test("mạch có nguy cơ chập không được kết luận đạt", () => {
  const result = applySafetyPolicy(ledLesson, analysisWith({ no_short_circuit: "possible_error" }));
  assert.equal(result.verdict, "review");
  assert.ok(result.safety.failedIds.includes("no_short_circuit"));
});

test("tiêu chí an toàn chưa nhìn rõ không được kết luận đạt", () => {
  const result = applySafetyPolicy(ledLesson, analysisWith({ power_connection: "not_visible" }));
  assert.equal(result.verdict, "review");
  assert.equal(result.safety.imageQualitySufficient, false);
  assert.ok(result.safety.unknownIds.includes("power_connection"));
});

test("chỉ kết luận đạt khi mọi tiêu chí đều đạt", () => {
  const result = applySafetyPolicy(ledLesson, analysisWith());
  assert.equal(result.verdict, "pass");
  assert.equal(result.safety.allSafetyPassed, true);
  assert.equal(result.safety.teacherCheckRequired, true);
});

test("cảnh báo an toàn bắt buộc dùng đúng nội dung", () => {
  assert.equal(SAFETY_WARNING, "AI chỉ hỗ trợ quan sát qua hình ảnh và có thể chưa chính xác hoàn toàn. Cần giáo viên xác nhận trước khi cắm nguồn.");
});

function ledPhotoAnalysis() {
  const values = {
    component_visibility: "visible", led_orientation: "anode_to_feed", resistor_present: 220,
    resistor_in_series: "series", power_connection: "D8", ground_connection: "GND",
    power_voltage: 5, no_short_circuit: "separate",
  };
  return { lessonId: ledLesson.id, analysisStatus: "ok", captureAdvice: [],
    checks: ledLesson.checkList.map(({ id }) => ({
      criterionId: id, observation: { method: "single_photo", value: values[id], imageIndex: 0,
        otherImageIndex: null, confidence: 0.95, region: null, detail: "Bằng chứng nhìn rõ." },
    })) };
}

const observationFor = (raw, id) => raw.checks.find(check => check.criterionId === id).observation;

test("LED chỉ giữ kết luận đạt khi các quan sát hỗ trợ tiêu chí an toàn", () => {
  assert.equal(finalizeCircuitAnalysis(ledLesson, ledPhotoAnalysis(), 1).verdict,"pass");
  const raw = ledPhotoAnalysis();
  observationFor(raw, "resistor_present").value = null;
  observationFor(raw, "led_orientation").imageIndex = 2;
  const result = finalizeCircuitAnalysis(ledLesson, raw, 1);
  assert.equal(result.verdict,"review");
  assert.ok(result.safety.unknownIds.includes("resistor_present"));
  assert.ok(result.safety.unknownIds.includes("led_orientation"));
  assert.ok(result.captureAdvice.some(tip => tip.includes("hai chân LED")));
  assert.ok(result.captureAdvice.some(tip => tip.includes("vạch màu")));
});

test("LED bị đảo cực hoặc có đường nối tắt không được kết luận đạt", () => {
  const raw = ledPhotoAnalysis();
  observationFor(raw, "led_orientation").value = "cathode_to_feed";
  observationFor(raw, "no_short_circuit").value = "bridged";
  const result = finalizeCircuitAnalysis(ledLesson, raw, 1);
  assert.equal(result.verdict,"review");
  assert.ok(result.safety.failedIds.includes("led_orientation"));
  assert.ok(result.safety.failedIds.includes("no_short_circuit"));
  const short = result.checks.find(check => check.id === "no_short_circuit");
  assert.equal(short.imageIndex, 0);
  assert.equal(short.region, null);
});

test("lỗi LED quan sát được giữ vùng trên đúng ảnh và sửa tóm tắt sai", () => {
  const raw = ledPhotoAnalysis();
  const region = { x: 45, y: 24, width: 13, height: 20 };
  Object.assign(observationFor(raw, "led_orientation"), { value: "cathode_to_feed", imageIndex: 1, region,
    photoReviews: [
      { imageIndex: 0, assessment: "context", detail: "Thấy bố cục mạch." },
      { imageIndex: 1, assessment: "supports", detail: "Nhìn rõ cực LED và đường nối." },
    ],
  });
  const result = finalizeCircuitAnalysis(ledLesson, raw, 2);
  const orientation = result.checks.find(check => check.id === "led_orientation");
  assert.equal(result.verdict, "review");
  assert.equal(orientation.status, "possible_error");
  assert.equal(orientation.imageIndex, 1);
  assert.deepEqual(orientation.region, region);
  assert.match(result.summary, /Chiều LED/);
});

test("tọa độ lỗi do quan sát LED vẫn được kiểm tra trước khi hiển thị", () => {
  const raw = ledPhotoAnalysis();
  Object.assign(observationFor(raw, "resistor_present"), { value: 470, region: { x: 95, y: 20, width: 16, height: 24 } });
  const result = finalizeCircuitAnalysis(ledLesson, raw, 1);
  const resistor = result.checks.find(check => check.id === "resistor_present");
  assert.equal(resistor.status, "possible_error");
  assert.equal(resistor.imageIndex, 0);
  assert.equal(resistor.region, null);
  assert.match(resistor.evidence, /470/);
});

test("quan sát LED không nâng tiêu chí chưa rõ thành đạt", () => {
  const raw = ledPhotoAnalysis();
  observationFor(raw, "ground_connection").confidence = .4;
  const result = finalizeCircuitAnalysis(ledLesson,raw,1);
  assert.equal(result.verdict,"review");
  assert.ok(result.safety.unknownIds.includes("ground_connection"));
});
