import test from "node:test";
import assert from "node:assert/strict";
import { lessons } from "../src/data/lessons.js";
import { getBuiltInReferenceImages, mergeReferenceImages } from "../src/services/reference-images.js";

test("mỗi bài học có đúng ba ảnh chuẩn sẵn có", () => {
  for (const lesson of lessons) {
    const references = getBuiltInReferenceImages(lesson);
    assert.equal(references.length, 3, lesson.id);
    assert.ok(references.every((record) => record.builtIn && record.approved && record.src && record.label));
  }
});

test("ảnh giáo viên thay lần lượt ảnh có sẵn nhưng tổng vẫn là ba", () => {
  const custom = [{ id: "custom-1", blob: new Blob(["image"]), approved: true }];
  const references = mergeReferenceImages(lessons[0], custom);
  assert.equal(references.length, 3);
  assert.equal(references[0].id, "custom-1");
  assert.equal(references.filter((record) => record.builtIn).length, 2);
});
