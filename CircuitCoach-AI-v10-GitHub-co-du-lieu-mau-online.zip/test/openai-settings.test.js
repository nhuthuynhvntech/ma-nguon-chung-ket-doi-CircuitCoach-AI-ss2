import test from "node:test";
import assert from "node:assert/strict";
import worker from "../worker/runtime.js";

const origin = "http://127.0.0.1:3190";
const settingsPath = "/api/settings/openai";

test("Người dùng local chưa đăng nhập có thể lưu hoặc dùng lại khóa OpenAI mặc định", async (t) => {
  const defaultKey = "sk-local-default-fixture";
  const customKey = "sk-local-custom-fixture";
  let overrideKey = "";
  const env = {
    LOCAL_PERSONAL_ACCOUNTS: true,
    LOCAL_OPENAI_SETTINGS: {
      async read() { return { defaultKey, overrideKey }; },
      async write(key) { overrideKey = key; },
    },
  };
  const send = (path, { method = "GET", cookie, body, source = origin } = {}, bindings = env) =>
    worker.fetch(new Request(origin + path, {
      method,
      headers: { ...(source ? { origin: source } : {}), "content-type": "application/json", ...(cookie ? { cookie } : {}) },
      body: body === undefined ? undefined : JSON.stringify(body),
    }), bindings);
  const settings = (apiKey, options) =>
    send(settingsPath, { method: "PUT", body: { apiKey }, ...options });

  assert.equal((await send(settingsPath, {}, {})).status, 404);
  assert.equal((await send(settingsPath, { method: "PUT", body: { apiKey: customKey } }, {})).status, 404);
  assert.equal((await settings(customKey, { source: "https://example.com" })).status, 403);
  assert.equal((await settings(customKey, { source: null })).status, 403);
  assert.equal((await settings(undefined)).status, 400);
  assert.equal((await settings("khóa không hợp lệ")).status, 400);
  assert.equal(overrideKey, "");
  const browserSession = await (await send("/api/classroom/browser-session")).json();
  assert.equal(browserSession.role, null);
  assert.equal(browserSession.localOpenAISettings, true);
  assert.deepEqual(await (await send(settingsPath)).json(), { keySource: "default" });

  const expectedHeaders = [];
  t.mock.method(globalThis, "fetch", async (url, options) => {
    assert.equal(url, "https://api.openai.com/v1/responses");
    expectedHeaders.push(options.headers.authorization);
    return Response.json({ output_text: JSON.stringify({ answer: "Gợi ý kiểm tra LED." }) });
  });
  const askAI = () => send("/api/guide-chat", {
    method: "POST",
    body: { lessonId: "led", messages: [{ role: "user", content: "Xem chiều LED ở đâu?" }] },
  });

  const saved = await settings(` ${customKey} `);
  assert.equal(saved.status, 200);
  assert.equal(saved.headers.get("cache-control"), "no-store");
  assert.deepEqual(await saved.json(), { keySource: "custom" });
  assert.deepEqual(await (await send(settingsPath)).json(), { keySource: "custom" });
  assert.equal((await askAI()).status, 200);

  assert.deepEqual(await (await settings("", { cookie: `cc_student=${"s".repeat(43)}` })).json(), { keySource: "default" });
  assert.equal((await askAI()).status, 200);
  assert.deepEqual(expectedHeaders, [`Bearer ${customKey}`, `Bearer ${defaultKey}`]);
});

test("Khóa riêng trên Sites chỉ áp dụng cho phiên trình duyệt đã nhập khóa", async (t) => {
  const hostedOrigin = "https://circuitcoach.example";
  const defaultKey = "sk-site-default-fixture";
  const customKey = "sk-test-browser-key-fixture";
  const env = {
    CIRCUITCOACH_HOSTED_ACCOUNTS: "true",
    CLASSROOM_SESSION_SECRET: "test-secret-for-browser-openai-settings".repeat(2),
    OPENAI_API_KEY: defaultKey,
  };
  const send = (path, { method = "GET", cookie, body, source = hostedOrigin } = {}, bindings = env) =>
    worker.fetch(new Request(hostedOrigin + path, {
      method,
      headers: { origin: source, "content-type": "application/json", ...(cookie ? { cookie } : {}) },
      body: body === undefined ? undefined : JSON.stringify(body),
    }), bindings);
  const sourceOf = async (cookie) => (await (await send(settingsPath, { cookie })).json()).keySource;
  const setKey = (apiKey, source) => send(settingsPath, { method: "PUT", body: { apiKey }, source });
  assert.equal(await sourceOf(), "default");
  const session = await (await send("/api/classroom/browser-session")).json();
  assert.equal(session.role, null);
  assert.equal(session.localOpenAISettings, false);
  assert.equal(session.browserOpenAISettings, true);
  assert.equal((await setKey(customKey, "https://other.example")).status, 403);
  assert.equal((await setKey("not-an-openai-key")).status, 400);

  const saved = await setKey(` ${customKey} `);
  assert.equal(saved.status, 200);
  assert.equal(saved.headers.get("cache-control"), "no-store");
  assert.deepEqual(await saved.json(), { keySource: "custom" });
  const setCookie = saved.headers.get("set-cookie");
  assert.match(setCookie, /^__Secure-cc_openai=v1\.[\w-]+\.[\w-]+; Path=\/api; HttpOnly; Secure; SameSite=Strict$/);
  assert.ok(!setCookie.includes(customKey));
  const cookie = setCookie.split(";")[0];
  assert.equal(await sourceOf(cookie), "custom");
  assert.equal(await sourceOf(), "default");
  assert.equal(await sourceOf(cookie.replace(/(v1\.)(.)/, (_, prefix, char) => prefix + (char === "a" ? "b" : "a"))), "default");

  const authHeaders = [];
  t.mock.method(globalThis, "fetch", async (url, options) => {
    assert.equal(url, "https://api.openai.com/v1/responses");
    authHeaders.push(options.headers.authorization);
    if (options.headers.authorization === `Bearer ${customKey}`) return Response.json({}, { status: 401 });
    return Response.json({ output_text: JSON.stringify({ answer: "Gợi ý kiểm tra LED." }) });
  });
  const askAI = (browserCookie) => send("/api/guide-chat", {
    method: "POST", cookie: browserCookie,
    body: { lessonId: "led", messages: [{ role: "user", content: "Xem chiều LED ở đâu?" }] },
  });
  const rejected = await askAI(cookie);
  assert.equal(rejected.status, 502);
  assert.equal((await rejected.json()).error.code, "OPENAI_401");
  assert.equal((await askAI()).status, 200);
  assert.deepEqual(authHeaders, [`Bearer ${customKey}`, `Bearer ${defaultKey}`]);
  const clear = await setKey("");
  assert.deepEqual(await clear.json(), { keySource: "default" });
  assert.match(clear.headers.get("set-cookie"), /^__Secure-cc_openai=; Path=\/api; HttpOnly; Secure; SameSite=Strict; Max-Age=0$/);
  const logout = await send("/api/classroom/browser-session", { method: "DELETE", cookie });
  assert.ok(logout.headers.getSetCookie().includes(clear.headers.get("set-cookie")));
  const withoutDefault = { ...env, OPENAI_API_KEY: "" };
  assert.deepEqual(await (await send(settingsPath, {}, withoutDefault)).json(), { keySource: "unconfigured" });
  assert.equal((await (await send("/api/health", { cookie }, withoutDefault)).json()).openaiConfigured, true);
});
