import assert from "node:assert/strict";
import test from "node:test";
import { placeAnnotationBadges } from "../src/views/annotation-placement.js";

function area(number, x, y, width, height) {
  return { number, problems: [{ region: { x, y, width, height } }] };
}

test("dời số sang cạnh khác nếu vị trí ưu tiên che vùng khoanh bên cạnh", () => {
  const focus = area(1, 10, 30, 15, 34);
  const neighbor = area(2, 29, 40, 16, 20);
  assert.equal(placeAnnotationBadges([focus], 240, 160).get(1), "right");
  assert.equal(placeAnnotationBadges([focus, neighbor], 240, 160).get(1), "bottom");
});

test("đặt số ở các cạnh khác nhau nếu nhiều vùng cùng vị trí", () => {
  const first = area(1, 40, 40, 20, 20);
  const second = area(2, 40, 40, 20, 20);
  assert.deepEqual([...placeAnnotationBadges([first, second], 200, 200)], [[1, "top"], [2, "right"]]);
});

test("chỉ dùng chú thích dưới ảnh nếu ảnh quá nhỏ để đặt số cạnh khung", () => {
  const region = area(1, 20, 20, 60, 60);
  assert.equal(placeAnnotationBadges([region], 100, 90).size, 0);
});
