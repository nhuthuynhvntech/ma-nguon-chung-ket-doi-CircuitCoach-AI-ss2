# Local update

- Admin can list and create accounts with a role and class or lesson scope.
- The first admin still uses the existing local provisioning command.
- Students open synchronized attempts with their group name and class
  code on the same local server. Group names are case-insensitive and
  shared names within a class open the same history.
- Class A/B reports show safety misses, failed runs, missing references
  and criterion accuracy by lesson. The report can be downloaded as CSV.
- Real OpenAI verification used project sample images and an isolated
  SQLite database. Both lanes finished, two rows were saved and the
  report counted one paired criterion. Transfer replay was rejected.
- Source backups exclude credentials and runtime data.
