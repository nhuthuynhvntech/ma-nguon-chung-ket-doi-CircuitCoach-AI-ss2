# Giáo viên duyệt ảnh tham chiếu

Bản local đã nạp cập nhật lúc 10:14 ngày 20/11/2026, giờ Việt Nam. Mã nguồn dựa trên commit `3fcb319` và các thay đổi local. [Trang Giáo viên](http://127.0.0.1:3187/#/teacher)

## Cách dùng

1. Đăng nhập Giáo viên, chọn lớp, bấm **Duyệt ảnh** và chọn bài học.
2. Mở **Ảnh chờ duyệt**. Bấm vào ảnh để xem rõ tiêu chí và nhãn đã ghi.
3. Chọn **Duyệt** cho ví dụ lấy từ bài nộp. Ảnh này vẫn thuộc phạm vi lớp. Với ảnh giáo viên đã tải trực tiếp, **Duyệt và công khai** cho phép khách xem ảnh trong Kho tham chiếu.
4. Chọn **Từ chối** với ảnh chờ duyệt hoặc **Ngừng dùng** với ảnh đã duyệt. Ảnh ngừng dùng được loại khỏi kho công khai và các lần chọn tham chiếu mới.

## Thay đổi

- Giáo viên xem và duyệt ảnh trong lớp được phân công. Hệ thống ghi người đưa ra quyết định và thời điểm lưu vào cơ sở dữ liệu.
- Quản trị viên có thể tạo tài khoản Giáo viên và Quản trị viên. Đường dẫn Kiểm duyệt cũ chuyển sang trang Giáo viên.
- Giao diện và luồng xử lý nằm trong `src/views/references.js`, `src/views/teacher.js`, `src/views/reference-upload.js`, `src/views/admin.js` và `worker/runtime.js`. Lần cập nhật này dùng cấu trúc cơ sở dữ liệu hiện có.

## Kiểm tra

- Đã kiểm tra trên trình duyệt với dữ liệu thử, từ đăng nhập giáo viên, chọn bài, duyệt ảnh tải trực tiếp, xem ảnh trong kho công khai, đến ngừng dùng. Danh sách vai trò của quản trị viên hiển thị Giáo viên và Quản trị viên.
- Kiểm tra quyền xác nhận giáo viên lớp khác, khách và tài khoản kiểm duyệt cũ không duyệt được. Hai yêu cầu duyệt đồng thời chỉ chấp nhận một quyết định. Ảnh từ bài nộp đã duyệt vẫn chỉ mở được trong lớp.
- Sau khi khởi động lại, bản local trả HTTP 200 cho trang và giao diện. Cơ sở dữ liệu kiểm tra toàn vẹn đạt, giữ 2 lớp, 2 bài làm và 2 ảnh tham chiếu đang chờ duyệt.
- Bộ kiểm tra toàn dự án đạt 46/48. Hai bài kiểm tra cũ còn lỗi ở Thư mục mạch đúng và giới hạn số ảnh dùng chung.

## Sao lưu và khôi phục

- ZIP trước cập nhật nằm trong `backups/CircuitCoach-giao-vien-duyet-anh-20261120-100548-3fcb319-before.zip`.
- ZIP sau cập nhật nằm trong `backups/CircuitCoach-giao-vien-duyet-anh-20261120-100548-3fcb319-after.zip` và kèm tài liệu này. Hai ZIP chứa mã nguồn. Dữ liệu lớp lưu trong thư mục `.data` của bản local.
- Để kiểm tra khôi phục, giải nén ZIP sang thư mục riêng, chạy `npm ci` và `npm run build:sites`. Chạy `npm run local` với `LOCAL_PORT` đặt ở một cổng thử để mở bản vừa khôi phục.
