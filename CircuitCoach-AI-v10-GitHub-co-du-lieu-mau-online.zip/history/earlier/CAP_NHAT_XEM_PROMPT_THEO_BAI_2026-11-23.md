# Xem prompt AI theo từng bài học

CircuitCoach AI đã nạp bản cập nhật local lúc 21:36 ngày 23/11/2026, giờ Việt Nam. Mã nguồn dựa trên commit `3fcb319` và các thay đổi local hiện có. Phạm vi cập nhật là bản local. [Mở trang prompt của bài LED](http://127.0.0.1:3187/#/lesson-prompts/led)

## Cách mở

Từ **Bài học**, bấm **Xem prompt AI** trên thẻ bài hoặc ngay trong trang của bài. Có thể chuyển qua lại giữa năm bài trên trang xem prompt. Mục kết nối và tiêu chí mở sẵn theo bài đang chọn. Các mục còn lại có thể bung ra để đọc toàn bộ văn bản.

Trang hiển thị các kết nối và tiêu chí của bài, prompt phân tích ảnh dùng chung, prompt gợi ý cho học sinh, prompt kiểm tra vùng khoanh và các lời nhắc mẫu theo lỗi giáo viên đã ghi nhận. Chế độ xem sử dụng cùng văn bản và bộ quy tắc trong mã nguồn. Ảnh và lời nhắc thực tế được bổ sung khi một lượt phân tích diễn ra.

## Kiểm tra và khôi phục

- 78 kiểm thử tự động đã đạt. Đã đối chiếu đầy đủ năm bài, xác nhận văn bản yêu cầu phân tích trước và sau cập nhật cho cùng cấu hình giống nhau.
- Đã kiểm tra trên trình duyệt đường vào từ trang bài LED và danh sách năm bài, đổi sang HC-SR04, mở các nhóm prompt và quay lại bài LED. Thay đổi không cần migration cơ sở dữ liệu.
- Thay đổi chính nằm trong `src/views/lesson-prompts.js`, các đường dẫn ở `src/router.js`, `src/views/lessons.js`, `src/views/analyzer.js`, phần hiển thị trong `src/style.css` và phần dùng chung văn bản ở `server/ai`, `worker/runtime.js`, `scripts/build-sites-worker.mjs`.
- Hai gói `CircuitCoach-xem-prompt-theo-bai-20261123-213323-3fcb319-before.zip` và `CircuitCoach-xem-prompt-theo-bai-20261123-213323-3fcb319-after.zip` chứa mã nguồn trước và sau cập nhật. Gói sau kèm ghi chú. Để quay lại, giải nén gói trước vào thư mục riêng, dùng các tệp trước cập nhật, chạy `node scripts/build-sites-worker.mjs` rồi khởi động lại local với dữ liệu hiện có.
