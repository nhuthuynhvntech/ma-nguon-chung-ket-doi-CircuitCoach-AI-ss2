# AI kiểm tra cận cảnh vùng khoanh

Bản local nạp cập nhật lúc 22:42 ngày 22/11/2026, giờ Việt Nam. Mã nguồn dựa trên commit `3fcb319` và các thay đổi local đã có. [Mở bài LED cơ bản](http://127.0.0.1:3187/#/analyzer/led)

## Hoạt động

- Lượt đầu phân tích mạch và xác định ảnh cùng vùng nghi vấn cho từng tiêu chí. Với bài LED cơ bản, ứng dụng cắt tối đa ba vùng có đủ tọa độ và giữ lề để AI nhìn cả chi tiết lẫn đầu nối xung quanh. Hai cảnh báo chung ảnh và chung vùng dùng một ảnh cắt.
- Lượt cận cảnh chỉ định vị bằng chứng. Khung mới được chiếu về đúng ảnh gốc và được dùng khi đủ chắc chắn, hợp lệ và nhỏ hơn khung ban đầu. Khi lượt cận cảnh kết luận chưa thấy bằng chứng định vị, kết quả vẫn giữ cảnh báo và cho mở ảnh liên quan.
- Nếu quá thời gian hoặc không đọc được ảnh, học sinh vẫn nhận kết quả lượt đầu. Ảnh tải từ giao diện được chuẩn hóa thành JPEG trước khi gửi. Bước cắt ảnh trên máy chủ xử lý JPEG.
- Bài nộp giữ tọa độ ban đầu cho các vùng đã được tinh chỉnh hoặc chuyển sang xem ảnh liên quan. Giao diện ghi **Vùng khoanh đã được AI kiểm tra cận cảnh** khi dùng khung mới.
- Hai luồng A/B của bài LED dùng cùng quy tắc định vị. Điểm đúng sai A/B vẫn dựa trên trạng thái từng tiêu chí. Bước định vị chỉ điều chỉnh khung trên ảnh.

## Kết quả kiểm tra

- Đạt 62 bài kiểm thử tự động. Kiểm thử trên bản dựng xác nhận hai lượt phân tích, ảnh cắt thật, quy đổi về đúng ảnh gốc và xử lý vùng sát mép.
- Một lượt phân tích OpenAI thật qua ứng dụng trả về đủ 8 tiêu chí trên ảnh mẫu công khai. Lượt đó chưa có kết quả kiểm tra cận cảnh.
- Trong bài kiểm tra riêng của lượt cận cảnh, OpenAI trả thành công sau khoảng 3,4 giây. Với khung ban đầu giả lập rộng 32% và cao 26% ảnh, AI thu vùng còn khoảng 4,9% chiều rộng và 6,6% chiều cao, vẫn bao vị trí chân D8 dùng làm mốc kiểm tra. Đây là thử nghiệm một vị trí trên ảnh mẫu. Cần đối chiếu với bộ vùng giáo viên gắn nhãn để đo mức cải thiện trên nhiều loại lỗi.
- Cập nhật chạy ở bản local và dùng gói JPEG `jpeg-js` 0.4.4. Thay đổi không cần migration cơ sở dữ liệu.

## Sao lưu và khôi phục

Hai gói `CircuitCoach-khoanh-can-canh-20261122-223505-3fcb319-before.zip` và `CircuitCoach-khoanh-can-canh-20261122-223505-3fcb319-after.zip` lưu mã nguồn trước và sau cập nhật. Gói sau chứa ghi chú này.

Để khôi phục, giải nén bản sao lưu vào thư mục riêng và dùng các tệp mã nguồn, `package.json` và tệp khóa phụ thuộc của bản đó. Cài phụ thuộc theo tệp khóa, chạy `node scripts/build-sites-worker.mjs` rồi khởi động lại bản local. Dữ liệu làm việc nằm trong `.data`.
