# Vai trò đăng nhập trên thanh đầu trang

Bản local chạy trên cổng 3187 lúc 15:18 ngày 20/11/2026, giờ Việt Nam. Mã nguồn dựa trên commit `3fcb319` và các thay đổi local. [Mở CircuitCoach AI](http://127.0.0.1:3187/#/home)

- Thanh đầu trang ghi rõ **Học sinh**, **Giáo viên** hoặc **Quản trị viên**. Tên và mã lớp xuất hiện khi phiên có thông tin tương ứng.
- Chọn **Đăng xuất** ngay trên thanh đầu trang để trở về màn chọn vai trò. Khi một phiên còn hoạt động, màn hình và máy chủ đều chặn chuyển sang vai trò khác. Các tab cùng trình duyệt cập nhật theo phiên.
- Nếu trình duyệt còn nhiều phiên từ bản cũ, hệ thống ưu tiên phiên hợp lệ theo thứ tự Quản trị viên, Giáo viên, Học sinh và xóa dấu phiên còn lại khỏi trình duyệt.
- Đã thử tuần tự ba vai trò trên trình duyệt, kiểm tra chuyển trang và chuyển vai trò ở nhiều tab. Bộ kiểm tra đạt 51/51. Cập nhật dùng cơ sở dữ liệu hiện có.

## Sao lưu

- ZIP trước cập nhật nằm tại `backups/CircuitCoach-vai-tro-tren-header-20261120-151053-3fcb319-before.zip`.
- ZIP sau cập nhật nằm tại `backups/CircuitCoach-vai-tro-tren-header-20261120-151053-3fcb319-after.zip` và kèm tệp này.
- Để thử khôi phục, giải nén mã nguồn vào thư mục riêng, chạy `npm ci`, `npm run build:sites` rồi `npm run local` với `LOCAL_PORT` đặt ở một cổng thử.
