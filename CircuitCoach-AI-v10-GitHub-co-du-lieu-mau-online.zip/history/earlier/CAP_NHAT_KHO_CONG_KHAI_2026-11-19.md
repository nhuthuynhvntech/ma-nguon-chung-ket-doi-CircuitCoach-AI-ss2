# Kho tham chiếu công khai theo bài

Ngày 19/11/2026, giờ Việt Nam. Bản cập nhật chạy tại [Kho tham chiếu local](http://127.0.0.1:3187/#/references). Mã nguồn dựa trên commit `3fcb319` và các thay đổi local. Bản Sites online hiện ở v4.

## Cách xem

- Từ trang đăng nhập, chọn **Kho tham chiếu**, rồi chọn một trong năm bài học. Khách có thể xem và phóng to ảnh, sơ đồ có sẵn, mẫu đúng và mẫu có lỗi đã công khai.
- Ảnh mẫu giáo viên tải trực tiếp xuất hiện sau khi kiểm duyệt viên chọn **Duyệt và công khai**. Thông tin hiện cho khách gồm tiêu chí, nhãn và dạng lỗi.
- Giáo viên mở **Ảnh của lớp** để xem ảnh từ bài nộp, ảnh đang chờ duyệt và ghi chú. Ảnh từ bài nộp thuộc phạm vi lớp. Luồng B tra kho đã duyệt theo lớp và bài học.
- Chọn **Ngừng dùng** để gỡ ảnh khỏi danh sách công khai và dừng phục vụ đường dẫn ảnh công khai.

## Kiểm tra

- Đã mở Kho tham chiếu từ trang đăng nhập trên trình duyệt, thấy đủ năm bài, mở thư mục LED và phóng to sơ đồ với quyền khách.
- Kiểm tra HTTP bằng dữ liệu thử xác nhận khách xem được ảnh tải trực tiếp đã duyệt, chỉ nhận dữ liệu tiêu chí và nhãn, không mở được ảnh học sinh, ảnh chờ duyệt hoặc ảnh đã ngừng dùng. Quyền xem trong lớp và luồng B đã được kiểm tra lại với dữ liệu thử.
- Build thành công. Máy chủ local trả HTTP 200 cho kho công khai và HTTP 403 cho đường dẫn kho riêng khi thiếu phiên giáo viên.
- Bộ kiểm tra toàn dự án đạt 46/48. Hai lỗi cũ còn lại liên quan tới ảnh bài nộp.

## Mã nguồn và sao lưu

- `src/views/home.js` thêm lối vào từ trang đăng nhập. `src/views/references.js` hiển thị kho công khai và phần ảnh của lớp. `worker/runtime.js` kiểm tra trạng thái duyệt ngay khi đọc danh sách và khi mở tệp ảnh.
- Cập nhật này dùng dữ liệu hiện có và không đổi cấu trúc SQLite.
- ZIP trước cập nhật nằm tại `backups/CircuitCoach-kho-cong-khai-20261119-220253-3fcb319-before.zip`. ZIP sau cập nhật nằm tại `backups/CircuitCoach-kho-cong-khai-20261119-220253-3fcb319-after.zip` và kèm tệp này.
- Để thử khôi phục, giải nén ZIP vào một thư mục riêng, chạy `npm ci`, `npm run build:sites` rồi `npm run local`. Đặt `LOCAL_PORT` trên một cổng thử.
