# Kho tham chiếu dùng chung theo bài học

Bản cập nhật chạy trên máy ở cổng 3187 lúc 14:22 ngày 20/11/2026, giờ Việt Nam. Mã nguồn dựa trên commit `3fcb319` và các thay đổi local. [Mở kho tham chiếu](http://127.0.0.1:3187/#/references)

## Cách dùng

- Mọi người mở **Kho tham chiếu** và chọn bài học để xem ảnh đã duyệt từ các lớp. Bấm ảnh để phóng to và đọc chú thích đã lưu.
- Giáo viên mở **Duyệt ảnh** và chọn bài học để xử lý ảnh thuộc lớp được phân công. Nút **Duyệt và công khai** đưa bản sao tham chiếu vào kho chung. **Ngừng dùng** rút ảnh khỏi kho chung.
- Luồng B chọn ví dụ đã duyệt theo bài học từ kho chung. Luồng A phân tích độc lập. Bài làm gốc và báo cáo riêng của lớp tiếp tục dùng quyền xem theo lớp.

## Kiểm tra

- Mã xử lý cập nhật tại `worker/runtime.js`, `src/views/references.js`, `src/views/teacher.js` và `src/views/ai-tracking.js`. Cập nhật dùng cấu trúc cơ sở dữ liệu hiện có.
- Đã kiểm tra bản local sau khởi động. Khách mở được cả 6 ảnh tham chiếu đã duyệt. Danh sách công khai trả ảnh, nhãn theo tiêu chí và chú thích. Lượt nộp gốc và ghi chú riêng của giáo viên giữ quyền truy cập hiện có.
- Kiểm thử riêng xác nhận khách không mở ảnh chờ duyệt, bị từ chối hoặc đã ngừng dùng. Giáo viên lớp khác không có quyền duyệt các ảnh này.
- Kiểm thử A/B dùng phản hồi AI mô phỏng. Luồng B chọn được ảnh từ lớp khác cùng bài và loại ảnh của chính lượt thử, ảnh trùng và mạch thuộc bộ kiểm tra. Bộ kiểm tra dự án đạt 48/48. SQLite trả `ok`.

## Sao lưu

- ZIP trước cập nhật nằm trong `backups/CircuitCoach-kho-tham-chieu-chung-20261120-141930-3fcb319-before.zip`.
- ZIP sau cập nhật nằm trong `backups/CircuitCoach-kho-tham-chieu-chung-20261120-141930-3fcb319-after.zip` và kèm tệp này. Các ZIP chứa mã nguồn.
- Để thử khôi phục, giải nén mã nguồn vào thư mục riêng, chạy `npm ci`, `npm run build:sites` và `npm run local` với `LOCAL_PORT` đặt ở một cổng thử.
