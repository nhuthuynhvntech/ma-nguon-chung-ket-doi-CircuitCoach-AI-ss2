# Tách giao diện học sinh theo từng thao tác

CircuitCoach AI đã nạp bản cập nhật local lúc 22:36 ngày 23/11/2026, giờ Việt Nam. Mã nguồn dựa trên commit `3fcb319` và các thay đổi local hiện có. Phạm vi triển khai là bản local. [Mở danh sách bài học](http://127.0.0.1:3187/#/lessons)

## Giao diện học sinh

- Từ danh sách bài, học sinh bấm **Mở bài học**. Bài mở sẵn ở mục **Gửi ảnh** để chọn ảnh, mở camera hoặc yêu cầu phân tích. Phần **Lỗi AI cần chú ý** nằm bên dưới thao tác gửi.
- **Hướng dẫn và ảnh mẫu** chứa sơ đồ, ảnh mẫu, gợi ý góc chụp và đường vào hướng dẫn lắp từng bước. **Tùy chọn AI** chứa chế độ demo, prompt và thao tác ảnh đối chiếu. **Lịch sử bài** mở các lượt đã làm của bài đang học.
- Trang kết quả mở ở **Tóm tắt**. **Ảnh và tiêu chí** chứa ảnh khoanh lỗi, bằng chứng và gợi ý theo tiêu chí. **Phản hồi** chứa nhận xét và xác nhận của giáo viên cùng các nút phản hồi của nhóm. Cảnh báo an toàn nằm ở đầu trang kết quả.

## Kiểm tra và khôi phục

- 78 kiểm thử tự động đã đạt. Đã đối chiếu với bản sao trước cập nhật để xác nhận các tệp xử lý AI, chấm, lưu lịch sử, phân quyền và đoạn gửi ảnh dùng cùng mã nguồn.
- Trình duyệt xác nhận bài mở ở mục gửi ảnh, chuyển mục được bằng bàn phím, giữ tùy chọn demo khi chuyển mục, mở được lịch sử và đọc lại kết quả có ảnh và 8 tiêu chí. Hộp chọn tệp của công cụ thử nghiệm bị treo, nên lần chọn ảnh mới chưa được xác nhận trên trình duyệt.
- Thay đổi ở `src/views/lessons.js`, `src/views/analyzer.js`, `src/views/result.js`, `src/views/student-tabs.js` và `src/style.css`. Cập nhật dùng cơ sở dữ liệu hiện có.
- Hai gói `CircuitCoach-tach-giao-dien-hoc-sinh-20261123-223227-3fcb319-before.zip` và `CircuitCoach-tach-giao-dien-hoc-sinh-20261123-223227-3fcb319-after.zip` lưu mã nguồn trước và sau cập nhật. Gói sau kèm ghi chú. Khi cần khôi phục, giải nén gói trước vào thư mục riêng, dùng mã nguồn trước cập nhật, chạy `node scripts/build-sites-worker.mjs` và khởi động lại với dữ liệu local hiện có.
