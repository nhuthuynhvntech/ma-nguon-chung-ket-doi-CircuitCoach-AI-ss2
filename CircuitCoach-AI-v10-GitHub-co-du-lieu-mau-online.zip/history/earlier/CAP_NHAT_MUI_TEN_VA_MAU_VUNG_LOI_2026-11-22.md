# Mũi tên và màu vùng lỗi của AI

Bản local được nạp lại lúc 22:12 ngày 22/11/2026, giờ Việt Nam. Mã nguồn dựa trên commit `3fcb319` và các thay đổi local đã có. [Mở CircuitCoach AI](http://127.0.0.1:3187/#/home)

## Cách đọc kết quả

- Đầu mũi tên bám vào giữa cạnh khung vùng lỗi. Số vùng giúp tìm nhận xét tương ứng trên ảnh thu nhỏ và ảnh phóng to.
- Vùng và nhận xét dùng cùng màu theo nhóm. Đỏ hồng biểu thị nguy cơ chập mạch, vàng biểu thị nguồn và GND, tím biểu thị chiều LED, xanh ngọc biểu thị điện trở, xanh lam biểu thị dây tín hiệu và kết nối, xám biểu thị linh kiện và các lỗi khác.
- Hai tiêu chí cùng nhóm, cùng ảnh và trùng khung dùng chung một số vùng. Bấm số trên ảnh để làm nổi bật các nhận xét liên quan. Bấm **Xem vùng trên ảnh** trong từng nhận xét để mở riêng vùng đó.
- Ảnh đã lưu trong lịch sử trên thiết bị có thể hiển thị vùng khoanh khi mở lại kết quả.

## Kiểm tra

- Đã mở lại kết quả LED đang xem trong trình duyệt. Bốn cảnh báo hiển thị thành ba vùng. Hai nhận xét về điện trở cùng mang số 1 và có màu xanh ngọc. Kết nối nguồn và GND giữ hai vị trí riêng cùng màu vàng.
- Đã kiểm tra đầu mũi tên bám cạnh khung ở ảnh thường và khi phóng to, thao tác chọn số làm nổi bật cả hai nhận xét chung vùng, và nút **Xem vùng trên ảnh** mở đúng khung đang xem.
- Kiểm thử tự động đạt 56/56. Máy chủ local trả trang chủ và bản dựng đã cập nhật. Bản này thay đổi cách hiển thị vùng AI đã xác định. Cập nhật không cần migration cơ sở dữ liệu.

## Sao lưu và khôi phục

Hai gói `CircuitCoach-mau-vung-loi-20261122-220713-3fcb319-before.zip` và `CircuitCoach-mau-vung-loi-20261122-220713-3fcb319-after.zip` lưu mã nguồn trước và sau cập nhật. Gói sau chứa ghi chú này.

Để khôi phục, giải nén ZIP trước cập nhật vào thư mục riêng. Chép lại `src/views/result.js`, `src/views/photo-tools.js`, `src/router.js` và `src/style.css` vào mã nguồn local, chạy `node scripts/build-sites-worker.mjs` rồi khởi động lại.
