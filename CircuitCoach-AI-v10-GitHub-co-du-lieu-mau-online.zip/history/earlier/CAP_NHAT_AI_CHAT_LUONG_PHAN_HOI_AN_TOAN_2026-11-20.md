# Kiểm tra ảnh và độ chính xác AI

Bản cập nhật chạy trên máy ở cổng 3187 lúc 14:55 ngày 20/11/2026, giờ Việt Nam. Mã nguồn dựa trên commit `3fcb319` và các thay đổi local. [Mở CircuitCoach AI](http://127.0.0.1:3187/#/home)

## Tính năng

- Khi học sinh chọn ảnh, ứng dụng kiểm tra độ sáng, độ phân giải và dấu hiệu thiếu nét. Màn hình chỉ rõ ảnh cần chụp lại. Kết quả **Chưa xác định** gợi ý góc chụp theo từng tiêu chí của bài.
- Với **LED cơ bản**, máy chủ kiểm tra thông tin AI ghi nhận về chiều LED, điện trở, chân D8, GND và đường nguồn. Thiếu bằng chứng trên ảnh thì tiêu chí liên quan chuyển sang **Chưa xác định**. Dấu hiệu như LED ngược cực, điện trở bị nối tắt hoặc đường nguồn có dấu hiệu chập giữ kết quả ở trạng thái cần kiểm tra. Giáo viên kiểm tra trực tiếp mạch thật trước khi cho phép cấp nguồn.
- Trong **Giáo viên → Xem & xác nhận → Kết quả và xác nhận AI**, chọn **AI sai** để ghi tiêu chí và nguyên nhân. Dữ liệu xuất hiện trong **Báo cáo phân tích** của giáo viên và **Tổng quan bài học** của quản trị viên.
- **Theo dõi AI** hiển thị mạch có lỗi an toàn bị báo đạt, cảnh báo nhầm và tiêu chí chưa xác định dù giáo viên đánh dấu ảnh rõ. Số liệu mới được lưu khi cả hai luồng chạy thành công, B dùng ảnh tham chiếu và có nhãn đủ điều kiện đối chiếu.

[Mở Theo dõi AI](http://127.0.0.1:3187/#/ai-progress)

## Số liệu ban đầu và kiểm tra

- Trước cập nhật, hệ thống có 10 bài nộp, 6 ví dụ tham chiếu và 4 bản ghi luồng AI, tương ứng 2 lượt A/B. Có 4 lượt ảnh thật với ít nhất một nhãn giáo viên rõ ràng. Chưa có bộ ảnh kiểm tra cố định hoặc lượt A/B được chấm điểm.
- Dữ liệu ảnh thật hiện có chưa đủ để đo thay đổi độ chính xác trên bộ khoảng 30 ảnh. Thử nghiệm cho luồng B dùng ảnh cận từ vùng giáo viên khoanh thực hiện sau khi có mốc so sánh.
- Đã chạy 51/51 bài kiểm tra, gồm kiểm tra an toàn LED bổ sung. Thử nghiệm trình duyệt dùng dữ liệu mô phỏng để xác nhận cảnh báo ảnh, lưu và mở lại phản hồi giáo viên, báo cáo quản trị và chỉ số A/B.
- Đã thử nâng cấp `0012_ai_comparison_metrics.sql` trên bản sao lưu. Sau khởi động trên cổng 3187, máy chủ tải được trang chủ và báo cáo AI. Dữ liệu hiện có giữ nguyên số bản ghi và tệp ảnh. Cơ sở dữ liệu kiểm tra toàn vẹn đạt.

## Sao lưu và khôi phục

- Mã nguồn trước cập nhật nằm trong `backups/CircuitCoach-ai-chat-luong-phan-hoi-an-toan-20261120-144324-3fcb319-before.zip`.
- Dữ liệu SQLite và ảnh trước cập nhật nằm trong `backups/CircuitCoach-ai-chat-luong-phan-hoi-an-toan-20261120-144324-3fcb319-data-before.zip`. Gói này chứa dữ liệu lớp.
- Mã nguồn sau cập nhật và tệp này nằm trong `backups/CircuitCoach-ai-chat-luong-phan-hoi-an-toan-20261120-144324-3fcb319-after.zip`.
- Để thử khôi phục, giải nén mã nguồn và gói dữ liệu vào thư mục riêng. Chạy `npm ci`, `npm run build:sites`, đặt `LOCAL_PORT` ở cổng thử rồi chạy `npm run local`.
