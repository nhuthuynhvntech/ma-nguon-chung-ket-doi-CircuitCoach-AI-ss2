# Hướng dẫn và kiểm tra tại từng bước lắp mạch

Ngày 19/11/2026, giờ Việt Nam. Bản cập nhật chạy ở [CircuitCoach local](http://127.0.0.1:3187/#/assembly/led). Nền mã nguồn là commit `3fcb319` và các cập nhật local. Bản Sites online hiện ở v4.

- **Cách làm** nằm ngay dưới chỉ báo bước và phía trên sơ đồ. Nội dung ghi rõ thao tác cần thực hiện trước khi chuyển bước.
- **Tự kiểm tra** nằm cạnh phần ghi hai đầu dây. Học sinh dùng mục này để đối chiếu nhãn chân và lần theo đường dây khi mạch đang ngắt nguồn.
- Cả 18 bước của năm bài có hướng dẫn và mục kiểm tra riêng. Hai phần đổi cùng bước đang xem khi điều khiển bằng tay hoặc tự chạy.
- Đã kiểm tra dữ liệu của năm bài, gồm 18 bước và 19 kết nối. Build thành công. Trên trình duyệt, đã xác nhận cả hai nội dung đổi đúng ở bước 2 khi bấm chuyển bước và bước 3 khi tự chạy trong bài LED.
- Cập nhật không thay đổi cấu trúc cơ sở dữ liệu. ZIP trước và sau nằm trong `backups/CircuitCoach-huong-dan-tung-buoc-20261119-231400-3fcb319-before.zip` và `backups/CircuitCoach-huong-dan-tung-buoc-20261119-231400-3fcb319-after.zip`.
- Để thử khôi phục, giải nén ZIP sang thư mục riêng, chạy `npm ci`, `npm run build:sites` và `npm run local` ở một cổng thử.
