# Dùng phản hồi của giáo viên trong lượt phân tích mới

CircuitCoach AI đã chạy bản cập nhật local lúc 15:34 ngày 23/11/2026, giờ Việt Nam. Mã nguồn dựa trên commit `3fcb319` và các thay đổi local hiện có. Bản Sites online vẫn ở phiên bản 4. [Mở CircuitCoach AI local](http://127.0.0.1:3187/#/lessons)

## Giáo viên thao tác thế nào

Mở bài làm, vào **Xem & xác nhận**, chọn **AI sai**, chọn tiêu chí và lý do, rồi bấm **Lưu xác nhận**. Ví dụ, khi giáo viên chọn lý do **Đọc nhầm chân**, lượt phân tích ảnh mới của học sinh cùng lớp và cùng bài nhắc AI lần theo dây đến hai đầu và kiểm tra nhãn chân. Các phản hồi đã có đủ tiêu chí và lý do được đọc ngay từ dữ liệu đã lưu.

## Phản hồi được dùng ra sao

- Trước cập nhật, báo cáo ghi nhận lỗi, còn lượt phân tích thường chưa lấy phản hồi từ cơ sở dữ liệu. Từ bản này, lượt phân tích lấy tối đa 6 điểm cần kiểm tra từ phản hồi của đúng lớp và bài học. Hệ thống ưu tiên tiêu chí an toàn và gom các phản hồi trùng tiêu chí, trùng lý do. Tên học sinh, mã lớp và nhận xét tự do của giáo viên được dùng trong phạm vi ứng dụng.
- Lượt phân tích có thể dùng tối đa 3 ảnh tham chiếu đã duyệt của cùng bài, ưu tiên tiêu chí giáo viên đã báo lỗi. Giáo viên cần đưa ảnh bài làm vào kho và duyệt trước khi ảnh đó được dùng làm mẫu chung. Hệ thống bỏ qua ảnh trùng với ảnh đang chấm và ảnh thuộc bộ đánh giá độc lập.
- Màn hình kết quả hiện số điểm cần kiểm tra và số ảnh đã duyệt mà lượt phân tích đã dùng. Các số này được lưu cùng bài làm khi đồng bộ. AI đối chiếu bằng chứng trên ảnh mới trước khi kết luận.
- Trong báo cáo A/B, luồng A phân tích ảnh cần chấm, luồng B có thêm ảnh tham chiếu đã duyệt. Phép so sánh này đo tác động của ảnh tham chiếu. Mức thay đổi độ chính xác của luồng học sinh cần được đo trên bộ ảnh độc lập do giáo viên gắn nhãn.

## Kiểm tra và khôi phục

- 72 kiểm thử tự động đã đạt. Kiểm thử tích hợp trên cơ sở dữ liệu riêng với phản hồi OpenAI mô phỏng xác nhận số lời nhắc tăng từ 0 lên 1 sau khi giáo viên lưu. Yêu cầu dùng phiên học sinh của lớp khác nhận 0 lời nhắc. Luồng A nhận 0 ảnh tham chiếu, luồng B nhận 1 ảnh phù hợp. Trang chủ, trạng thái máy chủ và báo cáo AI trên bản local đều phản hồi thành công.
- Thay đổi chính nằm ở `worker/runtime.js`, `src/data/ai-error-reasons.js`, các màn hình phân tích, kết quả, giáo viên và phần lưu lịch sử. Cập nhật dùng cơ sở dữ liệu hiện có và không cần migration.
- Hai gói `CircuitCoach-dung-phan-hoi-giao-vien-20261123-152913-3fcb319-before.zip` và `CircuitCoach-dung-phan-hoi-giao-vien-20261123-152913-3fcb319-after.zip` chứa mã nguồn. Gói sau kèm ghi chú này. Dữ liệu làm việc trong `.data` và cấu hình riêng được lưu ngoài hai gói.
- Để khôi phục, giải nén gói trước cập nhật vào thư mục riêng. Hãy khôi phục từ gói các tệp đã sửa trong đợt này, sau đó chạy `node scripts/build-sites-worker.mjs` và khởi động lại máy chủ local với thư mục dữ liệu hiện có.
