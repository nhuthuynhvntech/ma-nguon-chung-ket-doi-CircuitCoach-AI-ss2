# Đọc vạch màu điện trở từ ảnh cận

CircuitCoach AI đã nạp bản cập nhật local lúc 16:16 ngày 23/11/2026, giờ Việt Nam. Mã nguồn dựa trên commit `3fcb319` và các chỉnh sửa local hiện có. Bản Sites online vẫn ở phiên bản 4. [Mở bài LED cơ bản](http://127.0.0.1:3187/#/analyzer/led)

## Cách chấm

- Khi một ảnh cho thấy đủ bốn hoặc năm vạch màu, AI ghi lại thứ tự màu trong dữ liệu quan sát. Các ảnh còn lại có thể xác nhận đó là cùng điện trở nằm trên đường qua LED. Ảnh vạch màu rõ là căn cứ đọc trị số. Các góc khác giúp xác nhận vị trí lắp.
- Máy chủ giải mã trị số danh định và dung sai, rồi đối chiếu với ngưỡng của bài. Dãy **cam–cam–nâu–vàng kim** có trị số **330 Ω** và dung sai **±5%**, đạt tiêu chí **Điện trở hạn dòng** của bài LED cơ bản vì ngưỡng là **220–330 Ω**.
- Khi thiếu vạch, chưa xác định được cùng điện trở hoặc có bằng chứng mâu thuẫn, hệ thống giữ **Chưa xác định**. Nếu đạt, số Ω và dung sai được ghi trong kết quả. Các tiêu chí như mắc nối tiếp, chân D8, GND và chiều LED có đánh giá riêng. Giáo viên xác nhận an toàn trên mạch thật trước khi học sinh cấp nguồn.

## Kiểm tra và khôi phục

78 kiểm thử tự động đã đạt. Kiểm thử tái tạo ba nhận xét mà người dùng nêu, xác nhận máy chủ chấm **Đúng** từ dãy vạch màu và giữ tiêu chí chân Arduino ở **Chưa xác định** khi chưa có bằng chứng dành riêng cho chân đó. Mã 5 vạch đọc thành 470 Ω bị cảnh báo trong bài LED. Mã chưa đủ vạch và dữ liệu mâu thuẫn được giữ ở **Chưa xác định**. Cập nhật có hiệu lực cho các lượt phân tích mới và dùng cơ sở dữ liệu hiện có.

Đã thử OpenAI thật bằng ảnh mẫu trong dự án. Mẫu có vạch khó phân biệt được trả **Chưa xác định**. Mẫu kiểm soát có bốn màu được làm rõ từ ảnh dự án trả đúng thứ tự **cam–cam–nâu–vàng kim**, trị số **330 Ω ±5%** và chấm tiêu chí **Đúng**.

Hai gói `CircuitCoach-doc-vach-dien-tro-20261123-161432-3fcb319-before.zip` và `CircuitCoach-doc-vach-dien-tro-20261123-161432-3fcb319-after.zip` lưu mã nguồn trước và sau cập nhật. Gói sau kèm ghi chú này. Khi cần khôi phục, dùng các tệp trong `server/ai` và `test/circuit-observations.test.js` từ gói trước, chạy `node scripts/build-sites-worker.mjs` rồi khởi động lại máy chủ local với dữ liệu đang có.
