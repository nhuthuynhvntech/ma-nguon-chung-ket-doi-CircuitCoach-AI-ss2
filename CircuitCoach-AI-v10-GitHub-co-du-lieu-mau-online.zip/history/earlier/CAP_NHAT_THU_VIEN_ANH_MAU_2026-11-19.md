# Cập nhật thư viện ảnh mẫu theo bài học

Ngày 19/11/2026, giờ Việt Nam. Bản local tại [CircuitCoach AI](http://127.0.0.1:3187/#/home). Mã nguồn dựa trên commit `3fcb319` và các thay đổi local đang có. Phiên bản online hiện vẫn là v4.

## Thay đổi

- Cả năm bài học có mục **Thư viện ảnh mẫu**. Học sinh trong lớp có thể xem ảnh, phóng to và đọc chú thích.
- Từ trang **Giáo viên**, mở **Thư viện ảnh mẫu**, chọn bài, nhập tên ảnh và tải tệp JPEG, PNG hoặc WebP. Chú thích là tùy chọn. Ảnh được thu nhỏ trước khi gửi. Mỗi lớp có thể hiển thị tối đa 24 ảnh trong một bài.
- Giáo viên chỉ quản lý thư viện lớp được phân công. **Ẩn ảnh** ngừng chia sẻ với học sinh. **Hiện lại ảnh** đưa ảnh trở lại thư viện.
- Ảnh bài học phục vụ quan sát. Kho ví dụ có nhãn để đo A/B vẫn dùng quy trình duyệt riêng.
- Thư viện chính thức đang chờ giáo viên tải ảnh mạch thật. Kiểm tra tải lên dùng dữ liệu riêng.

## Dữ liệu và mã nguồn

- `drizzle/0006_lesson_sample_photos.sql` tạo bảng ghi bài, lớp, người tải, tên ảnh, chú thích, thời điểm tải và trạng thái ẩn. Tệp ảnh nằm trong `.data/images`.
- `worker/runtime.js` xử lý quyền xem, tải và thay đổi hiển thị. `scripts/local-worker.mjs` chuyển tiếp riêng từng cookie phiên đăng nhập.
- `src/views/lesson-samples.js` chứa giao diện thư viện. Trang giáo viên, trang phân tích bài học và hướng dẫn HTML đã có bước mở thư viện.
- Học sinh dùng phiên từ trước bản cập nhật có thể bấm **Kết nối lại thư viện** để đăng nhập lại theo tên nhóm và mã lớp đang dùng.

## Kiểm tra

- Build thành công. Trang chủ và máy chủ local đáp ứng HTTP 200. Kiểm tra toàn vẹn SQLite trả về `ok`.
- Kiểm tra trên bản local riêng qua HTTP. Đã thử cả năm bài học, tải ảnh, đọc chú thích và tải tệp, ngăn lớp khác xem, ngăn học sinh đổi ảnh, ẩn và hiện lại, kiểm tra giới hạn và đọc ảnh sau khi khởi động lại.
- Bộ kiểm tra tổng thể đạt 46/48. Hai kiểm tra cũ còn lỗi ở **Thư mục mạch đúng** và giới hạn số ảnh nộp dùng chung.

## Bản sao lưu và khôi phục

- Mã nguồn trước cập nhật nằm trong `backups/CircuitCoach-anh-mau-20261119-210319-3fcb319-before.zip`.
- Mã nguồn sau cập nhật nằm trong `backups/CircuitCoach-anh-mau-20261119-210319-3fcb319-after.zip`. Bản ZIP chứa tệp cập nhật này.
- Bản chụp SQLite và thư mục ảnh trước khi đổi cấu trúc dữ liệu nằm trong `backups/CircuitCoach-anh-mau-20261119-210319-3fcb319-data-before`. Giữ riêng bản chụp này vì có dữ liệu của lớp.
- Muốn thử khôi phục, giải nén mã nguồn sang thư mục riêng, dùng bản sao cơ sở dữ liệu cùng thư mục ảnh tương ứng và giữ thông tin phiên local đi kèm trong kho riêng. Chạy `npm ci`, `npm run build:sites` và `npm run local`. Với phiên bản trước cập nhật, chọn cổng riêng bằng biến `LOCAL_PORT` để không thay máy chủ đang hoạt động.
