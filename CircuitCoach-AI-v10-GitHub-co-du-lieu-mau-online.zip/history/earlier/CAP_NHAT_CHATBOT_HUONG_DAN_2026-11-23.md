# CircuitCoach AI · Chatbot hướng dẫn

Cập nhật bản local lúc 23:06 ngày 23/11/2026, giờ Việt Nam.

## Cách sử dụng

1. Mở [CircuitCoach](http://127.0.0.1:3187/#/lessons) và chọn **Hỏi trợ lý** trên thanh đầu trang. Nút này cũng có ở màn hình đăng nhập.
2. Nếu đang mở một bài, trợ lý tự chọn bài đó. Có thể đổi sang **Hướng dẫn chung** hoặc chọn một trong năm bài học.
3. Chọn **Gửi ảnh**, **Đọc kết quả**, **Cách lắp mạch** hoặc **An toàn** để xem ngay hướng dẫn có sẵn. Các câu trả lời phù hợp có nút mở trang phân tích hoặc trang lắp mạch.
4. Gõ câu hỏi tiếng Việt để hỏi thêm. Trợ lý dùng hướng dẫn của ứng dụng, các bước lắp và quy tắc của bài được chọn để trả lời. Có thể đóng rồi mở lại hộp thoại để hỏi tiếp trong cùng tab và chủ đề.

## Dữ liệu và hoạt động

- Hội thoại được giữ tạm trong tab đang dùng. Đổi bài trong hộp thoại, đổi phiên đăng nhập hoặc tải lại trang sẽ bắt đầu cuộc trò chuyện mới. Câu hỏi gõ tự do được gửi đến OpenAI để trả lời. Hướng dẫn có sẵn chạy trong trình duyệt.
- Chatbot bổ sung đường dẫn `/api/guide-chat` và dùng mô hình trợ giảng đã cấu hình. Bản cập nhật không cần thay đổi cấu trúc cơ sở dữ liệu.
- Chatbot có thể nhắc các bước kiểm tra. Giáo viên kiểm tra trực tiếp mạch thật và xác nhận trước khi học sinh cấp nguồn.

## Kết quả kiểm tra

- 79 kiểm thử tự động đạt. Bản dựng trang web và máy chủ thành công.
- Trên trang phân tích Servo, hộp thoại tự chọn đúng bài, hiển thị hướng dẫn lắp nhanh, giữ lịch sử khi đóng rồi mở lại và trả lời đúng chân Signal là D6 qua OpenAI.
- Một lượt gọi trực tiếp ở bài HC-SR04 xác nhận trợ lý hiểu câu hỏi tiếp theo và trả lời đúng chân ECHO là D10.

## Sao lưu mã nguồn

- Trước cập nhật `backups/CircuitCoach-chatbot-huong-dan-20261123-230223-3fcb319-before.zip`
- Sau cập nhật `backups/CircuitCoach-chatbot-huong-dan-20261123-230223-3fcb319-after.zip`

Hai tệp ZIP chứa mã nguồn. Khi cần đối chiếu hoặc khôi phục mã, giải nén bản tương ứng vào thư mục riêng. Dữ liệu và cấu hình bí mật được lưu riêng theo thiết lập của dự án.
