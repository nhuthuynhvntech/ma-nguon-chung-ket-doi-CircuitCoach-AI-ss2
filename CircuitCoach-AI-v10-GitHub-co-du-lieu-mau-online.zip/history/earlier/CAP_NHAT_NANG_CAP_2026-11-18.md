# Tien do nang cap

Ngay: 2026-11-18, Asia/Saigon.
Source: sites-online/.sites-checkout.
Sao luu truoc sua: backups/CircuitCoach-before-execution-20261118.zip.

Da them drizzle/0001_platform.sql: tai khoan, vai tro, phien, phan cong, phien ban bai hoc, lich su nhan, vi du, bo danh gia, ket qua A/B va audit.
Da kiem tra migration trong SQLite trong bo nho: tao thanh cong 13 bang, bao gom bang cu.
Migration chi bo sung bang; khong xoa hoac sua du lieu cu.

CHUA ap dung migration production. CHUA trien khai ban moi.
CHUA hoan thanh API dang nhap, phan quyen, giao dien, hai luong AI, bao cao, nhap du lieu cu va sao luu D1/R2.
Khong coi schema nay la chuc nang da hoat dong.
