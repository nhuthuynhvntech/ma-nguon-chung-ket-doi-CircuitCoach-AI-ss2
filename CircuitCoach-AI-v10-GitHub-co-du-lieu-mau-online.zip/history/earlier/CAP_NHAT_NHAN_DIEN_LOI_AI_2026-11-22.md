# Cải thiện nhận diện và đánh dấu lỗi của AI

Bản local nạp cập nhật lúc 21:34 ngày 22/11/2026, giờ Việt Nam. Mã nguồn dựa trên commit `3fcb319` và các thay đổi local đã có. [Mở CircuitCoach AI](http://127.0.0.1:3187/#/home)

## Thay đổi

- Mỗi ảnh bài làm được gửi kèm chỉ số riêng để AI phân biệt các góc chụp và chọn ảnh có bằng chứng rõ nhất. Ảnh tham chiếu có vai trò đối chiếu.
- AI được yêu cầu nêu linh kiện, chân hoặc đoạn dây nhìn thấy. Ảnh bị che được xử lý theo mức **Chưa xác định** hoặc **Không nhìn thấy** ở tiêu chí tương ứng.
- Với bài LED cơ bản, hệ thống đối chiếu kết luận theo tiêu chí với quan sát về chiều LED, điện trở và đường dây. Khi quan sát rõ cho thấy lỗi, hệ thống giữ đúng ảnh và vùng hợp lệ nếu có. Tóm tắt được cập nhật theo các tiêu chí sau khi đối chiếu.
- Màn hình kết quả có nút **Xem vùng trên ảnh** để mở riêng vùng liên quan. Với cảnh báo có ảnh làm căn cứ nhưng chưa có vùng hợp lệ, nút **Xem ảnh liên quan** mở ảnh để đối chiếu.
- Quy tắc được áp dụng trong phân tích mới và hai luồng đánh giá A/B. Giáo viên xác nhận an toàn sau khi kiểm tra mạch thật.

## Kiểm tra

- Bộ kiểm thử tự động đạt 56/56. Bản dựng và kiểm tra máy chủ local thành công.
- Kiểm thử mô phỏng trên bản dựng xác nhận lỗi LED đảo chiều giữ vùng đúng ảnh thứ hai. Cảnh báo chập mạch giữ ảnh thứ nhất và không vẽ khung khi thiếu tọa độ. Vùng vượt mép hoặc bao gần toàn bộ ảnh bị loại.
- Một lượt OpenAI thật với ảnh mẫu công khai đi kèm dự án trả về HTTP 200, 8 tiêu chí và 2 vùng đánh dấu. Đây là kiểm tra kết nối và luồng trả kết quả. Mức thay đổi độ chính xác cần được đo bằng A/B trên bộ ảnh có nhãn giáo viên.
- Bản cập nhật triển khai ở local. Thay đổi không cần migration cơ sở dữ liệu.

## Sao lưu và khôi phục

Hai gói `CircuitCoach-nhan-dien-loi-ai-20261122-212951-3fcb319-before.zip` và `CircuitCoach-nhan-dien-loi-ai-20261122-212951-3fcb319-after.zip` lưu mã nguồn trước và sau cập nhật. Gói sau cập nhật có kèm ghi chú này.

Để khôi phục, giải nén ZIP trước cập nhật vào thư mục riêng, rồi phục hồi các tệp có thay đổi trong `server/ai`, `worker/runtime.js`, `src/views/result.js`, `src/style.css`, `scripts/build-sites-worker.mjs` và hai bài kiểm thử `test/annotation-policy.test.js`, `test/safety-policy.test.js`. Chạy `node scripts/build-sites-worker.mjs` và khởi động lại bản local. Dữ liệu làm việc của dự án nằm trong thư mục `.data`.
