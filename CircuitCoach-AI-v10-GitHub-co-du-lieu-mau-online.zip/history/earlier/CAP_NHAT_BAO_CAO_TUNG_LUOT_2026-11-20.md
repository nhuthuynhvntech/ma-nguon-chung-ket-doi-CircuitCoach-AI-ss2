# Báo cáo thống kê và lịch sử từng lượt làm

Bản local đã chạy trên cổng 3187 lúc 15:35 ngày 20/11/2026, giờ Việt Nam. Mã nguồn dựa trên commit `3fcb319` và các thay đổi local.

## Báo cáo

- **Quản trị viên → Lớp học và báo cáo** có ba mục **Tổng quan hệ thống**, **Năng lực học sinh** và **Năng lực AI**. Bộ lọc hỗ trợ một lớp, tất cả lớp hoặc một bài học. [Mở trang Quản trị](http://127.0.0.1:3187/#/admin)
- **Giáo viên → Báo cáo thống kê** có thể chọn một lớp hoặc tất cả lớp được phân công. Máy chủ kiểm tra phạm vi lớp cho danh sách học sinh, bài nộp, ảnh và thống kê A/B. [Mở báo cáo Giáo viên](http://127.0.0.1:3187/#/teacher-reports)
- Năng lực học sinh được tính từ các nhãn giáo viên trên bài làm thật, có bảng theo bài, tiêu chí và từng học sinh hoặc nhóm. Phần tiến bộ so sánh những tiêu chí có nhãn rõ trong cả lượt đầu và lượt gần nhất được gắn nhãn của cùng nhóm ở một bài.
- Năng lực AI hiển thị kết quả xác nhận đúng sai, nguyên nhân AI sai và thử nghiệm A/B, gồm các chỉ số bỏ sót lỗi an toàn, báo đạt nhầm, cảnh báo nhầm và ảnh rõ vẫn chưa xác định. Báo cáo tổng quan đếm lớp, nhóm, lượt nộp, lượt phân tích, ảnh và mẫu đã duyệt.

## Từng lần làm

- Bảng điều khiển giáo viên hiện một dòng cho mỗi lần làm. Giáo viên có thể mở, nhận xét và xác nhận từng lượt riêng. Lịch sử học sinh và lịch sử riêng của bài cũng hiện **Lần 1**, **Lần 2** và các lần sau với liên kết kết quả riêng.
- Phần báo cáo **Học sinh và bài làm** phân trang từng lượt để xem lịch sử dài hơn. Mỗi báo cáo A/B thống kê lần chạy gần nhất của từng lượt nộp.

## Kiểm tra và sao lưu

- Đã kiểm tra trên trình duyệt bằng dữ liệu thử với nhiều lớp và hai lượt của cùng một bài. Kết quả xác nhận giáo viên chỉ xem lớp được phân công, hai lượt giữ nhận xét riêng và học sinh mở lại được từng lượt. Bộ kiểm tra đạt 52/52.
- Sau khởi động lại, trang chủ và giao diện trả HTTP 200. SQLite kiểm tra toàn vẹn đạt. Có 4 lớp, 10 bài nộp, 6 ảnh tham chiếu và 4 bản ghi luồng AI trước và sau khởi động. Cập nhật dùng cấu trúc cơ sở dữ liệu hiện có.
- ZIP trước cập nhật nằm tại `backups/CircuitCoach-bao-cao-tung-luot-20261120-152532-3fcb319-before.zip`. ZIP sau cập nhật nằm tại `backups/CircuitCoach-bao-cao-tung-luot-20261120-152532-3fcb319-after.zip` và kèm tệp này.
- Để thử khôi phục, giải nén mã nguồn vào thư mục riêng, chạy `npm ci`, `npm run build:sites` rồi `npm run local` với `LOCAL_PORT` đặt ở một cổng thử.
