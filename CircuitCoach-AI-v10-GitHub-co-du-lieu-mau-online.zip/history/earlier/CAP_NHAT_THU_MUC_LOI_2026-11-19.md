# Thư mục lỗi theo từng bài học

Ngày 19/11/2026, giờ Việt Nam. Bản cập nhật chạy ở [Kho tham chiếu local](http://127.0.0.1:3187/#/references). Mã nguồn dựa trên commit `3fcb319` và các cập nhật local. Bản Sites online hiện ở v4.

## Cách xem và thêm ảnh

1. Mở **Kho tham chiếu**, chọn bài học và xem mục **Mẫu có lỗi**.
2. Có sáu thư mục ở mỗi bài. Mỗi thư mục cho biết số ảnh và dấu hiệu để nhận biết dạng lỗi. Khi mở, ảnh được gom theo tiêu chí của bài.
3. Từ một thư mục lỗi, giáo viên bấm **Tải ảnh theo tiêu chí** để mở biểu mẫu điền sẵn bài và dạng lỗi. Chọn tiêu chí, tải ảnh và gửi duyệt.
4. Ảnh đủ điều kiện xuất hiện trong đúng thư mục sau khi duyệt. Khách xem các ảnh mẫu công khai. Giáo viên có mục **Ảnh của lớp** để xem dữ liệu của lớp, gồm cả ảnh đang chờ duyệt.

Sáu thư mục gồm **Thiếu linh kiện hoặc dây**, **Sai cực hoặc ngược chiều**, **Nối nhầm chân hoặc sai vị trí**, **Sai trị số hoặc mức nguồn**, **Nguy cơ chập mạch** và **Lỗi khác**. Ví dụ lỗi cũ thiếu dạng lỗi có thư mục **Chưa phân loại dạng lỗi** khi có dữ liệu phù hợp.

## Xác minh

- Build thành công. Trang chủ và kho công khai trên local trả HTTP 200.
- Trên trình duyệt, đã thấy đủ sáu thư mục ở bài LED, mở thư mục **Thiếu linh kiện hoặc dây**, rồi đổi sang bài Servo và thấy nhóm lỗi tương ứng.
- Kiểm tra dữ liệu thử xác nhận sáu thư mục của cả năm bài, lọc đúng dạng lỗi, gom ảnh theo tiêu chí, giữ riêng ảnh chờ duyệt và điền sẵn mẫu tải ảnh. 
- Bộ kiểm tra toàn dự án đạt 46/48. Hai lỗi cũ liên quan tới ảnh bài nộp.

## Sao lưu

- Cập nhật sử dụng loại lỗi đã lưu và không đổi cấu trúc CSDL.
- ZIP trước cập nhật nằm tại `backups/CircuitCoach-thu-muc-loi-20261119-222812-3fcb319-before.zip`.
- ZIP sau cập nhật nằm tại `backups/CircuitCoach-thu-muc-loi-20261119-222812-3fcb319-after.zip` và kèm tệp này.
- Để thử khôi phục, giải nén ZIP vào thư mục riêng, chạy `npm ci`, `npm run build:sites` rồi `npm run local` với `LOCAL_PORT` ở cổng thử.
