# Chỉ báo bước hiện tại trong hoạt ảnh lắp mạch

Ngày 19/11/2026, giờ Việt Nam. Bản cập nhật chạy trên [CircuitCoach local](http://127.0.0.1:3187/#/assembly/led). Nền mã nguồn là commit `3fcb319` và các cập nhật local. Bản Sites online hiện ở v4.

- Cả năm hướng dẫn hiển thị số bước ngay phía trên sơ đồ chân nối. Ví dụ, **Bước 2 / 3** nghĩa là đang xem bước thứ hai trong ba bước.
- Bước đang hiển thị có nhãn **Đang xem** trong danh sách. Cả chỉ báo và dấu chọn đổi theo nút chuyển bước, khi chọn bước trực tiếp và khi tự chạy.
- Trên trình duyệt đã xác nhận bài LED hiển thị **Bước 1 / 3**, chuyển tay đến **Bước 2 / 3** rồi tự chạy đến **Bước 3 / 3**. Dấu chọn trong danh sách khớp với bước đang phát.
- Build thành công. Bộ kiểm tra toàn dự án đạt 46/48, với hai lỗi cũ liên quan tới ảnh bài nộp. Cập nhật không thay đổi cấu trúc dữ liệu.
- ZIP trước và sau cập nhật có tên lần lượt `backups/CircuitCoach-buoc-hien-tai-20261119-230924-3fcb319-before.zip` và `backups/CircuitCoach-buoc-hien-tai-20261119-230924-3fcb319-after.zip`.
- Nếu cần thử khôi phục, giải nén ZIP vào thư mục riêng, chạy `npm ci`, `npm run build:sites` rồi `npm run local` ở một cổng thử.
