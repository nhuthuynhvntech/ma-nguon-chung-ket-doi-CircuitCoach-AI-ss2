# Hoạt ảnh hướng dẫn lắp mạch

Ngày 19/11/2026, giờ Việt Nam. Bản cập nhật chạy ở [CircuitCoach local](http://127.0.0.1:3187/#/lessons). Mã nguồn dựa trên commit `3fcb319` và các cập nhật local. Bản Sites online hiện ở v4.

## Cách dùng

- Từ **Bài học**, chọn **Hướng dẫn lắp mạch**. Bạn cũng có thể mở hướng dẫn từ trang của từng bài. Khách xem được hướng dẫn.
- Dây của bước hiện tại được vẽ từ đầu nối này đến đầu nối kia. Hai chân cần nối được đánh dấu. Các dây ở bước đã qua vẫn nhìn thấy trên sơ đồ.
- Có thể chọn bước trực tiếp, bấm **Bước trước**, **Bước tiếp theo**, **Xem lại bước**, hoặc dùng **Tự chạy** và **Tạm dừng**.
- Có 18 bước cho năm bài. Bài LED cơ bản và Servo có ba bước. HC-SR04, LED dùng pin và cảm biến độ ẩm đất có bốn bước. Bước gắn đầu dò minh họa cả hai dây.
- Mỗi hướng dẫn nhắc ngắt nguồn trong lúc lắp và chỉ cấp nguồn sau khi giáo viên kiểm tra mạch thật. Bài Servo và LED dùng pin có lưu ý riêng.

## Mã nguồn và kiểm tra

- `src/data/assembly-guides.js` lưu bố trí linh kiện, chân nối và nội dung. `src/views/assembly.js` vẽ dây và điều khiển phát. Hiệu ứng dùng Canvas có sẵn của trình duyệt.
- Trang hỗ trợ bố cục một cột ở màn hình hẹp và chế độ giảm chuyển động. Hoạt ảnh ngừng chạy tự động khi chuyển sang tab khác.
- Đã đối chiếu 18 bước và 19 đường dây với các kết nối của năm bài. Build thành công, máy chủ local trả HTTP 200.
- Trên trình duyệt đã mở năm hướng dẫn, thử chuyển bước và tự chạy rồi tạm dừng ở bài LED, kiểm tra hai dây đầu dò ở bài độ ẩm, và xác nhận tiêu đề hiện ở đầu trang khi mở từ danh sách.
- Bộ kiểm tra toàn dự án đạt 46/48. Hai lỗi cũ liên quan tới ảnh bài nộp.

## Sao lưu

- Cập nhật này không đổi cấu trúc cơ sở dữ liệu.
- ZIP trước cập nhật nằm ở `backups/CircuitCoach-hoat-anh-lap-mach-20261119-225707-3fcb319-before.zip`.
- ZIP sau cập nhật nằm ở `backups/CircuitCoach-hoat-anh-lap-mach-20261119-225707-3fcb319-after.zip` và kèm tệp này.
- Để thử khôi phục, giải nén ZIP vào thư mục riêng, chạy `npm ci`, `npm run build:sites` rồi `npm run local` với `LOCAL_PORT` ở một cổng thử.
