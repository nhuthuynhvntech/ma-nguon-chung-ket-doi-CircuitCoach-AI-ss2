# Bộ quy tắc phân tích chung cho năm bài

Bản local nạp lúc 23:57 ngày 22/11/2026, giờ Việt Nam. Mã nguồn dựa trên commit `3fcb319` và các thay đổi local đã có. [Mở CircuitCoach AI](http://127.0.0.1:3187/#/home)

## Luồng phân tích sau cập nhật

1. AI nhận ảnh mạch, sơ đồ và danh sách tiêu chí. Với mỗi tiêu chí, AI gửi giá trị quan sát được, cách lần theo bằng chứng, số ảnh, chi tiết nhìn thấy và vùng có thể khoanh. Trường hợp chưa chắc hoặc chi tiết không hiện trên ảnh có trạng thái riêng.
2. Hệ thống dùng bộ quy tắc chung cho **38 tiêu chí**. Mỗi bài khai báo thông số trong `src/data/circuit-rules.js`. Cùng quy tắc kiểm tra chân cắm đọc D8 ở bài LED, D9/D10 ở HC-SR04, D6 ở servo và A0 ở bài độ ẩm. Cùng quy tắc trị số dùng khoảng 220–330 Ω ở bài LED Arduino và 330–1000 Ω ở bài LED pin. Tiêu chí nguồn 9V còn yêu cầu bằng chứng về điện trở phù hợp.
3. Hệ thống kiểm tra chỉ số ảnh, độ chắc chắn và giá trị quan sát trước khi chấm. Cảnh báo dùng đúng ảnh có bằng chứng. Ảnh chụp từ nhiều góc cần dấu hiệu nhận biết cùng dây. Khi thiếu bằng chứng, ứng dụng trả **Chưa xác định** hoặc **Không nhìn thấy** và vẫn cho học sinh đọc phần nhận xét còn lại.
4. Cả năm bài có thể dùng bước cận cảnh trên ảnh JPEG khi vùng lỗi hợp lệ và còn thời gian. Bước này hỗ trợ vị trí vùng khoanh. Kết quả theo tiêu chí vẫn dựa trên quy tắc đã đối chiếu.
5. Luồng A và B dùng cùng quy tắc. B dùng thêm ảnh tham chiếu đã duyệt. Hồ sơ chạy A/B lưu phiên bản cấu hình và bộ quy tắc của lần chạy. Các lượt mới lưu bằng chứng có cấu trúc cùng nhận xét. **Giáo viên xác nhận an toàn sau khi kiểm tra mạch thật.**

## Kiểm tra

- **71 bài kiểm thử tự động đều đạt.** Có kiểm tra 38 tiêu chí, quy tắc pin 9V và điện trở, dây sai chân, thiếu bằng chứng, thiếu hoặc lặp tiêu chí, phạm vi tọa độ và lượt cận cảnh ở nhiều bài.
- Kiểm thử trên bản dựng nhận phản hồi mô phỏng cho năm bài qua API và chấm đúng các lỗi đã cài trong tình huống thử. Với cơ sở dữ liệu thử riêng, luồng A/B lấy được ảnh đã duyệt, chấm theo nhãn, lưu điểm và hiển thị kết quả trong báo cáo.
- Năm lượt gọi OpenAI thật trả đủ số tiêu chí của từng bài. Bốn lượt dùng ảnh mẫu của LED, HC-SR04, servo và LED pin. Lượt cho bài độ ẩm dùng ảnh servo để thử trường hợp cảm biến vắng mặt và nhận **Không nhìn thấy** ở tiêu chí A0. HC-SR04 cũng chạy được bước cận cảnh và giữ ảnh liên quan cho hai tiêu chí chưa định vị được vùng đáng tin.
- Các thử nghiệm xác nhận luồng chạy trên bản local. Mức tăng độ chính xác cần được đo bằng bộ ảnh độc lập có nhãn giáo viên. Thay đổi không cần migration cơ sở dữ liệu.

## Sao lưu và khôi phục

Hai gói `CircuitCoach-quy-tac-chung-5-bai-20261122-234745-3fcb319-before.zip` và `CircuitCoach-quy-tac-chung-5-bai-20261122-234745-3fcb319-after.zip` lưu mã nguồn trước và sau cập nhật. Gói sau chứa ghi chú này.

Để khôi phục, giải nén bản sao lưu vào một thư mục riêng, cài các phụ thuộc theo tệp khóa, sau đó chạy `node scripts/build-sites-worker.mjs` và khởi động lại. Cơ sở dữ liệu và ảnh của bản local nằm trong `.data`.
