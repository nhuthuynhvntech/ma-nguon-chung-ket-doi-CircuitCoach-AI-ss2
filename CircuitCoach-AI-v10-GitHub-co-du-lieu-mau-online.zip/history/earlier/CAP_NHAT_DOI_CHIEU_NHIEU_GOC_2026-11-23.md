# Đối chiếu nhiều góc chụp trước khi chấm và khoanh lỗi

CircuitCoach AI đã nạp bản cập nhật local lúc 15:42 ngày 23/11/2026, giờ Việt Nam. Mã nguồn dựa trên commit `3fcb319` và các thay đổi local đã có. Bản Sites online vẫn ở phiên bản 4. [Mở bản local](http://127.0.0.1:3187/#/lessons)

## Cách gửi ảnh

Gửi ảnh của cùng một mạch và giữ nguyên cách cắm dây giữa các lần chụp. Ba góc nên có là toàn cảnh thấy đường dây, cận đầu cắm trên bo mạch, và cận linh kiện hoặc cảm biến. Giữ một đoạn dây hoặc một chi tiết chung trong các khung hình để dễ đối chiếu. Thứ tự gửi ảnh không quyết định vai trò của mỗi góc.

## Cách AI đưa ra nhận xét

1. Với từng tiêu chí, AI ghi nhận chi tiết nhìn thấy và điểm nghi ngờ ở từng ảnh học sinh. Ảnh toàn cảnh giúp định hướng. Ảnh cận giúp đọc nhãn chân, lần đầu dây hoặc xem linh kiện.
2. Hệ thống chỉ chấm khi có nhận xét cho đủ số ảnh đã gửi và bằng chứng cho kết luận. Nếu ảnh toàn cảnh mờ, góc cận có thể giải đáp nghi ngờ khi xác định được cùng đầu nối hoặc cùng dây. Khi ghép các góc, cần thấy đoạn dây trùng khớp hoặc dấu vật lý riêng để nhận ra cùng chi tiết.
3. Nếu các ảnh cho bằng chứng mâu thuẫn hoặc chưa đủ rõ, tiêu chí hiện **Chưa xác định** và giữ nhận xét theo từng góc, kèm gợi ý chụp bổ sung. Các tiêu chí có đủ căn cứ vẫn được chấm trong cùng lượt.
4. Sau khi đối chiếu, vùng lỗi chỉ hiện trên ảnh có bằng chứng trực tiếp và định vị được. Học sinh và giáo viên xem nhận xét ở mục **Đối chiếu từng góc chụp**. Các nhận xét được lưu cùng lượt làm khi đồng bộ vào lớp.

## Kiểm tra

- 75 kiểm thử tự động đạt. Các tình huống kiểm tra gồm ba góc bổ sung cho nhau, nghi ngờ ở ảnh mờ được làm rõ ở góc cận, thiếu nhận xét cho một góc, chỉ số ảnh trùng và bằng chứng mâu thuẫn.
- Một lượt OpenAI thật với ảnh mẫu HC-SR04 và hai vùng cận cắt từ chính ảnh đó trả đủ ba nhận xét theo góc cho cả bảy tiêu chí. Hai cảnh báo TRIG và ECHO có vùng khoanh trên ảnh cận Arduino. Các tiêu chí chưa xác định có gợi ý chụp bổ sung. Lượt này kiểm chứng luồng xử lý bằng ảnh mẫu. Độ chính xác trên các góc chụp độc lập cần được đo với bộ ảnh có nhãn giáo viên.
- Đã kiểm tra nhận xét theo góc được lưu, đọc lại và giữ trong dữ liệu gửi vào lớp. Các lượt đã lưu trước cập nhật vẫn mở được. Không cần migration cơ sở dữ liệu.

## Sao lưu và khôi phục

Hai gói `CircuitCoach-doi-chieu-nhieu-goc-20261123-153914-3fcb319-before.zip` và `CircuitCoach-doi-chieu-nhieu-goc-20261123-153914-3fcb319-after.zip` chứa mã nguồn trước và sau cập nhật. Gói sau kèm ghi chú này. Hai gói lưu riêng với dữ liệu làm việc trong `.data` và cấu hình máy.

Thay đổi tập trung ở `server/ai/analyze-prompt.js`, `server/ai/circuit-observations.js`, `src/services/storage.js`, `src/views` và `src/style.css`. Để khôi phục, giải nén gói trước vào thư mục riêng, khôi phục các tệp đã sửa trong đợt này, chạy `node scripts/build-sites-worker.mjs` và khởi động lại máy chủ local với dữ liệu hiện có.
