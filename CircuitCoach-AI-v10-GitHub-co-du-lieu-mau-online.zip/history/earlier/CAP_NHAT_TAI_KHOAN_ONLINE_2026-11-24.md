# CircuitCoach AI · Tài khoản giáo viên và quản trị online

OpenAI Sites đã phát hành lại phiên bản 5 lúc 18:26 ngày 24/11/2026, giờ Việt Nam. Bản phát hành dùng cấu hình số 7 và mã nguồn `9ea1feb672e5bd39291b3fea6ce40b6f8e06fb37`.

- Tài khoản giáo viên có tên đăng nhập `gv`. Tài khoản quản trị viên có tên đăng nhập `admin`.
- Hai tài khoản dùng mật khẩu riêng. Thông tin đăng nhập được cấp trong tệp riêng. Bản sao lưu phát hành chứa mã nguồn và các ghi chú cập nhật.
- Đã đăng nhập thử cả hai tài khoản trên chính site online, kiểm tra đúng vai trò và đóng cả hai phiên thử.

[Mở trang đăng nhập CircuitCoach](https://circuitcoach-stem-lab-2026.tartlapwing1.chatgpt.site/#/home)

## Sao lưu

- Mã nguồn trước lần cập nhật tài khoản `backups/CircuitCoach-online-AI-20261123-235355-9ea1feb-after.zip`
- Mã nguồn và ghi chú sau cập nhật `backups/CircuitCoach-online-tai-khoan-20261124-182653-9ea1feb-after.zip`
