# CircuitCoach AI · Đổi mật khẩu online

OpenAI Sites đã phát hành phiên bản 6 lúc 18:35 ngày 24/11/2026, giờ Việt Nam. Commit phát hành là `cdf3de95d2764c31d363658618a81eb58af6af1a`.

- Cấp mật khẩu dạng cụm từ riêng cho tài khoản giáo viên `gv` và quản trị viên `admin`. Tệp thông tin đăng nhập được lưu riêng.
- Trong khu vực quản trị, mục **Đổi mật khẩu quản trị của tôi** yêu cầu nhập mật khẩu hiện tại và xác nhận mật khẩu mới từ 12 đến 128 ký tự. Khi đổi thành công, hệ thống đóng các phiên quản trị cũ và đưa người dùng về trang đăng nhập.
- Đã chạy 84 kiểm thử tự động. Bài kiểm tra riêng xác nhận chức năng yêu cầu phiên quản trị, mật khẩu hiện tại hợp lệ và mật khẩu mới đủ dài.
- Trên site online, cả hai tài khoản đều đăng nhập thành công bằng mật khẩu mới. Đã kiểm tra phiên quản trị cũ bị thu hồi.

[Trang đăng nhập CircuitCoach](https://circuitcoach-stem-lab-2026.tartlapwing1.chatgpt.site/#/home)

## Sao lưu mã nguồn

- Trước cập nhật `backups/CircuitCoach-doi-mat-khau-20261124-183040-9ea1feb-before.zip`
- Sau cập nhật `backups/CircuitCoach-doi-mat-khau-20261124-183040-cdf3de9-after.zip`

Giải nén các bản sao vào thư mục riêng để đối chiếu mã nguồn và ghi chú cập nhật.
