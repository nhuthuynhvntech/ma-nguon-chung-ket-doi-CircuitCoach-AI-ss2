# Quản trị lớp học và chú thích ảnh tham chiếu

Cập nhật đã chạy trên bản local cổng 3187 lúc 11:08 ngày 20/11/2026, giờ Việt Nam. Mã nguồn dựa trên commit `3fcb319` và các thay đổi local. [Mở CircuitCoach AI](http://127.0.0.1:3187/#/home)

## Quản trị viên

1. Mở **Tài khoản giáo viên** để xem tên đăng nhập, lớp phụ trách và trạng thái từng tài khoản. Khi tạo hoặc đặt lại mật khẩu, bấm **Hiện mật khẩu vừa cấp** để xem và gửi riêng cho giáo viên. Hệ thống lưu mật khẩu ở dạng băm. Đặt lại mật khẩu kết thúc các phiên đăng nhập cũ của tài khoản.
2. Mở **Lớp học và báo cáo** rồi chọn một lớp hoặc **Tất cả lớp**. Chọn bài học cụ thể hoặc xem số liệu của tất cả bài học. **Tổng quan bài học** hiển thị kết quả AI, xác nhận đúng sai của giáo viên, nhãn theo tiêu chí và số liệu A/B.
3. Mở **Học sinh và bài làm** để xem tên học sinh hoặc nhóm, lượt nộp và hoạt động gần nhất. Bấm **Xem bài** để xem ảnh, tiêu chí, nhận xét và xác nhận an toàn. Nhóm đã nộp bài trước đợt cập nhật được đọc từ lịch sử. Nhóm chỉ từng vào lớp và chưa nộp bài sẽ xuất hiện sau lần vào lớp tiếp theo.
4. Mở **Ảnh mẫu** để xem số lượng và trạng thái ảnh theo bài, gồm ảnh lớp và ví dụ tham chiếu. Bấm vào ảnh để xem chi tiết và phóng to.

[Mở trang Quản trị](http://127.0.0.1:3187/#/admin)

## Giáo viên

1. Gõ mã trong ô **Mã lớp mới**, rồi bấm **Tạo mã lớp**. Mã gồm 4–12 chữ cái không dấu hoặc chữ số. Hệ thống đổi chữ thường thành chữ in hoa và kiểm tra trùng mã.
2. Mở **Xem & xác nhận** của một nhóm. Ô **Nhận xét cho học sinh** nằm ngay dưới ảnh và lưu ngay trên màn hình đó. Kiểm tra an toàn, nhãn tiêu chí và A/B có thể mở khi cần.
3. Trong **Tải ảnh theo tiêu chí**, chọn ảnh rồi dùng **Khoanh vùng**, **Vẽ**, **Chú thích** hoặc **Hoàn tác**. Với ảnh từ bài nộp, mở **Nhãn tiêu chí và ảnh tham chiếu**, lưu nhãn tiêu chí rồi chọn góc chụp để vẽ. Dấu vẽ và ghi chú được lưu cùng ảnh tham chiếu và hiển thị khi mở ảnh từ thư viện.
4. Người tải ảnh mẫu phải là giáo viên được phân công lớp đó. Quản trị viên có quyền xem ảnh lớp. Bấm vào ảnh để mở khung xem và dùng các nút **Phóng to** hoặc **Thu nhỏ**.

[Mở trang Giáo viên](http://127.0.0.1:3187/#/teacher)

## Dữ liệu và kiểm tra

- Hai cập nhật cơ sở dữ liệu `0010_reference_annotations.sql` và `0011_student_groups.sql` lưu chú thích ảnh và danh sách nhóm vào lớp. Ảnh lưu dãy tọa độ nét vẽ cùng ghi chú để có thể phóng to mà vẫn giữ vị trí. Màn hình phân tích AI dùng ảnh gốc.
- Đã kiểm tra trình duyệt với tài khoản và bài thử riêng. Kiểm tra gồm nhập mã, lưu nhận xét, khoanh vùng, vẽ, thêm chú thích, mở lại và phóng ảnh, lọc báo cáo, xem bài và đặt lại mật khẩu. Quyền tải ảnh mẫu đã được thử với giáo viên của lớp, giáo viên lớp khác, học sinh và quản trị viên.
- Bộ kiểm tra đạt 48/48. Hai bài kiểm tra cũ đã được cập nhật để kiểm tra đúng điều kiện xác nhận an toàn của thư mục mạch đúng và cách máy chủ xử lý số ảnh do học sinh tự khai.
- Sau khi khởi động lại, có 3 tài khoản nhân sự, 3 lớp, 5 bài nộp, 4 ví dụ tham chiếu, 2 bản ghi luồng AI và 18 tệp ảnh hoặc thông tin ảnh. Số lượng giữ nguyên qua lần nâng cấp. SQLite trả `ok` và không có lỗi khóa ngoại.

## Sao lưu và khôi phục

- Mã nguồn trước cập nhật nằm trong `backups/CircuitCoach-quan-tri-anh-nhan-ma-lop-20261120-104952-3fcb319-before.zip`.
- Dữ liệu và ảnh trước cập nhật nằm trong `backups/CircuitCoach-quan-tri-anh-nhan-ma-lop-20261120-104952-3fcb319-data-before.zip`. Giữ riêng gói này vì có dữ liệu lớp.
- Mã nguồn sau cập nhật và tài liệu này nằm trong `backups/CircuitCoach-quan-tri-anh-nhan-ma-lop-20261120-104952-3fcb319-after.zip`.
- Để thử khôi phục, giải nén mã nguồn vào thư mục riêng. Nếu cần thử cùng dữ liệu, giải nén gói dữ liệu vào thư mục đó. Chạy `npm ci`, `npm run build:sites`, sau đó đặt `LOCAL_PORT` sang một cổng thử và chạy `npm run local` để SQLite áp dụng các cập nhật.
