# Chấm tiêu chí từ bằng chứng ghép qua ba ảnh

Bản local của CircuitCoach AI đã nạp bản cập nhật lúc 16:08 ngày 23/11/2026, giờ Việt Nam. Mã nguồn dựa trên commit `3fcb319` và các chỉnh sửa local đã có. Bản Sites online vẫn ở phiên bản 4. [Mở bản local](http://127.0.0.1:3187/#/lessons)

## Cách xét ảnh và trả kết quả

- Từng ảnh có thể đóng góp một phần bằng chứng. Ảnh toàn cảnh mờ nhãn vẫn có giá trị nếu thấy rõ đoạn dây giúp nối các góc cận. Nhận xét theo góc ghi phần dùng được và phần còn mờ.
- Tiêu chí được chấm **Đúng** nếu ghép các phần đủ để nhận ra cùng đường nối và giá trị quan sát khớp quy tắc bài. Ví dụ, ảnh 2 thấy đầu TRIG ở cảm biến, ảnh 1 thấy đường dây nối tiếp với hai ảnh cận, và ảnh 3 đọc được đầu cắm D9. Phần **AI quan sát** giải thích cách nối các phần đó. Kết quả được lưu cùng lượt làm.
- Khi vẫn thiếu một đoạn thiết yếu, có nhiều cách lần dây hoặc các ảnh mâu thuẫn, tiêu chí hiện **Chưa xác định** kèm gợi ý chụp. Khi đủ bằng chứng về lỗi và xác định được vị trí, vùng khoanh thuộc ảnh cho thấy trực tiếp vị trí lỗi. Quyết định cấp nguồn vẫn thuộc về giáo viên kiểm tra mạch thật.

## Kiểm tra và khôi phục

76 kiểm thử tự động đã đạt. Kiểm thử tích hợp trên bản dựng với phản hồi OpenAI mô phỏng xác nhận đường TRIG qua đủ ba ảnh được chấm **Đúng** và hiển thị cách lần dây. Khi ảnh giữa không còn cho thấy đoạn nối, cùng tiêu chí trả **Chưa xác định** và có gợi ý chụp. Bản local phản hồi kiểm tra máy chủ và trang chủ thành công. Cập nhật không cần migration cơ sở dữ liệu.

Hai gói `CircuitCoach-ghep-bang-chung-20261123-160631-3fcb319-before.zip` và `CircuitCoach-ghep-bang-chung-20261123-160631-3fcb319-after.zip` lưu mã nguồn trước và sau cập nhật. Gói sau kèm ghi chú này. Khi cần khôi phục, lấy lại `server/ai/analyze-prompt.js`, `server/ai/circuit-observations.js` và `test/circuit-observations.test.js` từ gói trước, chạy `node scripts/build-sites-worker.mjs` rồi khởi động lại máy chủ local với dữ liệu đang có.
