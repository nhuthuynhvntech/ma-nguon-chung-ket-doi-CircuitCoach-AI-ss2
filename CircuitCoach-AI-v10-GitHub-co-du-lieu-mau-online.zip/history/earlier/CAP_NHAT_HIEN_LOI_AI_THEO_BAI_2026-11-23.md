# Hiển thị lỗi AI được giáo viên ghi nhận theo bài học

CircuitCoach AI đã nạp bản cập nhật local lúc 21:48 ngày 23/11/2026, giờ Việt Nam. Mã nguồn dựa trên commit `3fcb319` và các thay đổi local hiện có. Phạm vi cập nhật là bản local. [Mở bài LED cơ bản](http://127.0.0.1:3187/#/analyzer/led)

## Học sinh và giáo viên xem ở đâu

Mục **Lỗi AI cần chú ý** xuất hiện khi mở bài và trên trang **Xem prompt AI**. Học sinh thấy phản hồi của lớp mình. Giáo viên thấy phản hồi theo lớp phụ trách đang chọn. Mỗi dòng ghi tiêu chí, lý do giáo viên báo AI sai, số lượt và lời nhắc AI nhận khi phân tích ảnh mới. Nếu bài chưa có phản hồi, mục này ghi rõ trạng thái.

Để bổ sung, giáo viên mở một lượt làm thật, chọn **AI sai**, chọn tiêu chí cùng lý do rồi bấm **Lưu xác nhận**. Khi mở lại bài, hệ thống đọc phản hồi đã lưu theo lớp và bài học. Các lượt trùng tiêu chí và lý do được gộp số lần. Hệ thống lấy tối đa 6 lời nhắc và ưu tiên tiêu chí an toàn. Trang hiển thị và lượt phân tích dùng chung nguồn lời nhắc. Nội dung gửi đến AI gồm tên tiêu chí và lời nhắc chuẩn tương ứng.

## Kiểm tra và khôi phục

- Cả 78 kiểm thử tự động đã đạt. Kiểm thử tích hợp trên SQLite riêng xác nhận giáo viên lưu một lỗi thì số lượt hiển thị tăng. Phiên học sinh của lớp và giáo viên phụ trách nhận cùng danh sách. Yêu cầu của lớp khác bị từ chối. Kiểm thử với phản hồi OpenAI mô phỏng xác nhận dữ liệu gửi cho AI chứa đúng các lời nhắc đang hiển thị.
- Đã kiểm tra bài LED trên trình duyệt bằng dữ liệu đang lưu. Trang bài học và trang prompt hiện cùng 3 mục lỗi, gồm **Kết nối nguồn** với lý do **Đọc nhầm chân hoặc đường dây**.
- Thay đổi dùng cơ sở dữ liệu hiện có và không cần migration. Mã mới nằm trong `worker/runtime.js`, `src/services/classroom.js`, `src/views/lesson-ai-reminders.js` và các chỗ tích hợp ở trang bài học, trang prompt và giao diện dùng chung.
- Hai gói `CircuitCoach-hien-loi-ai-theo-bai-20261123-214521-3fcb319-before.zip` và `CircuitCoach-hien-loi-ai-theo-bai-20261123-214521-3fcb319-after.zip` chứa mã nguồn trước và sau cập nhật. Gói sau kèm ghi chú này. Khi cần khôi phục, giải nén gói trước vào thư mục riêng, dùng mã nguồn trước cập nhật, chạy `node scripts/build-sites-worker.mjs` và khởi động lại máy chủ local với dữ liệu hiện có.
