# Kho tham chiếu theo bài học

Ngày 19/11/2026, giờ Việt Nam. Bản cập nhật đang chạy ở [CircuitCoach local](http://127.0.0.1:3187/#/references). Mã nguồn dựa trên commit `3fcb319` và các thay đổi local. Phiên bản Sites online hiện ở v4.

## Thay đổi

- Mục **Kho tham chiếu** thay cho tên **Mạch đúng**. Cả năm bài có thư mục riêng. Trong thư mục bài có ảnh đúng theo tiêu chí, mạch đúng đã xác nhận trước đây và thư mục con cho từng tiêu chí và dạng lỗi đã duyệt.
- Trong chi tiết lượt có ảnh đã đồng bộ, giáo viên lưu nhãn phù hợp rồi chọn tiêu chí và góc chụp ở **Thêm ví dụ vào kho tham chiếu**. Với nhãn **Có lỗi**, chọn dạng lỗi và thêm dấu hiệu quan sát được khi cần.
- Kiểm duyệt viên xem ảnh, tên bài, tiêu chí, dạng lỗi và ghi chú để duyệt hoặc từ chối. Ảnh đang chờ, bị từ chối hoặc đã ngừng dùng nằm riêng. Quyền xem kho giới hạn theo lớp của giáo viên.
- Luồng B chọn tối đa ba ví dụ đã duyệt thuộc đúng lớp và bài, ưu tiên có mẫu đúng và mẫu lỗi khác nhau khi dữ liệu cho phép. AI nhận nhãn kèm theo từng ảnh và chỉ đánh giá ảnh bài làm. Luồng A tiếp tục phân tích độc lập. Kết quả A/B lưu ID của các ảnh đã sử dụng.
- Ảnh từ cùng lượt đang đánh giá, ảnh trùng nguyên tệp và ví dụ thuộc bộ đánh giá được loại khỏi tham chiếu. Kho local chính thức hiện có một ví dụ đã lưu và chưa có ví dụ được duyệt.

## Dữ liệu và kiểm tra

- `drizzle/0007_reference_cases.sql` lưu chỉ số ảnh nguồn và thêm khóa để ngăn gửi trùng ví dụ đang chờ hoặc đã duyệt. Ví dụ cũ giữ nguyên nội dung và trạng thái. Dạng lỗi và ghi chú lưu trong phiên bản nhãn. Ảnh sao chép nằm trong `.data/images`.
- `src/views/references.js` hiển thị các thư mục. `src/views/teacher.js` và `src/views/reviewer.js` xử lý gửi và duyệt. `worker/runtime.js` lưu ví dụ, kiểm tra quyền và chọn ảnh cho B.
- Build thành công. Trang kho có năm thư mục trên trình duyệt. Đã mở thư mục LED và xác nhận khách chỉ thấy hướng dẫn mở lớp. SQLite local đã áp dụng bản cập nhật cấu trúc và kiểm tra toàn vẹn trả về `ok`.
- Kiểm tra luồng thật qua HTTP trên dữ liệu thử riêng với phản hồi OpenAI mô phỏng. Chọn ảnh thứ hai, gắn đúng tiêu chí và dạng lỗi, chặn gửi trùng, duyệt ảnh, tách lớp và tách bài. Luồng A dùng 0 ảnh và luồng B dùng đúng 3 ví dụ hợp lệ. Kiểm tra này xác nhận cách chọn ảnh, còn mức cải thiện nhận diện cần đo trên ảnh thật có nhãn.
- Bộ kiểm tra toàn dự án đạt 46/48. Hai kiểm tra cũ còn lỗi ở quy tắc **Thư mục mạch đúng** và số ảnh bài nộp dùng chung.

## Sao lưu và khôi phục

- ZIP trước cập nhật nằm trong `backups/CircuitCoach-kho-tham-chieu-20261119-212935-3fcb319-before.zip`.
- ZIP sau cập nhật nằm trong `backups/CircuitCoach-kho-tham-chieu-20261119-212935-3fcb319-after.zip`, kèm tệp thông tin này.
- Bản chụp SQLite và kho ảnh trước thay đổi nằm trong `backups/CircuitCoach-kho-tham-chieu-20261119-212935-3fcb319-data-before`. Giữ riêng vì có dữ liệu của lớp.
- Khi thử khôi phục, giải nén mã nguồn vào thư mục riêng, dùng bản sao CSDL cùng thư mục ảnh tương ứng. Giữ thông tin phiên local riêng. Chạy `npm ci`, `npm run build:sites` và `npm run local` với `LOCAL_PORT` ở cổng thử.
