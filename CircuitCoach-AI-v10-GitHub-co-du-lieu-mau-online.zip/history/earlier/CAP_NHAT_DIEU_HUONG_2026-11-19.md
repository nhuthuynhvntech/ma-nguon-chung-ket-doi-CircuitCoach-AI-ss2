# Sửa lỗi chuyển tab trong CircuitCoach AI

Ngày 19/11/2026, giờ Việt Nam. Bản sửa đã chạy ở [CircuitCoach local](http://127.0.0.1:3187/#/home). Mã nguồn dựa trên commit `3fcb319` và các cập nhật local. Bản Sites online hiện ở v4.

## Hiện tượng và nguyên nhân

- Bấm **Bài học** trong thư viện ảnh có thể mở đúng địa chỉ nhưng hiện màn hình đăng nhập. Bộ điều hướng yêu cầu phiên học sinh cho cả những nội dung có thể đọc chung.
- Một tab trình duyệt mới thiếu dấu phiên giáo viên lưu riêng trong tab, dù máy chủ còn phiên hợp lệ.
- Đăng nhập một vai trò nhân sự ghi đè cookie dùng chung của vai trò trước. Tác vụ tải dữ liệu của một số trang cũng có thể vẽ lại sau khi người dùng chuyển mục.

## Cách dùng sau bản sửa

- Mở **Bài học** để xem nội dung, kết nối và ảnh đối chiếu. Vào nhóm học sinh để nộp ảnh và xem dữ liệu riêng của nhóm.
- Giáo viên đã đăng nhập có thể mở **Thư viện ảnh mẫu**, **Mạch đúng** và báo cáo của lớp khi phiên còn hiệu lực. Tab mới xác nhận phiên từ máy chủ.
- Phiên giáo viên, quản trị và kiểm duyệt có thể cùng hoạt động trên một trình duyệt. Khi đăng xuất một vai trò, các phiên còn lại tiếp tục hoạt động.
- Tải lại một lần nếu tab đã mở từ trước bản cập nhật. Nếu phiên đã hết hạn, đăng nhập lại đúng vai trò.

## Xác minh

- Tái hiện trên trình duyệt bằng cách bấm **Bài học** từ thư viện. Sau bản sửa, danh mục và bài LED hiện đúng. Đã mở **Theo dõi AI**, chọn HC-SR04 rồi mở cùng báo cáo trong tab trình duyệt mới.
- Kiểm tra HTTP trên dữ liệu thử riêng. Ba vai trò cùng hoạt động, phiên giáo viên được nhận lại, phiên cũ tương thích, đăng xuất theo vai trò, quyền theo lớp và luồng học sinh xem ảnh mẫu đều hoạt động.
- Build thành công. Bộ kiểm tra toàn dự án đạt 46/48. Hai kiểm tra cũ còn lỗi ở **Thư mục mạch đúng** và giới hạn số ảnh nộp dùng chung.

## Mã nguồn và sao lưu

- `src/router.js`, `src/views/analyzer.js`, `src/views/lessons.js`, `src/views/shared.js` xử lý truy cập trang chung, nội dung bài và trang riêng của nhóm.
- `src/services/classroom.js` và `worker/runtime.js` xác nhận phiên giáo viên và tách cookie theo vai trò. `src/views/teacher.js`, `src/views/admin.js` và `src/views/references.js` kiểm tra trang đang mở trước khi vẽ lại.
- Bản sửa không yêu cầu cập nhật cấu trúc dữ liệu. Mã nguồn trước và sau cập nhật lần lượt nằm trong `backups/CircuitCoach-tabs-20261119-211625-3fcb319-before.zip` và `backups/CircuitCoach-tabs-20261119-211625-3fcb319-after.zip`.
- Để thử khôi phục, giải nén ZIP vào một thư mục riêng, chạy `npm ci`, `npm run build:sites` và `npm run local`. Đặt `LOCAL_PORT` sang cổng thử riêng.
