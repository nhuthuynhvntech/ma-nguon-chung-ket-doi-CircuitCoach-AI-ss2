# CircuitCoach AI · Kích hoạt OpenAI trên bản online

OpenAI Sites đã phát hành lại phiên bản 5 lúc 23:53 ngày 23/11/2026, giờ Việt Nam. Phiên bản dùng commit `9ea1feb672e5bd39291b3fea6ce40b6f8e06fb37` và cấu hình trực tuyến số 6.

Khóa OpenAI đang dùng ở bản local đã được lưu dưới dạng bí mật trong cấu hình `OPENAI_API_KEY` của CircuitCoach theo lựa chọn của chủ dự án.

## Kiểm tra trên site

- Trợ lý trả lời đúng dây ECHO của bài HC-SR04 nối chân D10 trên Arduino Uno.
- Phân tích ảnh mẫu HC-SR04 qua OpenAI thật hoàn tất và trả về 7 tiêu chí.
- Trang Theo dõi AI theo bài học truy cập được. Hai phép thử AI đã dùng ảnh mẫu và câu hỏi thử nghiệm.

[Mở CircuitCoach AI](https://circuitcoach-stem-lab-2026.tartlapwing1.chatgpt.site/#/home)

## Sao lưu

- Mã nguồn trước lần cập nhật cấu hình `backups/CircuitCoach-online-20261123-232646-9ea1feb-after.zip`
- Mã nguồn cùng ghi chú cấu hình đã xác minh `backups/CircuitCoach-online-AI-20261123-235355-9ea1feb-after.zip`

Giải nén bản sao vào một thư mục riêng để đối chiếu mã và ghi chú. Khóa API được quản lý trong cấu hình bí mật của OpenAI Sites.
