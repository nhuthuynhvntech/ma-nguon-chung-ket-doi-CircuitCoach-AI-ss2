# CircuitCoach AI · Triển khai online

- OpenAI Sites xác nhận triển khai phiên bản 5 lúc 23:36 ngày 23/11/2026, giờ Việt Nam.
- Mã nguồn phát hành `9ea1feb672e5bd39291b3fea6ce40b6f8e06fb37`
- Địa chỉ [CircuitCoach AI](https://circuitcoach-stem-lab-2026.tartlapwing1.chatgpt.site/#/home)
- Quyền truy cập công khai của site được giữ như phiên bản trước.

## Nội dung đã đưa lên site

- Năm bài học, hướng dẫn lắp mạch, ảnh mẫu, kho tham chiếu và theo dõi AI theo từng bài.
- Đăng nhập theo vai trò học sinh, giáo viên và quản trị. Học sinh vào lớp bằng tên hoặc tên nhóm và mã lớp. Giáo viên tạo mã lớp. Quản trị quản lý tài khoản và xem báo cáo toàn hệ thống.
- Lịch sử và nhận xét theo từng lượt làm, nhãn tiêu chí của giáo viên, kiểm tra an toàn và báo cáo theo lớp.
- Phân tích ảnh nhiều góc, hai luồng AI A/B, kho ảnh đã duyệt và trợ lý cá nhân dùng lịch sử nhóm.
- Tài khoản giáo viên và quản trị đã cấu hình online được tạo trong cơ sở dữ liệu khi đăng nhập đúng lần đầu. Giáo viên cũ tiếp tục phụ trách các lớp đã tồn tại.

## Dữ liệu và kiểm tra

- Sites đã áp dụng 12 bản nâng cấp cấu trúc dữ liệu trên cơ sở dữ liệu hiện có. Đã đối chiếu đủ 3 lượt làm từ bản online trước đó. Ảnh bài làm vẫn dùng kho ảnh của site.
- Đã sao lưu 3 lượt làm và 3 ảnh gắn với các lượt đó trước khi nâng cấp. Tệp sao lưu dữ liệu chứa hồ sơ lớp học và cần lưu riêng. Dữ liệu local trên máy và dữ liệu online tiếp tục dùng hai cơ sở dữ liệu riêng.
- 84 kiểm thử tự động đạt. Bản thử riêng đã xác minh nâng cấp dữ liệu, đăng nhập các vai trò, đổi mật khẩu giáo viên, quyền xem ảnh, báo cáo theo lớp và lịch sử trợ lý.
- Trong môi trường thử riêng, OpenAI thật đã xử lý thành công cả luồng A và luồng B với ảnh mẫu Servo. Luồng A dùng ảnh bài làm, luồng B dùng thêm một ảnh tham chiếu đã duyệt. Hai kết quả và điểm đối chiếu một tiêu chí đã được lưu.
- Đã mở và kiểm tra trang, kho tham chiếu, Theo dõi AI và quyền truy cập báo cáo tại địa chỉ online.
- OpenAI trả về lỗi xác thực 401 khi site gọi chatbot hoặc phân tích ảnh. Bước còn lại là cấu hình khóa API hợp lệ trên Sites qua kết nối OpenAI Developers, phát hành lại phiên bản đã lưu và kiểm tra hai chức năng với OpenAI thật.

## Sao lưu

- Mã nguồn trước cập nhật `backups/CircuitCoach-online-20261123-232646-3fcb319-before.zip`
- Dữ liệu của bản online v4 `backups/CircuitCoach-online-v4-data-20261123-232646.zip`
- Mã nguồn sau cập nhật `backups/CircuitCoach-online-20261123-232646-9ea1feb-after.zip`

Để đối chiếu hoặc khôi phục mã nguồn, giải nén bản ZIP tương ứng vào thư mục riêng. Tệp dữ liệu gồm `snapshot.json` và ảnh gắn với lượt làm, có dấu kiểm tra SHA-256 cho ảnh. Trong lịch sử OpenAI Sites, phiên bản 4 là bản phát hành trước thay đổi này.
