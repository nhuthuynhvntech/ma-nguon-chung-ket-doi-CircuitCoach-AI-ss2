# Ghi lưu ý khi chỉ một góc chụp đủ bằng chứng

Bản local của CircuitCoach AI đã nạp cập nhật lúc 16:02 ngày 23/11/2026, giờ Việt Nam. Thay đổi dựa trên commit `3fcb319` và các chỉnh sửa local đã có. Bản Sites online vẫn ở phiên bản 4. [Mở bản local](http://127.0.0.1:3187/#/lessons)

Sau khi đối chiếu tất cả ảnh đã gửi, hệ thống chấp nhận kết luận cho từng tiêu chí nếu một ảnh tự nó cho thấy đủ bằng chứng và các góc khác không mâu thuẫn. Ví dụ, nếu chỉ ảnh 3 cho thấy rõ cả đường dây và chân cắm, phần **AI quan sát** sẽ nêu ảnh 3 và ghi “Chỉ 1 trong 3 góc chụp có đủ bằng chứng cho chi tiết này.” Phần **Đối chiếu từng góc chụp** vẫn ghi điều nhìn thấy hoặc điểm nghi ngờ ở hai góc kia.

Cảnh báo có thể được khoanh ngay trên ảnh có bằng chứng nếu định vị được. Khi có bằng chứng mâu thuẫn hoặc chưa đủ rõ, tiêu chí hiện **Chưa xác định** và có gợi ý chụp bổ sung. Nhận xét được lưu cùng lượt làm. Cập nhật không cần migration cơ sở dữ liệu.

75 kiểm thử tự động đã đạt. Kiểm thử với phản hồi OpenAI mô phỏng xác nhận bản dựng giữ nhận xét cho cả ba ảnh, chỉ khoanh ảnh 3 và thêm lưu ý vào tiêu chí. Trường hợp nộp một ảnh hoặc có nhiều ảnh cùng làm bằng chứng không hiện lưu ý này.

Hai gói `CircuitCoach-luu-y-mot-goc-20261123-160100-3fcb319-before.zip` và `CircuitCoach-luu-y-mot-goc-20261123-160100-3fcb319-after.zip` lưu mã nguồn. Gói sau có kèm ghi chú. Khi cần khôi phục, lấy lại `server/ai/circuit-observations.js` và `test/circuit-observations.test.js` từ gói trước, chạy `node scripts/build-sites-worker.mjs` rồi khởi động lại máy chủ bằng dữ liệu hiện có.
