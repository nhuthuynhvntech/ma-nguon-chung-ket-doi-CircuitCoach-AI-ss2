# Nhận xét khi ảnh mạch chưa đủ rõ

Bản local chạy trên cổng 3187 lúc 15:03 ngày 20/11/2026, giờ Việt Nam. Mã nguồn dựa trên commit `3fcb319` và các thay đổi local. [Mở CircuitCoach AI](http://127.0.0.1:3187/#/home)

- Khi AI trả ảnh chưa đủ rõ, ứng dụng mở trang **Nhận xét sơ bộ**. Học sinh xem được phần AI quan sát, tiêu chí **Chưa xác định**, nhận xét của giáo viên nếu đã gửi và mục phản hồi của nhóm.
- Gợi ý góc chụp bổ sung có thể mở khi cần. Nút **Gửi ảnh mới** là tùy chọn. Cảnh báo an toàn và xác nhận kiểm tra mạch thật của giáo viên vẫn hiển thị trên trang.
- Thay đổi tại `src/views/result.js` áp dụng cả cho lượt phân tích cũ. Bản cập nhật dùng cấu trúc cơ sở dữ liệu hiện có.
- Đã kiểm tra trên trình duyệt với bài thử chưa rõ, bài thử không có tiêu chí và bài thử ảnh rõ. Đã xác minh nhận xét giáo viên tải từ máy chủ và phản hồi của học sinh lưu thành công. Bộ kiểm tra đạt 51/51.

## Sao lưu

- ZIP trước cập nhật nằm tại `backups/CircuitCoach-nhan-xet-anh-chua-ro-20261120-150054-3fcb319-before.zip`.
- ZIP sau cập nhật nằm tại `backups/CircuitCoach-nhan-xet-anh-chua-ro-20261120-150054-3fcb319-after.zip` và kèm tệp này. Hai ZIP chứa mã nguồn.
- Để thử khôi phục, giải nén mã nguồn vào thư mục riêng. Chạy `npm ci`, `npm run build:sites` rồi `npm run local` với `LOCAL_PORT` đặt ở cổng thử.
