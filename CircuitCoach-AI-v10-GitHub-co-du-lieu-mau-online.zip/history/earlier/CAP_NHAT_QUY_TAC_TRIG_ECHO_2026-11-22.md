# Đối chiếu chân TRIG và ECHO của HC-SR04

Bản local được nạp lúc 23:37 ngày 22/11/2026, giờ Việt Nam. Cập nhật dựa trên commit `3fcb319` và các thay đổi local đã có. [Mở bài HC-SR04](http://127.0.0.1:3187/#/analyzer/hcsr04)

## Luồng sau cập nhật

1. Trong cùng lượt phân tích, AI ghi chân Arduino quan sát được, ảnh cho thấy đầu dây trên cảm biến, ảnh cho thấy đầu dây trên Arduino và vùng bằng chứng nếu thấy rõ.
2. Hệ thống đối chiếu với hai quy tắc của bài. **TRIG → D9** và **ECHO → D10** dùng cùng dữ liệu quy tắc ở bảng bài học và máy chủ. Khi nhìn thấy đầu dây cắm sai chân, kết quả ghi chân quan sát được và chân đúng theo sơ đồ.
3. Với nhiều góc chụp, quan sát chỉ được dùng khi có đoạn dây nối tiếp ở phần ảnh chồng nhau hoặc có dấu vật lý riêng để nhận ra cùng dây. Khi thiếu bằng chứng, kết quả là **Chưa xác định** hoặc **Không nhìn thấy**. Chân cảm biến bỏ trống nhìn rõ được ghi **Cần kiểm tra** và có thể đánh dấu ngay trên ảnh cảm biến.
4. Bản ghi mới lưu trạng thái AI dự đoán ban đầu và quan sát được dùng để đối chiếu, giúp xem lại nếu giáo viên phát hiện khác biệt. Cả hai luồng A/B của HC-SR04 dùng cùng quy tắc cho hai tín hiệu này. Xác nhận an toàn vẫn do giáo viên thực hiện trên mạch thật.

## Kết quả kiểm tra

- 69 bài kiểm thử tự động đều đạt. Đã kiểm tra dây đúng, hai dây đổi chỗ, ảnh che hoặc mơ hồ, nhãn chân không hợp lệ, chân cảm biến bỏ trống và vùng khoanh vượt ảnh.
- Kiểm thử trên bản dựng mô phỏng AI đánh dấu hai tiêu chí đúng trong phần nhận xét sơ bộ, đồng thời ghi nhận TRIG vào D10 và ECHO vào D9. Quy tắc đã trả cả hai tiêu chí **Cần kiểm tra** trong một lượt gọi AI.
- Một lượt OpenAI thật bằng ảnh mẫu đi kèm dự án trả đủ 7 tiêu chí. AI đọc TRIG vào D10 và ECHO vào D11 trên ảnh thử. Hệ thống đối chiếu với D9 và D10, trả hai cảnh báo có vùng khoanh. Kết quả này xác nhận luồng chạy. Cần bộ ảnh được giáo viên xác nhận để chấm độ chính xác thực tế.
- Phạm vi triển khai là bản local và hai tiêu chí TRIG, ECHO. Thay đổi không cần migration cơ sở dữ liệu.

## Sao lưu và khôi phục

Hai gói `CircuitCoach-hcsr04-quy-tac-tin-hieu-20261122-233330-3fcb319-before.zip` và `CircuitCoach-hcsr04-quy-tac-tin-hieu-20261122-233330-3fcb319-after.zip` lưu mã nguồn trước và sau cập nhật. Gói sau có kèm ghi chú này.

Để quay về bản cũ, giải nén gói trước cập nhật vào thư mục riêng. Khôi phục mã nguồn trong `server/ai`, `server/lessons/hcsr04.js`, `src/data/lessons.js`, `src/services/storage.js`, `worker/runtime.js` và `scripts/build-sites-worker.mjs`, rồi chạy `node scripts/build-sites-worker.mjs` và khởi động lại. Dữ liệu làm việc lưu tại `.data`.
