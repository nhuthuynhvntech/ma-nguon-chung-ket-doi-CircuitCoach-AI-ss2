# Cải thiện thao tác khoanh lỗi trên ảnh

Bản local được nạp lại lúc 21:15 ngày 22/11/2026, giờ Việt Nam. Bản cập nhật dựa trên mã nguồn tại commit `3fcb319` và các thay đổi local đã có. [Mở khu vực Giáo viên](http://127.0.0.1:3187/#/teacher)

## Cách dùng

- Mở **Giáo viên → Xem & xác nhận → Nhãn tiêu chí và ảnh tham chiếu**, rồi chọn góc chụp. Các công cụ này cũng có trong **Tải ảnh mẫu theo tiêu chí**.
- Bấm **+** để phóng to tới 300%. Chọn **Di chuyển ảnh** và kéo ảnh tới vị trí cần xem. **Vừa khung** đưa ảnh về kích thước ban đầu.
- Chọn **Khoanh vùng** và kéo chéo qua lỗi. Khi cần đánh dấu một chi tiết nhỏ, chạm một lần lên chi tiết đó. Vòng nét đứt cho biết vùng sẽ được đánh dấu trước khi thả. Khi kéo ngang hoặc dọc, vòng vẫn có chiều rộng và chiều cao tối thiểu để nhìn rõ.
- **Hoàn tác** và **Làm lại** áp dụng cho dấu khoanh, nét vẽ tự do và chú thích đã đặt. Trong một bài nộp, có thể đổi góc chụp rồi quay lại với các dấu đã đặt trên góc đó. Mỗi lần gửi ví dụ dùng ảnh đang chọn cùng các dấu trên ảnh đó.

## Kiểm tra

- Đã kiểm tra trên một ảnh mạch của bài nộp ở bản local. Kéo ngang và chạm tạo hai vòng nhìn thấy được. Hoàn tác còn một vòng, làm lại khôi phục vòng thứ hai.
- Các vòng giữ nguyên tọa độ khi phóng to, kéo ảnh, đưa về vừa khung và chọn lại ảnh. Đã mở một ảnh đã duyệt trong kho tham chiếu và thấy dấu đã lưu trên ảnh.
- Bộ kiểm thử tự động đạt 52/52. Bản dựng và kiểm tra phản hồi máy chủ local đã thành công.
- Dấu đánh dấu vẫn dùng tọa độ theo tỷ lệ ảnh trong dữ liệu tham chiếu. Cập nhật giao diện này không cần migration cơ sở dữ liệu. Phạm vi triển khai của cập nhật là bản local.

## Sao lưu và khôi phục mã nguồn

Hai ZIP `CircuitCoach-khoanh-loi-20261122-210755-3fcb319-before.zip` và `CircuitCoach-khoanh-loi-20261122-210755-3fcb319-after.zip` nằm trong thư mục `backups`. Đây là bản sao lưu mã nguồn.

Để quay về giao diện trước cập nhật, giải nén ZIP trước cập nhật vào một thư mục riêng. Sao chép lại ba tệp `src/views/photo-tools.js`, `src/views/teacher.js` và `src/style.css` vào mã nguồn local, chạy `node scripts/build-sites-worker.mjs`, rồi khởi động lại máy chủ local. Cơ sở dữ liệu và ảnh làm việc nằm ở thư mục `.data` của bản local.
