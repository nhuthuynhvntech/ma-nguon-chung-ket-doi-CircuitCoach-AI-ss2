# Tải ảnh mẫu theo tiêu chí

Ngày 19/11/2026, giờ Việt Nam. Bản cập nhật chạy ở [CircuitCoach local](http://127.0.0.1:3187/#/reference-upload). Mã nguồn dựa trên commit `3fcb319` và các thay đổi local. Bản Sites online hiện ở v4.

## Sử dụng

1. Đăng nhập **Giáo viên** và mở lớp. Chọn **Tải ảnh theo tiêu chí** ở trang giáo viên hoặc trong **Kho tham chiếu**.
2. Chọn bài học. Danh sách tiêu chí đổi theo bài. Chọn tiêu chí ảnh minh họa và nhãn đúng hoặc có lỗi. Khi báo lỗi, chọn dạng lỗi. Nếu chọn **Lỗi khác**, nhập dấu hiệu quan sát được.
3. Chọn tệp JPEG, PNG hoặc WebP trên máy và kiểm tra ảnh xem trước. Bấm **Gửi ảnh để duyệt**.
4. Ảnh xuất hiện trong mục ảnh chưa đủ điều kiện tham chiếu. Kiểm duyệt viên duyệt theo phạm vi bài được phân công. Ảnh đã duyệt có thể được luồng B chọn khi phân tích đúng lớp và bài.

## Dữ liệu và kiểm tra

- `drizzle/0008_uploaded_reference_cases.sql` tạo bảng ảnh tải trực tiếp và danh mục đọc chung cho ảnh tải lên cùng ảnh từ lượt phân tích. Bản ghi lưu lớp, bài, tiêu chí, nhãn, trạng thái kiểm duyệt và người gửi. Tệp ảnh nằm trong `.data/images`. Tải ảnh trực tiếp không tạo lượt bài làm học sinh.
- `src/views/reference-upload.js` chứa biểu mẫu, xem trước và thông báo lưu. `worker/runtime.js` kiểm tra phạm vi lớp, định dạng, tiêu chí, ảnh trùng và trạng thái duyệt.
- Build thành công. Trang chủ trên máy chủ local trả HTTP 200. Bản cập nhật cấu trúc dữ liệu đã áp dụng và SQLite trả `ok` khi kiểm tra toàn vẹn. Ví dụ cũ vẫn có trong danh mục, kho thật chưa có ảnh tải trực tiếp.
- Trên trình duyệt với lớp thử, đã mở trang từ Giáo viên, đổi từ bài LED sang Servo và xác nhận xuất hiện tiêu chí Servo. Chọn nhãn **Có lỗi** hiện trường **Dạng lỗi**.
- Kiểm tra HTTP trên bản riêng đã xác nhận tải ảnh, chặn quyền sai lớp, ngăn gửi trùng, duyệt đúng phạm vi, đọc ảnh đã lưu và đưa ảnh tải trực tiếp đã duyệt vào luồng B. Thử nghiệm A/B dùng phản hồi OpenAI mô phỏng để kiểm tra cách chọn ảnh.
- Bộ kiểm tra toàn dự án đạt 46/48. Hai lỗi cũ liên quan đến Thư mục mạch đúng và giới hạn số ảnh bài nộp dùng chung.

## Sao lưu và khôi phục

- ZIP mã nguồn trước cập nhật nằm trong `backups/CircuitCoach-tai-anh-tieu-chi-20261119-214534-3fcb319-before.zip`.
- ZIP mã nguồn sau cập nhật nằm trong `backups/CircuitCoach-tai-anh-tieu-chi-20261119-214534-3fcb319-after.zip` và kèm tệp ghi thay đổi này.
- Bản chụp SQLite và kho ảnh trước thay đổi nằm trong `backups/CircuitCoach-tai-anh-tieu-chi-20261119-214534-3fcb319-data-before`. Giữ riêng bản sao có dữ liệu lớp.
- Khi thử khôi phục, giải nén mã nguồn vào thư mục riêng, dùng CSDL và thư mục ảnh từ bản chụp tương ứng. Chạy `npm ci`, `npm run build:sites` rồi `npm run local` với `LOCAL_PORT` trên cổng thử.
