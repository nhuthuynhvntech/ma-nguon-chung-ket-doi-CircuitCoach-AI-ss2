# Luồng quản trị, giáo viên và học sinh

Ngày 19/11/2026, giờ Việt Nam. Bản cập nhật chạy ở [CircuitCoach local](http://127.0.0.1:3187/#/home). Mã nguồn dựa trên commit `3fcb319` và các cập nhật local. Bản Sites online hiện ở v4.

## Cách dùng

1. **Quản trị viên** đăng nhập, chọn **Tạo tài khoản giáo viên** và đặt tên đăng nhập, mật khẩu riêng. Giáo viên mới có thể đăng nhập ngay để tạo lớp.
2. **Giáo viên** đăng nhập, bấm **Tạo mã lớp** rồi **Sao chép mã lớp** để gửi cho học sinh. Khi có nhiều lớp, chọn mã lớp cần xem trong danh sách. Mỗi mã được tạo và lưu trên máy chủ.
3. **Học sinh** chọn vai trò học sinh, nhập **Tên hoặc tên nhóm** và **Mã lớp**, rồi bấm **Vào lớp**. Dùng lại đúng hai thông tin này để mở lịch sử đã đồng bộ. Mã lớp cần tồn tại trên cùng máy chủ.
4. Dùng nút **Đăng xuất quản trị**, **Đăng xuất giáo viên** hoặc **Thoát lớp** để về màn chọn vai trò. Lịch sử đã đồng bộ được giữ trên máy chủ.

## Dữ liệu và quyền xem

- `drizzle/0009_class_registry.sql` tạo danh sách mã lớp và ghi nhận các mã cũ từ lớp đã phân công, bài làm và thư viện. Quyền của giáo viên dựa trên các mã lớp họ được gắn trong CSDL.
- Dữ liệu học sinh được mở theo cặp tên nhóm và mã lớp. Cùng một trình duyệt có thể đăng nhập nhóm khác. Lịch sử và thao tác đồng bộ dùng phạm vi nhóm đang mở. Phiên nhân sự được xác nhận trên máy chủ.
- Trang quản trị hiển thị cả mã lớp mới chưa có bài nộp. Ảnh tham chiếu công khai tiếp tục phục vụ khách theo trạng thái duyệt.

## Xác minh

- Đã thử trên trình duyệt bằng dữ liệu riêng. Quản trị tạo giáo viên, giáo viên mới tạo mã lớp, học sinh vào bằng tên và mã đó. Cả ba thao tác đăng xuất đều đưa về màn chọn vai trò.
- Kiểm tra HTTP xác nhận giáo viên chỉ truy cập lớp có quyền, mã lớp sai bị từ chối, học sinh đổi nhóm không nhìn thấy lịch sử nhóm cũ, và đăng nhập lại với đúng tên và mã mở được bài đã lưu.
- Đã kiểm tra luồng nộp ảnh, duyệt ảnh, kho công khai và A/B bằng dữ liệu thử, với phản hồi OpenAI mô phỏng cho A/B.
- Đã đối chiếu dữ liệu live local với bản chụp trước khi cập nhật. Lớp `DEMO921`, 1 bài làm đã lưu và 2 tài khoản nhân sự đều có trong CSDL mới. SQLite trả `ok` khi kiểm tra toàn vẹn.
- Build thành công. Bộ kiểm tra toàn dự án đạt 46/48. Hai lỗi cũ liên quan tới ảnh bài nộp.

## Sao lưu và khôi phục

- ZIP mã nguồn trước cập nhật nằm tại `backups/CircuitCoach-luong-vai-tro-20261119-223943-3fcb319-before.zip`.
- ZIP mã nguồn sau cập nhật nằm tại `backups/CircuitCoach-luong-vai-tro-20261119-223943-3fcb319-after.zip` và kèm tệp này.
- Bản chụp SQLite và kho ảnh nằm tại `backups/CircuitCoach-luong-vai-tro-20261119-223943-3fcb319-data-before`. Giữ riêng vì chứa dữ liệu lớp.
- Để thử khôi phục, giải nén mã nguồn vào thư mục riêng, dùng bản sao CSDL và thư mục ảnh tương ứng. Chạy `npm ci`, `npm run build:sites` rồi `npm run local` với `LOCAL_PORT` ở một cổng thử.
