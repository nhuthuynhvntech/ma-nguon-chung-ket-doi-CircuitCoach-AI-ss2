# Giao diện sáng và tối cho CircuitCoach AI

Bản local đã nạp cập nhật lúc 22:04 ngày 23/11/2026, giờ Việt Nam. Mã nguồn dựa trên commit `3fcb319` và các thay đổi local hiện có. Phạm vi triển khai là bản local. [Mở CircuitCoach AI](http://127.0.0.1:3187/#/lessons)

## Cách dùng

Bấm **Sáng** hoặc **Tối** ở đầu trang để đổi giao diện. Nút cũng có trên màn hình đăng nhập. Khi mới mở bằng trình duyệt chưa lưu lựa chọn, hệ thống dùng chế độ tối. Lựa chọn được lưu trên trình duyệt và được áp dụng khi đổi trang hoặc tải lại.

Hai bảng màu điều chỉnh nền, chữ, bảng, ô nhập, cảnh báo và sơ đồ lắp mạch. Đổi nền cập nhật giao diện ngay trên trang đang mở, giữ nguyên mục đang xem và thao tác đang thực hiện.

## Kiểm tra và khôi phục

- 78 kiểm thử tự động đã đạt. Kiểm tra 22 cặp màu chữ và nền chính ở cả hai chế độ cho kết quả tương phản tối thiểu 4,5:1.
- Đã thử trên trình duyệt bằng bàn phím và chuột, kiểm tra giữ lựa chọn sau tải lại, chuyển giữa trang prompt, trang phân tích, sơ đồ lắp mạch và danh sách bài học. Mục prompt đang mở tiếp tục hiện khi đổi nền.
- Cập nhật nằm trong `index.html`, `src/main.js`, `src/services/theme.js`, `src/style.css`, thanh đầu trang và màn hình đăng nhập. Lựa chọn được lưu trên trình duyệt, dùng cơ sở dữ liệu hiện có và không cần migration.
- Hai gói `CircuitCoach-giao-dien-sang-toi-20261123-215935-3fcb319-before.zip` và `CircuitCoach-giao-dien-sang-toi-20261123-215935-3fcb319-after.zip` lưu mã nguồn trước và sau cập nhật. Gói sau kèm ghi chú này. Khi cần khôi phục, giải nén gói trước vào một thư mục riêng và dùng mã nguồn trước cập nhật, sau đó chạy `node scripts/build-sites-worker.mjs` và khởi động lại máy chủ local với dữ liệu hiện có.
