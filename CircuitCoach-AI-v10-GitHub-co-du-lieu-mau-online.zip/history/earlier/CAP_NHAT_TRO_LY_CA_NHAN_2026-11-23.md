# CircuitCoach AI · Trợ lý cá nhân theo lịch sử

Bản local được cập nhật lúc 23:19 ngày 23/11/2026, giờ Việt Nam. Mã nguồn dựa trên commit 3fcb319 cùng các cập nhật local đã có.

## Cách dùng

1. Mở [CircuitCoach](http://127.0.0.1:3187/#/home), vào vai trò **Học sinh** bằng tên hoặc tên nhóm và mã lớp.
2. Bấm **Hỏi trợ lý**. Thẻ **Bước tiếp theo của nhóm** sẽ đọc lịch sử trong cơ sở dữ liệu và gợi ý việc cần làm. Nếu đang mở một bài, trợ lý ưu tiên bài đó. Ở mục hướng dẫn chung, trợ lý xem bài có lượt làm gần nhất.
3. Mở nhận xét đã lưu hoặc chọn **Xem lượt làm gần nhất** để xem lại kết quả. Có thể hỏi tiếp “Lần tới em nên kiểm tra chỗ nào?” để nhận hướng dẫn cụ thể hơn.

## Cách trợ lý dùng lịch sử

- Lấy tối đa 24 lượt làm thật gần đây đã đồng bộ. Khi chọn một bài, các lượt được lấy trong bài đó. Khi chọn hướng dẫn chung, trợ lý tóm tắt bài gần nhất trong số các lượt đã lấy.
- Nếu lượt gần nhất có cảnh báo an toàn từ giáo viên, thẻ ưu tiên cảnh báo đó. Các tiêu chí chưa rõ dẫn tới gợi ý bổ sung ảnh. Nhãn giáo viên được ưu tiên khi có cả nhãn và nhận định AI cho cùng tiêu chí.
- Ghi nhận một tiêu chí tiến bộ khi nhãn mới nhất là đúng và nhãn trước đó của tiêu chí ấy là sai. Đánh giá của giáo viên về độ chính xác của AI được xử lý riêng với nhãn của từng tiêu chí mạch.
- Thông tin lịch sử gửi đến OpenAI chỉ gồm tóm tắt theo bài và tiêu chí. Tên nhóm, mã lớp, ảnh, mã lượt làm và nguyên văn nhận xét không thuộc tóm tắt gửi đi. Khi gõ câu hỏi, nội dung câu hỏi được gửi cùng với tóm tắt. Nhận xét đầy đủ hiển thị trong ứng dụng theo phiên học sinh.
- Nhắc nhở xuất hiện khi mở trợ lý. Cơ sở dữ liệu hiện có lưu lượt làm và nhận xét, nên có thể dùng lại sau khi đăng nhập. Các tin nhắn hỏi đáp giữ tạm theo tab. Bản cập nhật không cần chuyển đổi dữ liệu hay thêm bảng mới.
- Giáo viên vẫn kiểm tra trực tiếp mạch đang thực hành và quyết định khi nào được cấp nguồn.

## Kiểm tra

- 84 kiểm thử tự động đạt. Bản dựng và trang local trên cổng 3187 hoạt động.
- Cơ sở dữ liệu thử riêng xác nhận tính năng loại lượt mô phỏng, lọc theo bài và từ chối truy cập lịch sử của nhóm khác hoặc lớp khác bằng phiên hiện tại.
- Trên giao diện, trợ lý hiển thị nhãn Signal cần sửa, tiến bộ ở GND, nhận xét giáo viên và mở đúng lượt làm. Câu hỏi thử qua OpenAI trả lời đúng chân Signal là D6 và nhắc giữ nguồn ngắt khi kiểm tra.

## Sao lưu mã nguồn

- Trước cập nhật `backups/CircuitCoach-tro-ly-ca-nhan-20261123-231514-3fcb319-before.zip`
- Sau cập nhật `backups/CircuitCoach-tro-ly-ca-nhan-20261123-231514-3fcb319-after.zip`

Giải nén bản tương ứng vào thư mục riêng để đối chiếu hoặc khôi phục mã. Tệp ZIP không chứa cơ sở dữ liệu, ảnh bài nộp hay cấu hình bí mật.
