# Kiểm tra lại cảnh báo chiều LED

Ngày 25/11/2026 · CircuitCoach AI · Bản local Windows

Lượt phân tích gần nhất báo cathode đi về nhánh cấp ở ảnh 3. Vùng đánh dấu chân hồi nằm chồng lên vùng bản cực bên trong. Ảnh cận cho thấy cathode dạng chén đi về GND và anode đi qua điện trở về D8, phù hợp với chiều mắc của bài LED cơ bản.

Bộ chấm kiểm tra vùng của hai chân ở ngoài vỏ LED. Để cảnh báo mắc ngược, AI phải chỉ ra hai đầu nối cuối và nhãn đọc được trên ảnh. Bài LED cơ bản yêu cầu D8 và GND. Bài LED dùng pin yêu cầu cực dương và cực âm. Nếu vùng chân chồng lên bản cực hoặc các đầu nối chưa được xác minh, kết quả hiện **Chưa xác định**.

Mỗi lượt tiếp tục dùng một yêu cầu AI. Giáo viên xác nhận an toàn trên mạch thật trước khi cấp nguồn.

113 kiểm thử tự động đạt. Kiểm thử cục bộ phát lại ba ảnh với vùng bằng chứng từ lượt báo sai và phản hồi AI mô phỏng. Vùng cũ cho trạng thái **Chưa xác định**. Vùng đã đối chiếu theo đường nối quan sát được cho trạng thái **Đúng**. Ca mắc ngược có đủ hai đầu nối vẫn cho cảnh báo.

- Mã nguồn trước cập nhật `backups/CircuitCoach-Chieu-LED-bao-sai-2026-11-25-114258-truoc.zip`
- Mã nguồn sau cập nhật `backups/CircuitCoach-Chieu-LED-bao-sai-2026-11-25-114258-sau.zip`
