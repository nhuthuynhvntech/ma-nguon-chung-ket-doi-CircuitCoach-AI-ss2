# Đối chiếu vùng giáo viên khoanh · 24/11/2026

Kho LED có năm ảnh lỗi GND đã duyệt và được khoanh. Cả năm trùng tệp với một trong ba góc ảnh của lượt được kiểm tra. Bộ lọc ví dụ trước đây bỏ qua ảnh trùng để tránh dùng lại chính ảnh cần chấm.

Khi ảnh mẫu đã khoanh có nội dung khác ảnh đang phân tích, CircuitCoach chọn ví dụ cùng bài và tiêu chí, rồi dùng vùng giáo viên khoanh để tạo ảnh cận minh họa. Khi dấu khoanh thuộc đúng một ảnh của lượt hiện tại, CircuitCoach dùng tọa độ làm vùng cần đọc kỹ trên ảnh đó. AI vẫn phải lần đúng đầu dây, đọc nhãn lỗ cắm và dùng bằng chứng trên ảnh hiện tại.

Nếu lỗ cắm AI xác định lệch khỏi vùng giáo viên đã khoanh trên cùng ảnh và tiêu chí, kết quả hiện **Chưa xác định**. Học sinh xem số ảnh có vùng khoanh đã được đưa vào đối chiếu trong **Kết quả → Tóm tắt**. Ảnh chưa duyệt và ảnh đã ngừng dùng bị loại khỏi bước đối chiếu. Luồng A/B dùng ảnh mẫu đã khoanh khác ảnh của lượt đang đo.

96 kiểm thử đạt. Kiểm tra tại máy bằng bản đã đóng gói và phản hồi mô phỏng xác nhận cả ba ảnh LED đã lưu đều nhận đúng vùng khoanh GND và đưa vùng đó vào lượt đọc cận. Kết quả này xác minh đường đưa dữ liệu vào AI. Chân cắm trên bộ ảnh riêng vẫn cần được xác minh trong lần phân tích bằng OpenAI thật.

Trong thư mục `backups`, `CircuitCoach-Khoanh-giao-vien-2026-11-24-234441-truoc.zip` chứa bản trước cập nhật, `CircuitCoach-Khoanh-giao-vien-2026-11-24-234441-sau.zip` chứa bản mới và `CircuitCoach-Khoanh-giao-vien-2026-11-24-234441-du-lieu.zip` chứa cơ sở dữ liệu cùng 99 ảnh đã sao lưu.
