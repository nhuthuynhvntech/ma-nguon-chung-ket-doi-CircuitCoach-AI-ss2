# Đọc lại các tiêu chí AI từng sai · 24/11/2026

Khi học sinh phân tích ảnh, CircuitCoach lấy các tiêu chí đã được giáo viên báo AI nhận diện sai trong cùng bài và lớp. Các tiêu chí đó được đọc lại độc lập trên toàn bộ ảnh của lượt hiện tại. Với lỗi đọc nhầm chân, AI lần đầu dây xuất phát đến đúng lỗ cắm và kiểm tra nhãn của các chân kề bên. Các nhắc nhở theo loại lỗi được đưa vào cả lượt phân tích chung và lượt đọc lại.

Máy chủ đối chiếu giá trị quan sát từ hai lượt. Ví dụ, nếu một lượt thấy GND và lượt còn lại thấy D12, tiêu chí chuyển thành **Chưa xác định** và kết quả giải thích sự mâu thuẫn. Khi đủ bằng chứng về D12, ứng dụng báo kiểm tra kết nối và khoanh đúng ảnh nếu lượt đọc lại định vị được. Một tiêu chí đã được đọc lại có thể vẫn chưa xác định nếu ảnh thiếu bằng chứng.

Học sinh thấy số tiêu chí đã được đọc lại trong **Kết quả → Tóm tắt**. Giáo viên xem hướng dẫn AI ở **Bài học → Xem prompt AI → Prompt đọc lại các tiêu chí AI từng sai**. Lượt đọc lại dùng tối đa sáu tiêu chí từ danh sách nhắc hiện có. Hai lượt chạy song song trong giới hạn thời gian của yêu cầu phân tích. Bộ kiểm thử A/B tiếp tục sử dụng luồng phân tích dành cho thử nghiệm.

89 kiểm thử đều đạt. Kiểm thử mô phỏng OpenAI dùng bộ ảnh mới đã xác minh tình huống GND và D12 mâu thuẫn, hai lượt cùng phát hiện D12, có ảnh liên quan nhưng thiếu vị trí khoanh và lượt đọc lại bị gián đoạn.

Trong thư mục `backups`, `CircuitCoach-Doc-lai-loi-AI-2026-11-24-225628-truoc.zip` chứa bản trước cập nhật, `CircuitCoach-Doc-lai-loi-AI-2026-11-24-225628-sau.zip` chứa bản đã cập nhật và `CircuitCoach-Doc-lai-loi-AI-2026-11-24-225628-du-lieu.zip` chứa cơ sở dữ liệu cùng 85 ảnh đã sao lưu.
