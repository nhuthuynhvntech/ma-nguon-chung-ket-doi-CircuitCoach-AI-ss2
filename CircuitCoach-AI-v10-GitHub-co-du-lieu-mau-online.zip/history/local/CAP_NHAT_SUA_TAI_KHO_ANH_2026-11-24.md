# Sửa lỗi tải kho ảnh · 24/11/2026

Trang [Kho tham chiếu bài LED](http://127.0.0.1:3190/#/references/led) kẹt ở “Đang tải ảnh của bài…” dù máy chủ đã trả danh sách. Phần tạo liên kết thư mục lỗi vẫn dùng tên cũ `privateView` sau khi chuyển sang kho chung. Bản sửa dùng chế độ hiện tại `managing` để tạo đúng liên kết cho kho công khai và kho quản lý.

Đã khởi động lại bản local trên cổng 3190 và kiểm tra trực tiếp trên trình duyệt. Bài LED hiển thị 4 ảnh đã duyệt. Nút **Làm mới**, thư mục **Nối nhầm chân hoặc sai vị trí** và thao tác phóng to ảnh hoạt động. Bộ 85 kiểm thử đều đạt.

Trong thư mục `backups`, tệp `CircuitCoach-sua-tai-anh-2026-11-24-213723-truoc.zip` chứa bản chạy và mã nguồn trước khi sửa. Tệp `CircuitCoach-sua-tai-anh-2026-11-24-213723-sau.zip` chứa bản đã sửa. Tệp `CircuitCoach-sua-tai-anh-2026-11-24-213723-du-lieu.zip` chứa cơ sở dữ liệu, 59 ảnh và bảng kê của bản sao lưu.
