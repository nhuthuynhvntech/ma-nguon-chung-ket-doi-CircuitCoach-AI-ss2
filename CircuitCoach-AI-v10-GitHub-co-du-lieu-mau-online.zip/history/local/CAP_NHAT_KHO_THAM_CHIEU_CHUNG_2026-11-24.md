# Kho tham chiếu dùng chung · 24/11/2026

Mở [Kho tham chiếu](http://127.0.0.1:3190/#/references), chọn bài học rồi xem mẫu đúng hoặc các thư mục dạng lỗi. Tất cả ảnh đã duyệt của cùng bài được hiển thị chung. Học sinh cũng thấy ảnh này trong **Hướng dẫn và ảnh mẫu** và có thể bấm vào để phóng to, xem các nét khoanh và chú thích.

Giáo viên đăng nhập, vào [Quản lý kho chung](http://127.0.0.1:3190/#/references/all?view=manage) rồi chọn bài. Nút **Tải ảnh theo tiêu chí** mở biểu mẫu chọn bài, tiêu chí, nhãn và ảnh. Giáo viên có thể duyệt ảnh mình tải trực tiếp hoặc ảnh được gửi từ lớp mình phụ trách. Quản trị viên có thể duyệt và ngừng dùng ảnh trên toàn hệ thống.

Khi chọn **Duyệt và công khai**, ảnh xuất hiện trong kho của bài học và có thể được AI chọn làm ví dụ theo tiêu chí. Khi chọn **Ngừng dùng**, ảnh rời danh sách công khai và danh sách ví dụ AI có thể chọn. Ảnh và lịch sử duyệt vẫn được lưu trong dữ liệu local. Ảnh bài làm của học sinh tiếp tục theo quyền của lớp nguồn cho đến khi giáo viên chủ động gửi một ảnh vào quy trình duyệt tham chiếu.

Đã chạy 85 kiểm thử. Máy chủ local trên cổng 3190 trả đủ 10 ảnh công khai của bản dữ liệu hiện có, gồm 7 ảnh bài LED và 3 ảnh bài HC-SR04. Bản sao dữ liệu có 28 lượt làm, 58 tệp ảnh và đã vượt qua kiểm tra toàn vẹn SQLite.

## Tệp sao lưu trong thư mục backups

- `CircuitCoach-Kho-chung-2026-11-24-140719-truoc.zip` chứa mã nguồn và bản chạy trước khi cập nhật.
- `CircuitCoach-Kho-chung-2026-11-24-140719-sau.zip` chứa mã nguồn, bản chạy và ghi chú cập nhật này.
- `CircuitCoach-Kho-chung-2026-11-24-140719-du-lieu.zip` chứa cơ sở dữ liệu, ảnh và bảng kê để đối chiếu.

Hướng dẫn khôi phục nằm trong `HUONG_DAN_KHOI_PHUC.md`.
