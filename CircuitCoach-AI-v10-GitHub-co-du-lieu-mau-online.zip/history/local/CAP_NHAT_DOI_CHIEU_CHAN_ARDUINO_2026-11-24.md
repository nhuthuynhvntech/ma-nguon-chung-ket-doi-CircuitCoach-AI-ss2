# Đối chiếu vị trí chân Arduino Uno · 24/11/2026

Các bài dùng Arduino Uno có bước đối chiếu lỗ cắm theo sơ đồ chân. AI chỉ vị trí đầu dây đi vào lỗ và ba lỗ làm mốc trên cùng một hàng. Máy chủ kiểm tra thứ tự, khoảng cách giữa các mốc và độ lệch của đầu dây trước khi suy ra tên chân. Ví dụ, trên hàng có **GND → D13 → D12 → D11**, vị trí giữa D13 và D11 tương ứng với D12.

Kết quả nêu tên các mốc đã dùng và khoanh tại lỗ cắm của vùng có lỗi. Nếu các mốc chưa đáng tin cậy, đầu dây chưa ở đúng một lỗ hoặc các góc ảnh mâu thuẫn, tiêu chí được giữ ở **Chưa xác định**. Bước đối chiếu nằm trong lượt đọc lại, chạy song song với lượt phân tích chung.

Học sinh xem kết quả trong **Tóm tắt**. Prompt và các hàng chân được hỗ trợ có ở [Prompt bài LED](http://127.0.0.1:3190/#/lesson-prompts/led), mục **Prompt đối chiếu vị trí chân Arduino Uno**.

94 kiểm thử đạt. Kiểm thử dùng tọa độ đo gần đúng trên ảnh LED xác định được D12 và kiểm tra thêm ảnh xoay, đầu dây nằm giữa hai lỗ, mốc sai hàng và hai lỗ GND trên hàng nguồn. Kiểm thử tích hợp mô phỏng xác nhận bộ đối chiếu có thể sửa giá trị GND thành D12 khi các mốc và vị trí đầu dây chỉ ra D12.

Chạy thử với OpenAI thật trên hai ảnh mẫu công khai đi kèm dự án trả kết quả HTTP 200 sau khoảng 24 giây. Hệ thống đối chiếu được một tiêu chí và xác định lỗ GND. Tiêu chí chân cấp tín hiệu được giữ ở **Chưa xác định**.

Trong thư mục `backups`, `CircuitCoach-So-do-chan-2026-11-24-230916-truoc.zip` chứa bản trước cập nhật, `CircuitCoach-So-do-chan-2026-11-24-230916-sau.zip` chứa bản đã cập nhật và `CircuitCoach-So-do-chan-2026-11-24-230916-du-lieu.zip` chứa cơ sở dữ liệu cùng 88 ảnh đã sao lưu.
