# Đọc cận cảnh hàng chân Arduino · 24/11/2026

Ở lượt LED sau cập nhật sơ đồ chân, AI giữ cả hai kết nối ở **Chưa xác định**. Ảnh cận có chi tiết để kiểm tra nhưng kết quả từ hai lượt trên ảnh toàn khung vẫn chưa xác định được đúng lỗ.

Với các tiêu chí nối dây vào Arduino Uno, CircuitCoach tạo bản cắt cận từ các góc đã gửi và giữ ảnh gốc bên cạnh để lần đường dây. Ảnh cận được đưa vào lượt đọc chạy song song. Nếu vẫn thiếu vị trí và còn thời gian, ứng dụng cắt lại từ vùng đã quan sát để thử một góc khác. Máy chủ kiểm tra ba mốc trên hàng chân, quy đổi tọa độ về đúng ảnh gốc rồi mới vẽ vùng khi đủ bằng chứng về lỗi. Nếu các góc vẫn mâu thuẫn, giao diện giữ **Chưa xác định**.

Học sinh xem bằng chứng ngay trong **Kết quả → Tóm tắt**. Dòng **Vị trí được xác minh lại trên ảnh cắt cận** xuất hiện khi bước đọc cận định vị thành công. Có thể xem hướng dẫn của AI ở [Prompt bài LED](http://127.0.0.1:3190/#/lesson-prompts/led).

95 kiểm thử đạt. Kiểm thử tích hợp mô phỏng xác nhận bước đọc cận khôi phục được D12 trên ảnh 2 khi lượt toàn khung chưa xác định. Trên chính ảnh LED đã lưu, kiểm tra tại máy bằng các điểm do người kiểm tra đánh dấu đã quy đổi đúng D12 sau khi cắt ảnh. Chạy OpenAI thật với hai ảnh mẫu công khai trả kết quả sau khoảng 51 giây. Bước đọc cận xác minh được GND và tiêu chí chân tín hiệu vẫn **Chưa xác định**. Bộ ảnh riêng được dùng riêng cho kiểm tra tọa độ tại máy.

Trong thư mục `backups`, `CircuitCoach-Doc-can-chan-2026-11-24-233015-truoc.zip` chứa bản trước cập nhật, `CircuitCoach-Doc-can-chan-2026-11-24-233015-sau.zip` chứa bản mới và `CircuitCoach-Doc-can-chan-2026-11-24-233015-du-lieu.zip` chứa cơ sở dữ liệu cùng 93 ảnh đã sao lưu.
