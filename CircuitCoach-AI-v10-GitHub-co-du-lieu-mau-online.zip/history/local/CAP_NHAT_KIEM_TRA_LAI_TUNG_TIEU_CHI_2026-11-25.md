# Kiểm tra lại từng tiêu chí bằng ảnh bổ sung

25/11/2026 · CircuitCoach AI · Bản local Windows

Mở **Kết quả → Tóm tắt** của một lượt làm đã đồng bộ. Dưới tiêu chí đang cần kiểm tra hoặc chưa xác định, chọn **Chụp ảnh kiểm tra lại** hoặc **Tải ảnh kiểm tra lại**. Chụp cận đúng chi tiết được nêu ở tiêu chí và giữ nguồn ngắt. Hệ thống kiểm tra tiêu chí đó ngay trên trang. Nếu mất kết nối hoặc hết thời gian chờ, có thể thử lại ảnh vừa chọn.

Mỗi lần kiểm tra tạo một bản ghi riêng gắn với bài làm và tiêu chí. Kết quả mới nhất xuất hiện trên thẻ tiêu chí cùng ảnh và lời giải thích. Các lần trước mở được trong cùng thẻ. Kết quả toàn mạch ban đầu và quyết định của giáo viên tiếp tục lưu trong bài gốc. Các mục cần kiểm tra trực tiếp vẫn thuộc bước xác nhận an toàn của giáo viên.

Giáo viên phụ trách mở **Xem & xác nhận → Ảnh kiểm tra lại từng tiêu chí** để xem ảnh và kết quả lưu theo bài làm. Ảnh kiểm tra lại thuộc kho riêng của lớp và sử dụng cùng quyền xem ảnh của bài gốc.

116 kiểm thử tự động đạt. Kiểm tra OpenAI thật dùng một ảnh mẫu và một yêu cầu, chấm đúng tiêu chí được chọn, lưu bản ghi và đọc lại ảnh thành công. Máy chủ local đã áp dụng bảng mới. Chụp bằng camera cần quyền camera trong trình duyệt.

- Mã nguồn trước cập nhật `backups/CircuitCoach-Kiem-tra-lai-tung-tieu-chi-2026-11-25-130735-truoc.zip`
- Mã nguồn sau cập nhật `backups/CircuitCoach-Kiem-tra-lai-tung-tieu-chi-2026-11-25-130735-sau.zip`
- Dữ liệu trước cập nhật `backups/du-lieu-local/2026-11-25T06-07-35.441Z`
- Dữ liệu sau cập nhật `backups/du-lieu-local/2026-11-25T06-15-02.587Z`
