# Xác định chiều LED bài 4 từ hai nhánh nhìn thấy

25/11/2026 · CircuitCoach AI · Bản local Windows

Ở lượt lưu 14:07, ảnh cận cho thấy hai điện cực của LED, điện trở và công tắc. Lượt chấm trước nhận ra cathode đi tới công tắc nhưng vẫn cần dấu cực pin để diễn giải chiều LED.

Bài 4 nay xác minh chiều lắp LED khi lần được anode đến điện trở và cathode đến công tắc. Các chi tiết có thể đến từ nhiều góc chụp. Khi có dấu cực pin nhìn rõ, đường nối đã lần tới cực cũng là bằng chứng. Cực pin, nhãn điện áp, trạng thái đóng mạch và kiểm tra an toàn vẫn có tiêu chí riêng.

Lượt OpenAI sau thay đổi dùng đúng ba ảnh đã lưu. Chiều LED được chấm **Đúng** từ ảnh 3. Ảnh 2 được AI đọc đỏ–đỏ–nâu–vàng kim, tương ứng 220 Ω, nên tiêu chí điện trở cảnh báo ngoài khoảng 330–1.000 Ω của bài. Cần đối chiếu giá trị thật của điện trở trước khi cấp nguồn. Ảnh hiện chưa cho thấy dấu cực pin, nhãn điện áp và bằng chứng tiếp điểm công tắc đã đóng. Nguy cơ chập cần giáo viên kiểm tra trực tiếp.

118 kiểm thử tự động đạt. Quy tắc mới áp dụng khi phân tích hoặc kiểm tra lại tiêu chí chiều LED bằng ảnh.

- Mã nguồn trước cập nhật `backups/CircuitCoach-Chieu-LED-bai-4-2026-11-25-141346-truoc.zip`
- Mã nguồn sau cập nhật `backups/CircuitCoach-Chieu-LED-bai-4-2026-11-25-141346-sau.zip`
