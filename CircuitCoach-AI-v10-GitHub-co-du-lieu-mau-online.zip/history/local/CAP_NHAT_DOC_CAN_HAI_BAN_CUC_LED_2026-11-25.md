# Đọc cận hai bản cực LED trong cùng lượt phân tích

25/11/2026 · CircuitCoach AI · Bản local Windows

Ở lượt lưu gần nhất, AI nhận diện được linh kiện nhưng chưa xác định chiều LED. Thử lại bằng OpenAI trên ba ảnh của lượt đó cho thấy mô hình đọc được nhãn D8 và GND trên ảnh toàn khung nhưng gán nhầm chén phản xạ sang chân bên kia.

Với hai bài có tiêu chí chiều LED, hệ thống chọn tối đa hai vùng có chi tiết để tạo ảnh cận tự động từ ảnh JPEG. OpenAI nhận các ảnh gốc và các vùng cận trong cùng một yêu cầu. Ảnh cận giữ chỉ số của ảnh gốc. Hướng dẫn yêu cầu đọc lòng chén phản xạ trong thân LED trước, xác định nơi chân đi qua mép vỏ rồi lần đến nhãn thực tế. Máy chủ vẫn yêu cầu bằng chứng rõ để chấm chiều. Giáo viên vẫn xác nhận an toàn trên mạch thật trước khi cấp nguồn.

Kiểm tra bằng OpenAI trên đúng ba ảnh đã lưu cho tiêu chí chiều LED **Đúng**. Ảnh 2 cho thấy cathode nối về GND. Ảnh 3 giúp lần nhánh anode qua điện trở tới D8. Lượt này chỉ dùng ảnh mạch cần chấm. Kiểm tra riêng kết nối và trị số điện trở vẫn có thể ở **Chưa xác định**. Kết quả cũ tiếp tục được giữ trong lịch sử. Đã đạt 114 kiểm thử tự động.

- Bản sao mã nguồn trước cập nhật `backups/CircuitCoach-Doc-ro-chieu-LED-2026-11-25-123836-truoc.zip`
- Bản sao mã nguồn sau cập nhật `backups/CircuitCoach-Doc-ro-chieu-LED-2026-11-25-123836-sau.zip`
