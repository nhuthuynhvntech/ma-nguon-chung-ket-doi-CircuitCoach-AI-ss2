# Nhận xét của giáo viên theo từng ảnh kiểm tra lại

25/11/2026 · CircuitCoach AI · Bản local Windows

Giáo viên phụ trách lớp vào **Dành cho giáo viên → Xem & xác nhận → Ảnh kiểm tra lại từng tiêu chí**. Bấm ảnh để phóng to trong trình xem. Viết nhận xét dưới đúng ảnh rồi bấm **Lưu nhận xét ảnh**. Có thể chỉnh sửa nhận xét đã lưu trong cùng ô.

Học sinh mở lại trang kết quả để đọc nhận xét của giáo viên ngay dưới ảnh bổ sung tương ứng. Nhận xét, người ghi và thời điểm lưu gắn với bản ghi của ảnh trong cơ sở dữ liệu. Kết quả AI và nhận xét chung của bài vẫn xem được trong phần gốc.

Các lần lưu từ hai thiết bị được kiểm tra phiên bản để tránh ghi đè nội dung mới. Trang giáo viên cập nhật thông báo lưu ngay tại biểu mẫu và tạm hoãn tải lại khi có bản nháp đang nhập. Chỉ giáo viên phụ trách lớp có quyền sửa nhận xét.

117 kiểm thử tự động đạt, gồm lưu, sửa, giới hạn quyền, chống ghi đè và tải lại nhận xét ở phía học sinh. Đã xác minh ảnh LED đã gửi trước cập nhật còn hiển thị và có ô nhận xét trên bản local.

- Mã nguồn trước cập nhật `backups/CircuitCoach-Nhan-xet-anh-kiem-tra-lai-2026-11-25-134435-truoc.zip`
- Mã nguồn sau cập nhật `backups/CircuitCoach-Nhan-xet-anh-kiem-tra-lai-2026-11-25-134435-sau.zip`
- Dữ liệu trước cập nhật `backups/du-lieu-local/2026-11-25T06-44-35.870Z`
- Dữ liệu sau cập nhật `backups/du-lieu-local/2026-11-25T06-47-40.299Z`
