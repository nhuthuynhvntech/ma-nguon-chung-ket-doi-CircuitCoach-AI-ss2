# Phân tích ảnh mạch trong một lượt

Ngày 25/11/2026 · CircuitCoach AI · Bản local Windows

Mỗi lần phân tích gửi một yêu cầu OpenAI. Yêu cầu chứa các góc ảnh đã tải, tiêu chí bài học, ảnh tham chiếu và lời nhắc phù hợp từ giáo viên. Nếu ứng dụng tìm được vùng giáo viên đã đánh dấu trên đúng ảnh này, có thể gửi kèm ảnh cận của vùng đó trong cùng yêu cầu.

Máy chủ kiểm tra bằng chứng theo từng tiêu chí. Hệ thống có thể dùng một góc đủ rõ hoặc ghép bằng chứng từ nhiều góc. Nhãn chân Arduino Uno phải khớp với vị trí lỗ cắm và mốc cùng hàng. Chi tiết thiếu hoặc mâu thuẫn hiện **Chưa xác định**. Các tiêu chí cần đo hoặc kiểm tra mạch thật vẫn yêu cầu giáo viên xác minh trước khi cấp nguồn.

Mỗi nhánh A/B dùng một lượt đọc riêng. Phiên bản quy tắc mới được ghi cùng kết quả để theo dõi lịch sử.

Thử với hai ảnh mẫu LED cho đúng một yêu cầu OpenAI và kết quả sau khoảng 50 giây. Ba mục có bằng chứng gồm nhận diện linh kiện, trị số điện trở 220 Ω và mắc nối tiếp. Các mục D8, GND và chiều LED trong bộ ảnh này chưa đủ bằng chứng để chấm. Bộ 109 kiểm thử tự động xác nhận cả trường hợp dùng nhiều góc, phát hiện nhãn chân mâu thuẫn và lưu kết quả của lượt đọc mới.

- Mã nguồn trước cập nhật `backups/CircuitCoach-Mot-luot-doc-2026-11-25-102546-truoc.zip`
- Mã nguồn sau cập nhật `backups/CircuitCoach-Mot-luot-doc-2026-11-25-102546-sau.zip`
