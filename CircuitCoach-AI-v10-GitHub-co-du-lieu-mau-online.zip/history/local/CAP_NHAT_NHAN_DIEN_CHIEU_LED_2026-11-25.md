# Nhận diện chiều LED từ hai bản cực

Ngày 25/11/2026 · CircuitCoach AI · Bản local Windows

Trong ba ảnh gần nhất, ảnh cận thể hiện bản cực dạng chén nối về GND và bản cực nhỏ nối qua điện trở về D8. Năm lượt LED gần nhất đều dừng tiêu chí chiều LED ở bước kiểm tra bằng chứng.

Lượt đọc yêu cầu AI nhận diện hai bản cực khác nhau trên cùng một ảnh và ghi rõ chân nào nối về nhánh cấp hoặc nhánh hồi. Hệ thống kiểm tra sự tương ứng giữa kết luận và nhãn chân đã lần được. Các vùng khoanh hai bản cực có thể chồng nhẹ nếu tâm từng vùng vẫn nằm ở hai vị trí riêng biệt. Khi các góc bổ sung cho nhau, hệ thống dùng ảnh cận để đọc bản cực và góc khác để lần đường nối.

Khi hai bản cực đã rõ mà đường nối còn thiếu, kết quả hiển thị góc thấy bản cực và nêu phần đường nối cần xác minh. Kết quả chiều LED khi đó vẫn là **Chưa xác định**. Toàn bộ ảnh tiếp tục được xử lý trong một lượt.

112 kiểm thử tự động đạt. Kiểm tra luồng chấm cục bộ với ba ảnh và phản hồi AI mô phỏng xác nhận ứng dụng có thể chấm chiều đúng, ghi nhận hai bản cực khi còn thiếu đường nối và giữ **Chưa xác định** khi nhãn chân mâu thuẫn.

- Mã nguồn trước cập nhật `backups/CircuitCoach-Chieu-LED-2026-11-25-113506-truoc.zip`
- Mã nguồn sau cập nhật `backups/CircuitCoach-Chieu-LED-2026-11-25-113506-sau.zip`
