# Hiển thị vùng có dấu hiệu lỗi và vùng cần xem lại

25/11/2026 · CircuitCoach AI · Bản local Windows

Bản trước chỉ vẽ vùng lỗi khi kết quả có sẵn tọa độ khoanh chính. Tọa độ dùng để định vị chi tiết còn nhìn thấy bị bỏ khi tiêu chí chuyển thành chưa xác định.

Bản mới dùng nét liền khi kết quả có bằng chứng và vị trí lỗi. Nếu khung chính trống, có thể lấy vị trí từ bằng chứng đã được xác minh, chẳng hạn thân điện trở nơi đọc vạch màu. Nét đứt dùng cho bộ phận liên quan còn nhìn thấy nhưng chưa đủ căn cứ để chấm. Số đặt ngoài vùng và chú thích dưới ảnh giúp đối chiếu. Khi chỉ có ảnh liên quan, có thể xem ảnh mà không gán một vùng cụ thể.

Vùng xem lại được lưu riêng cùng tiêu chí. Ảnh đã đồng bộ có thể được tải từ dữ liệu lớp khi thiết bị thiếu bản lưu cục bộ. Giao diện xem phóng to ảnh kiểm tra lại cũng hiển thị đánh dấu mới. Những lượt cũ chỉ có thể hiện khung nếu dữ liệu đã lưu có tọa độ hợp lệ hoặc vị trí bằng chứng phù hợp.

Thử OpenAI thật trên ba ảnh bài 4 đã lưu lúc 14:25 trả về bốn vùng nét đứt, gồm thân LED, đầu kẹp pin và hai vùng liên quan đến công tắc. Vị trí được đối chiếu với các ảnh gốc. Trường hợp lấy vùng lỗi từ bằng chứng, tọa độ vượt khung và vùng chỉ kiểm tra trực tiếp đã được xác minh trong bộ 121 kiểm thử tự động.

- Mã nguồn trước cập nhật `backups/CircuitCoach-Khoanh-vung-kiem-tra-2026-11-25-142835-truoc.zip`
- Mã nguồn sau cập nhật `backups/CircuitCoach-Khoanh-vung-kiem-tra-2026-11-25-142835-sau.zip`
