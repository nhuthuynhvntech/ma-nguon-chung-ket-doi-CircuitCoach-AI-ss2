# Chỉ kết luận khi có bằng chứng · 25/11/2026

Mọi tiêu chí trong lượt phân tích ảnh thật được đọc hai lượt độc lập. Để hiển thị **Đúng** hoặc **Cần kiểm tra**, hai lượt phải chỉ ra những vùng bằng chứng phù hợp trên ảnh hiện tại. Một ảnh đủ rõ vẫn có thể làm căn cứ khi cả hai lượt chỉ ra cùng chi tiết. Nếu hai lượt đọc khác nhau, thiếu một phần bằng chứng hoặc lượt đọc lại gặp lỗi, tiêu chí hiện **Chưa xác định**.

Với chiều LED, hai lượt phải xác nhận được bản cực lớn dạng chén và bản cực nhỏ trên cùng một góc rõ, rồi lần ra hai nhánh chân. Với Arduino Uno, đầu dây còn phải khớp lỗ cắm theo các mốc trên hàng chân. Ảnh mẫu và vùng giáo viên đã khoanh giúp tìm đúng chỗ cần xem. Để đọc trị số điện trở, AI phải chỉ ra vạch màu hoặc trị số có đơn vị nhìn thấy trên thân. Để đọc điện áp từ ảnh, AI phải chỉ ra số và đơn vị in trên nguồn đang nối.

Ảnh có thể làm căn cứ cảnh báo khi thấy cầu nối trực tiếp. Việc loại trừ chập và cho phép cấp nguồn cần giáo viên kiểm tra mạch thật. Vùng khoanh chỉ hiện khi tọa độ khớp chi tiết có bằng chứng. **Kết quả → Tóm tắt** hiển thị thông báo đối chiếu bằng chứng và giữ đủ các tiêu chí, kể cả những mục chưa xác định. Luồng A/B dùng cùng điều kiện bằng chứng cho cả hai nhánh.

102 kiểm thử đạt. Các ca kiểm tra gồm AI tự tin 99% nhưng chỉ thấy một bản cực, báo cùng kết luận nhưng chỉ vào hai vùng khác nhau, số điện áp bị đọc sai, trị số điện trở thiếu vạch và ảnh chưa đủ để loại trừ chập. Ca đối chứng xác nhận hệ thống vẫn chấm được từ một góc đủ rõ.

Nếu lượt đọc chính hết thời gian chờ, ứng dụng vẫn mở **Tóm tắt** với danh sách đầy đủ các tiêu chí ở **Chưa xác định** và gợi ý kiểm tra theo từng tiêu chí. Thông báo giải thích rằng dịch vụ AI chưa hoàn tất hai lượt đọc.

Đã chạy lại bản local trên cổng 3190 và thử với OpenAI thật bằng hai ảnh mẫu công khai của bài LED dùng pin. Sau khoảng 55 giây, trang kết quả trả đủ 10 tiêu chí ở **Chưa xác định**. Kết quả thử xác nhận hệ thống giữ trạng thái cần kiểm tra khi bằng chứng chưa đủ. Độ chính xác nhận dạng trên các bộ ảnh thật vẫn cần được đánh giá bằng nhãn của giáo viên.

Trong thư mục `backups`, `CircuitCoach-Bang-chung-2026-11-25-002731-truoc.zip` chứa bản trước cập nhật, `CircuitCoach-Bang-chung-2026-11-25-002731-sau.zip` chứa bản mới và `CircuitCoach-Bang-chung-2026-11-25-002731-du-lieu.zip` chứa cơ sở dữ liệu với 47 lượt làm và 110 ảnh đã sao lưu.
