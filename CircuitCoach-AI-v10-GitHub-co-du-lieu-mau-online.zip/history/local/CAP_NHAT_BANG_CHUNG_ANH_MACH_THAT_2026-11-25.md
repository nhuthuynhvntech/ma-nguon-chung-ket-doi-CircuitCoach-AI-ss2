# Kiểm tra chân cắm từ ảnh mạch thật

Ngày 25/11/2026 · CircuitCoach AI · Bản local Windows

Hai ảnh của lượt LED gần nhất cho thấy một chân điện trở vào lỗ D8 và một chân LED vào lỗ GND. Lượt đó chấm được 2/8 tiêu chí. Kết quả về chân cắm bị giữ lại ở bước xác minh mốc hoặc nối vùng bằng chứng từ linh kiện tới lỗ.

Bản mới có thể xác nhận bằng hai mốc khi đọc rõ nhãn của chính lỗ có dây và một lỗ liền kề trong cùng cụm. Hệ thống kiểm tra vị trí đầu cắm, nhãn thật trên ảnh và đường nối từ linh kiện. Nếu chân linh kiện cắm trực tiếp, vùng thân linh kiện và đường chân kim loại phải khớp hai đầu. Trường hợp thiếu nhãn, nhãn đọc mâu thuẫn hoặc thân linh kiện nằm ngoài đường nối vẫn hiện **Chưa xác định**.

Kết quả ghi rõ tên lỗ khi nhãn và tọa độ đã được xác minh nhưng đoạn nối chưa đủ căn cứ để chấm. Với chiều LED, gợi ý chụp lại hướng dẫn ngắt nguồn rồi chụp ngang thân LED để nhìn được hai bản cực. Điện áp thực tế và kiểm tra chập vẫn cần giáo viên kiểm tra mạch.

Luồng phân tích tiếp tục dùng một yêu cầu OpenAI cho tất cả ảnh. 111 kiểm thử tự động đạt, gồm đọc D8 từ nhãn in, yêu cầu lỗ liền kề, từ chối thân linh kiện ngoài đường nối và ghi nhận riêng lỗ GND đã xác minh.

Thử bằng hai bản ảnh mẫu cùng góc chụp có sẵn trong mã nguồn, OpenAI trả kết quả sau khoảng 34 giây. Hệ thống chấm **Đúng** 4/8 tiêu chí, gồm nhìn thấy linh kiện, mắc nối tiếp, chân D8 và chân GND. Chiều LED và trị số điện trở còn **Chưa xác định** ở lần thử này. Hai tiêu chí về điện áp và chập cần kiểm tra trực tiếp. Kết quả kiểm chứng nhãn chân vẫn cần phân biệt với độ chính xác của tọa độ khoanh trên ảnh.

- Mã nguồn trước cập nhật `backups/CircuitCoach-Bang-chung-anh-that-2026-11-25-104943-truoc.zip`
- Mã nguồn sau cập nhật `backups/CircuitCoach-Bang-chung-anh-that-2026-11-25-104943-sau.zip`
