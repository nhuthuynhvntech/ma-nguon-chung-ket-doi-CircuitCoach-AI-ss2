# Cập nhật tệp cấu hình OpenAI trên máy

Ngày 25/11/2026 · CircuitCoach AI · Bản local cổng 3190

Bản local đọc khóa từ dòng `OPENAI_API_KEY=` trong tệp `%LOCALAPPDATA%\CircuitCoach\local-3190\.env`. Mở tệp bằng Notepad, dán khóa sau dấu bằng và bấm Ctrl+S. Ứng dụng dùng giá trị đã lưu từ yêu cầu API kế tiếp. Nếu dòng này để trống, ứng dụng dùng khóa từ biến môi trường hiện có.

Đã thử đọc một giá trị mẫu ngay sau khi lưu tệp và kiểm tra trang chủ cùng đường dẫn kiểm tra trạng thái của bản local sau khi khởi động lại.

- Bản mã nguồn trước cập nhật `backups/CircuitCoach-Cau-hinh-OpenAI-2026-11-25-074154-truoc.zip`
- Bản mã nguồn sau cập nhật `backups/CircuitCoach-Cau-hinh-OpenAI-2026-11-25-074154-sau.zip`
