# Cấu hình OpenAI trong ứng dụng

Ngày 25/11/2026 · CircuitCoach AI · Bản local Windows

1. Đăng nhập bằng tài khoản quản trị rồi mở **Quản trị → Cấu hình**.
2. Dán khóa vào ô **Khóa API OpenAI mới** và bấm **Lưu khóa**. Khóa có hiệu lực từ yêu cầu AI tiếp theo và được giữ khi khởi động lại.
3. Chọn **Dùng khóa mặc định** để bỏ khóa đã nhập. CircuitCoach lấy mặc định từ tệp `.env` trong thư mục riêng của Windows, sau đó từ biến môi trường nếu tệp chưa có khóa.

Màn hình hiển thị nguồn khóa đang dùng. Giá trị khóa được lưu phía máy chủ trong thư mục riêng của Windows, ngoài thư mục dự án.

- Mã nguồn trước cập nhật `backups/CircuitCoach-Cau-hinh-trong-ung-dung-2026-11-25-074746-truoc.zip`
- Mã nguồn sau cập nhật `backups/CircuitCoach-Cau-hinh-trong-ung-dung-2026-11-25-074746-sau.zip`
