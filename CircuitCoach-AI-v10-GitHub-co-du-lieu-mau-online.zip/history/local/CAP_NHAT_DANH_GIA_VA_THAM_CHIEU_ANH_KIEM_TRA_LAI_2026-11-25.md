# Đánh giá, khoanh vùng và dùng ảnh kiểm tra lại làm tham chiếu

25/11/2026 · CircuitCoach AI · Bản local Windows

Giáo viên phụ trách mở **Dành cho giáo viên → Xem & xác nhận → Ảnh kiểm tra lại từng tiêu chí → Đánh giá AI và khoanh vùng**. Chọn AI đúng, AI sai hoặc chưa chắc, rồi chọn nhãn thực tế của mạch trên ảnh. Khi cần, ghi lý do AI sai, loại lỗi của mạch và dấu hiệu muốn AI xem. Có thể khoanh vùng, vẽ và ghi chú trực tiếp trên ảnh. **Lưu đánh giá** ghi dữ liệu vào bài làm. Học sinh mở lại bài để thấy đánh giá và phóng to ảnh đã đánh dấu.

**Đưa vào kho tham chiếu chung** lưu và duyệt ảnh theo nhãn thực tế. Việc cập nhật ảnh trong kho dùng cùng nút sau khi chỉnh đánh giá. Kho chung giữ ảnh, vùng khoanh và dấu hiệu đã được giáo viên đưa vào kho. Nhận xét riêng dưới ảnh vẫn nằm trong bài làm của lớp.

Lượt phân tích tiếp theo có thể dùng ảnh đã duyệt của đúng bài và tiêu chí, kể cả lượt kiểm tra lại riêng. Nếu đúng ảnh đã khoanh được gửi lại, hệ thống đưa vùng đã khoanh làm vị trí cần xem kỹ. AI vẫn đối chiếu bằng chứng trên ảnh đang phân tích. Đánh giá AI sai cũng góp lý do vào phần Lỗi AI cần chú ý của lớp. Báo cáo A/B loại ảnh mẫu xuất phát từ chính lượt làm đang được đo.

117 kiểm thử tự động đạt. Kiểm thử tích hợp đã xác nhận quyền giáo viên, việc lưu và cập nhật ảnh mẫu, cùng nội dung ảnh và vùng khoanh trong yêu cầu phân tích. Phản hồi OpenAI trong kiểm thử này dùng mô phỏng. Đã xác minh ảnh LED có sẵn trước cập nhật hiển thị đủ chức năng đánh giá trên bản local.

- Mã nguồn trước cập nhật `backups/CircuitCoach-Danh-gia-anh-kiem-tra-lai-2026-11-25-135207-truoc.zip`
- Mã nguồn sau cập nhật `backups/CircuitCoach-Danh-gia-anh-kiem-tra-lai-2026-11-25-135207-sau.zip`
- Dữ liệu trước cập nhật `backups/du-lieu-local/2026-11-25T06-52-07.512Z`
- Dữ liệu sau cập nhật `backups/du-lieu-local/2026-11-25T06-59-13.346Z`
