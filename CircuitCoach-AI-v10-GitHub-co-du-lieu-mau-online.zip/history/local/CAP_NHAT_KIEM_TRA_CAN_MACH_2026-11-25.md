# Kiểm tra cận bằng chứng trên ảnh mạch

Ngày 25/11/2026 · CircuitCoach AI · Bản local Windows

Bản trước hết thời gian ở bước đọc cận hàng chân Arduino trong hai lần thử ảnh LED mẫu. Bản mới gửi yêu cầu ngắn hơn dành cho những tiêu chí còn thiếu bằng chứng. Khi cần, ứng dụng cắt một vùng quanh điện trở được phát hiện trong chính ảnh đã gửi để AI đọc vạch màu, đồng thời gửi các góc gốc để AI lần đường dây. Với Arduino, vùng cắt có thêm vị trí đầu cắm quan sát được.

Tiêu chí chỉ được chấm khi lượt đọc cận và một lượt độc lập trước đó cùng có bằng chứng. Các nhận xét đã có bằng chứng được giữ lại. Khi hai lượt đọc ban đầu mâu thuẫn, tiêu chí tiếp tục ở **Chưa xác định**. Hai nhánh A/B dùng cùng quy tắc xác minh. Mốc Arduino được giới hạn theo từng cụm lỗ cắm, nên D7 chỉ hợp lệ ở cụm D0–D7.

Bản local cho hai lượt đầu lần lượt tối đa 72 và 70 giây. Bước đọc cận có thể chạy đến giây 100 và trình duyệt chờ tối đa 110 giây cho cả lượt. Chỉ những lượt cần đọc lại mới dùng bước bổ sung.

Với tiêu chí nhận diện linh kiện, hai vùng có thể khác kích thước nếu vùng rộng bao phủ ít nhất 80% vùng nhỏ trên cùng một ảnh. Điều kiện chấm đường dây, cực LED và đầu cắm vẫn dùng bằng chứng riêng.

Trên cùng hai ảnh LED mẫu, các lần chạy OpenAI có kết quả khác nhau. Một lượt xác nhận 4/8 tiêu chí. Một lượt hết thời gian ở hai bước đọc, từ đó điều chỉnh thời gian chờ. Lượt thử cuối với thời gian chờ mới hoàn tất cả bước đọc cận và xác nhận điện trở 220 Ω cùng chân GND. Kết quả nhận diện linh kiện bị loại do hai vùng có kích thước khác nhau. Kiểm thử với đúng hai vùng đó xác nhận bản cuối công nhận tiêu chí này. D8 và chiều LED của bộ ảnh mẫu vẫn thiếu bằng chứng nhất quán.

109 kiểm thử tự động đạt, gồm xác nhận trị số điện trở qua ảnh cận, giữ trường hợp mâu thuẫn, xác minh D8 ở rìa cụm lỗ và đối chiếu hai vùng linh kiện có kích thước khác nhau.

- Mã nguồn trước cập nhật `backups/CircuitCoach-Kiem-tra-can-2026-11-25-095126-truoc.zip`
- Mã nguồn sau cập nhật `backups/CircuitCoach-Kiem-tra-can-2026-11-25-095126-sau.zip`
