# Chú thích vùng lỗi trên ảnh · 24/11/2026

Trong kết quả phân tích, mở **Ảnh và tiêu chí**. Các số nằm cạnh vùng khoanh ở vị trí còn trống. Bên dưới mỗi ảnh có mục tương ứng gồm số, tên tiêu chí và điều AI quan sát. Bấm vào một chú thích để làm nổi vùng khoanh tương ứng. Khi phóng to ảnh, phần chú thích theo số xuất hiện dưới ảnh.

Nếu vùng khoanh sát mép hoặc các vùng quá gần nhau, số vẫn xuất hiện trong chú thích dưới ảnh. Mỗi nhóm lỗi giữ màu đã dùng trong kết quả và các vùng dùng tọa độ đã lưu của lượt phân tích.

Đã kiểm tra trên trình duyệt với hai ảnh mẫu và ba vùng khoanh. Đã kiểm tra vị trí số, thao tác chọn chú thích và chú thích trong cửa sổ phóng to. 88 kiểm thử đạt, gồm ba kiểm thử về vùng sát nhau và ảnh nhỏ.

## Sao lưu

- `CircuitCoach-Chu-thich-loi-2026-11-24-215243-truoc.zip` chứa mã nguồn và bản chạy trước khi cập nhật.
- `CircuitCoach-Chu-thich-loi-2026-11-24-215243-sau.zip` chứa bản đã cập nhật.
- `CircuitCoach-Chu-thich-loi-2026-11-24-215243-du-lieu.zip` chứa cơ sở dữ liệu, 61 ảnh và bảng kê đã kiểm tra.
