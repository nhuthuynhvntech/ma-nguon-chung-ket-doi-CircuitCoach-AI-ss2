# Đăng nhập CircuitCoach AI trên máy

Ngày 25/11/2026 · Bản local Windows cổng 3190

| Vai trò | Thông tin cần nhập |
| --- | --- |
| Học sinh | Tên cá nhân hoặc tên nhóm và mã lớp do giáo viên cấp |
| Giáo viên | Tên đăng nhập `gv`, mật khẩu trong dòng `TEACHER_PASSWORD` của tệp cấu hình |
| Quản trị viên | Tên đăng nhập `admin`, mật khẩu trong dòng `ADMIN_PASSWORD` của tệp cấu hình |

Tên tài khoản giáo viên, quản trị, tên nhóm và mã lớp chấp nhận cả chữ hoa lẫn chữ thường. Hãy đăng xuất trước khi đổi vai trò.

Tệp `%LOCALAPPDATA%\CircuitCoach\local-3190\.env` chứa hướng dẫn vào lớp và bốn dòng `TEACHER_USERNAME`, `TEACHER_PASSWORD`, `ADMIN_USERNAME` và `ADMIN_PASSWORD`. Sau khi chỉnh các dòng này, khởi động lại CircuitCoach. Nếu đổi mật khẩu trong tệp, phiên cũ của tài khoản đó sẽ kết thúc. Để đổi mật khẩu cho tài khoản được quản lý bằng tệp, sửa dòng tương ứng trong tệp.

CircuitCoach lưu mã lớp và dữ liệu nhóm trong cơ sở dữ liệu. Tệp cấu hình dùng tên đăng nhập để chọn tài khoản, vì vậy hãy giữ tên hiện có khi chỉ đổi mật khẩu.

- Mã nguồn trước cập nhật `backups/CircuitCoach-Dang-nhap-local-2026-11-25-080042-truoc.zip`
- Mã nguồn sau cập nhật `backups/CircuitCoach-Dang-nhap-local-2026-11-25-080042-sau.zip`
