# Đối chiếu bằng chứng giữa các góc chụp

Ngày 25/11/2026 · CircuitCoach AI · Bản local Windows

Phép thử ban đầu với hai ảnh mẫu LED cho kết quả 0/8 tiêu chí đúng. Hai lượt đọc nhận ra linh kiện và đường mắc nối tiếp nhưng chọn hai ảnh khác nhau. Quy tắc cũ yêu cầu các vùng bằng chứng trùng trên cùng một ảnh nên loại cả hai nhận xét. Cùng bộ ảnh đó, hai lượt còn đọc ra hai trị số điện trở khác nhau.

Bản mới chấp nhận trạng thái **Đúng** từ hai góc khác nhau khi hai lượt cùng quan sát một giá trị, cùng xác nhận các ảnh được dùng và đã xem tất cả các góc. Khi cần ghép ảnh để lần dây, hai lượt phải xác nhận được các đầu nối và những vùng dây giao nhau trên cùng ảnh. Với Arduino Uno, mỗi lượt cần xác minh đúng lỗ cắm nếu dùng hai góc khác nhau. Hai cách đọc mâu thuẫn vẫn hiện **Chưa xác định**.

Trang **Kết quả → Tóm tắt** ghi **Cần kiểm tra trực tiếp** cho những tiêu chí cần đo hoặc kiểm tra mạch thật, như loại trừ chập và kiểm tra mức tín hiệu D8 của bài LED cơ bản. Giáo viên vẫn xác nhận an toàn trước khi cấp nguồn.

106 kiểm thử tự động đạt. Các ca kiểm tra bao gồm hai góc đủ bằng chứng, ba góc bổ sung, hai trị số điện trở khác nhau và xác minh chân Arduino.

Chạy lại cùng hai ảnh mẫu với OpenAI cho 2/8 tiêu chí **Đúng**, gồm nhận diện linh kiện và mắc nối tiếp, 4 tiêu chí **Chưa xác định** và 2 tiêu chí **Cần kiểm tra trực tiếp**. Điều kiện xác minh lỗ cắm và đọc mã màu vẫn giữ lại những tiêu chí thiếu bằng chứng. Lượt đọc cận hàng chân hết thời gian chờ trong cả hai phép thử.

- Mã nguồn trước cập nhật `backups/CircuitCoach-Doc-bang-chung-2026-11-25-092418-truoc.zip`
- Mã nguồn sau cập nhật `backups/CircuitCoach-Doc-bang-chung-2026-11-25-092418-sau.zip`
