# Cấu hình OpenAI trên bản local

Ngày 25/11/2026 · CircuitCoach AI · Windows

Học sinh, giáo viên, quản trị và khách có thể mở **Cấu hình OpenAI** từ trang đăng nhập hoặc chọn **Cấu hình** trên thanh điều hướng.

Khóa được lưu dùng chung cho CircuitCoach trên máy này và có hiệu lực từ yêu cầu AI tiếp theo. Màn hình hiển thị nguồn khóa đang dùng. Nút **Dùng khóa mặc định** khôi phục cấu hình ban đầu của máy.

- Mã nguồn trước cập nhật `backups/CircuitCoach-Cau-hinh-chung-2026-11-25-081918-truoc.zip`
- Mã nguồn sau cập nhật `backups/CircuitCoach-Cau-hinh-chung-2026-11-25-081918-sau.zip`
