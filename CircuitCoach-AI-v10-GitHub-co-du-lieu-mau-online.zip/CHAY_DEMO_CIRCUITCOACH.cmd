@echo off
setlocal
cd /d "%~dp0"
set "CC_NODE=node.exe"
where node.exe >nul 2>nul
if errorlevel 1 (
  echo Can cai Node.js 24 de chay ban dung thu.
  pause
  exit /b 1
)
if not exist dist\server\index.js (
  echo Chay npm ci va npm run build truoc khi mo ban dung thu.
  pause
  exit /b 1
)
if not defined LOCAL_PORT set "LOCAL_PORT=3191"
set "CIRCUITCOACH_ONLINE_DEMO=1"
"%CC_NODE%" scripts\local-worker.mjs
pause
