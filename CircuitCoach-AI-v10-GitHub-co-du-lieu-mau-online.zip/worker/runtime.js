import { CIRCUIT_LESSON_SPECS } from "../src/data/circuit-rules.js";
import { getLesson } from "../src/data/lessons.js";
import { knowledgeBase } from "../src/data/knowledge-base.js";
import { REFERENCE_ERROR_TYPES } from "../src/data/reference-cases.js";
import { mergeArduinoPinDetailReview } from "../server/ai/arduino-pin-geometry.js";
import { CIRCUIT_ANALYSIS_JSON_SCHEMA, CIRCUIT_OBSERVATION_VERSION, buildCircuitFocusSchema, circuitAnalysisTimedOut, validateSingleCircuitRead } from "../server/ai/circuit-observations.js";
import { buildAnalyzeInput, buildLedDetailInput, buildLedPhotoInstructions, buildPrimaryAnalysisInstructions, buildStudentImageInput, studentImageDetail } from "../server/ai/analyze-prompt.js";
import { cropMarkedReference } from "../server/ai/region-refinement.js";
import { finalizeCircuitAnalysis } from "../server/ai/finalize-analysis.js";
import { AI_ERROR_REASONS, AI_ERROR_REVIEW_GUIDANCE, parseTeacherAiError } from "../src/data/ai-error-reasons.js";
import { SESSION_ROLES } from "../src/data/session-roles.js";
import { buildGuideChatRequest, prepareGuideChat, readGuideChatReply } from "../server/ai/guide-chat.js";
import { STUDENT_GUIDE_WINDOW, studentGuideForModel, summarizeStudentGuide } from "../server/ai/student-guide.js";

const ASSETS = /*__ASSET_MAP__*/ {};
const CLASS_CODE = /^[A-Z0-9]{4,12}$/;
const VERIFICATIONS = new Set(["correct", "incorrect", "uncertain", null]);
const TEACHER_STATUSES = new Set(["approved", null]);
const IMAGE_TYPES = new Set(["image/jpeg", "image/png", "image/webp"]);
const newestRecheckPredicate = `r.id = (SELECT newer.id FROM platform_criterion_rechecks newer
  WHERE newer.attempt_id=r.attempt_id AND newer.criterion_id=r.criterion_id
  ORDER BY newer.created_at DESC, newer.id DESC LIMIT 1)`;
const latestAttemptRechecks = `(SELECT json_group_array(json_object('id',r.id,'criterionId',r.criterion_id,
  'createdAt',r.created_at,'check',json(r.check_json))) FROM platform_criterion_rechecks r
  WHERE r.attempt_id=a.id AND ${newestRecheckPredicate}) AS latest_rechecks`;
const RATE_LIMITS = new Map();
const GUIDE_CHAT_RATE_LIMITS = new Map();
const LOGIN_LIMITS = new Map();
const RATE_WINDOW_MS = 10 * 60 * 1000;
const RATE_MAX = 12;

const tutorJsonSchema = {
  type: "object",
  additionalProperties: false,
  required: ["title", "hint", "question", "reviewTopic"],
  properties: {
    title: { type: "string" },
    hint: { type: "string" },
    question: { type: "string" },
    reviewTopic: { type: "string" },
  },
};

function getWorkerLesson(id) {
  const lesson = getLesson(id);
  if (!lesson) return null;
  return {
    ...lesson,
    checkList: lesson.checks.map(([checkId, label, category]) => ({
      id: checkId,
      label,
      category,
      reviewTopic: knowledgeBase[checkId]?.topic || label,
    })),
  };
}

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
};

function json(payload, status = 200) {
  return new Response(JSON.stringify(payload), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" } });
}

function attemptFromReportRow(row) {
  const attempt = JSON.parse(row.payload_json);
  if (row.latest_rechecks) attempt.latestRechecks = JSON.parse(row.latest_rechecks);
  return attempt;
}

function normalizeCode(value) {
  return String(value || "").trim().toUpperCase();
}

function hostedClassroomEnabled(env) {
  return env.CIRCUITCOACH_HOSTED_ACCOUNTS === "true";
}

function personalAccountsEnabled(env) {
  return env.LOCAL_PERSONAL_ACCOUNTS === true || hostedClassroomEnabled(env);
}

async function teacherPasswordMatches(request, env) {
  const expectedUsername = typeof env.TEACHER_USERNAME === "string" ? env.TEACHER_USERNAME : "";
  const expected = typeof env.TEACHER_PASSWORD === "string" ? env.TEACHER_PASSWORD : "";
  if (!expectedUsername || expected.length < 6) return false;
  const suppliedUsername = request.headers.get("x-teacher-username") || "";
  const supplied = request.headers.get("x-teacher-password") || "";
  const encoder = new TextEncoder();
  const [expectedUsernameDigest, suppliedUsernameDigest, expectedDigest, suppliedDigest] = await Promise.all([
    crypto.subtle.digest("SHA-256", encoder.encode(expectedUsername)),
    crypto.subtle.digest("SHA-256", encoder.encode(suppliedUsername)),
    crypto.subtle.digest("SHA-256", encoder.encode(expected)),
    crypto.subtle.digest("SHA-256", encoder.encode(supplied)),
  ]);
  const expectedUsernameBytes = new Uint8Array(expectedUsernameDigest);
  const suppliedUsernameBytes = new Uint8Array(suppliedUsernameDigest);
  const expectedBytes = new Uint8Array(expectedDigest);
  const suppliedBytes = new Uint8Array(suppliedDigest);
  let difference = 0;
  for (let index = 0; index < expectedUsernameBytes.length; index += 1) difference |= expectedUsernameBytes[index] ^ suppliedUsernameBytes[index];
  for (let index = 0; index < expectedBytes.length; index += 1) difference |= expectedBytes[index] ^ suppliedBytes[index];
  return difference === 0;
}

async function platformDigest(value) {
  const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return base64UrlBytes(new Uint8Array(bytes));
}

async function platformPassword(password, salt, iterations) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: base64UrlDecode(salt), iterations }, key, 256);
  return base64UrlBytes(new Uint8Array(bits));
}

async function hashStaffPassword(password, env) {
  const salt = base64UrlBytes(crypto.getRandomValues(new Uint8Array(16)));
  const hosted = hostedClassroomEnabled(env);
  const hash = await platformPassword(password, salt, hosted ? 100_000 : 600_000);
  return `${hosted ? "p100." : ""}${salt}.${hash}`;
}

async function staffPasswordMatches(password, storedHash) {
  if (!storedHash) return false;
  const parts = storedHash.split(".");
  const hosted = parts[0] === "p100";
  const [salt, hash] = hosted ? parts.slice(1) : parts;
  return Boolean(hash && await platformPassword(password, salt, hosted ? 100_000 : 600_000) === hash);
}

function findStaffAccount(env, username, role) {
  return env.DB.prepare(`SELECT u.id,u.username,u.password_hash FROM platform_users u
    JOIN platform_roles r ON r.user_id=u.id WHERE u.username=? AND u.disabled=0 AND r.role=?`)
    .bind(username, role).first();
}

const fileManagedPasswordMessage = "Mật khẩu này được quản lý trong tệp .env. Hãy sửa tệp và khởi động lại CircuitCoach.";

function staffRotationPasswordAccepted(password, username, role, env) {
  if (!validText(password, 128)) return false;
  if (password.length >= 12) return true;
  const configuredUsername = role === "admin" ? env.ADMIN_USERNAME : env.TEACHER_USERNAME;
  return hostedClassroomEnabled(env) && password.length >= 6
    && password === env.CIRCUITCOACH_STAFF_ROTATION_PASSWORD
    && username.toLowerCase() === configuredUsername?.toLowerCase();
}

async function changeAdminPassword(request, env, url) {
  if (request.headers.get("origin") !== url.origin) return json({ error: "Nguồn yêu cầu không hợp lệ." }, 403);
  const identity = await platformIdentity(request, env, "admin");
  if (!identity) return json({ error: "Hãy đăng nhập quản trị để đổi mật khẩu." }, 401);
  if (env.LOCAL_FILE_STAFF_IDS?.has(identity.id)) return json({ error: fileManagedPasswordMessage }, 409);
  const { currentPassword, password } = await parseBody(request).catch(() => null) || {};
  if (!validText(currentPassword, 128) || !staffRotationPasswordAccepted(password, identity.username, "admin", env)) {
    return json({ error: "Nhập mật khẩu hiện tại và mật khẩu mới từ 12 đến 128 ký tự." }, 400);
  }
  if (password === currentPassword) return json({ error: "Hãy nhập một mật khẩu mới khác mật khẩu hiện tại." }, 400);
  if (loginRateLimited(request)) return json({ error: "Quá nhiều lần xác thực. Hãy thử lại sau." }, 429);
  const account = await findStaffAccount(env, identity.username, "admin");
  if (account?.id !== identity.id || !await staffPasswordMatches(currentPassword, account.password_hash)) {
    return json({ error: "Mật khẩu hiện tại không đúng." }, 401);
  }

  const hash = await hashStaffPassword(password, env);
  const [updated] = await env.DB.batch([
    env.DB.prepare("UPDATE platform_users SET password_hash=? WHERE id=? AND disabled=0 AND password_hash=?")
      .bind(hash, identity.id, account.password_hash),
    env.DB.prepare(`DELETE FROM platform_sessions WHERE user_id=? AND EXISTS
      (SELECT 1 FROM platform_users WHERE id=? AND password_hash=?)`).bind(identity.id, identity.id, hash),
  ]);
  if (!updated.meta.changes) return json({ error: "Mật khẩu vừa thay đổi. Hãy đăng nhập lại." }, 409);
  const response = json({ saved: true });
  expireBrowserCookie(response, staffCookieName("admin"));
  return response;
}

async function provisionHostedStaff(request, env, role, username, password) {
  if (!hostedClassroomEnabled(env)) return null;
  const matches = role === "admin"
    ? await adminCredentialsMatch(username, password, env)
    : await teacherPasswordMatches(request, env);
  if (!matches) return null;

  const id = crypto.randomUUID();
  const passwordHash = await hashStaffPassword(password, env);
  const writes = [
    env.DB.prepare("INSERT INTO platform_users (id,username,password_hash,created_at) VALUES (?,?,?,?) ON CONFLICT(username) DO NOTHING")
      .bind(id, username, passwordHash, new Date().toISOString()),
    env.DB.prepare("INSERT INTO platform_roles (user_id,role) SELECT id,? FROM platform_users WHERE id=?").bind(role, id),
  ];
  if (role === "teacher") {
    writes.push(env.DB.prepare(`INSERT INTO platform_class_members (class_code,user_id,membership)
      SELECT code,?,'teacher' FROM platform_classes WHERE created_by IS NULL
      AND EXISTS (SELECT 1 FROM platform_roles WHERE user_id=? AND role='teacher')`).bind(id, id));
  }
  const created = await env.DB.batch(writes);
  if (created[0].meta.changes) return { id, username, password_hash: passwordHash };
  const concurrent = await findStaffAccount(env, username, role);
  return await staffPasswordMatches(password, concurrent?.password_hash) ? concurrent : null;
}

function secureClassroomCookie(url) {
  return url.protocol === "https:" ? "; Secure" : "";
}

function staffCookieName(role) {
  return `cc_staff_${role}`;
}

function staffCookieToken(request, name) {
  const match = new RegExp(`(?:^|;\\s*)${name}=([\\w-]{43})(?:;|$)`);
  return request.headers.get("cookie")?.match(match)?.[1];
}

async function platformIdentity(request, env, role, classCode) {
  const token = staffCookieToken(request, staffCookieName(role)) || staffCookieToken(request, "cc_teacher");
  if (!token) return null;
  return env.DB.prepare(`SELECT u.id, u.username, s.expires_at AS expiresAt FROM platform_sessions s
    JOIN platform_users u ON u.id = s.user_id
    JOIN platform_roles r ON r.user_id = u.id AND r.role = ?
    WHERE s.token_hash = ? AND s.expires_at > ? AND u.disabled = 0
    AND (? IS NULL OR EXISTS (SELECT 1 FROM platform_class_members m
      WHERE m.user_id = u.id AND m.class_code = ? AND m.membership = 'teacher'))`)
    .bind(role, await platformDigest(token), new Date().toISOString(), classCode ?? null, classCode ?? null).first();
}

const platformTeacher = (request, env, classCode) => platformIdentity(request, env, "teacher", classCode);

async function activeBrowserRole(request, env) {
  for (const role of ["admin", "teacher"]) {
    const account = await platformIdentity(request, env, role);
    if (account) return { role, account };
  }
  return { role: studentToken(request) ? "student" : null, account: null };
}

async function requireNoRoleSwitch(request, env, role) {
  const active = await activeBrowserRole(request, env);
  if (active.role && active.role !== role) {
    return json({ error: `Bạn đang đăng nhập với vai trò ${SESSION_ROLES[active.role].label}. Hãy đăng xuất để đổi vai trò.` }, 409);
  }
  return null;
}

function expireBrowserCookie(response, name, path = "/api") {
  response.headers.append("Set-Cookie", `${name}=; HttpOnly; SameSite=Strict; Path=${path}; Max-Age=0`);
}

function expireStudentCookies(response) {
  expireBrowserCookie(response, "cc_student");
  expireBrowserCookie(response, "cc_sample_class", "/api/classroom/lesson-samples");
}

async function signOutBrowser(request, env, url) {
  if (request.headers.get("origin") !== url.origin) return json({ error: "Nguồn yêu cầu không hợp lệ." }, 403);
  const staffCookies = [staffCookieName("admin"), staffCookieName("teacher"), "cc_teacher"];
  const tokens = [...new Set(staffCookies.map(name => staffCookieToken(request, name)).filter(Boolean))];
  if (tokens.length) {
    const hashes = await Promise.all(tokens.map(platformDigest));
    await env.DB.batch(hashes.map(hash => env.DB.prepare("DELETE FROM platform_sessions WHERE token_hash=?").bind(hash)));
  }
  const response = json({ authenticated: false, role: null });
  for (const name of staffCookies) expireBrowserCookie(response, name);
  expireStudentCookies(response);
  if (browserOpenAISettingsEnabled(env, url)) setBrowserOpenAIKeyCookie(response, "");
  return response;
}

async function teacherClassCodes(env, userId) {
  const { results } = await env.DB.prepare(`SELECT c.code FROM platform_classes c
    JOIN platform_class_members m ON m.class_code=c.code
    WHERE m.user_id=? AND m.membership='teacher' ORDER BY c.code`).bind(userId).all();
  return results.map(row => row.code);
}

function registeredClass(env, code) {
  return env.DB.prepare("SELECT code FROM platform_classes WHERE code=?").bind(code).first();
}

async function createTeacherClass(request, env, url) {
  if (request.headers.get("origin") !== url.origin) return json({ error: "Nguồn yêu cầu không hợp lệ." }, 403);
  const teacher = await platformTeacher(request, env);
  if (!teacher) return json({ error: "Đăng nhập giáo viên để tạo mã lớp." }, 403);
  const body = await parseBody(request).catch(() => null);
  const typedCode = typeof body?.classCode === "string" ? body.classCode.trim() : "";
  if (!/^[A-Za-z0-9]{4,12}$/.test(typedCode)) return json({ error: "Mã lớp cần từ 4 đến 12 chữ cái hoặc chữ số." }, 400);
  const code = typedCode.toUpperCase();
  try {
    await env.DB.batch([
      env.DB.prepare("INSERT INTO platform_classes (code,created_by,created_at) VALUES (?,?,?)").bind(code, teacher.id, new Date().toISOString()),
      env.DB.prepare("INSERT INTO platform_class_members (class_code,user_id,membership) VALUES (?,?,'teacher')").bind(code, teacher.id),
    ]);
  } catch (error) {
    if (!await registeredClass(env, code)) throw error;
    return json({ error: "Mã lớp này đã tồn tại. Hãy nhập một mã khác." }, 409);
  }
  return json({ classCode: code }, 201);
}

function studentToken(request) {
  return request.headers.get("cookie")?.match(/(?:^|;\s*)cc_student=([\w-]{43})(?:;|$)/)?.[1];
}

function studentSessionKey(env) {
  const secret = hostedClassroomEnabled(env) ? env.CLASSROOM_SESSION_SECRET : env.ADMIN_SESSION_SECRET;
  if (typeof secret !== "string" || secret.length < 32) throw new Error("Classroom session secret is not configured.");
  return crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
}

function normalizeStudentGroup(name) {
  return typeof name === "string" ? name.trim().normalize("NFC").toLowerCase() : "";
}

function studentGroupProof(classCode, group) {
  return new TextEncoder().encode(JSON.stringify([classCode, group]));
}

async function matchesStudentGroupSession(request, env, classCode, studentName) {
  const token = studentToken(request);
  const group = normalizeStudentGroup(studentName);
  return Boolean(token && CLASS_CODE.test(classCode) && group.length >= 2 && group.length <= 40
    && await crypto.subtle.verify("HMAC", await studentSessionKey(env),
      base64UrlDecode(token), studentGroupProof(classCode, group)));
}

function lessonSampleClassProof(token, classCode) {
  return new TextEncoder().encode(JSON.stringify(["lesson-samples", token, classCode]));
}

async function studentCanReadLessonSamples(request, env, classCode) {
  const token = studentToken(request);
  const proof = request.headers.get("cookie")?.match(/(?:^|;\s*)cc_sample_class=([\w-]{43})(?:;|$)/)?.[1];
  return Boolean(token && proof && await crypto.subtle.verify(
    "HMAC", await studentSessionKey(env), base64UrlDecode(proof), lessonSampleClassProof(token, classCode),
  ));
}

async function canAccessAttempt(request, env, id, classCode, staffAllowed = true) {
  if (!personalAccountsEnabled(env)) return true;
  if (staffAllowed && (await platformTeacher(request, env, classCode) || await platformIdentity(request, env, "admin"))) return true;
  const token = studentToken(request);
  if (!token) return false;
  return Boolean(await env.DB.prepare("SELECT id FROM classroom_attempts WHERE id=? AND class_code=? AND local_owner_hash=?")
    .bind(id, classCode, await platformDigest(token)).first());
}

async function requireTeacher(request, env, classCode) {
  if (personalAccountsEnabled(env)) {
    return await platformTeacher(request, env, classCode) ? null : json({ error: "Hãy đăng nhập bằng tài khoản giáo viên được phân công lớp này." }, 403);
  }
  if (typeof env.TEACHER_USERNAME !== "string" || !env.TEACHER_USERNAME || typeof env.TEACHER_PASSWORD !== "string" || env.TEACHER_PASSWORD.length < 6) {
    return json({ error: "Tài khoản giáo viên chưa được cấu hình." }, 503);
  }
  if (!await teacherPasswordMatches(request, env)) return json({ error: "Tên đăng nhập hoặc mật khẩu giáo viên không đúng." }, 401);
  return null;
}

function adminConfigured(env) {
  return typeof env.ADMIN_USERNAME === "string" && env.ADMIN_USERNAME.length > 0
    && typeof env.ADMIN_PASSWORD === "string" && env.ADMIN_PASSWORD.length >= 10
    && typeof env.ADMIN_SESSION_SECRET === "string" && env.ADMIN_SESSION_SECRET.length >= 32;
}

function base64UrlBytes(bytes) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function base64UrlEncode(value) {
  return base64UrlBytes(new TextEncoder().encode(value));
}

function base64UrlDecode(value) {
  const base64 = value.replace(/-/g, "+").replace(/_/g, "/");
  const binary = atob(base64 + "=".repeat((4 - base64.length % 4) % 4));
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}

async function adminCredentialsMatch(username, password, env) {
  if (!adminConfigured(env)) return false;
  const encoder = new TextEncoder();
  const [expectedUser, suppliedUser, expectedPass, suppliedPass] = await Promise.all([
    crypto.subtle.digest("SHA-256", encoder.encode(env.ADMIN_USERNAME)),
    crypto.subtle.digest("SHA-256", encoder.encode(String(username || ""))),
    crypto.subtle.digest("SHA-256", encoder.encode(env.ADMIN_PASSWORD)),
    crypto.subtle.digest("SHA-256", encoder.encode(String(password || ""))),
  ]);
  let difference = 0;
  for (const [expected, supplied] of [[new Uint8Array(expectedUser), new Uint8Array(suppliedUser)], [new Uint8Array(expectedPass), new Uint8Array(suppliedPass)]]) {
    for (let index = 0; index < expected.length; index += 1) difference |= expected[index] ^ supplied[index];
  }
  return difference === 0;
}

async function createAdminToken(env) {
  const payload = base64UrlEncode(JSON.stringify({ sub: env.ADMIN_USERNAME, exp: Math.floor(Date.now() / 1000) + 30 * 60 }));
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(env.ADMIN_SESSION_SECRET), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const signature = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(payload));
  return `${payload}.${base64UrlBytes(new Uint8Array(signature))}`;
}

async function adminSessionValid(request, env) {
  if (!adminConfigured(env)) return false;
  const token = (request.headers.get("cookie") || "").split(";").map((part) => part.trim()).find((part) => part.startsWith("circuitcoach_admin="))?.slice("circuitcoach_admin=".length) || "";
  const [payload, signature] = token.split(".");
  if (!payload || !signature) return false;
  try {
    const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(env.ADMIN_SESSION_SECRET), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
    const validSignature = await crypto.subtle.verify("HMAC", key, base64UrlDecode(signature), new TextEncoder().encode(payload));
    if (!validSignature) return false;
    const session = JSON.parse(new TextDecoder().decode(base64UrlDecode(payload)));
    return session.sub === env.ADMIN_USERNAME && Number(session.exp) > Math.floor(Date.now() / 1000);
  } catch { return false; }
}

async function requireAdmin(request, env) {
  if (personalAccountsEnabled(env)) {
    return await platformIdentity(request, env, "admin") ? null : json({ error: "Phiên quản trị đã hết hạn. Hãy đăng nhập lại." }, 401);
  }
  if (!adminConfigured(env)) return json({ error: "Tài khoản quản trị chưa được cấu hình đầy đủ." }, 503);
  if (!await adminSessionValid(request, env)) return json({ error: "Phiên quản trị đã hết hạn. Hãy đăng nhập lại." }, 401);
  return null;
}

function loginRateLimited(request) {
  const now = Date.now();
  const client = request.headers.get("cf-connecting-ip") || "anonymous";
  const current = LOGIN_LIMITS.get(client);
  if (!current || now - current.startedAt >= 15 * 60 * 1000) {
    LOGIN_LIMITS.set(client, { startedAt: now, count: 1 });
    return false;
  }
  current.count += 1;
  return current.count > 12;
}

function buildAdminSummary(allAttempts) {
  const attempts = [...allAttempts].sort((a, b) => new Date(b.time) - new Date(a.time));
  const classes = new Map();
  const groups = new Set();
  for (const attempt of attempts) {
    const classCode = normalizeCode(attempt.classCode);
    if (!classCode) continue;
    groups.add(`${classCode}:${attempt.studentId}`);
    const current = classes.get(classCode) || { classCode, attemptCount: 0, groupIds: new Set(), latestActivity: null };
    current.attemptCount += 1;
    current.groupIds.add(String(attempt.studentId || attempt.studentName || ""));
    if (!current.latestActivity || new Date(attempt.time) > new Date(current.latestActivity)) current.latestActivity = attempt.time;
    classes.set(classCode, current);
  }
  return {
    stats: {
      classCount: classes.size,
      groupCount: groups.size,
      attemptCount: attempts.length,
      teacherConfirmedCorrect: attempts.filter((item) => item.teacherVerification === "correct").length,
      teacherConfirmedIncorrect: attempts.filter((item) => item.teacherVerification === "incorrect").length,
      awaitingTeacher: attempts.filter((item) => !item.teacherVerification).length,
    },
    classes: [...classes.values()].map(({ groupIds, ...item }) => ({ ...item, groupCount: groupIds.size }))
      .sort((a, b) => (b.latestActivity || "").localeCompare(a.latestActivity || "")),
    attempts: attempts.slice(0, 1000),
    truncated: attempts.length > 1000,
  };
}

function validText(value, max) {
  return typeof value === "string" && value.length > 0 && value.length <= max;
}

const ANALYSIS_MODELS = ["gpt-5.6-terra", "gpt-6.1-terra", "gpt-6.2-sol"];

function analysisModelChoices(env) {
  return [...new Set([env.OPENAI_ANALYZE_MODEL || ANALYSIS_MODELS[0], ...ANALYSIS_MODELS])];
}

function analysisModelForAttempt(attempt, env) {
  const models = analysisModelChoices(env);
  return models.includes(attempt.analysisModel) ? attempt.analysisModel : models[0];
}

export function sanitizeAttempt(input, env = {}) {
  const classCode = normalizeCode(input?.classCode);
  if (!CLASS_CODE.test(classCode)) throw new Error("Mã lớp không hợp lệ.");
  if (!validText(input?.id, 80) || !validText(input?.studentId, 80) || !validText(input?.studentName, 60) || !validText(input?.lessonId, 40)) throw new Error("Dữ liệu nhóm không hợp lệ.");
  if (!Array.isArray(input.problems) || input.problems.length > 30) throw new Error("Danh sách tiêu chí không hợp lệ.");
  const createdAt = Number.isFinite(Date.parse(input.time)) ? new Date(input.time).toISOString() : new Date().toISOString();
  const context = input.analysisContext;
  const validContext = context && Number.isInteger(context.approvedExamples) && context.approvedExamples >= 0 && context.approvedExamples <= 3
    && Number.isInteger(context.reviewReminders) && context.reviewReminders >= 0 && context.reviewReminders <= 6;
  const validRecheckCount = validContext && Number.isInteger(context.recheckedCriteria)
    && context.recheckedCriteria >= 0 && context.recheckedCriteria <= context.reviewReminders;
  const validPinLayoutCount = validContext && Number.isInteger(context.pinLayoutChecks)
    && context.pinLayoutChecks > 0 && context.pinLayoutChecks <= 4;
  const validMarkedReferenceCount = validContext && Number.isInteger(context.markedReferences)
    && context.markedReferences > 0 && context.markedReferences <= context.approvedExamples;
  const validMarkedViewCount = validContext && Number.isInteger(context.markedViews)
    && context.markedViews > 0 && context.markedViews <= 3;
  return {
    id: input.id,
    studentId: input.studentId,
    studentName: input.studentName.slice(0, 60),
    teamMembers: Array.isArray(input.teamMembers) ? input.teamMembers.slice(0, 3).map((member) => String(member).slice(0, 60)) : [],
    classCode,
    lessonId: input.lessonId,
    time: createdAt,
    analysisStatus: validText(input.analysisStatus, 40) ? input.analysisStatus : "unknown",
    ...(!input.demo && analysisModelChoices(env).includes(input.analysisModel) ? { analysisModel: input.analysisModel } : {}),
    ...(["direct_only", "single_read"].includes(input.evidencePolicy) && !input.demo ? { evidencePolicy: input.evidencePolicy } : {}),
    summary: validText(input.summary, 1000) ? input.summary : "",
    verdict: validText(input.verdict, 20) ? input.verdict : "review",
    safety: input.safety && typeof input.safety === "object" ? input.safety : null,
    captureAdvice: Array.isArray(input.captureAdvice) ? input.captureAdvice.slice(0, 10) : [],
    demo: Boolean(input.demo),
    ...(validContext && !input.demo ? { analysisContext: {
      approvedExamples: context.approvedExamples, reviewReminders: context.reviewReminders,
      ...(validRecheckCount ? { recheckedCriteria: context.recheckedCriteria } : {}),
      ...(validPinLayoutCount ? { pinLayoutChecks: context.pinLayoutChecks } : {}),
      ...(validMarkedReferenceCount ? { markedReferences: context.markedReferences } : {}),
      ...(validMarkedViewCount ? { markedViews: context.markedViews } : {}),
    } } : {}),
    problems: input.problems.slice(0, 30),
    verification: VERIFICATIONS.has(input.verification) ? input.verification : null,
    teacherStatus: null,
    teacherComment: typeof input.teacherComment === "string" ? input.teacherComment.slice(0, 1000) : "",
    teacherCommentAt: Number.isFinite(Date.parse(input.teacherCommentAt)) ? new Date(input.teacherCommentAt).toISOString() : null,
    teacherVerification: null,
    teacherVerificationNote: "",
    teacherAiError: null,
    teacherVerifiedBy: null,
    teacherVerifiedAt: null,
    teacherSafetyCheck: null,
    teacherSafetyNote: "",
    teacherSafetyCheckedBy: null,
    teacherSafetyCheckedAt: null,
    teacherPhysicallyChecked: false,
    teacherCriterionLabels: {},
    teacherImageQuality: null,
    teacherLabelsBy: null,
    teacherLabelsAt: null,
    imageCount: 0,
  };
}

async function parseBody(request) {
  const text = await request.text();
  if (text.length > 100_000) throw new Error("Dữ liệu gửi lên quá lớn.");
  return JSON.parse(text || "{}");
}

function apiError(code, message, status) {
  return json({ error: { code, message } }, status);
}

function rateLimit(request, limits = RATE_LIMITS) {
  const now = Date.now();
  const client = request.headers.get("cf-connecting-ip") || "anonymous";
  const current = limits.get(client);
  if (!current || now - current.startedAt >= RATE_WINDOW_MS) {
    limits.set(client, { startedAt: now, count: 1 });
    return false;
  }
  current.count += 1;
  return current.count > RATE_MAX;
}

function validateImages(files) {
  if (!files.length) throw Object.assign(new Error("Hãy thêm ít nhất một ảnh mạch."), { code: "NO_IMAGES", status: 400 });
  for (const file of files) {
    if (!IMAGE_TYPES.has(file.type) || file.size > 3_000_000) {
      throw Object.assign(new Error("Mỗi ảnh phải là JPEG, PNG hoặc WEBP và không quá 3 MB."), { code: "INVALID_IMAGE", status: 400 });
    }
  }
}

async function fileToDataUrl(file) {
  const bytes = new Uint8Array(await file.arrayBuffer());
  let binary = "";
  for (let offset = 0; offset < bytes.length; offset += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
  }
  return `data:${file.type};base64,${btoa(binary)}`;
}

function responseText(payload) {
  if (typeof payload.output_text === "string" && payload.output_text) return payload.output_text;
  for (const item of payload.output || []) {
    for (const content of item.content || []) {
      if (content.type === "output_text" && typeof content.text === "string") return content.text;
    }
  }
  throw Object.assign(new Error("OpenAI không trả về nội dung phân tích."), { code: "OPENAI_EMPTY_RESPONSE", status: 502 });
}

async function callOpenAI(env, payload, signal) {
  if (!env.OPENAI_API_KEY) throw Object.assign(new Error("OpenAI API chưa được cấu hình."), { code: "OPENAI_NOT_CONFIGURED", status: 503 });
  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      authorization: `Bearer ${env.OPENAI_API_KEY}`,
      "content-type": "application/json",
    },
    body: JSON.stringify({ ...payload, store: false }),
    signal,
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = response.status === 429
      ? "Dịch vụ AI đang bận hoặc đã đạt giới hạn sử dụng. Hãy thử lại sau."
      : response.status === 401 || response.status === 403
        ? "OpenAI từ chối khóa API đang dùng. Hãy kiểm tra khóa và quyền sử dụng mô hình trong phần Cấu hình."
        : response.status === 404
          ? "Model này chưa khả dụng với khóa API đang dùng. Hãy kiểm tra quyền truy cập hoặc chọn model khác."
          : "OpenAI chưa thể hoàn tất yêu cầu. Hãy thử lại.";
    throw Object.assign(new Error(message), { code: `OPENAI_${response.status}`, status: response.status === 429 ? 429 : 502 });
  }
  return JSON.parse(responseText(data));
}

async function readStudentGuide(request, env, url, student, lesson) {
  const classCode = typeof student?.classCode === "string" ? normalizeCode(student.classCode) : "";
  if (!personalAccountsEnabled(env) || request.headers.get("origin") !== url.origin
    || !await matchesStudentGroupSession(request, env, classCode, student?.name)
    || (await activeBrowserRole(request, env)).role !== "student") {
    throw Object.assign(new Error("Hãy vào lại đúng nhóm để dùng trợ lý cá nhân."), { status: 403, code: "GUIDE_STUDENT_SESSION" });
  }

  const owner = await platformDigest(studentToken(request));
  const { results } = await env.DB.prepare(`SELECT id, payload_json FROM classroom_attempts
    WHERE class_code=? AND local_owner_hash=? AND COALESCE(json_extract(payload_json,'$.demo'),0)=0
      AND (? IS NULL OR json_extract(payload_json,'$.lessonId')=?)
    ORDER BY created_at DESC, rowid DESC LIMIT ?`)
    .bind(classCode, owner, lesson?.id ?? null, lesson?.id ?? null, STUDENT_GUIDE_WINDOW).all();
  return summarizeStudentGuide(results.map(row => ({ ...JSON.parse(row.payload_json), id: row.id })), lesson);
}

async function handleStudentGuide(request, env, url) {
  try {
    const body = await parseBody(request).catch(() => null);
    const lesson = typeof body?.lessonId === "string" ? getLesson(body.lessonId) : null;
    if (body?.lessonId && !lesson) return apiError("INVALID_LESSON", "Bài học không hợp lệ.", 400);
    return json({ guide: await readStudentGuide(request, env, url, body?.student, lesson) });
  } catch (error) {
    if (error.code === "GUIDE_STUDENT_SESSION") return apiError(error.code, error.message, 403);
    return apiError("GUIDE_HISTORY_FAILED", "Chưa tải được lịch sử. Hãy mở lại trợ lý để thử lại.", 503);
  }
}

async function handleGuideChat(request, env, url) {
  const origin = request.headers.get("origin");
  if (origin && origin !== url.origin) return apiError("INVALID_ORIGIN", "Nguồn yêu cầu không hợp lệ.", 403);
  try {
    const body = await parseBody(request).catch(() => null);
    const input = prepareGuideChat(body);
    if (rateLimit(request, GUIDE_CHAT_RATE_LIMITS)) return apiError("RATE_LIMITED", "Em gửi nhiều câu hỏi gần nhau. Hãy chờ một chút rồi thử lại.", 429);
    if (body.student) input.studentGuide = studentGuideForModel(await readStudentGuide(request, env, url, body.student, input.lesson));
    const payload = buildGuideChatRequest(env.OPENAI_TUTOR_MODEL || "gpt-5.6-luna", input);
    const result = await callOpenAI(env, payload, AbortSignal.timeout(25_000));
    return json(readGuideChatReply(result));
  } catch (error) {
    const message = error.status === 400 || ["GUIDE_STUDENT_SESSION", "OPENAI_401", "OPENAI_403"].includes(error.code)
      ? error.message : "Trợ lý đang bận. Em có thể dùng các câu hỏi nhanh.";
    return apiError(error.code || "GUIDE_CHAT_FAILED", message, error.status || 502);
  }
}

async function readClassAnalysisReminders(env, lesson, classCode) {
  const { results } = await env.DB.prepare(`WITH scope AS (
    SELECT id,payload_json FROM classroom_attempts
    WHERE class_code=? AND json_extract(payload_json,'$.lessonId')=? AND COALESCE(json_extract(payload_json,'$.demo'),0)=0
  ), feedback AS (
    SELECT json_extract(payload_json,'$.teacherAiError.criterionId') AS criterionId,
      json_extract(payload_json,'$.teacherAiError.reason') AS reason,json_extract(payload_json,'$.teacherVerifiedAt') AS reviewedAt
    FROM scope WHERE json_extract(payload_json,'$.teacherVerification')='incorrect'
      AND json_extract(payload_json,'$.teacherVerifiedAt') IS NOT NULL AND json_type(payload_json,'$.teacherAiError')='object'
    UNION ALL
    SELECT r.criterion_id,json_extract(r.teacher_review_json,'$.aiErrorReason'),json_extract(r.teacher_review_json,'$.at')
    FROM platform_criterion_rechecks r JOIN scope ON scope.id=r.attempt_id
    WHERE json_extract(r.teacher_review_json,'$.aiVerdict')='incorrect'
  ) SELECT criterionId,reason,COUNT(*) AS reports,MAX(reviewedAt) AS latest
    FROM feedback WHERE reason IS NOT NULL GROUP BY criterionId,reason ORDER BY reports DESC,latest DESC,criterionId,reason LIMIT 18`)
    .bind(classCode, lesson.id).all();
  const criteria = new Map(lesson.checkList.map(criterion => [criterion.id, criterion]));
  return results.filter(row => criteria.has(row.criterionId) && Object.hasOwn(AI_ERROR_REVIEW_GUIDANCE, row.reason))
    .sort((a, b) => Number(criteria.get(b.criterionId).category === "safety") - Number(criteria.get(a.criterionId).category === "safety"))
    .slice(0, 6)
    .map(({ criterionId, reason, reports }) => ({
      criterionId, criterionLabel: criteria.get(criterionId).label,
      reasonLabel: AI_ERROR_REASONS[reason], reports, guidance: AI_ERROR_REVIEW_GUIDANCE[reason],
    }));
}

async function readStudentAnalysisReminders(request, env, lesson, form) {
  const classCode = normalizeCode(form.get("classCode"));
  return await matchesStudentGroupSession(request, env, classCode, form.get("studentName"))
    ? readClassAnalysisReminders(env, lesson, classCode) : [];
}

async function handleLessonAiReminders(request, env, url) {
  if (request.headers.get("origin") !== url.origin) return json({ error: "Nguồn yêu cầu không hợp lệ." }, 403);
  const body = await parseBody(request).catch(() => null);
  const lesson = typeof body?.lessonId === "string" ? getWorkerLesson(body.lessonId) : null;
  const classCode = normalizeCode(body?.classCode);
  if (!lesson || !CLASS_CODE.test(classCode)) return json({ error: "Chọn bài học và mã lớp hợp lệ." }, 400);
  const student = await matchesStudentGroupSession(request, env, classCode, body.studentName);
  if (!student && !await platformTeacher(request, env, classCode)) {
    return json({ error: "Cần phiên học sinh của lớp hoặc tài khoản giáo viên phụ trách lớp." }, 403);
  }
  return json({ reminders: await readClassAnalysisReminders(env, lesson, classCode) });
}

async function buildLabeledAnalysisReferences(references) {
  return Promise.all(references.map(async ({ file, criterion, label, errorType, markedRegion, recheckEvidence, recheckGuidance }) => {
    const crop = markedRegion ? await cropMarkedReference(file, markedRegion).catch(() => null) : null;
    const markedDetail = crop ? " Ảnh đã được cắt quanh vùng giáo viên đánh dấu."
      : markedRegion ? ` Vùng giáo viên đánh dấu trên ảnh mẫu: ${describeReferenceRegion(markedRegion)}.` : "";
    return {
      criterionId: criterion.id, marked: Boolean(markedRegion),
      content: [
        { type: "input_text", text: `ẢNH MẪU ĐỐI CHIẾU cho tiêu chí "${criterion.label}" (${criterion.id}). Nhãn giáo viên trên ảnh mẫu: ${label === "correct" ? "ĐÚNG" : "CÓ LỖI"}.${errorType ? ` Dạng lỗi: ${errorType}.` : ""}${markedDetail} Dùng để nhận ra dấu hiệu cần tìm trên ảnh học sinh.`
          + (recheckEvidence ? ` Dấu hiệu giáo viên ghi cho ảnh mẫu này: ${recheckEvidence}.` : "")
          + (recheckGuidance ? ` Điểm AI cần chú ý khi xem ảnh mới: ${recheckGuidance}` : "") },
        { type: "input_image", image_url: await fileToDataUrl(crop || file), detail: "high" },
      ],
    };
  }));
}

function describeReferenceRegion(region) {
  return `x=${Math.round(region.x)}–${Math.round(region.x + region.width)}%, y=${Math.round(region.y)}–${Math.round(region.y + region.height)}%`;
}

function buildMarkedViewInput(markedViews) {
  if (!markedViews.length) return [];
  return [{ type: "input_text", text: "VÙNG GIÁO VIÊN ĐÁNH DẤU TRÊN ẢNH HIỆN TẠI. Tọa độ tính theo ảnh gốc. Đây là nơi cần xem kỹ. Hãy tự lần đầu dây, đọc nhãn của lỗ tương ứng và kết luận từ bằng chứng thấy được.\n"
    + markedViews.map(mark => `- Ảnh ${mark.imageIndex + 1}, ${mark.criterionId}: ${describeReferenceRegion(mark.region)}.`
      + (mark.recheckEvidence ? ` Chi tiết giáo viên yêu cầu đối chiếu: ${mark.recheckEvidence}. Tự kiểm tra chi tiết này trên ảnh.` : "")).join("\n") }];
}

async function buildMarkedDetailInput(images, markedViews) {
  const crops = await Promise.all(markedViews.slice(0, 3).map(async ({ imageIndex, criterionId, region }) => {
    const crop = await cropMarkedReference(images[imageIndex], region).catch(() => null);
    if (!crop) return [];
    return [
      { type: "input_text", text: `ẢNH CẬN CỦA ẢNH GỐC imageIndex=${imageIndex}, tiêu chí ${criterionId}. Dùng ảnh cận để đọc chi tiết, ghi tất cả tọa độ theo ảnh gốc.` },
      { type: "input_image", image_url: await fileToDataUrl(crop), detail: "high" },
    ];
  }));
  return crops.flat();
}

function readCircuit(env, model, lesson, content, started) {
  const deadline = env.LOCAL_PERSONAL_ACCOUNTS === true ? 72_000 : 58_000;
  const signal = AbortSignal.timeout(Math.max(1, deadline - (Date.now() - started)));
  const criterionIds = lesson.checkList.map(criterion => criterion.id);
  return callOpenAI(env, {
    model, instructions: buildPrimaryAnalysisInstructions(lesson), input: [{ role: "user", content }],
    text: { format: { type: "json_schema", name: "circuit_analysis", strict: true, schema: buildCircuitFocusSchema(lesson, criterionIds) } },
  }, signal).catch(error => {
    if (signal.aborted || error.name === "TimeoutError") return circuitAnalysisTimedOut(lesson);
    throw error;
  });
}

async function handleAnalyze(request, env) {
  if (rateLimit(request)) return apiError("RATE_LIMITED", "Bạn đã gửi quá nhiều lần. Hãy chờ vài phút rồi thử lại.", 429);
  const started = Date.now();
  try {
    const form = await request.formData();
    const lesson = getWorkerLesson(String(form.get("lessonId") || ""));
    if (!lesson) return apiError("INVALID_LESSON", "Bài học không hợp lệ.", 400);
    const models = analysisModelChoices(env);
    const model = form.get("analysisModel") ?? models[0];
    if (!models.includes(model)) return apiError("INVALID_ANALYSIS_MODEL", "Hãy chọn một model trong danh sách phân tích.", 400);
    const images = form.getAll("images").filter((value) => value && typeof value.arrayBuffer === "function").slice(0, 3);
    const references = form.getAll("referenceImages").filter((value) => value && typeof value.arrayBuffer === "function").slice(0, 3);
    validateImages(images);
    if (references.length) validateImages(references);
    const reminders = personalAccountsEnabled(env)
      ? await readStudentAnalysisReminders(request, env, lesson, form).catch(() => []) : [];
    const { examples: approved, markedViews } = personalAccountsEnabled(env)
      ? await selectReferenceCases(env, lesson, null, images, reminders.map(row => row.criterionId), true)
        .catch(() => ({ examples: [], markedViews: [] }))
      : { examples: [], markedViews: [] };
    const referenceInputs = await buildLabeledAnalysisReferences(approved);
    const markedViewInput = buildMarkedViewInput(markedViews);
    const standardPhotos = references.slice(0, 3 - approved.length);
    const reminderInput = reminders.length ? [{ type: "input_text", text: "NHẮC KIỂM TRA TỪ PHẢN HỒI GIÁO VIÊN CÙNG BÀI. Đây là các điểm cần xem kỹ trên ảnh mới. Chỉ kết luận dựa trên bằng chứng của ảnh mới.\n"
      + reminders.map(row => `- ${row.criterionLabel} (${row.criterionId}) · ${row.reasonLabel}. ${row.guidance}`).join("\n") }] : [];
    const detail = studentImageDetail(lesson, model);
    const studentPhotoInput = buildStudentImageInput(await Promise.all(images.map(async file => ({
      type: "input_image", image_url: await fileToDataUrl(file), detail,
    }))));
    const content = [
      { type: "input_text", text: buildAnalyzeInput(lesson, approved.length + standardPhotos.length, approved.length > 0) },
      ...reminderInput,
      ...markedViewInput,
      ...referenceInputs.flatMap(item => item.content),
      ...(standardPhotos.length ? [{ type: "input_text", text: "ẢNH MẠCH CHUẨN — dùng để đối chiếu, không chấm điểm:" }] : []),
      ...await Promise.all(standardPhotos.map(async (file) => ({ type: "input_image", image_url: await fileToDataUrl(file), detail: "high" }))),
      ...studentPhotoInput,
      ...await buildMarkedDetailInput(images, markedViews),
      ...buildLedPhotoInstructions(lesson),
      ...await buildLedDetailInput(lesson, images, fileToDataUrl, detail),
    ];
    const analysis = await readCircuit(env, model, lesson, content, started);
    const result = finalizeCircuitAnalysis(lesson, analysis, images.length, { singleRead: true, markedViews });
    const pinLayoutChecks = result.checks.filter(check => check.ruleEvidence?.pinLayout).length;
    return json({ ...result, demo: false, analysisModel: model,
      analysisContext: { approvedExamples: approved.length, reviewReminders: reminders.length,
        ...(pinLayoutChecks ? { pinLayoutChecks } : {}),
        ...(referenceInputs.some(item => item.marked) ? { markedReferences: referenceInputs.filter(item => item.marked).length } : {}),
        ...(markedViews.length ? { markedViews: new Set(markedViews.map(mark => mark.imageIndex)).size } : {}),
      } });
  } catch (error) {
    return apiError(error.code || "ANALYZE_FAILED", error.message || "Không thể phân tích mạch.", error.status || 500);
  }
}

async function analyzeLane(env, lesson, images, references = [], { model = analysisModelChoices(env)[0], rechecking = false, markedViews = [] } = {}) {
  const started = Date.now();
  const detail = studentImageDetail(lesson, model);
  const studentPhotoInput = buildStudentImageInput(await Promise.all(images.map(async file => ({
    type: "input_image", image_url: await fileToDataUrl(file), detail,
  }))));
  const referenceInputs = await buildLabeledAnalysisReferences(references);
  const content = [
    { type: "input_text", text: buildAnalyzeInput(lesson, references.length, references.length > 0) },
    ...(rechecking ? [{ type: "input_text", text: "Đây là ảnh mới để kiểm tra lại đúng một tiêu chí. Chỉ kết luận tiêu chí được yêu cầu, dựa vào bằng chứng hiện có trong ảnh mới." }] : []),
    ...buildMarkedViewInput(markedViews),
    ...referenceInputs.flatMap(item => item.content),
    ...studentPhotoInput,
    ...await buildMarkedDetailInput(images, markedViews),
    ...buildLedPhotoInstructions(lesson),
    ...await buildLedDetailInput(lesson, images, fileToDataUrl, detail),
  ];
  const analysis = await readCircuit(env, model, lesson, content, started);
  if (rechecking && analysis.readTimedOut) {
    throw Object.assign(new Error("AI chưa kịp kiểm tra ảnh. Em có thể thử lại ảnh này."), { code: "RECHECK_TIMEOUT", status: 504 });
  }
  return finalizeCircuitAnalysis(lesson, analysis, images.length, { singleRead: true, markedViews });
}

async function handleCriterionRechecks(request, env, url, match) {
  const [, pathId, photoId] = match;
  const { method } = request;
  if (method !== "GET" && (method !== "POST" || photoId)) return apiError("METHOD", "Phương thức không được hỗ trợ.", 405);
  if (method === "POST" && request.headers.get("origin") !== url.origin) {
    return apiError("INVALID_ORIGIN", "Nguồn yêu cầu không hợp lệ.", 403);
  }
  if (!env.DB || !env.BUCKET) return apiError("STORAGE_UNAVAILABLE", "Kho dữ liệu lớp học chưa sẵn sàng.", 503);
  try {
    const id = decodeURIComponent(pathId);
    const classCode = normalizeCode(url.searchParams.get("classCode"));
    if (!validText(id, 80) || !CLASS_CODE.test(classCode)) return apiError("INVALID_ATTEMPT", "Lượt phân tích không hợp lệ.", 400);
    if (!await canAccessAttempt(request, env, id, classCode, method === "GET")) {
      return apiError("NO_ATTEMPT_ACCESS", "Em cần vào đúng nhóm sở hữu lượt phân tích này.", 403);
    }
    const attemptRow = await env.DB.prepare("SELECT payload_json FROM classroom_attempts WHERE id=? AND class_code=?")
      .bind(id, classCode).first();
    if (!attemptRow) return apiError("ATTEMPT_NOT_FOUND", "Chưa tìm thấy lượt phân tích đã đồng bộ.", 404);
    if (method === "GET") {
      if (photoId) {
        const entry = await env.DB.prepare("SELECT id FROM platform_criterion_rechecks WHERE attempt_id=? AND id=?").bind(id, photoId).first();
        const photo = entry && await env.BUCKET.get(`criterion-rechecks/${entry.id}`);
        if (!photo) return apiError("PHOTO_NOT_FOUND", "Không tìm thấy ảnh kiểm tra lại.", 404);
        return new Response(photo.body, { headers: { "content-type": photo.httpMetadata?.contentType || "image/jpeg",
          "cache-control": "private, no-store", "x-content-type-options": "nosniff" } });
      }
      const { results } = await env.DB.prepare(`SELECT r.id, r.criterion_id AS criterionId, r.created_at AS createdAt, r.check_json AS checkJson,
        r.teacher_comment AS teacherComment, r.teacher_comment_at AS teacherCommentAt, r.teacher_comment_by AS teacherCommentBy,
        r.teacher_comment_version AS teacherCommentVersion, r.teacher_review_json AS reviewJson, r.teacher_review_version AS teacherReviewVersion,
        (SELECT u.id FROM platform_uploaded_reference_cases u WHERE u.source_recheck_id=r.id AND u.status='approved'
          ORDER BY u.created_at DESC,u.id DESC LIMIT 1) AS referenceId
        FROM platform_criterion_rechecks r WHERE r.attempt_id=? ORDER BY r.created_at DESC,r.id DESC`).bind(id).all();
      return json({ rechecks: results.map(({ checkJson, reviewJson, ...row }) => ({
        ...row, check: JSON.parse(checkJson), teacherReview: JSON.parse(reviewJson),
      })) });
    }
    const form = await request.formData();
    const criterionId = String(form.get("criterionId") || "");
    const attempt = JSON.parse(attemptRow.payload_json);
    const lesson = getWorkerLesson(attempt.lessonId);
    const criterion = lesson?.checkList.find(check => check.id === criterionId);
    const original = attempt.problems?.find(check => (check.id || check.criterionId) === criterionId);
    if (attempt.demo || !criterion || !["possible_error", "uncertain", "not_visible"].includes(original?.status)
      || original?.ruleEvidence?.physicalCheckRequired || CIRCUIT_LESSON_SPECS[lesson.id].rules[criterionId]?.physicalCheck) {
      return apiError("INVALID_CRITERION", "Tiêu chí này không có lượt kiểm tra lại bằng ảnh.", 400);
    }
    const photos = form.getAll("photo");
    if (photos.length !== 1 || typeof photos[0]?.arrayBuffer !== "function" || !photos[0].size) {
      return apiError("INVALID_IMAGE", "Hãy chọn đúng một ảnh để kiểm tra lại.", 400);
    }
    validateImages(photos);
    if (rateLimit(request)) return apiError("RATE_LIMITED", "Bạn đã gửi quá nhiều lần. Hãy chờ một chút rồi thử lại.", 429);
    const focusedLesson = { ...lesson, checkList: [criterion] };
    const [photo] = photos;
    const { examples, markedViews } = await selectReferenceCases(env, focusedLesson, null, photos, [criterion.id], true)
      .catch(() => ({ examples: [], markedViews: [] }));
    const model = analysisModelForAttempt(attempt, env);
    const result = await analyzeLane(env, focusedLesson, photos, examples, { model, rechecking: true, markedViews });
    const recheck = { id: crypto.randomUUID(), criterionId, createdAt: new Date().toISOString(), check: result.checks[0] };
    const objectKey = `criterion-rechecks/${recheck.id}`;
    await env.BUCKET.put(objectKey, photo.stream(), { httpMetadata: { contentType: photo.type } });
    try {
      await env.DB.prepare(`INSERT INTO platform_criterion_rechecks (id, attempt_id, criterion_id, check_json, model, created_at)
        VALUES (?, ?, ?, ?, ?, ?)`).bind(recheck.id, id, criterionId, JSON.stringify(recheck.check),
        model, recheck.createdAt).run();
    } catch (error) {
      const exists = await env.DB.prepare("SELECT id FROM platform_criterion_rechecks WHERE id=?").bind(recheck.id).first().catch(() => true);
      if (!exists) await env.BUCKET.delete(objectKey).catch(() => {});
      throw error;
    }
    return json({ recheck }, 201);
  } catch (error) {
    const status = error.status || 500;
    return apiError(error.code || "RECHECK_FAILED", error.status ? error.message : "Chưa lưu được lượt kiểm tra lại. Em có thể thử lại.", status);
  }
}

async function saveRecheckComment(request, env, url, match) {
  if (request.method !== "PATCH") return apiError("METHOD", "Phương thức không được hỗ trợ.", 405);
  if (request.headers.get("origin") !== url.origin) return apiError("INVALID_ORIGIN", "Nguồn yêu cầu không hợp lệ.", 403);
  const [, pathId, recheckId] = match;
  const attemptId = decodeURIComponent(pathId);
  const classCode = normalizeCode(url.searchParams.get("classCode"));
  if (!validText(attemptId, 80) || !CLASS_CODE.test(classCode)) return apiError("INVALID_ATTEMPT", "Lượt phân tích không hợp lệ.", 400);
  const teacher = await platformTeacher(request, env, classCode);
  if (!teacher) return apiError("NO_ATTEMPT_ACCESS", "Cần đăng nhập bằng tài khoản giáo viên phụ trách lớp này.", 403);
  const body = await parseBody(request).catch(() => null);
  if (typeof body?.comment !== "string" || body.comment.length > 1000
    || !Number.isSafeInteger(body.version) || body.version < 0) {
    return apiError("INVALID_COMMENT", "Nhận xét được phép dài tối đa 1.000 ký tự.", 400);
  }
  const teacherComment = body.comment.trim();
  const teacherCommentAt = new Date().toISOString();
  const write = await env.DB.prepare(`UPDATE platform_criterion_rechecks
    SET teacher_comment=?, teacher_comment_at=?, teacher_comment_by=?, teacher_comment_version=teacher_comment_version+1
    WHERE id=? AND attempt_id=? AND teacher_comment_version=? AND EXISTS (
      SELECT 1 FROM classroom_attempts WHERE id=? AND class_code=?
    )`).bind(teacherComment, teacherCommentAt, teacher.username, recheckId, attemptId, body.version, attemptId, classCode).run();
  if (!write.meta.changes) {
    const row = await env.DB.prepare(`SELECT r.id FROM platform_criterion_rechecks r JOIN classroom_attempts a ON a.id=r.attempt_id
      WHERE r.id=? AND a.id=? AND a.class_code=?`).bind(recheckId, attemptId, classCode).first();
    return row ? apiError("COMMENT_CHANGED", "Nhận xét vừa được cập nhật ở nơi khác. Hãy mở lại bài để lấy bản mới.", 409)
      : apiError("RECHECK_NOT_FOUND", "Không tìm thấy ảnh kiểm tra lại của bài này.", 404);
  }
  return json({ teacherComment, teacherCommentAt, teacherCommentBy: teacher.username, teacherCommentVersion: body.version + 1 });
}

async function handleRecheckReview(request, env, url, match) {
  const [, pathId, recheckId, action] = match;
  const publishing = action === "reference";
  if (request.method !== (publishing ? "POST" : "PATCH")) return apiError("METHOD", "Phương thức không được hỗ trợ.", 405);
  if (request.headers.get("origin") !== url.origin) return apiError("INVALID_ORIGIN", "Nguồn yêu cầu không hợp lệ.", 403);
  const attemptId = decodeURIComponent(pathId);
  const classCode = normalizeCode(url.searchParams.get("classCode"));
  if (!validText(attemptId, 80) || !CLASS_CODE.test(classCode)) return apiError("INVALID_ATTEMPT", "Lượt phân tích không hợp lệ.", 400);
  const teacher = await platformTeacher(request, env, classCode);
  if (!teacher) return apiError("NO_ATTEMPT_ACCESS", "Chỉ giáo viên phụ trách lớp có thể đánh giá ảnh này.", 403);
  const body = await parseBody(request).catch(() => null);
  if (!Number.isSafeInteger(body?.version) || body.version < 0) return apiError("INVALID_REVIEW", "Phiên bản đánh giá không hợp lệ.", 400);
  const row = await env.DB.prepare(`SELECT r.criterion_id AS criterionId, r.teacher_review_json AS reviewJson,
    r.teacher_review_version AS version, a.payload_json FROM platform_criterion_rechecks r
    JOIN classroom_attempts a ON a.id=r.attempt_id WHERE r.id=? AND a.id=? AND a.class_code=?`)
    .bind(recheckId, attemptId, classCode).first();
  if (!row) return apiError("RECHECK_NOT_FOUND", "Không tìm thấy ảnh kiểm tra lại của bài này.", 404);
  if (row.version !== body.version) return apiError("REVIEW_CHANGED", "Đánh giá vừa thay đổi. Hãy mở lại bài để xem bản mới.", 409);
  if (!publishing) {
    const { aiVerdict, photoLabel, aiErrorReason, errorType, evidence } = body;
    const annotations = readReferenceAnnotations(body.annotations);
    if (!["correct", "incorrect", "uncertain"].includes(aiVerdict)
      || !["correct", "incorrect", "uncertain"].includes(photoLabel) || annotations === null
      || typeof evidence !== "string" || evidence.length > 300
      || (aiVerdict === "incorrect" && !Object.hasOwn(AI_ERROR_REASONS, aiErrorReason))
      || invalidReferenceErrorType(photoLabel, photoLabel === "incorrect" ? errorType : null, evidence.trim())) {
      return apiError("INVALID_REVIEW", "Chọn đánh giá AI, nhãn ảnh và loại lỗi tương ứng. Ghi chú tối đa 300 ký tự.", 400);
    }
    const teacherReview = { aiVerdict, photoLabel, aiErrorReason: aiVerdict === "incorrect" ? aiErrorReason : null,
      errorType: photoLabel === "incorrect" ? errorType : null, evidence: evidence.trim(), annotations: JSON.parse(annotations),
      by: teacher.username, at: new Date().toISOString() };
    const saved = await env.DB.prepare(`UPDATE platform_criterion_rechecks SET teacher_review_json=?,
      teacher_review_version=teacher_review_version+1 WHERE id=? AND attempt_id=? AND teacher_review_version=?`)
      .bind(JSON.stringify(teacherReview), recheckId, attemptId, body.version).run();
    if (!saved.meta.changes) return apiError("REVIEW_CHANGED", "Đánh giá vừa thay đổi. Hãy mở lại bài để xem bản mới.", 409);
    return json({ teacherReview, teacherReviewVersion: body.version + 1 });
  }
  const review = JSON.parse(row.reviewJson);
  if (!["correct", "incorrect"].includes(review.photoLabel)) {
    return apiError("REFERENCE_LABEL_REQUIRED", "Ảnh tham chiếu cần nhãn thực tế Đúng hoặc Có lỗi.", 400);
  }
  if (!env.BUCKET) return apiError("STORAGE_UNAVAILABLE", "Kho ảnh chưa sẵn sàng.", 503);
  const object = await env.BUCKET.get(`criterion-rechecks/${recheckId}`);
  if (!IMAGE_TYPES.has(object?.httpMetadata?.contentType)) return apiError("PHOTO_NOT_FOUND", "Không tìm thấy ảnh kiểm tra lại.", 404);
  const photo = new Blob([await new Response(object.body).arrayBuffer()], { type: object.httpMetadata.contentType });
  const lessonId = JSON.parse(row.payload_json).lessonId;
  const sourceKey = await platformDigest(JSON.stringify(["criterion-recheck", recheckId, row.version]));
  const existing = await env.DB.prepare("SELECT id FROM platform_uploaded_reference_cases WHERE source_key=? AND status='approved'")
    .bind(sourceKey).first();
  if (existing) return json({ saved: true, id: existing.id });
  const id = crypto.randomUUID();
  const now = new Date().toISOString();
  const activeVersion = "EXISTS (SELECT 1 FROM platform_criterion_rechecks WHERE id=? AND teacher_review_version=?)";
  return storeReferencePhoto(env, id, photo, sourceKey, [
    env.DB.prepare(`UPDATE platform_uploaded_reference_cases SET status='retired',reviewed_by=?,reviewed_at=?
      WHERE source_recheck_id=? AND status='approved' AND source_key<>? AND ${activeVersion}`)
      .bind(teacher.id, now, recheckId, sourceKey, recheckId, row.version),
    env.DB.prepare(`INSERT INTO platform_uploaded_reference_cases
      (id,class_code,lesson_id,criterion_id,label,error_type,evidence,status,created_by,created_at,reviewed_by,reviewed_at,
       source_key,annotations_json,source_recheck_id,ai_error_reason)
      SELECT ?,?,?,?,?,?,?,'approved',?,?,?,?,?,?,?,? WHERE ${activeVersion}`)
      .bind(id, classCode, lessonId, row.criterionId, review.photoLabel, review.errorType, review.evidence, teacher.id, now,
        teacher.id, now, sourceKey, JSON.stringify(review.annotations), recheckId, review.aiErrorReason, recheckId, row.version),
  ], { verifyInsert: true });
}

async function handleTutor(request, env, url) {
  if (rateLimit(request)) return apiError("RATE_LIMITED", "Bạn đã gửi quá nhiều lần. Hãy chờ vài phút rồi thử lại.", 429);
  try {
    const payload = await parseBody(request);
    const lesson = getWorkerLesson(payload.lessonId);
    const check = lesson?.checkList.find((item) => item.id === payload.problem?.id);
    const knowledge = knowledgeBase[payload.problem?.id];
    if (!lesson || !check || !knowledge) return apiError("INVALID_PROBLEM", "Vấn đề không thuộc bài học đã chọn.", 400);
    if (url.searchParams.get("demo") === "true") return json({ ...getLocalHint(payload.problem, payload.studentContext?.hintLevel || 1), demo: true });
    const result = await callOpenAI(env, {
      model: env.OPENAI_TUTOR_MODEL || "gpt-5.6-luna",
      instructions: TUTOR_DEVELOPER_PROMPT,
      input: buildTutorInput({ lesson, problem: payload.problem, studentContext: payload.studentContext, knowledge }),
      text: { format: { type: "json_schema", name: "circuit_tutor_hint", strict: true, schema: tutorJsonSchema } },
    });
    return json({ ...result, source: "openai", demo: false });
  } catch (error) {
    return apiError(error.code || "TUTOR_FAILED", error.message || "Không thể tạo gợi ý.", error.status || 500);
  }
}

const LESSON_SAMPLE_LIMIT = 24;

async function isSupportedPhotoUpload(file) {
  if (!file || typeof file.arrayBuffer !== "function" || !IMAGE_TYPES.has(file.type) || file.size > 3_000_000) return false;
  const header = new Uint8Array(await file.slice(0, 12).arrayBuffer());
  if (file.type === "image/jpeg") return header[0] === 0xff && header[1] === 0xd8 && header[2] === 0xff;
  const signature = String.fromCharCode(...header);
  if (file.type === "image/png") return signature.startsWith("\x89PNG\r\n\x1a\n");
  return signature.startsWith("RIFF") && signature.slice(8, 12) === "WEBP";
}

async function handleLessonSamples(request, env, url, lessonId, photoId) {
  const classCode = normalizeCode(url.searchParams.get("classCode"));
  if (!CLASS_CODE.test(classCode) || !getLesson(lessonId)) return json({ error: "Mã lớp hoặc bài học không hợp lệ." }, 400);
  if (!env.DB || !env.BUCKET) return json({ error: "Kho ảnh mẫu chưa sẵn sàng." }, 503);

  const teacher = await platformTeacher(request, env, classCode);
  const managing = url.searchParams.get("manage") === "1";
  const scope = [classCode, lessonId];
  if (request.method === "GET") {
    const staff = teacher || await platformIdentity(request, env, "admin");
    if (managing && !staff) return json({ error: "Hãy đăng nhập bằng tài khoản nhân sự có quyền xem ảnh lớp." }, 403);
    if (!staff && !await studentCanReadLessonSamples(request, env, classCode)) {
      return json({ error: "Hãy vào nhóm của lớp để xem thư viện." }, 401);
    }
    if (!photoId) {
      const { results } = await env.DB.prepare(`SELECT id, title, caption, hidden_at AS hiddenAt
        FROM platform_lesson_sample_photos WHERE class_code=? AND lesson_id=? AND (? OR hidden_at IS NULL)
        ORDER BY created_at DESC, id`).bind(...scope, Number(Boolean(staff && managing))).all();
      return json({ photos: results, limit: LESSON_SAMPLE_LIMIT });
    }
    const row = await env.DB.prepare(`SELECT id FROM platform_lesson_sample_photos
      WHERE class_code=? AND lesson_id=? AND id=? AND (? OR hidden_at IS NULL)`)
      .bind(...scope, photoId, staff ? 1 : 0).first();
    const image = row && await env.BUCKET.get("lesson-samples/" + row.id);
    const contentType = image?.httpMetadata?.contentType;
    if (!IMAGE_TYPES.has(contentType)) return json({ error: "Không tìm thấy ảnh mẫu." }, 404);
    return new Response(image.body, { headers: {
      "content-type": contentType,
      "cache-control": "private, no-store",
      "x-content-type-options": "nosniff",
    } });
  }

  if (!teacher || request.headers.get("origin") !== url.origin) {
    return json({ error: "Chỉ giáo viên được phân công mới có thể thay đổi thư viện của lớp." }, 403);
  }
  const capacityError = () => json({ error: `Bài học đã có ${LESSON_SAMPLE_LIMIT} ảnh đang hiển thị. Hãy ẩn một ảnh trước.` }, 409);
  const visibleCount = "(SELECT COUNT(*) FROM platform_lesson_sample_photos WHERE class_code=? AND lesson_id=? AND hidden_at IS NULL)";
  if (request.method === "POST" && !photoId) {
    const form = await request.formData().catch(() => null);
    const title = form?.get("title");
    const caption = form?.get("caption") ?? "";
    const image = form?.get("image");
    if (typeof title !== "string" || !title.trim() || title.length > 100 || typeof caption !== "string" || caption.length > 280) {
      return json({ error: "Nhập tên ảnh tối đa 100 ký tự và chú thích tối đa 280 ký tự." }, 400);
    }
    if (!await isSupportedPhotoUpload(image)) return json({ error: "Chọn ảnh JPEG, PNG hoặc WebP hợp lệ, tối đa 3 MB." }, 400);
    const id = crypto.randomUUID();
    const key = "lesson-samples/" + id;
    let persisted = false;
    try {
      await env.BUCKET.put(key, image.stream(), { httpMetadata: { contentType: image.type } });
      const write = await env.DB.prepare(`INSERT INTO platform_lesson_sample_photos
        (id, class_code, lesson_id, title, caption, created_by, created_at)
        SELECT ?, ?, ?, ?, ?, ?, ? WHERE ${visibleCount} < ?`)
        .bind(id, ...scope, title.trim(), caption.trim(), teacher.id, new Date().toISOString(), ...scope, LESSON_SAMPLE_LIMIT).run();
      persisted = Boolean(write.meta.changes);
      return persisted ? json({ id }, 201) : capacityError();
    } finally {
      if (!persisted) await env.BUCKET.delete(key);
    }
  }
  if (request.method === "PATCH" && photoId) {
    const body = await parseBody(request).catch(() => null);
    if (typeof body?.visible !== "boolean") return json({ error: "Trạng thái ảnh không hợp lệ." }, 400);
    const current = await env.DB.prepare("SELECT hidden_at FROM platform_lesson_sample_photos WHERE class_code=? AND lesson_id=? AND id=?")
      .bind(...scope, photoId).first();
    if (!current) return json({ error: "Không tìm thấy ảnh mẫu." }, 404);
    const write = await env.DB.prepare(`UPDATE platform_lesson_sample_photos SET hidden_at=?
      WHERE class_code=? AND lesson_id=? AND id=? AND (? OR hidden_at IS NULL OR ${visibleCount} < ?)`)
      .bind(body.visible ? null : new Date().toISOString(), ...scope, photoId, body.visible ? 0 : 1, ...scope, LESSON_SAMPLE_LIMIT).run();
    return write.meta.changes ? json({ visible: body.visible }) : capacityError();
  }
  return json({ error: "Thao tác chưa được hỗ trợ." }, 405);
}

async function referencePhotoDigest(file) {
  return base64UrlBytes(new Uint8Array(await crypto.subtle.digest("SHA-256", await file.arrayBuffer())));
}

function invalidReferenceErrorType(label, errorType, evidence) {
  return label === "incorrect" && (
    typeof errorType !== "string" || !Object.hasOwn(REFERENCE_ERROR_TYPES, errorType)
    || (errorType === "other" && !evidence)
  );
}

function invalidReferenceErrorResponse() {
  return json({ error: "Chọn dạng lỗi. Nếu chọn Lỗi khác, ghi rõ dấu hiệu nhìn thấy trên ảnh." }, 400);
}

function readReferenceAnnotations(input) {
  if (input == null) return "[]";
  if (typeof input === "string") {
    if (input.length > 40_000) return null;
    try { input = JSON.parse(input); } catch { return null; }
  }
  if (!Array.isArray(input) || input.length > 20) return null;
  const normalized = [];
  for (const mark of input) {
    const { kind, points, text } = mark || {};
    if (!["line", "circle", "note"].includes(kind) || !Array.isArray(points)) return null;
    const validCount = kind === "line" ? points.length >= 2 && points.length <= 100 : points.length === (kind === "circle" ? 2 : 1);
    if (!validCount || !points.every(pair => Array.isArray(pair) && pair.length === 2 &&
      pair.every(value => Number.isInteger(value) && value >= 0 && value <= 1000))) return null;
    if (kind === "note" && (typeof text !== "string" || !text.trim() || text.length > 80)) return null;
    normalized.push(kind === "note" ? { kind, points, text: text.trim() } : { kind, points });
  }
  return JSON.stringify(normalized);
}

async function storeReferencePhoto(env, id, photo, sourceKey, writes, { verifyInsert = false } = {}) {
  const photoKey = "reviewed-examples/" + id;
  try {
    await env.BUCKET.put(photoKey, photo.stream(), { httpMetadata: { contentType: photo.type } });
    const saved = await env.DB.batch(writes);
    if (verifyInsert && !saved.at(-1).meta.changes) {
      await env.BUCKET.delete(photoKey);
      return apiError("REVIEW_CHANGED", "Đánh giá vừa thay đổi. Hãy mở lại bài để chọn bản mới.", 409);
    }
  } catch (error) {
    await env.BUCKET.delete(photoKey);
    const existing = await env.DB.prepare("SELECT id FROM platform_reference_case_catalog WHERE source_key=? AND status IN ('pending','approved')").bind(sourceKey).first();
    if (existing) return json({ error: "Ảnh và trường hợp này đã có trong kho hoặc đang chờ duyệt." }, 409);
    throw error;
  }
  return json({ saved: true, id }, 201);
}

async function submitReferenceCase(request, env, url) {
  if (request.headers.get("origin") !== url.origin) return json({ error: "Nguồn yêu cầu không hợp lệ." }, 403);
  const body = await parseBody(request).catch(() => null);
  const id = body?.id;
  const classCode = normalizeCode(body?.classCode);
  const photoIndex = body?.photoIndex;
  const criterionId = body?.criterionId;
  const note = body?.evidence ?? "";
  const annotations = readReferenceAnnotations(body?.annotations);
  if (!validText(id, 80) || !CLASS_CODE.test(classCode) || !Number.isInteger(photoIndex) || photoIndex < 0 || photoIndex > 2
    || typeof criterionId !== "string" || typeof note !== "string" || note.length > 300) {
    return json({ error: "Hãy chọn tiêu chí, ảnh minh họa và nhập ghi chú tối đa 300 ký tự." }, 400);
  }
  if (annotations === null) return json({ error: "Nét vẽ hoặc chú thích trên ảnh không hợp lệ." }, 400);
  const teacher = await platformTeacher(request, env, classCode);
  if (!teacher) return json({ error: "Chỉ giáo viên được phân công mới có thể gửi ví dụ của lớp." }, 403);
  const row = await env.DB.prepare("SELECT payload_json FROM classroom_attempts WHERE id=? AND class_code=?").bind(id, classCode).first();
  if (!row) return json({ error: "Không tìm thấy bài." }, 404);
  const attempt = JSON.parse(row.payload_json);
  const lesson = getWorkerLesson(attempt.lessonId);
  const label = attempt.teacherCriterionLabels?.[criterionId];
  if (attempt.demo || photoIndex >= Number(attempt.imageCount || 0) || !lesson?.checkList.some(criterion => criterion.id === criterionId)
    || !["correct", "incorrect"].includes(label)) {
    return json({ error: "Cần ảnh thật đã đồng bộ và nhãn Đúng hoặc Có lỗi đã lưu cho tiêu chí này." }, 400);
  }
  const errorType = label === "incorrect" ? body.errorType : null;
  const evidence = note.trim();
  if (invalidReferenceErrorType(label, errorType, evidence)) return invalidReferenceErrorResponse();
  const photo = await loadComparisonPhoto(env, classCode, id, photoIndex);
  if (!photo) return json({ error: "Không tìm thấy ảnh đã đồng bộ." }, 409);
  const exampleId = crypto.randomUUID();
  const revision = crypto.randomUUID();
  const sourceKey = await platformDigest(JSON.stringify([id, photoIndex, criterionId, label, errorType, await referencePhotoDigest(photo)]));
  const now = new Date().toISOString();
  return storeReferencePhoto(env, exampleId, photo, sourceKey, [
    env.DB.prepare(`INSERT INTO platform_label_revisions
      (id,attempt_id,criterion_id,author_id,status,evidence,error_type,image_quality,confirmation_source,created_at)
      VALUES (?,?,?,?,?,?,?,?,'image',?)`).bind(revision, id, criterionId, teacher.id, label, evidence, errorType, attempt.teacherImageQuality || null, now),
    env.DB.prepare(`INSERT INTO platform_reference_examples
      (id,attempt_id,lesson_id,label_revision_id,status,created_at,photo_index,source_key,annotations_json)
      VALUES (?,?,?,?,'pending',?,?,?,?)`).bind(exampleId, id, lesson.id, revision, now, photoIndex, sourceKey, annotations),
  ]);
}

async function uploadReferenceCase(request, env, url) {
  if (request.headers.get("origin") !== url.origin) return json({ error: "Nguồn yêu cầu không hợp lệ." }, 403);
  const shared = url.searchParams.get("scope") === "all";
  const classCode = shared ? "" : normalizeCode(url.searchParams.get("classCode"));
  if (!shared && !CLASS_CODE.test(classCode)) return json({ error: "Mã lớp không hợp lệ." }, 400);
  const teacher = await platformTeacher(request, env, shared ? undefined : classCode);
  if (!teacher) return json({ error: "Cần đăng nhập giáo viên có quyền tải ảnh tham chiếu." }, 403);
  const form = await request.formData().catch(() => null);
  const lesson = getWorkerLesson(form?.get("lessonId"));
  const criterionId = form?.get("criterionId");
  const label = form?.get("label");
  const note = form?.get("evidence") ?? "";
  const photo = form?.get("image");
  const annotations = readReferenceAnnotations(form?.get("annotations"));
  if (!lesson?.checkList.some(criterion => criterion.id === criterionId) || !["correct", "incorrect"].includes(label)
    || typeof note !== "string" || note.length > 300) {
    return json({ error: "Chọn bài học, tiêu chí và nhãn đúng hoặc có lỗi. Ghi chú tối đa 300 ký tự." }, 400);
  }
  if (annotations === null) return json({ error: "Nét vẽ hoặc chú thích trên ảnh không hợp lệ." }, 400);
  const errorType = label === "incorrect" ? form.get("errorType") : null;
  const evidence = note.trim();
  if (invalidReferenceErrorType(label, errorType, evidence)) return invalidReferenceErrorResponse();
  if (!await isSupportedPhotoUpload(photo)) return json({ error: "Chọn ảnh JPEG, PNG hoặc WebP hợp lệ, tối đa 3 MB." }, 400);
  const id = crypto.randomUUID();
  const sourceKey = await platformDigest(JSON.stringify(["upload", classCode, lesson.id, criterionId, label, errorType, await referencePhotoDigest(photo)]));
  return storeReferencePhoto(env, id, photo, sourceKey, [
    env.DB.prepare(`INSERT INTO platform_uploaded_reference_cases
      (id,class_code,lesson_id,criterion_id,label,error_type,evidence,status,created_by,created_at,source_key,annotations_json)
      VALUES (?,?,?,?,?,?,?,'pending',?,?,?,?)`).bind(id, classCode, lesson.id, criterionId, label, errorType, evidence, teacher.id, new Date().toISOString(), sourceKey, annotations),
  ]);
}

async function sharedReferenceAccess(request, env) {
  const admin = await platformIdentity(request, env, "admin");
  if (admin) return { actor: admin, predicate: "1", values: [] };
  const teacher = await platformTeacher(request, env);
  if (!teacher) return null;
  return {
    actor: teacher,
    predicate: `(EXISTS (SELECT 1 FROM platform_class_members m
      WHERE m.class_code=c.class_code AND m.user_id=? AND m.membership='teacher')
      OR (c.source='upload' AND c.class_code='' AND EXISTS
        (SELECT 1 FROM platform_uploaded_reference_cases u WHERE u.id=c.id AND u.created_by=?)))`,
    values: [teacher.id, teacher.id],
  };
}

function sharedReferenceDenied() {
  return json({ error: "Cần đăng nhập giáo viên hoặc quản trị viên để quản lý kho chung." }, 403);
}

async function readReferenceCases(request, env, url) {
  const shared = url.searchParams.get("scope") === "all";
  const classCode = normalizeCode(url.searchParams.get("classCode"));
  const lessonId = url.searchParams.get("lessonId");
  if ((!shared && !CLASS_CODE.test(classCode)) || !getLesson(lessonId)) return json({ error: "Mã lớp hoặc bài học không hợp lệ." }, 400);
  let access = { predicate: "c.class_code=?", values: [classCode] };
  if (shared) {
    access = await sharedReferenceAccess(request, env);
    if (!access) return sharedReferenceDenied();
  } else {
    const denied = await requireTeacher(request, env, classCode);
    if (denied) return denied;
  }
  const { results } = await env.DB.prepare(`WITH lesson_cases AS (
    SELECT c.id,c.status,c.source,c.photo_index AS photoIndex,c.reviewed_at AS reviewedAt,c.created_at,
      c.criterion_id AS criterionId,c.label,c.error_type AS errorType,c.evidence,c.annotations_json AS annotationsJson,
      (${access.predicate}) AS canManage
    FROM platform_reference_case_catalog c WHERE c.lesson_id=?
  )
  SELECT id,status,source,photoIndex,reviewedAt,criterionId,label,errorType,
    CASE WHEN canManage THEN evidence ELSE NULL END AS evidence,annotationsJson,canManage
    FROM lesson_cases WHERE canManage${shared ? " OR status='approved'" : ""}
    ORDER BY (status='approved') DESC,created_at DESC,id DESC`).bind(...access.values, lessonId).all();
  return json({ cases: results.map(({ annotationsJson, canManage, ...row }) => ({
    ...row, canManage: Boolean(canManage), annotations: JSON.parse(annotationsJson),
  })) });
}

async function reviewReferenceCase(request, env, url) {
  if (request.headers.get("origin") !== url.origin) return json({ error: "Nguồn yêu cầu không hợp lệ." }, 403);
  const { scope, classCode: inputCode, id, status } = await parseBody(request).catch(() => null) || {};
  const shared = scope === "all";
  const classCode = normalizeCode(inputCode);
  if ((!shared && !CLASS_CODE.test(classCode)) || !validText(id, 80) || !["approved", "rejected", "retired"].includes(status)) {
    return json({ error: "Mã lớp, ví dụ hoặc trạng thái không hợp lệ." }, 400);
  }
  const access = shared
    ? await sharedReferenceAccess(request, env)
    : { actor: await platformTeacher(request, env, classCode), predicate: "c.class_code=?", values: [classCode] };
  if (!access?.actor) return shared ? sharedReferenceDenied() : json({ error: "Chỉ giáo viên được phân công mới được duyệt ảnh của lớp." }, 403);
  const example = await env.DB.prepare(`SELECT c.source FROM platform_reference_case_catalog c WHERE c.id=? AND ${access.predicate}`)
    .bind(id, ...access.values).first();
  if (!example) return json({ error: "Không tìm thấy ảnh tham chiếu bạn có quyền quản lý." }, 404);
  const table = example.source === "upload" ? "platform_uploaded_reference_cases" : "platform_reference_examples";
  const previousStatus = status === "retired" ? "approved" : "pending";
  const reviewedAt = new Date().toISOString();
  const write = await env.DB.prepare(`UPDATE ${table} SET status=?,reviewed_by=?,reviewed_at=?
    WHERE id=? AND status=? AND EXISTS (SELECT 1 FROM platform_reference_case_catalog c WHERE c.id=? AND ${access.predicate})`)
    .bind(status, access.actor.id, reviewedAt, id, previousStatus, id, ...access.values).run();
  if (!write.meta.changes) return json({ error: "Ảnh đã đổi trạng thái. Hãy làm mới danh sách." }, 409);
  return json({ saved: true, reviewedAt });
}

async function readPublicReferenceCases(env, url) {
  const lessonId = url.searchParams.get("lessonId");
  if (!getLesson(lessonId)) return json({ error: "Bài học không hợp lệ." }, 400);
  const { results } = await env.DB.prepare(`SELECT id,criterion_id AS criterionId,label,error_type AS errorType,annotations_json AS annotationsJson
    FROM platform_reference_case_catalog WHERE lesson_id=? AND status='approved'
    ORDER BY reviewed_at DESC,id`).bind(lessonId).all();
  return json({ cases: results.map(({ annotationsJson, ...row }) => ({ ...row, annotations: JSON.parse(annotationsJson) })) });
}

async function referencePhotoResponse(env, id) {
  const object = id && await env.BUCKET.get("reviewed-examples/" + id);
  const contentType = object?.httpMetadata?.contentType;
  if (!IMAGE_TYPES.has(contentType)) return json({ error: "Không tìm thấy ảnh." }, 404);
  return new Response(object.body, { headers: {
    "content-type": contentType,
    "cache-control": "no-store",
    "x-content-type-options": "nosniff",
  } });
}

async function learningReport(request, env, url, role) {
  const teacher = role === "teacher" ? await platformTeacher(request, env) : null;
  if (role === "teacher" && !teacher) return json({ error: "Cần đăng nhập giáo viên để xem báo cáo lớp." }, 403);
  if (role === "admin") {
    const denied = await requireAdmin(request, env);
    if (denied) return denied;
  }
  const classCode = normalizeCode(url.searchParams.get("classCode"));
  const lessonId = url.searchParams.get("lessonId") || "";
  const attemptOffset = Number(url.searchParams.get("attemptOffset") || 0);
  const photoOffset = Number(url.searchParams.get("photoOffset") || 0);
  if ((classCode && !CLASS_CODE.test(classCode)) || (lessonId && !getLesson(lessonId)) ||
      ![attemptOffset, photoOffset].every(offset => Number.isSafeInteger(offset) && offset >= 0)) {
    return json({ error: "Bộ lọc lớp, bài học hoặc trang không hợp lệ." }, 400);
  }
  const teacherId = teacher?.id || null;
  if (teacherId && classCode && !(await teacherClassCodes(env, teacherId)).includes(classCode)) {
    return json({ error: "Lớp này chưa được phân công cho bạn." }, 403);
  }
  const lessonField = "json_extract(a.payload_json,'$.lessonId')";
  const groupField = "COALESCE(a.local_owner_hash,lower(trim(a.student_name)))";
  const assignedTo = column => `(? IS NULL OR EXISTS (SELECT 1 FROM platform_class_members m
    WHERE m.user_id=? AND m.membership='teacher' AND m.class_code=${column}))`;
  const classFilters = [teacherId, teacherId, classCode, classCode];
  const filters = [...classFilters, lessonId, lessonId];
  const classWhere = column => `${assignedTo(column)} AND (?='' OR ${column}=?)`;
  const attemptsWhere = `${classWhere("a.class_code")} AND (?='' OR ${lessonField}=?)`;
  const isReal = "COALESCE(json_extract(a.payload_json,'$.demo'),0)=0";
  const wasAnalysed = `(${isReal} AND COALESCE(json_extract(a.payload_json,'$.analysisStatus'),'ok')<>'submitted')`;
  const gallery = `SELECT id,class_code,lesson_id,criterion_id AS criterionId,label,status,
      NULL AS title,evidence AS caption,annotations_json AS annotationsJson,source,created_at
    FROM platform_reference_case_catalog
    UNION ALL SELECT id,class_code,lesson_id,NULL,'correct',
      CASE WHEN hidden_at IS NULL THEN 'visible' ELSE 'hidden' END,
      title,caption,'[]','sample',created_at FROM platform_lesson_sample_photos`;
  const photosWhere = `${classWhere("g.class_code")} AND (?='' OR g.lesson_id=?)`;
  const attemptLimit = 30;
  const photoLimit = 24;
  const [classes, reports, attempts, labels, groupSkills, aiErrors, roster, activity, sampleCounts, photos, comparisons, progress, classActivity, staff, rechecks] = await Promise.all([
    env.DB.prepare(`SELECT c.code,
        (SELECT group_concat(u.username) FROM platform_class_members m JOIN platform_users u ON u.id=m.user_id
         WHERE m.class_code=c.code AND m.membership='teacher') AS teachers
      FROM platform_classes c WHERE ${assignedTo("c.code")} ORDER BY c.code`).bind(teacherId,teacherId).all(),
    env.DB.prepare(`SELECT ${lessonField} AS lessonId, COUNT(*) AS attempts,
        SUM(CASE WHEN ${isReal} THEN 1 ELSE 0 END) AS realAttempts,
        SUM(CASE WHEN ${wasAnalysed} THEN 1 ELSE 0 END) AS analysed,
        SUM(CASE WHEN ${isReal} AND EXISTS(SELECT 1 FROM json_each(a.payload_json,'$.teacherCriterionLabels') v
          WHERE v.value IN ('correct','incorrect')) THEN 1 ELSE 0 END) AS labelledAttempts,
        SUM(CASE WHEN ${wasAnalysed} AND json_extract(a.payload_json,'$.verdict')='pass' THEN 1 ELSE 0 END) AS aiPass,
        SUM(CASE WHEN ${wasAnalysed} AND json_extract(a.payload_json,'$.teacherVerification')='correct' THEN 1 ELSE 0 END) AS aiCorrect,
        SUM(CASE WHEN ${wasAnalysed} AND json_extract(a.payload_json,'$.teacherVerification')='incorrect' THEN 1 ELSE 0 END) AS aiIncorrect,
        SUM(CASE WHEN ${wasAnalysed} AND json_extract(a.payload_json,'$.teacherVerification')='uncertain' THEN 1 ELSE 0 END) AS aiUncertain
      FROM classroom_attempts a WHERE ${attemptsWhere} GROUP BY ${lessonField}`).bind(...filters).all(),
    env.DB.prepare(`SELECT a.payload_json, ${latestAttemptRechecks}, ROW_NUMBER() OVER (
        PARTITION BY a.class_code, ${groupField}, ${lessonField}
        ORDER BY a.created_at,a.id) AS attemptNumber
      FROM classroom_attempts a WHERE ${attemptsWhere}
      ORDER BY a.created_at DESC,a.id DESC LIMIT ? OFFSET ?`).bind(...filters, attemptLimit, attemptOffset).all(),
    env.DB.prepare(`SELECT ${lessonField} AS lessonId,l.key AS criterionId,
        SUM(l.value='correct') AS correct,SUM(l.value='incorrect') AS incorrect,SUM(l.value='uncertain') AS uncertain
      FROM classroom_attempts a, json_each(a.payload_json,'$.teacherCriterionLabels') l
      WHERE ${attemptsWhere} AND ${isReal} AND l.value IN ('correct','incorrect','uncertain')
      GROUP BY ${lessonField},l.key`).bind(...filters).all(),
    env.DB.prepare(`SELECT a.class_code AS classCode,MAX(a.student_name) AS name,${lessonField} AS lessonId,
        COUNT(DISTINCT CASE WHEN l.value IN ('correct','incorrect') THEN a.id END) AS labelledAttempts,
        SUM(l.value='correct') AS correct,SUM(l.value='incorrect') AS incorrect,SUM(l.value='uncertain') AS uncertain
      FROM classroom_attempts a, json_each(a.payload_json,'$.teacherCriterionLabels') l
      WHERE ${attemptsWhere} AND ${isReal} AND l.value IN ('correct','incorrect','uncertain')
      GROUP BY a.class_code,${groupField},${lessonField} ORDER BY a.class_code,name,lessonId`).bind(...filters).all(),
    env.DB.prepare(`SELECT ${lessonField} AS lessonId,
        json_extract(a.payload_json,'$.teacherAiError.criterionId') AS criterionId,
        json_extract(a.payload_json,'$.teacherAiError.reason') AS reason,COUNT(*) AS count
      FROM classroom_attempts a WHERE ${attemptsWhere} AND COALESCE(json_extract(a.payload_json,'$.demo'),0)=0
      AND json_extract(a.payload_json,'$.teacherVerification')='incorrect'
      AND json_type(a.payload_json,'$.teacherAiError')='object'
      GROUP BY lessonId,criterionId,reason ORDER BY count DESC,lessonId,criterionId`).bind(...filters).all(),
    env.DB.prepare(`SELECT class_code AS classCode, group_key AS groupKey, display_name AS name,last_seen_at AS lastSeenAt
      FROM platform_student_groups sg WHERE ${classWhere("sg.class_code")}`).bind(...classFilters).all(),
    env.DB.prepare(`SELECT class_code AS classCode,student_name AS name,MAX(a.created_at) AS lastSeenAt,
        SUM(CASE WHEN ?='' OR ${lessonField}=? THEN 1 ELSE 0 END) AS attempts
      FROM classroom_attempts a WHERE ${classWhere("a.class_code")}
      GROUP BY class_code,student_name`).bind(lessonId,lessonId,...classFilters).all(),
    env.DB.prepare(`SELECT lesson_id AS lessonId,label,status,COUNT(*) AS count FROM (${gallery}) g
      WHERE ${photosWhere} GROUP BY lesson_id,label,status`).bind(...filters).all(),
    env.DB.prepare(`SELECT id,class_code AS classCode,lesson_id AS lessonId,criterionId,label,status,title,caption,annotationsJson,source
      FROM (${gallery}) g WHERE ${photosWhere} ORDER BY created_at DESC,id LIMIT ? OFFSET ?`).bind(...filters,photoLimit,photoOffset).all(),
    readAiComparisonRows(env, classCode || null, lessonId, 0, true, teacherId),
    env.DB.prepare(`WITH evaluated AS (
        SELECT a.id,a.class_code,${groupField} AS groupId,${lessonField} AS lessonId,
          json_extract(a.payload_json,'$.teacherCriterionLabels') AS labels,a.created_at
        FROM classroom_attempts a WHERE ${attemptsWhere} AND ${isReal} AND EXISTS(
          SELECT 1 FROM json_each(a.payload_json,'$.teacherCriterionLabels') v WHERE v.value IN ('correct','incorrect'))
      ), ranked AS (
        SELECT *,ROW_NUMBER() OVER (PARTITION BY class_code,groupId,lessonId ORDER BY created_at,id) AS firstRank,
          ROW_NUMBER() OVER (PARTITION BY class_code,groupId,lessonId ORDER BY created_at DESC,id DESC) AS lastRank
        FROM evaluated
      )
      SELECT f.lessonId,COUNT(DISTINCT json_array(f.class_code,f.groupId)) AS groups,COUNT(*) AS paired,
        SUM(firstLabel.value='correct') AS firstCorrect,SUM(lastLabel.value='correct') AS lastCorrect,
        SUM(firstLabel.value='incorrect' AND lastLabel.value='correct') AS improved
      FROM ranked f JOIN ranked l ON l.class_code=f.class_code AND l.groupId=f.groupId AND l.lessonId=f.lessonId
        AND l.lastRank=1 AND l.id<>f.id
      JOIN json_each(f.labels) firstLabel JOIN json_each(l.labels) lastLabel ON firstLabel.key=lastLabel.key
      WHERE f.firstRank=1 AND firstLabel.value IN ('correct','incorrect') AND lastLabel.value IN ('correct','incorrect')
      GROUP BY f.lessonId`).bind(...filters).all(),
    env.DB.prepare(`SELECT a.class_code AS classCode,COUNT(*) AS attempts,
        SUM(CASE WHEN ${wasAnalysed} THEN 1 ELSE 0 END) AS analysed,
        SUM(COALESCE(json_extract(a.payload_json,'$.imageCount'),0)) AS images,MAX(a.created_at) AS lastAttemptAt
      FROM classroom_attempts a WHERE ${attemptsWhere} GROUP BY a.class_code`).bind(...filters).all(),
    role === "admin" ? env.DB.prepare(`SELECT r.role,COUNT(*) AS total,
        SUM(CASE WHEN u.disabled=0 THEN 1 ELSE 0 END) AS active
      FROM platform_users u JOIN platform_roles r ON r.user_id=u.id
      WHERE r.role IN ('teacher','admin') GROUP BY r.role`).all() : Promise.resolve({ results:[] }),
    env.DB.prepare(`SELECT ${lessonField} AS lessonId, r.criterion_id AS criterionId, COUNT(*) AS total,
        SUM(json_extract(r.check_json,'$.status') = 'correct') AS correct
      FROM platform_criterion_rechecks r JOIN classroom_attempts a ON a.id=r.attempt_id
      WHERE ${attemptsWhere} AND ${isReal} AND ${newestRecheckPredicate}
      GROUP BY ${lessonField}, r.criterion_id`).bind(...filters).all(),
  ]);
  const rosterKey = (code, group) => JSON.stringify([code, group]);
  const groups = new Map(roster.results.map(row => [rosterKey(row.classCode,row.groupKey), { ...row, attempts: 0 }]));
  for (const row of activity.results) {
    const key = rosterKey(row.classCode,normalizeStudentGroup(row.name));
    const group = groups.get(key);
    if (group) {
      group.attempts += row.attempts;
      if (row.lastSeenAt > group.lastSeenAt) group.lastSeenAt = row.lastSeenAt;
    } else groups.set(key, row);
  }
  return json({
    classes: classes.results,
    lessons: reports.results,
    labels: labels.results,
    groupSkills: groupSkills.results,
    aiErrors: aiErrors.results,
    groups: [...groups.values()].sort((a,b) => a.classCode.localeCompare(b.classCode) || a.name.localeCompare(b.name,"vi")),
    attempts: attempts.results.map(row => ({ ...attemptFromReportRow(row),attemptNumber:row.attemptNumber })),
    recheckedCriteria: rechecks.results,
    attemptLimit,
    photoLimit,
    sampleCounts: sampleCounts.results,
    photos: photos.results.map(({ annotationsJson, ...row }) => ({ ...row, annotations: JSON.parse(annotationsJson) })),
    comparisons: groupAiComparisonRows(comparisons, "lesson"),
    progress: progress.results,
    classActivity: classActivity.results,
    staff: staff.results,
  });
}

const openAIEndpoints = new Set(["/api/health", "/api/analyze", "/api/analyze/compare", "/api/guide-chat", "/api/tutor"]);
const openAIKeyPattern = /^sk-[A-Za-z0-9_-]{8,509}$/;
const browserOpenAIKeyCookie = "__Secure-cc_openai";

function browserOpenAISettingsEnabled(env, url) {
  return hostedClassroomEnabled(env) && url.protocol === "https:"
    && typeof env.CLASSROOM_SESSION_SECRET === "string" && env.CLASSROOM_SESSION_SECRET.length >= 32;
}

async function browserOpenAIEncryptionKey(env, url) {
  const seed = new TextEncoder().encode(JSON.stringify(["circuitcoach/openai-settings/v1", url.origin, env.CLASSROOM_SESSION_SECRET]));
  const bytes = await crypto.subtle.digest("SHA-256", seed);
  return crypto.subtle.importKey("raw", bytes, "AES-GCM", false, ["encrypt", "decrypt"]);
}

async function sealBrowserOpenAIKey(apiKey, env, url) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, await browserOpenAIEncryptionKey(env, url),
    new TextEncoder().encode(apiKey));
  return `v1.${base64UrlBytes(iv)}.${base64UrlBytes(new Uint8Array(ciphertext))}`;
}

async function readBrowserOpenAIKey(request, env, url) {
  const cookie = request.headers.get("cookie")?.match(/(?:^|;\s*)__Secure-cc_openai=v1\.([\w-]{16})\.([\w-]{36,704})(?:;|$)/);
  if (!cookie) return "";
  try {
    const decoded = await crypto.subtle.decrypt({ name: "AES-GCM", iv: base64UrlDecode(cookie[1]) },
      await browserOpenAIEncryptionKey(env, url), base64UrlDecode(cookie[2]));
    const apiKey = new TextDecoder().decode(decoded);
    return openAIKeyPattern.test(apiKey) ? apiKey : "";
  } catch {
    return "";
  }
}

function setBrowserOpenAIKeyCookie(response, value) {
  response.headers.append("Set-Cookie",
    `${browserOpenAIKeyCookie}=${value}; Path=/api; HttpOnly; Secure; SameSite=Strict${value ? "" : "; Max-Age=0"}`);
}

async function handleOpenAISettings(request, env, url) {
  const localSettings = env.LOCAL_OPENAI_SETTINGS;
  if (!localSettings && !browserOpenAISettingsEnabled(env, url)) return json({ error: "Chưa có cấu hình OpenAI cho bản này." }, 404);
  if (request.method !== "GET" && request.method !== "PUT") return json({ error: "Phương thức không được hỗ trợ." }, 405);

  let apiKey;
  if (request.method === "PUT") {
    if (request.headers.get("origin") !== url.origin) return json({ error: "Nguồn yêu cầu không hợp lệ." }, 403);
    const body = await parseBody(request).catch(() => null);
    if (typeof body?.apiKey !== "string") return json({ error: "Dữ liệu khóa OpenAI không hợp lệ." }, 400);
    apiKey = body.apiKey.trim();
    if (apiKey && !openAIKeyPattern.test(apiKey)) {
      return json({ error: "Hãy nhập khóa API OpenAI bắt đầu bằng sk-." }, 400);
    }
  }

  try {
    if (localSettings) {
      if (apiKey !== undefined) await localSettings.write(apiKey);
      const { overrideKey, defaultKey } = await localSettings.read();
      return json({ keySource: openAIKeySource(overrideKey, defaultKey) });
    }
    const overrideKey = apiKey ?? await readBrowserOpenAIKey(request, env, url);
    const response = json({ keySource: openAIKeySource(overrideKey, env.OPENAI_API_KEY) });
    if (apiKey !== undefined) {
      setBrowserOpenAIKeyCookie(response, apiKey ? await sealBrowserOpenAIKey(apiKey, env, url) : "");
    }
    return response;
  } catch {
    return json({ error: "Không thể truy cập cấu hình OpenAI. Hãy thử lại." }, 500);
  }
}

function openAIKeySource(overrideKey, defaultKey) {
  return overrideKey ? "custom" : defaultKey ? "default" : "unconfigured";
}

async function handleApi(request, env, url) {
  if (url.pathname === "/api/settings/openai") return handleOpenAISettings(request, env, url);
  const recheckMatch = url.pathname.match(/^\/api\/classroom\/attempts\/([^/]+)\/rechecks(?:\/([a-f0-9-]{36})\/image)?$/);
  if (openAIEndpoints.has(url.pathname) || (recheckMatch && request.method === "POST")) {
    if (env.LOCAL_OPENAI_SETTINGS) {
      const { overrideKey, defaultKey } = await env.LOCAL_OPENAI_SETTINGS.read();
      env = { ...env, OPENAI_API_KEY: overrideKey || defaultKey };
    } else if (browserOpenAISettingsEnabled(env, url)) {
      const overrideKey = await readBrowserOpenAIKey(request, env, url);
      if (overrideKey) env = { ...env, OPENAI_API_KEY: overrideKey };
    }
  }
  if (url.pathname === "/api/health") return json({
    status: "ok",
    openaiConfigured: Boolean(env.OPENAI_API_KEY),
    demoMode: false,
    classroomSync: true,
    analyzeModel: analysisModelChoices(env)[0],
    analysisModels: analysisModelChoices(env),
    tutorModel: env.OPENAI_TUTOR_MODEL || "gpt-5.6-luna",
  });
  if (url.pathname === "/api/analyze" && request.method === "POST") return handleAnalyze(request, env);
  if (recheckMatch && personalAccountsEnabled(env)) return handleCriterionRechecks(request, env, url, recheckMatch);
  const recheckCommentMatch = url.pathname.match(/^\/api\/classroom\/attempts\/([^/]+)\/rechecks\/([a-f0-9-]{36})\/comment$/);
  if (recheckCommentMatch && personalAccountsEnabled(env)) return saveRecheckComment(request, env, url, recheckCommentMatch);
  const recheckReviewMatch = url.pathname.match(/^\/api\/classroom\/attempts\/([^/]+)\/rechecks\/([a-f0-9-]{36})\/(review|reference)$/);
  if (recheckReviewMatch && personalAccountsEnabled(env)) return handleRecheckReview(request, env, url, recheckReviewMatch);
  if (url.pathname === "/api/guide-chat" && request.method === "POST") return handleGuideChat(request, env, url);
  if (url.pathname === "/api/guide-chat/history" && request.method === "POST") return handleStudentGuide(request, env, url);
  if (personalAccountsEnabled(env) && url.pathname === "/api/analyze/compare" && request.method === "POST") return handleCompareAnalyze(request, env);
  if (personalAccountsEnabled(env) && url.pathname === "/api/classroom/lesson-ai-reminders" && request.method === "POST") {
    return handleLessonAiReminders(request, env, url);
  }
  if (personalAccountsEnabled(env) && url.pathname === "/api/classroom/ai-tracking" && request.method === "GET") {
    return handleAiTracking(request, env, url);
  }
  if (personalAccountsEnabled(env) && url.pathname === "/api/ai-progress" && request.method === "GET") {
    return handlePublicAiProgress(env, url);
  }
  if (personalAccountsEnabled(env) && request.method === "GET") {
    if (url.pathname === "/api/reference-cases") return readPublicReferenceCases(env, url);
    const publicPhoto = url.pathname.match(/^\/api\/reference-cases\/photo\/([a-f0-9-]{36})$/);
    if (publicPhoto) {
      const row = await env.DB.prepare("SELECT id FROM platform_reference_case_catalog WHERE id=? AND status='approved'")
        .bind(publicPhoto[1]).first();
      return referencePhotoResponse(env, row?.id);
    }
  }
  const lessonSample = personalAccountsEnabled(env) && url.pathname.match(/^\/api\/classroom\/lesson-samples\/([a-z0-9-]+)(?:\/([a-f0-9-]{36}))?$/);
  if (lessonSample) return handleLessonSamples(request, env, url, lessonSample[1], lessonSample[2]);
  const trackedPhoto = personalAccountsEnabled(env) && url.pathname.match(/^\/api\/classroom\/ai-tracking\/photo\/([\w-]+)$/);
  if (trackedPhoto && request.method === "GET") {
    if (url.searchParams.get("scope") === "all") {
      const access = await sharedReferenceAccess(request, env);
      if (!access) return sharedReferenceDenied();
      const example = await env.DB.prepare(`SELECT c.id FROM platform_reference_case_catalog c
        WHERE c.id=? AND (c.status='approved' OR ${access.predicate})`).bind(trackedPhoto[1], ...access.values).first();
      return referencePhotoResponse(env, example?.id);
    }
    const classCode = normalizeCode(url.searchParams.get("classCode"));
    if (!CLASS_CODE.test(classCode)) return json({ error: "Mã lớp không hợp lệ." }, 400);
    const denied = await requireTeacher(request, env, classCode);
    if (denied && !await platformIdentity(request, env, "admin")) return denied;
    const example = await env.DB.prepare("SELECT id FROM platform_reference_case_catalog WHERE id=? AND (class_code=? OR status='approved')")
      .bind(trackedPhoto[1], classCode).first();
    return referencePhotoResponse(env, example?.id);
  }
  if (personalAccountsEnabled(env) && url.pathname === "/api/classroom/browser-session") {
    if (request.method === "DELETE") return signOutBrowser(request, env, url);
    if (request.method === "GET") {
      const { role, account } = await activeBrowserRole(request, env);
      const classCodes = role === "teacher" ? await teacherClassCodes(env, account.id) : [];
      const response = json({
        role, authenticated: Boolean(role), username: account?.username || "", classCodes,
        expiresAt: account?.expiresAt || null, localOpenAISettings: Boolean(env.LOCAL_OPENAI_SETTINGS),
        browserOpenAISettings: browserOpenAISettingsEnabled(env, url),
      });
      if (account) {
        if (studentToken(request)) expireStudentCookies(response);
        const other = staffCookieName(role === "admin" ? "teacher" : "admin");
        if (staffCookieToken(request, other)) expireBrowserCookie(response, other);
        if (staffCookieToken(request, staffCookieName(role)) && staffCookieToken(request, "cc_teacher")) {
          expireBrowserCookie(response, "cc_teacher");
        }
      }
      return response;
    }
  }
  if (url.pathname === "/api/classroom/student-group" && request.method === "DELETE") {
    if (personalAccountsEnabled(env)) return signOutBrowser(request, env, url);
    if (request.headers.get("origin") !== url.origin) return json({ error: "Nguồn yêu cầu không hợp lệ." }, 403);
    const response = json({ signedOut: true });
    response.headers.append("Set-Cookie", "cc_student=; HttpOnly; SameSite=Strict; Path=/api; Max-Age=0");
    response.headers.append("Set-Cookie", "cc_sample_class=; HttpOnly; SameSite=Strict; Path=/api/classroom/lesson-samples; Max-Age=0");
    return response;
  }
  if (url.pathname === "/api/classroom/student-group" && request.method === "POST") {
    if (!personalAccountsEnabled(env)) return json({ attempts: [] });
    if (request.headers.get("origin") !== url.origin) return json({ error: "Nguồn yêu cầu không hợp lệ." }, 403);
    const blockedRole = await requireNoRoleSwitch(request, env, "student");
    if (blockedRole) return blockedRole;
    if (rateLimit(request)) return json({ error: "Hãy chờ trước khi thử lại." }, 429);
    const { name, classCode } = await parseBody(request).catch(() => ({})) || {};
    const code = normalizeCode(classCode);
    const group = normalizeStudentGroup(name);
    if (!CLASS_CODE.test(code) || group.length < 2 || group.length > 40) return json({ error: "Tên nhóm hoặc mã lớp không hợp lệ." }, 400);
    if (!await registeredClass(env, code)) return json({ error: "Không tìm thấy mã lớp. Hãy kiểm tra mã giáo viên đã cung cấp." }, 404);
    const key = await studentSessionKey(env);
    const token = base64UrlBytes(new Uint8Array(await crypto.subtle.sign("HMAC", key, studentGroupProof(code, group))));
    const owner = await platformDigest(token);
    const { results } = await env.DB.prepare(`SELECT a.id,a.student_name,a.payload_json,a.local_owner_hash,${latestAttemptRechecks}
      FROM classroom_attempts a WHERE a.class_code=? ORDER BY a.created_at DESC`).bind(code).all();
    const matches = results.filter(row => normalizeStudentGroup(row.student_name) === group);
    const olderSessions = matches.filter(row => row.local_owner_hash !== owner);
    const seenAt = new Date().toISOString();
    const rosterWrite = env.DB.prepare(`INSERT INTO platform_student_groups
      (class_code,group_key,display_name,first_seen_at,last_seen_at) VALUES (?,?,?,?,?)
      ON CONFLICT(class_code,group_key) DO UPDATE SET display_name=excluded.display_name,last_seen_at=excluded.last_seen_at`)
      .bind(code, group, name.trim(), seenAt, seenAt);
    await env.DB.batch([rosterWrite, ...olderSessions.map(row =>
      env.DB.prepare("UPDATE classroom_attempts SET local_owner_hash=? WHERE id=? AND class_code=?").bind(owner,row.id,code))]);
    const attempts = matches.map(attemptFromReportRow);
    const studentId = attempts[0]?.studentId || "group-" + await platformDigest(JSON.stringify(["group-id", token]));
    const response = json({ attempts, studentId });
    const proof = base64UrlBytes(new Uint8Array(await crypto.subtle.sign("HMAC", key, lessonSampleClassProof(token, code))));
    const secure = secureClassroomCookie(url);
    response.headers.append("Set-Cookie", `cc_student=${token}; HttpOnly; SameSite=Strict; Path=/api; Max-Age=31536000${secure}`);
    response.headers.append("Set-Cookie", `cc_sample_class=${proof}; HttpOnly; SameSite=Strict; Path=/api/classroom/lesson-samples; Max-Age=31536000${secure}`);
    return response;
  }
  if (personalAccountsEnabled(env) && url.pathname === "/api/classroom/teacher/classes" && request.method === "POST") {
    return createTeacherClass(request, env, url);
  }
  if (personalAccountsEnabled(env) && url.pathname === "/api/classroom/admin/password" && request.method === "POST") {
    return changeAdminPassword(request, env, url);
  }
  if (personalAccountsEnabled(env) && url.pathname === "/api/classroom/admin/accounts") {
    const denied = await requireAdmin(request,env);
    if (denied) return denied;
    if (request.method === "GET") {
      const { results } = await env.DB.prepare(`SELECT u.id,u.username,u.disabled,group_concat(r.role) AS roles,
        (SELECT group_concat(class_code) FROM platform_class_members WHERE user_id=u.id AND membership='teacher') AS classCodes
        FROM platform_users u JOIN platform_roles r ON r.user_id=u.id
        WHERE r.role IN ('admin','teacher') GROUP BY u.id ORDER BY u.username`).all();
      return json({ accounts: env.LOCAL_FILE_STAFF_IDS
        ? results.map(account => ({ ...account, configuredByFile: env.LOCAL_FILE_STAFF_IDS.has(account.id) }))
        : results });
    }
    if (request.method === "POST") {
      if (request.headers.get("origin") !== url.origin) return json({ error: "Nguồn yêu cầu không hợp lệ." },403);
      const { username, password, role } = await parseBody(request).catch(() => ({})) || {};
      if (typeof username !== "string" || !/^[\w.-]{3,40}$/.test(username) || typeof password !== "string" || password.length < 12 || password.length > 128 || !["admin","teacher"].includes(role)) {
        return json({ error: "Kiểm tra tên tài khoản, mật khẩu và vai trò." }, 400);
      }
      if (await env.DB.prepare("SELECT id FROM platform_users WHERE username=?").bind(username).first()) return json({ error: "Tên tài khoản đã tồn tại." },409);
      const id = crypto.randomUUID();
      const hash = await hashStaffPassword(password, env);
      const writes = [
        env.DB.prepare("INSERT INTO platform_users (id,username,password_hash,created_at) VALUES (?,?,?,?)").bind(id,username,hash,new Date().toISOString()),
        env.DB.prepare("INSERT INTO platform_roles VALUES (?,?)").bind(id,role),
      ];
      try {
        await env.DB.batch(writes);
      } catch (error) {
        if (await env.DB.prepare("SELECT id FROM platform_users WHERE username=?").bind(username).first()) return json({ error: "Tên tài khoản đã tồn tại." },409);
        throw error;
      }
      return json({ created: true },201);
    }
    if (request.method === "PATCH") {
      if (request.headers.get("origin") !== url.origin) return json({ error: "Nguồn yêu cầu không hợp lệ." }, 403);
      const { id, password } = await parseBody(request).catch(() => null) || {};
      if (!validText(id, 80) || !validText(password, 128)) {
        return json({ error: "Mật khẩu mới cần từ 12 đến 128 ký tự." }, 400);
      }
      const account = await env.DB.prepare(`SELECT u.id,u.username FROM platform_users u JOIN platform_roles r
        ON r.user_id=u.id AND r.role='teacher' WHERE u.id=? AND u.disabled=0`).bind(id).first();
      if (!account) return json({ error: "Không tìm thấy tài khoản giáo viên đang hoạt động." }, 404);
      if (env.LOCAL_FILE_STAFF_IDS?.has(account.id)) return json({ error: fileManagedPasswordMessage }, 409);
      if (!staffRotationPasswordAccepted(password, account.username, "teacher", env)) {
        return json({ error: "Mật khẩu mới cần từ 12 đến 128 ký tự." }, 400);
      }
      const hash = await hashStaffPassword(password, env);
      await env.DB.batch([
        env.DB.prepare("UPDATE platform_users SET password_hash=? WHERE id=?").bind(hash, id),
        env.DB.prepare("DELETE FROM platform_sessions WHERE user_id=?").bind(id),
      ]);
      return json({ saved: true });
    }
  }
  if (personalAccountsEnabled(env) && url.pathname === "/api/classroom/comparison-report" && request.method === "GET") {
    const classCode = normalizeCode(url.searchParams.get("classCode"));
    const denied = await requireTeacher(request, env, classCode);
    if (denied) return denied;
    const rows = await readAiComparisonRows(env, classCode, "", 0, true);
    return json({ lessons: groupAiComparisonRows(rows, "lesson") });
  }
  if (personalAccountsEnabled(env) && url.pathname === "/api/classroom/reference-submit" && request.method === "POST") {
    return submitReferenceCase(request, env, url);
  }
  if (personalAccountsEnabled(env) && url.pathname === "/api/classroom/reference-upload" && request.method === "POST") {
    return uploadReferenceCase(request, env, url);
  }
  if (personalAccountsEnabled(env) && url.pathname === "/api/classroom/reference-cases" && request.method === "GET") {
    return readReferenceCases(request, env, url);
  }
  if (personalAccountsEnabled(env) && url.pathname === "/api/classroom/reference-decision" && request.method === "POST") {
    return reviewReferenceCase(request, env, url);
  }
  if (url.pathname === "/api/tutor" && request.method === "POST") return handleTutor(request, env, url);
  if (personalAccountsEnabled(env) && url.pathname === "/api/classroom/teacher-session" && request.method === "GET") {
    const teacher = await platformTeacher(request, env);
    if (!teacher) return json({ authenticated: false }, 401);
    return json({ authenticated: true, username: teacher.username, classCodes: await teacherClassCodes(env, teacher.id) });
  }
  const personalLogin = url.pathname.match(/^\/api\/classroom\/(teacher|admin)-login$/);
  if (personalAccountsEnabled(env) && personalLogin && request.method === "POST") {
      if (request.headers.get("origin") !== url.origin) return json({ error: "Nguồn yêu cầu không hợp lệ." }, 403);
      const role = personalLogin[1];
      const blockedRole = await requireNoRoleSwitch(request, env, role);
      if (blockedRole) return blockedRole;
      if (loginRateLimited(request)) return json({ error: "Quá nhiều lần đăng nhập." }, 429);
      const credentials = role === "teacher"
        ? { username: request.headers.get("x-teacher-username"), password: request.headers.get("x-teacher-password") }
        : await parseBody(request).catch(() => ({}));
      const username = typeof credentials?.username === "string" ? credentials.username : "";
      const password = typeof credentials?.password === "string" ? credentials.password : "";
      const invalidLogin = () => json({ error: "Tên đăng nhập hoặc mật khẩu không đúng." }, 401);
      if (!validText(username, 40) || !validText(password, 128)) return invalidLogin();
      let account = await findStaffAccount(env, username, role);
      if (account) {
        if (!await staffPasswordMatches(password, account.password_hash)) return invalidLogin();
      } else {
        account = await provisionHostedStaff(request, env, role, username, password);
        if (!account) return invalidLogin();
      }
      const token = base64UrlBytes(crypto.getRandomValues(new Uint8Array(32)));
      const now = new Date();
      const write = await env.DB.prepare(`INSERT INTO platform_sessions SELECT ?,?,?,?
        WHERE EXISTS (SELECT 1 FROM platform_users WHERE id=? AND password_hash=? AND disabled=0)`)
        .bind(await platformDigest(token), account.id, new Date(+now + 1800000).toISOString(), now.toISOString(), account.id, account.password_hash).run();
      if (!write.meta.changes) return json({ error: "Tài khoản đã thay đổi. Hãy đăng nhập lại." }, 401);
      const classCodes = role === "teacher" ? await teacherClassCodes(env, account.id) : [];
      const response = json({ authenticated: true, personalSession: true, classCodes, username: account.username });
      response.headers.set("Set-Cookie", `${staffCookieName(role)}=${token}; HttpOnly; SameSite=Strict; Path=/api; Max-Age=1800${secureClassroomCookie(url)}`);
      return response;
  }
  if (url.pathname === "/api/classroom/teacher-login" && request.method === "POST") {
    const denied = await requireTeacher(request, env);
    return denied || json({ authenticated: true });
  }
  const personalLogout = url.pathname.match(/^\/api\/classroom\/(teacher|admin)-logout$/);
  if (personalAccountsEnabled(env) && personalLogout && request.method === "POST") {
    return signOutBrowser(request, env, url);
  }
  if (url.pathname === "/api/classroom/admin-login" && request.method === "POST") {
    if (loginRateLimited(request)) return json({ error: "Quá nhiều lần đăng nhập. Hãy thử lại sau 15 phút." }, 429);
    if (!adminConfigured(env)) return json({ error: "Tài khoản quản trị chưa được cấu hình đầy đủ." }, 503);
    try {
      const credentials = await parseBody(request);
      if (!await adminCredentialsMatch(credentials.username, credentials.password, env)) return json({ error: "Tên đăng nhập hoặc mật khẩu quản trị không đúng." }, 401);
      const token = await createAdminToken(env);
      const secure = url.protocol === "https:" ? "; Secure" : "";
      return new Response(JSON.stringify({ authenticated: true, role: "admin", expiresIn: 1800 }), {
        headers: {
          "content-type": "application/json; charset=utf-8",
          "cache-control": "no-store",
          "set-cookie": `circuitcoach_admin=${token}; HttpOnly; Path=/; SameSite=Strict; Max-Age=1800${secure}`,
        },
      });
    } catch { return json({ error: "Thông tin đăng nhập không hợp lệ." }, 400); }
  }
  if (url.pathname === "/api/classroom/admin-logout" && request.method === "POST") {
    const secure = url.protocol === "https:" ? "; Secure" : "";
    return new Response(JSON.stringify({ authenticated: false }), {
      headers: {
        "content-type": "application/json; charset=utf-8",
        "cache-control": "no-store",
        "set-cookie": `circuitcoach_admin=; HttpOnly; Path=/; SameSite=Strict; Max-Age=0${secure}`,
      },
    });
  }
  if (personalAccountsEnabled(env) && url.pathname === "/api/classroom/admin/learning" && request.method === "GET") {
    return learningReport(request, env, url, "admin");
  }
  if (personalAccountsEnabled(env) && url.pathname === "/api/classroom/teacher/learning" && request.method === "GET") {
    return learningReport(request, env, url, "teacher");
  }
  if (url.pathname === "/api/classroom/admin/summary" && request.method === "GET") {
    const denied = await requireAdmin(request, env);
    if (denied) return denied;
    if (!env.DB) return json({ error: "Kho dữ liệu lớp học chưa sẵn sàng." }, 503);
    const classesQuery = personalAccountsEnabled(env)
      ? `SELECT c.code AS classCode, COUNT(a.id) AS attemptCount, COUNT(DISTINCT a.student_id) AS groupCount,
        MAX(a.created_at) AS latestActivity FROM platform_classes c LEFT JOIN classroom_attempts a ON a.class_code=c.code
        GROUP BY c.code ORDER BY latestActivity DESC,c.code`
      : "SELECT class_code AS classCode, COUNT(*) AS attemptCount, COUNT(DISTINCT student_id) AS groupCount, MAX(created_at) AS latestActivity FROM classroom_attempts GROUP BY class_code ORDER BY latestActivity DESC";
    const [statsResult, classesResult, recentResult] = await Promise.all([
      env.DB.prepare("SELECT COUNT(*) AS attemptCount, COUNT(DISTINCT class_code) AS classCount, COUNT(DISTINCT class_code || ':' || student_id) AS groupCount, SUM(CASE WHEN json_extract(payload_json, '$.teacherVerification') = 'correct' THEN 1 ELSE 0 END) AS teacherConfirmedCorrect, SUM(CASE WHEN json_extract(payload_json, '$.teacherVerification') = 'incorrect' THEN 1 ELSE 0 END) AS teacherConfirmedIncorrect, SUM(CASE WHEN json_extract(payload_json, '$.teacherVerification') IS NULL THEN 1 ELSE 0 END) AS awaitingTeacher FROM classroom_attempts").first(),
      env.DB.prepare(classesQuery).all(),
      env.DB.prepare("SELECT payload_json FROM classroom_attempts ORDER BY created_at DESC LIMIT 1000").all(),
    ]);
    const attempts = (recentResult.results || []).map((row) => { try { return JSON.parse(row.payload_json); } catch { return null; } }).filter(Boolean);
    const stats = statsResult || {};
    return json({
      stats: {
        classCount: (classesResult.results || []).length,
        groupCount: Number(stats.groupCount) || 0,
        attemptCount: Number(stats.attemptCount) || 0,
        teacherConfirmedCorrect: Number(stats.teacherConfirmedCorrect) || 0,
        teacherConfirmedIncorrect: Number(stats.teacherConfirmedIncorrect) || 0,
        awaitingTeacher: Number(stats.awaitingTeacher) || 0,
      },
      classes: classesResult.results || [],
      attempts,
      truncated: Number(stats.attemptCount) > attempts.length,
    });
  }
  if (!env.DB) return json({ error: "Kho dữ liệu lớp học chưa sẵn sàng." }, 503);

  if (url.pathname === "/api/classroom/references" && request.method === "GET") {
    const classCode = normalizeCode(url.searchParams.get("classCode"));
    if (personalAccountsEnabled(env) && !await platformTeacher(request, env, classCode) && !await platformIdentity(request, env, "admin")) return json({ error: "Kho ảnh lớp cần quyền giáo viên." }, 403);
    if (!CLASS_CODE.test(classCode)) return json({ error: "Mã lớp không hợp lệ." }, 400);
    const lessonId = String(url.searchParams.get("lessonId") || "").trim();
    const result = await env.DB.prepare("SELECT payload_json FROM classroom_attempts WHERE class_code = ? ORDER BY created_at DESC LIMIT 500").bind(classCode).all();
    const references = (result.results || [])
      .map((row) => { try { return JSON.parse(row.payload_json); } catch { return null; } })
      .filter(Boolean)
      .filter((attempt) => attempt.classCode === classCode && attempt.verdict === "pass" && attempt.teacherVerification === "correct" && attempt.teacherSafetyCheck === "safe_to_power" && attempt.teacherPhysicallyChecked === true && Number(attempt.imageCount) > 0 && (!lessonId || attempt.lessonId === lessonId))
      .sort((a, b) => new Date(b.teacherVerifiedAt || b.time) - new Date(a.teacherVerifiedAt || a.time))
      .slice(0, 100)
      .map((attempt) => ({ id: attempt.id, attemptId: attempt.id, lessonId: attempt.lessonId, title: "Mạch đúng đã được giáo viên xác nhận", imageCount: Math.min(3, Number(attempt.imageCount) || 0), approvedBy: attempt.teacherVerifiedBy || "Giáo viên", approvedAt: attempt.teacherVerifiedAt || null, note: attempt.teacherVerificationNote || "" }));
    return json({ references });
  }

  if (url.pathname === "/api/classroom/attempts" && request.method === "GET") {
    const denied = await requireTeacher(request, env, normalizeCode(url.searchParams.get("classCode")));
    if (denied) return denied;
    const classCode = normalizeCode(url.searchParams.get("classCode"));
    if (!CLASS_CODE.test(classCode)) return json({ error: "Mã lớp không hợp lệ." }, 400);
    const columns = personalAccountsEnabled(env) ? `a.payload_json, ${latestAttemptRechecks}` : "a.payload_json";
    const result = await env.DB.prepare(`SELECT ${columns} FROM classroom_attempts a WHERE a.class_code = ? ORDER BY a.created_at DESC LIMIT 500`).bind(classCode).all();
    const attempts = (result.results || []).map((row) => { try { return attemptFromReportRow(row); } catch { return null; } }).filter(Boolean);
    return json({ attempts });
  }

  if (url.pathname === "/api/classroom/attempts" && request.method === "POST") {
    try {
      const attempt = sanitizeAttempt(await parseBody(request), env);
      if (personalAccountsEnabled(env)) {
        if (request.headers.get("origin") !== url.origin) return json({ error: "Nguồn yêu cầu không hợp lệ." }, 403);
        const token = studentToken(request);
        const group = normalizeStudentGroup(attempt.studentName);
        if (!token || !await registeredClass(env, attempt.classCode) || !await crypto.subtle.verify(
          "HMAC", await studentSessionKey(env), base64UrlDecode(token), studentGroupProof(attempt.classCode, group),
        )) return json({ error: "Hãy vào đúng nhóm và lớp trước khi đồng bộ bài làm." }, 403);
        const owner = await platformDigest(token);
        const payload = JSON.stringify({ ...attempt, teacherComment: "", teacherCommentAt: null });
        await env.DB.prepare("INSERT INTO classroom_attempts (id,class_code,student_id,student_name,created_at,payload_json,updated_at,local_owner_hash) VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING")
          .bind(attempt.id, attempt.classCode, attempt.studentId, attempt.studentName, attempt.time, payload, new Date().toISOString(), owner).run();
        const row = await env.DB.prepare("SELECT id FROM classroom_attempts WHERE id=? AND class_code=? AND student_id=? AND local_owner_hash=?")
          .bind(attempt.id, attempt.classCode, attempt.studentId, owner).first();
        if (!row) return json({ error: "Không thể đồng bộ lượt phân tích này." }, 409);
        const response = json({ synced: true, id: attempt.id }, 201);
        response.headers.set("Set-Cookie", `cc_student=${token}; HttpOnly; SameSite=Strict; Path=/api; Max-Age=31536000${secureClassroomCookie(url)}`);
        return response;
      }
      await env.DB.prepare("INSERT INTO classroom_attempts (id, class_code, student_id, student_name, created_at, payload_json, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT(id) DO NOTHING").bind(attempt.id, attempt.classCode, attempt.studentId, attempt.studentName, attempt.time, JSON.stringify(attempt), new Date().toISOString()).run();
      const existing = await env.DB.prepare("SELECT class_code, student_id FROM classroom_attempts WHERE id = ?").bind(attempt.id).first();
      if (!existing || existing.class_code !== attempt.classCode || existing.student_id !== attempt.studentId) return json({ error: "Mã lượt phân tích đã được sử dụng." }, 409);
      return json({ synced: true, id: attempt.id }, 201);
    } catch (error) { return json({ error: error.message || "Dữ liệu không hợp lệ." }, 400); }
  }

  const imageUploadMatch = url.pathname.match(/^\/api\/classroom\/attempts\/([^/]+)\/images$/);
  if (imageUploadMatch && request.method === "POST") {
    try {
      if (!env.BUCKET) return json({ error: "Kho ảnh lớp học chưa sẵn sàng." }, 503);
      const id = decodeURIComponent(imageUploadMatch[1]);
      const form = await request.formData();
      const classCode = normalizeCode(form.get("classCode"));
      if (!CLASS_CODE.test(classCode) || !validText(id, 80)) throw new Error("Yêu cầu không hợp lệ.");
      if (!await canAccessAttempt(request, env, id, classCode, false)) return json({ error: "Không có quyền tải ảnh cho lượt này." }, 403);
      const row = await env.DB.prepare("SELECT payload_json FROM classroom_attempts WHERE id = ? AND class_code = ?").bind(id, classCode).first();
      if (!row) return json({ error: "Không tìm thấy kết quả." }, 404);
      const images = form.getAll("images").filter((value) => value && typeof value.arrayBuffer === "function").slice(0, 3);
      if (!images.length) throw new Error("Chưa có ảnh để tải lên.");
      for (const image of images) {
        if (!["image/jpeg", "image/png", "image/webp"].includes(image.type) || image.size > 3_000_000) throw new Error("Mỗi ảnh phải là JPEG, PNG hoặc WEBP và không quá 3 MB.");
      }
      const safeId = encodeURIComponent(id);
      for (let index = 0; index < images.length; index += 1) {
        const image = images[index];
        await env.BUCKET.put(`${classCode}/${safeId}/${index}`, image.stream(), { httpMetadata: { contentType: image.type }, customMetadata: { classCode, attemptId: id } });
      }
      for (let index = images.length; index < 3; index += 1) await env.BUCKET.delete(`${classCode}/${safeId}/${index}`);
      await env.DB.prepare("UPDATE classroom_attempts SET payload_json = json_set(payload_json, '$.imageCount', ?), updated_at = ? WHERE id = ? AND class_code = ?").bind(images.length, new Date().toISOString(), id, classCode).run();
      return json({ synced: true, imageCount: images.length });
    } catch (error) { return json({ error: error.message || "Không thể lưu ảnh." }, 400); }
  }

  const imageReadMatch = url.pathname.match(/^\/api\/classroom\/attempts\/([^/]+)\/images\/(\d)$/);
  if (imageReadMatch && request.method === "GET") {
    if (!env.BUCKET) return json({ error: "Kho ảnh lớp học chưa sẵn sàng." }, 503);
    const id = decodeURIComponent(imageReadMatch[1]);
    const imageIndex = Number(imageReadMatch[2]);
    const classCode = normalizeCode(url.searchParams.get("classCode"));
    if (!CLASS_CODE.test(classCode) || !validText(id, 80) || imageIndex < 0 || imageIndex > 2) return json({ error: "Yêu cầu không hợp lệ." }, 400);
    if (!await canAccessAttempt(request, env, id, classCode)) return json({ error: "Không có quyền xem ảnh." }, 403);
    const row = await env.DB.prepare("SELECT payload_json FROM classroom_attempts WHERE id = ? AND class_code = ?").bind(id, classCode).first();
    if (!row) return json({ error: "Không tìm thấy kết quả." }, 404);
    const attempt = JSON.parse(row.payload_json);
    if (imageIndex >= Number(attempt.imageCount || 0)) return json({ error: "Không tìm thấy ảnh." }, 404);
    const object = await env.BUCKET.get(`${classCode}/${encodeURIComponent(id)}/${imageIndex}`);
    if (!object) return json({ error: "Không tìm thấy ảnh." }, 404);
    return new Response(object.body, { headers: { "content-type": object.httpMetadata?.contentType || "image/jpeg", "cache-control": "private, no-store", "x-content-type-options": "nosniff" } });
  }

  const verifyMatch = url.pathname.match(/^\/api\/classroom\/attempts\/([^/]+)\/verify$/);
  if (verifyMatch && request.method === "POST") {
    try {
      const id = decodeURIComponent(verifyMatch[1]);
      const body = await parseBody(request);
      const classCode = normalizeCode(body.classCode);
      const denied = await requireTeacher(request, env, classCode);
      if (denied) return denied;
      const teacherName = personalAccountsEnabled(env) ? (await platformTeacher(request, env, classCode))?.username : env.TEACHER_USERNAME;
      const hasAiLabel = Object.hasOwn(body, "teacherVerification");
      const hasAiError = Object.hasOwn(body, "teacherAiError");
      const hasSafetyCheck = Object.hasOwn(body, "teacherSafetyCheck");
      const hasLabels = Object.hasOwn(body, "teacherCriterionLabels") || Object.hasOwn(body, "teacherImageQuality");
      const teacherVerification = body.teacherVerification;
      if (!CLASS_CODE.test(classCode) || !validText(id, 80) || (!hasAiLabel && !hasSafetyCheck && !hasLabels)) throw new Error("Xác nhận của giáo viên không hợp lệ.");
      if (hasAiLabel && !["correct", "incorrect", "uncertain"].includes(teacherVerification)) throw new Error("Nhãn đánh giá AI không hợp lệ.");
      if (hasAiError && teacherVerification !== "incorrect") throw new Error("Chỉ lưu nguyên nhân khi đánh dấu AI sai.");
      const row = await env.DB.prepare("SELECT payload_json FROM classroom_attempts WHERE id = ? AND class_code = ?").bind(id, classCode).first();
      if (!row) return json({ error: "Không tìm thấy kết quả." }, 404);
      const attempt = JSON.parse(row.payload_json);
      if (hasSafetyCheck) {
        const status = body.teacherSafetyCheck;
        if (!["not_checked", "safe_to_power", "unsafe", "uncertain"].includes(status)) throw new Error("Trạng thái kiểm tra an toàn không hợp lệ.");
        const physicallyChecked = status !== "not_checked" && body.teacherPhysicalCheck === true;
        if (status !== "not_checked" && !physicallyChecked) throw new Error("Giáo viên cần xác nhận đã kiểm tra trực tiếp mạch thật.");
        attempt.teacherSafetyCheck = status;
        attempt.teacherSafetyNote = typeof body.teacherSafetyNote === "string" ? body.teacherSafetyNote.trim().slice(0, 500) : "";
        attempt.teacherSafetyCheckedBy = physicallyChecked ? teacherName : null;
        attempt.teacherSafetyCheckedAt = physicallyChecked ? new Date().toISOString() : null;
        attempt.teacherPhysicallyChecked = physicallyChecked;
      }
      if (hasAiLabel) {
        if (hasAiError) attempt.teacherAiError = parseTeacherAiError(body.teacherAiError, getLesson(attempt.lessonId));
        else if (teacherVerification !== "incorrect") attempt.teacherAiError = null;
        attempt.teacherVerification = teacherVerification;
        attempt.teacherVerificationNote = typeof body.teacherVerificationNote === "string" ? body.teacherVerificationNote.trim().slice(0, 500) : "";
        attempt.teacherVerifiedBy = teacherName;
        attempt.teacherVerifiedAt = new Date().toISOString();
        attempt.teacherStatus = teacherVerification === "correct" ? "approved" : null;
      }
      if (hasLabels) {
        const labels = body.teacherCriterionLabels;
        const quality = body.teacherImageQuality;
        const validIds = new Set(attempt.problems.map((problem) => problem.id || problem.criterionId));
        if (!labels || typeof labels !== "object" || Array.isArray(labels) || Object.keys(labels).length > 30 || !["clear", "blurred", "occluded", "unassessable", null].includes(quality) || Object.entries(labels).some(([criterionId, value]) => !validIds.has(criterionId) || !["correct", "incorrect", "uncertain"].includes(value))) throw new Error("Nhãn tiêu chí hoặc chất lượng ảnh không hợp lệ.");
        attempt.teacherCriterionLabels = Object.fromEntries(Object.entries(labels));
        attempt.teacherImageQuality = quality;
        attempt.teacherLabelsBy = teacherName;
        attempt.teacherLabelsAt = new Date().toISOString();
      }
      const write = await env.DB.prepare("UPDATE classroom_attempts SET payload_json = ?, updated_at = ? WHERE id = ? AND class_code = ? AND payload_json = ?").bind(JSON.stringify(attempt), new Date().toISOString(), id, classCode, row.payload_json).run();
      if (!write.meta.changes) return json({ error: "Bài làm vừa thay đổi. Hãy tải lại dữ liệu trước khi lưu." }, 409);
      return json({ synced: true, attempt });
    } catch (error) { return json({ error: error.message || "Xác nhận không hợp lệ." }, 400); }
  }

  const match = url.pathname.match(/^\/api\/classroom\/attempts\/([^/]+)$/);
  if (match && request.method === "GET") {
    const id = decodeURIComponent(match[1]);
    const classCode = normalizeCode(url.searchParams.get("classCode"));
    if (!CLASS_CODE.test(classCode) || !validText(id, 80)) return json({ error: "Yêu cầu không hợp lệ." }, 400);
    if (!await canAccessAttempt(request, env, id, classCode)) return json({ error: "Không có quyền xem lượt phân tích." }, 403);
    const columns = personalAccountsEnabled(env) ? `a.payload_json, ${latestAttemptRechecks}` : "a.payload_json";
    const row = await env.DB.prepare(`SELECT ${columns} FROM classroom_attempts a WHERE a.id = ? AND a.class_code = ?`).bind(id, classCode).first();
    if (!row) return json({ error: "Không tìm thấy kết quả." }, 404);
    return json({ attempt: attemptFromReportRow(row) });
  }
  if (match && request.method === "PATCH") {
    try {
      const id = decodeURIComponent(match[1]);
      const updates = await parseBody(request);
      const classCode = normalizeCode(updates.classCode);
      if (!CLASS_CODE.test(classCode) || !validText(id, 80)) throw new Error("Yêu cầu không hợp lệ.");
      if ("verification" in updates && !await canAccessAttempt(request, env, id, classCode, false)) return json({ error: "Không có quyền sửa lượt phân tích." }, 403);
      const row = await env.DB.prepare("SELECT payload_json FROM classroom_attempts WHERE id = ? AND class_code = ?").bind(id, classCode).first();
      if (!row) return json({ error: "Không tìm thấy kết quả." }, 404);
      if ("teacherStatus" in updates || "teacherComment" in updates) {
        const denied = await requireTeacher(request, env, classCode);
        if (denied) return denied;
      }
      const attempt = JSON.parse(row.payload_json);
      if ("verification" in updates) {
        if (!VERIFICATIONS.has(updates.verification)) throw new Error("Xác nhận không hợp lệ.");
        attempt.verification = updates.verification;
      }
      if ("teacherStatus" in updates) {
        if (!TEACHER_STATUSES.has(updates.teacherStatus)) throw new Error("Trạng thái giáo viên không hợp lệ.");
        attempt.teacherStatus = updates.teacherStatus;
      }
      if ("teacherComment" in updates) {
        if (typeof updates.teacherComment !== "string" || updates.teacherComment.length > 1000) throw new Error("Nhận xét không hợp lệ.");
        attempt.teacherComment = updates.teacherComment.trim();
        attempt.teacherCommentAt = new Date().toISOString();
      }
      const write = await env.DB.prepare("UPDATE classroom_attempts SET payload_json = ?, updated_at = ? WHERE id = ? AND class_code = ? AND payload_json = ?").bind(JSON.stringify(attempt), new Date().toISOString(), id, classCode, row.payload_json).run();
      if (!write.meta.changes) return json({ error: "Bài làm vừa thay đổi. Hãy tải lại dữ liệu trước khi lưu." }, 409);
      return json({ synced: true, attempt });
    } catch (error) { return json({ error: error.message || "Dữ liệu không hợp lệ." }, 400); }
  }

  return json({ error: "Không tìm thấy API." }, 404);
}

function scoreAiComparison(lesson, labels, results, imageQuality) {
  const scores = { paired: 0, correctA: 0, correctB: 0, safetyErrors: 0, missedA: 0, missedB: 0 };
  const metrics = newAiComparisonMetrics();
  scores.metrics = metrics;
  const [baseline, referenced] = results;
  if (!baseline.result || !referenced.result || !referenced.referencesUsed) return scores;
  for (const criterion of lesson.checkList) {
    const label = labels[criterion.id];
    if (!label) continue;
    const a = baseline.result.checks.find(check => check.id === criterion.id);
    const b = referenced.result.checks.find(check => check.id === criterion.id);
    if (!a || !b) continue;
    const expected = label === "correct" ? "correct" : "possible_error";
    scores.paired++;
    scores.correctA += Number(a.status === expected);
    scores.correctB += Number(b.status === expected);
    if (label === "correct") {
      metrics.correctLabels++;
      metrics.falseAlarmA += Number(a.status === "possible_error");
      metrics.falseAlarmB += Number(b.status === "possible_error");
    }
    if (imageQuality === "clear") {
      metrics.clearChecks++;
      metrics.unknownClearA += Number(["uncertain","not_visible"].includes(a.status));
      metrics.unknownClearB += Number(["uncertain","not_visible"].includes(b.status));
    }
    if (label === "incorrect" && criterion.category === "safety") {
      scores.safetyErrors++;
      scores.missedA += Number(a.status === "correct");
      scores.missedB += Number(b.status === "correct");
    }
  }
  if (lesson.checkList.some(check => check.category === "safety" && labels[check.id] === "incorrect")) {
    metrics.unsafeRuns = 1;
    metrics.falsePassA = Number(baseline.result.verdict === "pass");
    metrics.falsePassB = Number(referenced.result.verdict === "pass");
  }
  return scores;
}

function newAiComparisonMetrics() {
  return { correctLabels:0, falseAlarmA:0, falseAlarmB:0, clearChecks:0, unknownClearA:0, unknownClearB:0, unsafeRuns:0, falsePassA:0, falsePassB:0 };
}

async function readAiComparisonRows(env, classCode, lessonId, days, latestOnly = false, teacherId = null) {
  const cutoff = days ? new Date(Date.now() - days * 86400000).toISOString() : "";
  const { results } = await env.DB.prepare(`SELECT b.id, json_extract(a.payload_json,'$.lessonId') AS lesson,
    date(b.completed_at,'+7 hours') AS day, b.completed_at AS completedAt, b.model,
    b.configuration_version AS configuration, x.status AS statusA, b.status AS statusB,
    b.reference_ids_json AS referenceIds, json_array_length(b.reference_ids_json) AS referencesUsed, s.paired, s.correct_a AS a,
    s.correct_b AS b, s.safety_errors AS safetyErrors, s.missed_a AS missedA, s.missed_b AS missedB,
    s.labels_at AS labelsAt, s.metrics_json AS metricsJson
    FROM platform_ai_runs b
    JOIN classroom_attempts a ON a.id=b.attempt_id
    JOIN platform_ai_runs x ON x.id=substr(b.id,1,length(b.id)-1)||'A' AND x.attempt_id=b.attempt_id AND x.lane='A'
    LEFT JOIN platform_ai_comparison_scores s ON s.reference_run_id=b.id
    WHERE (? IS NULL OR a.class_code=?) AND b.lane='B' AND b.completed_at IS NOT NULL
      AND (? IS NULL OR EXISTS (SELECT 1 FROM platform_class_members m
        WHERE m.user_id=? AND m.membership='teacher' AND m.class_code=a.class_code))
      AND (?='' OR json_extract(a.payload_json,'$.lessonId')=?)
      AND (?='' OR b.completed_at>=?)
      AND (?=0 OR b.id=(SELECT id FROM platform_ai_runs
        WHERE attempt_id=a.id AND lane='B' ORDER BY completed_at DESC,id DESC LIMIT 1))
    ORDER BY b.completed_at DESC,b.id DESC`)
    .bind(classCode, classCode, teacherId, teacherId, lessonId, lessonId, cutoff, cutoff, Number(latestOnly)).all();
  return results;
}

function groupAiComparisonRows(rows, field) {
  const groups = new Map();
  for (const row of rows) {
    const key = row[field];
    const counts = groups.get(key) || {
      [field]: key, runs: 0, paired: 0, a: 0, b: 0, failed: 0, missingReferences: 0,
      legacy: 0, unscored: 0, safetyErrors: 0, missedA: 0, missedB: 0, metrics: newAiComparisonMetrics(),
    };
    groups.set(key, counts);
    counts.runs++;
    const failed = row.statusA !== "succeeded" || row.statusB !== "succeeded";
    counts.failed += Number(failed);
    counts.missingReferences += Number(!row.referencesUsed);
    counts.legacy += Number(row.paired === null);
    counts.unscored += Number(!failed && row.referencesUsed > 0 && row.paired === 0);
    for (const column of ["paired","a","b","safetyErrors","missedA","missedB"]) counts[column] += row[column] || 0;
    if (row.metricsJson) {
      const metrics = JSON.parse(row.metricsJson);
      for (const name of Object.keys(counts.metrics)) counts.metrics[name] += metrics[name] || 0;
    }
  }
  return [...groups.values()];
}

function readAiTrackingFilters(url) {
  const lessonId = url.searchParams.get("lessonId") || "";
  const days = Number(url.searchParams.get("days") ?? "30");
  if (![0, 7, 30, 90].includes(days) || (lessonId && !getWorkerLesson(lessonId))) return null;
  return { lessonId, days };
}

async function handlePublicAiProgress(env, url) {
  const filters = readAiTrackingFilters(url);
  if (!filters) return json({ error: "Bộ lọc chưa hợp lệ." }, 400);
  const { lessonId, days } = filters;
  const [rows, approved] = await Promise.all([
    readAiComparisonRows(env, null, lessonId, days),
    env.DB.prepare(`SELECT lesson_id AS lesson, status, COUNT(*) AS count
      FROM platform_reference_case_catalog WHERE status='approved' AND (?='' OR lesson_id=?)
      GROUP BY lesson_id,status`).bind(lessonId, lessonId).all(),
  ]);
  return json({
    lessons: groupAiComparisonRows(rows, "lesson"),
    daily: groupAiComparisonRows(rows, "day"),
    libraryCounts: approved.results,
  });
}

async function handleAiTracking(request, env, url) {
  const classCode = normalizeCode(url.searchParams.get("classCode"));
  const filters = readAiTrackingFilters(url);
  if (!CLASS_CODE.test(classCode) || !filters) return json({ error: "Bộ lọc chưa hợp lệ." }, 400);
  const { lessonId, days } = filters;
  const denied = await requireTeacher(request, env, classCode);
  if (denied) return denied;
  const [rows, library, totals] = await Promise.all([
    readAiComparisonRows(env, classCode, lessonId, days),
    env.DB.prepare(`SELECT id,lesson_id AS lesson,status,reviewed_at AS reviewedAt,
      criterion_id AS criterion,label,error_type AS errorType
      FROM platform_reference_case_catalog WHERE (class_code=? OR status='approved') AND (?='' OR lesson_id=?)
      ORDER BY created_at DESC,id DESC LIMIT 48`)
      .bind(classCode, lessonId, lessonId).all(),
    env.DB.prepare(`SELECT lesson_id AS lesson,status,COUNT(*) AS count
      FROM platform_reference_case_catalog
      WHERE (class_code=? OR status='approved') AND (?='' OR lesson_id=?) GROUP BY lesson_id,status`)
      .bind(classCode, lessonId, lessonId).all(),
  ]);
  return json({
    classCode, lessons: groupAiComparisonRows(rows,"lesson"),
    daily: groupAiComparisonRows(rows,"day"),
    recent: rows.slice(0, 50).map(({ metricsJson, ...row }) => ({ ...row, referenceIds: JSON.parse(row.referenceIds) })),
    runCount: rows.length, library: library.results, libraryCounts: totals.results,
  });
}

function referenceRegionFromMarks(annotationsJson) {
  const normalized = readReferenceAnnotations(annotationsJson);
  if (!normalized) return null;
  const marks = JSON.parse(normalized);
  const shapes = marks.filter(mark => mark.kind !== "note");
  const points = (shapes.length ? shapes : marks).flatMap(mark => mark.points);
  if (!points.length) return null;
  const [xs, ys] = [0, 1].map(axis => points.map(point => point[axis] / 10));
  const width = Math.max(1, Math.max(...xs) - Math.min(...xs));
  const height = Math.max(1, Math.max(...ys) - Math.min(...ys));
  return { x: Math.min(Math.min(...xs), 100 - width), y: Math.min(Math.min(...ys), 100 - height), width, height };
}

async function selectReferenceCases(env, lesson, attemptId, images, priorityCriteria = [], collectMarkedViews = false) {
  const { results } = await env.DB.prepare(`WITH candidates AS (
    SELECT e.id,e.attempt_id,e.criterion_id,e.label AS status,e.error_type,e.annotations_json,e.source_recheck_id,e.evidence,e.ai_error_reason,
      ROW_NUMBER() OVER (PARTITION BY e.label,e.criterion_id,e.error_type
        ORDER BY (json_array_length(e.annotations_json)>0) DESC,e.reviewed_at DESC,e.created_at DESC,e.id) AS case_rank,
      e.reviewed_at
    FROM platform_reference_case_catalog e
    WHERE e.lesson_id=? AND e.status='approved' AND (? IS NULL OR e.attempt_id IS NULL OR e.attempt_id<>?)
      AND e.label IN ('correct','incorrect')
      AND NOT EXISTS (SELECT 1 FROM platform_evaluation_members m WHERE m.attempt_id=e.attempt_id)
  ) SELECT * FROM candidates WHERE case_rank<=8
    ORDER BY (status='incorrect' AND error_type IS NULL),(json_array_length(annotations_json)>0) DESC,case_rank,reviewed_at DESC,id`)
    .bind(lesson.id, attemptId, attemptId).all();
  const priority = new Set(priorityCriteria);
  results.sort((a, b) => Number(priority.has(b.criterion_id)) - Number(priority.has(a.criterion_id)));
  const criteria = new Map(lesson.checkList.map(criterion => [criterion.id, criterion]));
  const submittedDigests = await Promise.all(images.map(referencePhotoDigest));
  const photoDigests = new Set(submittedDigests);
  const approvedFiles = new Map();
  async function loadApproved(row) {
    if (approvedFiles.has(row.id)) return approvedFiles.get(row.id);
    const object = await env.BUCKET.get("reviewed-examples/" + row.id);
    const contentType = object?.httpMetadata?.contentType;
    if (!IMAGE_TYPES.has(contentType) || object.size > 3_000_000) return null;
    const file = new File([await new Response(object.body).arrayBuffer()], "reference", { type: contentType });
    if (!file.size || file.size > 3_000_000) return null;
    const entry = { file, digest: await referencePhotoDigest(file), markedRegion: referenceRegionFromMarks(row.annotations_json) };
    approvedFiles.set(row.id, entry);
    return entry;
  }
  const markedViews = new Map();
  if (collectMarkedViews) {
    const markedCandidates = results.filter(row => row.annotations_json !== "[]" && criteria.has(row.criterion_id)).slice(0, 12);
    for (const row of markedCandidates) {
      const entry = await loadApproved(row);
      if (!entry?.markedRegion || !photoDigests.has(entry.digest)) continue;
      for (const [imageIndex, digest] of submittedDigests.entries()) {
        const key = `${imageIndex}:${row.criterion_id}`;
        if (digest === entry.digest && !markedViews.has(key)) {
          markedViews.set(key, { imageIndex, criterionId: row.criterion_id, region: entry.markedRegion,
            ...(row.source_recheck_id && row.evidence ? { recheckEvidence: row.evidence } : {}) });
        }
      }
    }
  }
  const tried = new Set();
  const usedAttempts = new Set();
  const usedCases = new Set();
  const selected = [];

  // Keep room for both labels, then prefer a second, different error case.
  for (const label of ["incorrect", "correct", "incorrect", "correct", "incorrect", "correct"]) {
    if (selected.length === 3) break;
    for (const row of results) {
      const criterion = criteria.get(row.criterion_id);
      const errorType = Object.hasOwn(REFERENCE_ERROR_TYPES, row.error_type) ? REFERENCE_ERROR_TYPES[row.error_type] : "";
      const caseKey = JSON.stringify([label, row.criterion_id, errorType]);
      if (row.status !== label || !criterion || tried.has(row.id) || usedAttempts.has(row.attempt_id) || usedCases.has(caseKey)) continue;
      tried.add(row.id);
      const entry = await loadApproved(row);
      if (!entry || photoDigests.has(entry.digest)) continue;
      selected.push({ id: row.id, file: entry.file, criterion, label, errorType, markedRegion: entry.markedRegion,
        ...(row.source_recheck_id ? { recheckEvidence: row.evidence,
          recheckGuidance: Object.hasOwn(AI_ERROR_REVIEW_GUIDANCE, row.ai_error_reason) ? AI_ERROR_REVIEW_GUIDANCE[row.ai_error_reason] : "" } : {}),
      });
      photoDigests.add(entry.digest);
      if (row.attempt_id) usedAttempts.add(row.attempt_id);
      usedCases.add(caseKey);
      break;
    }
  }
  return { examples: selected, markedViews: [...markedViews.values()] };
}

async function handleCompareAnalyze(request, env) {
  if (rateLimit(request)) return apiError("RATE_LIMITED", "Hãy chờ rồi thử lại.", 429);
  try {
    const form = await request.formData();
    const lesson = getWorkerLesson(String(form.get("lessonId") || ""));
    const attemptId = String(form.get("attemptId") || "");
    const classCode = normalizeCode(form.get("classCode"));
    if (!lesson || !validText(attemptId, 80) || !CLASS_CODE.test(classCode)) return apiError("INVALID_REQUEST", "Yêu cầu không hợp lệ.", 400);
    const denied = await requireTeacher(request, env, classCode);
    if (denied) return denied;
    const target = await env.DB.prepare("SELECT payload_json FROM classroom_attempts WHERE id=? AND class_code=?").bind(attemptId,classCode).first();
    const attempt = target && JSON.parse(target.payload_json);
    if (!attempt || attempt.demo || attempt.lessonId !== lesson.id) return apiError("INVALID_ATTEMPT", "Không tìm thấy bài phù hợp.", 404);
    const images = [];
    for (let index = 0; index < Math.min(3, attempt.imageCount || 0); index++) {
      const file = await loadComparisonPhoto(env,classCode,attemptId,index);
      if (!file) return apiError("MISSING_IMAGE", "Bài làm thiếu ảnh đã đồng bộ.", 409);
      images.push(file);
    }
    validateImages(images);
    const { examples: referenceFiles } = await selectReferenceCases(env, lesson, attemptId, images);
    const referenceIds = referenceFiles.map(reference => reference.id);
    const started = Date.now();
    const model = analysisModelChoices(env)[0];
    const rubric = JSON.stringify({ checks: lesson.checkList, expectedConnections: lesson.expectedConnections, rules: CIRCUIT_LESSON_SPECS[lesson.id].rules });
    const rubricId = await platformDigest(JSON.stringify([lesson.id, rubric]));
    const promptVersion = await platformDigest(JSON.stringify([buildPrimaryAnalysisInstructions(lesson), buildAnalyzeInput(lesson, 0), buildAnalyzeInput(lesson, 1, true), buildStudentImageInput.toString(), buildLedPhotoInstructions(lesson), buildLedDetailInput.toString(), studentImageDetail(lesson, model), buildLabeledAnalysisReferences.toString(), analyzeLane.toString()]));
    const proofConfiguration = [buildCircuitFocusSchema(lesson, lesson.checkList.map(criterion => criterion.id)),
      validateSingleCircuitRead.toString(), readCircuit.toString()];
    const configuration = await platformDigest(JSON.stringify([model, rubricId, promptVersion, CIRCUIT_OBSERVATION_VERSION,
      CIRCUIT_ANALYSIS_JSON_SCHEMA, proofConfiguration, selectReferenceCases.toString(), REFERENCE_ERROR_TYPES, finalizeCircuitAnalysis.toString()]));
    const [laneA, laneB] = await Promise.allSettled([
      analyzeLane(env, lesson, images),
      analyzeLane(env, lesson, images, referenceFiles),
    ]);
    const results = [laneA, laneB].map((lane, index) => lane.status === "fulfilled"
      ? { status: "succeeded", result: lane.value, referencesUsed: index ? referenceFiles.length : 0 }
      : { status: "failed", error: lane.reason?.message || "AI không hoàn tất.", referencesUsed: index ? referenceFiles.length : 0 });
    const runId = crypto.randomUUID();
    const completed = new Date().toISOString();
    const created = new Date(started).toISOString();
    const duration = Date.now() - started;
    const labels = Object.fromEntries(lesson.checkList
      .map(criterion => [criterion.id, attempt.teacherCriterionLabels?.[criterion.id]])
      .filter(([, label]) => ["correct", "incorrect"].includes(label)));
    const scores = scoreAiComparison(lesson, labels, results, attempt.teacherImageQuality);
    const writes = results.map((result,index) => {
      const lane = index ? "B" : "A";
      return env.DB.prepare(`INSERT INTO platform_ai_runs
        (id,attempt_id,lane,configuration_version,retry_key,status,model,prompt_version,lesson_version_id,result_json,reference_ids_json,duration_ms,created_at,completed_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
        .bind(runId + lane, attemptId, lane, configuration, runId + lane, result.status, model, promptVersion, rubricId, JSON.stringify(result), JSON.stringify(index ? referenceIds : []), duration, created, completed);
    });
    await env.DB.batch([
      env.DB.prepare("INSERT INTO platform_lesson_versions (id,lesson_id,snapshot_json,created_at) VALUES (?,?,?,?) ON CONFLICT(id) DO NOTHING")
        .bind(rubricId, lesson.id, rubric, created),
      ...writes,
      env.DB.prepare(`INSERT INTO platform_ai_comparison_scores
        (reference_run_id,labels_json,labels_at,paired,correct_a,correct_b,safety_errors,missed_a,missed_b,metrics_json)
        VALUES (?,?,?,?,?,?,?,?,?,?)`)
        .bind(runId + "B", JSON.stringify(labels), attempt.teacherLabelsAt || null, scores.paired, scores.correctA, scores.correctB,
          scores.safetyErrors, scores.missedA, scores.missedB, scores.paired ? JSON.stringify(scores.metrics) : null),
    ]);
    return json({ runId, results, scoredCriteria: scores.paired });
  } catch (error) { return apiError(error.code || "COMPARE_FAILED", error.message || "Không thể so sánh AI.", error.status || 500); }
}

async function loadComparisonPhoto(env, classCode, id, index) {
  const object = await env.BUCKET.get(`${classCode}/${encodeURIComponent(id)}/${index}`);
  if (!object) return null;
  const bytes = await new Response(object.body).arrayBuffer();
  return new File([bytes], "circuit", { type: object.httpMetadata?.contentType || "image/jpeg" });
}

function assetResponse(pathname) {
  const key = Object.hasOwn(ASSETS, pathname) ? pathname : "/index.html";
  const encoded = ASSETS[key];
  if (!encoded) return new Response("Not found", { status: 404 });
  const bytes = Uint8Array.from(atob(encoded), (character) => character.charCodeAt(0));
  const extension = key.slice(key.lastIndexOf("."));
  const cacheControl = key === "/index.html" ? "no-store" : key.includes("/assets/") ? "public, max-age=31536000, immutable" : "public, max-age=300";
  return new Response(bytes, { headers: { "content-type": mimeTypes[extension] || "application/octet-stream", "cache-control": cacheControl } });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    try {
      if (url.pathname.startsWith("/api/")) return await handleApi(request, env, url);
      if (request.method !== "GET" && request.method !== "HEAD") return new Response("Method not allowed", { status: 405 });
      return assetResponse(url.pathname === "/" ? "/index.html" : url.pathname);
    } catch (error) {
      console.error("CircuitCoach worker error", error);
      return json({ error: "Máy chủ gặp lỗi. Hãy thử lại." }, 500);
    }
  },
};
