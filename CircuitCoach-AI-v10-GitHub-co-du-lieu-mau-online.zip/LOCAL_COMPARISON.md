# Local comparison update

Teachers open an attempt, save a criterion label, then submit its first
synced photo. Reviewers assigned to the lesson can inspect the saved photo,
approve or reject it, and retire approved examples.

Teachers can run A/B on the saved images. B uses up to three approved
examples from the same class and lesson. Each lane is saved separately.
The class report uses the latest pair per attempt and counts matched
criteria with definite teacher labels and references used in B.

Source backups exclude runtime data and credentials. Build passed.
Live AI requests require working API credentials and model access.
