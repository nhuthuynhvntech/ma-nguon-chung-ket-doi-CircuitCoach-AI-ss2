# Local access update

New synchronized attempts are bound to a browser cookie. The server
stores its hash and checks it for student reads, feedback and image
uploads. Assigned teachers and admins can read attempt records and images.
Legacy attempts remain available to assigned staff. The existing class
reference list is staff-only in local mode.

Browser ownership does not transfer to another browser or device.
The review submission/approval workflow, AI A/B and reports are pending.
