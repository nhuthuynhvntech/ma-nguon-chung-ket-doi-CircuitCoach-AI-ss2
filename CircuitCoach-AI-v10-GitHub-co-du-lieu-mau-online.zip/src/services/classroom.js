const TEACHER_CLASS_KEY = "circuitcoach.teacher-class-code";
const TEACHER_USERNAME_KEY = "circuitcoach.teacher-username";
const TEACHER_PASSWORD_KEY = "circuitcoach.teacher-password";
const CLASS_CODE_PATTERN = /^[A-Z0-9]{4,12}$/;
export const CLASSROOM_SESSION_CHANGE = "circuitcoach.session-change";
let browserSession = null;

export function getBrowserSession() {
  return browserSession;
}

export function setBrowserSession(session) {
  browserSession = session;
}

export async function fetchBrowserSession() {
  try {
    const session = await request("/api/classroom/browser-session");
    return session && Object.hasOwn(session, "role") ? session : null;
  }
  catch (error) {
    if (error.status === 404) return null;
    throw error;
  }
}

export function signOutBrowserSession() {
  return request("/api/classroom/browser-session", { method: "DELETE" });
}

export function withBrowserSessionLock(action) {
  return navigator.locks ? navigator.locks.request("circuitcoach-session", action) : action();
}

export function notifyBrowserSessionChange() {
  localStorage.setItem(CLASSROOM_SESSION_CHANGE, crypto.randomUUID());
}

export function normalizeClassCode(value) {
  return String(value || "").trim().toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 12);
}

export function isValidClassCode(value) {
  return CLASS_CODE_PATTERN.test(normalizeClassCode(value));
}

export function getTeacherClassCode() {
  return normalizeClassCode(localStorage.getItem(TEACHER_CLASS_KEY));
}

export function saveTeacherClassCode(value) {
  const code = normalizeClassCode(value);
  if (!isValidClassCode(code)) throw new Error("Mã lớp cần từ 4–12 chữ cái hoặc chữ số.");
  localStorage.setItem(TEACHER_CLASS_KEY, code);
  return code;
}

export function getTeacherPassword() {
  return sessionStorage.getItem(TEACHER_PASSWORD_KEY) || "";
}

export function getTeacherUsername() {
  return sessionStorage.getItem(TEACHER_USERNAME_KEY) || "GV";
}

export function saveTeacherUsername(value) {
  const username = String(value || "").trim();
  if (!username || username.length > 40) throw new Error("Tên đăng nhập giáo viên không hợp lệ.");
  sessionStorage.setItem(TEACHER_USERNAME_KEY, username);
  return username;
}

export function saveTeacherPassword(value) {
  const password = String(value || "");
  if (password.length < 6 || password.length > 128) throw new Error("Mật khẩu giáo viên cần từ 6–128 ký tự.");
  sessionStorage.setItem(TEACHER_PASSWORD_KEY, password);
  return password;
}

export function clearTeacherPassword() {
  sessionStorage.removeItem(TEACHER_PASSWORD_KEY);
  sessionStorage.removeItem(TEACHER_USERNAME_KEY);
}

async function request(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: { ...(options.body instanceof FormData ? {} : { "content-type": "application/json" }), ...(options.headers || {}) },
  });
  const payload = await response.json().catch(() => ({}));
  const message = typeof payload.error === "string" ? payload.error : payload.error?.message;
  if (!response.ok) throw Object.assign(new Error(message || "Không thể kết nối dữ liệu lớp học."), { status: response.status });
  return payload;
}

export async function publishAttempt(attempt, imageFiles = []) {
  if (!isValidClassCode(attempt.classCode)) return { synced: false, reason: "missing_class_code" };
  const result = await request("/api/classroom/attempts", { method: "POST", body: JSON.stringify(attempt) });
  const imageResult = await uploadAttemptImages(attempt.id, attempt.classCode, imageFiles);
  return { ...result, ...imageResult };
}

export async function uploadAttemptImages(attemptId, classCode, imageFiles = []) {
  const code = normalizeClassCode(classCode);
  if (!attemptId || !isValidClassCode(code)) return { imagesSynced: false, imageCount: 0, imageError: "Thiếu mã lớp." };
  const selected = [...imageFiles].slice(0, 3);
  if (!selected.length) return { imagesSynced: false, imageCount: 0, imageError: "Không còn ảnh trong phiên này." };
  const form = new FormData();
  form.append("classCode", code);
  selected.forEach((file) => form.append("images", file, file.name));
  const response = await fetch(`/api/classroom/attempts/${encodeURIComponent(attemptId)}/images`, { method: "POST", body: form });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) return { imagesSynced: false, imageCount: 0, imageError: typeof payload.error === "string" ? payload.error : "Không thể đồng bộ ảnh." };
  return { imagesSynced: true, imageCount: payload.imageCount || selected.length };
}

function loginPasswordMinimum() {
  return ["127.0.0.1", "localhost"].includes(location.hostname) ? 5 : 6;
}

export async function verifyTeacherAccount(username, password) {
  const account = String(username || "").trim();
  const value = String(password || "");
  if (!account || account.length > 40) throw new Error("Tên đăng nhập giáo viên không hợp lệ.");
  const minimum = loginPasswordMinimum();
  if (value.length < minimum || value.length > 128) throw new Error(`Mật khẩu giáo viên cần từ ${minimum}–128 ký tự.`);
  return request("/api/classroom/teacher-login", {
    method: "POST",
    headers: { "x-teacher-username": account, "x-teacher-password": value },
    body: "{}",
  });
}

export async function fetchTeacherSession() {
  try {
    return await request("/api/classroom/teacher-session");
  } catch (error) {
    if (error.status === 401 || error.status === 404) return null;
    throw error;
  }
}

export function applyTeacherSession(session) {
  if (!session) {
    if (getTeacherPassword() === "cookie-session") clearTeacherPassword();
    return "";
  }
  const classCodes = (session.classCodes || []).filter(isValidClassCode);
  const savedClass = getTeacherClassCode();
  const classCode = classCodes.includes(savedClass) ? savedClass : classCodes[0];
  saveTeacherUsername(session.username);
  saveTeacherPassword("cookie-session");
  if (classCode) return saveTeacherClassCode(classCode);
  localStorage.removeItem(TEACHER_CLASS_KEY);
  return "";
}

export function createTeacherClass(classCode) {
  return request("/api/classroom/teacher/classes", { method: "POST", body: JSON.stringify({ classCode }) });
}

export function fetchLearningReport(filters, signal, role = "admin") {
  const scope = role === "teacher" ? "teacher" : "admin";
  return request(`/api/classroom/${scope}/learning?${new URLSearchParams(filters)}`, { signal });
}

export function fetchStaffAccounts() {
  return request("/api/classroom/admin/accounts");
}

export function fetchOpenAISettings() {
  return request("/api/settings/openai");
}

export function saveOpenAIKey(apiKey) {
  return request("/api/settings/openai", { method: "PUT", body: JSON.stringify({ apiKey }) });
}

export function saveStaffAccount(account, method = "POST") {
  return request("/api/classroom/admin/accounts", { method, body: JSON.stringify(account) });
}

export function updateAdminPassword(currentPassword, password) {
  return request("/api/classroom/admin/password", { method: "POST", body: JSON.stringify({ currentPassword, password }) });
}

export function logoutTeacherAccount() {
  return request("/api/classroom/teacher-logout", { method: "POST", body: "{}" });
}

export async function verifyAdminAccount(username, password) {
  const account = String(username || "").trim();
  const value = String(password || "");
  if (!account || account.length > 40) throw new Error("Tên đăng nhập quản trị không hợp lệ.");
  const minimum = loginPasswordMinimum();
  if (value.length < minimum || value.length > 128) throw new Error(`Mật khẩu quản trị cần từ ${minimum}–128 ký tự.`);
  return request("/api/classroom/admin-login", {
    method: "POST",
    body: JSON.stringify({ username: account, password: value }),
  });
}

export async function fetchAdminSummary() {
  return request("/api/classroom/admin/summary");
}

export async function logoutAdmin() {
  return request("/api/classroom/admin-logout", { method: "POST", body: "{}" });
}

export async function fetchClassAttempts(classCode, teacherPassword, teacherUsername = "") {
  const code = normalizeClassCode(classCode);
  if (!isValidClassCode(code)) return [];
  const payload = await request(`/api/classroom/attempts?classCode=${encodeURIComponent(code)}`, {
    headers: { "x-teacher-username": String(teacherUsername || ""), "x-teacher-password": String(teacherPassword || "") },
  });
  return Array.isArray(payload.attempts) ? payload.attempts : [];
}

export async function fetchSharedAttempt(attemptId, classCode) {
  const code = normalizeClassCode(classCode);
  if (!attemptId || !isValidClassCode(code)) return null;
  const payload = await request(`/api/classroom/attempts/${encodeURIComponent(attemptId)}?classCode=${encodeURIComponent(code)}`);
  return payload.attempt || null;
}

function attemptRecheckPath(attemptId, classCode, photoId, action = "image") {
  const query = new URLSearchParams({ classCode: normalizeClassCode(classCode) });
  const photoPath = photoId ? `/${encodeURIComponent(photoId)}/${action}` : "";
  return `/api/classroom/attempts/${encodeURIComponent(attemptId)}/rechecks${photoPath}?${query}`;
}

export async function fetchCriterionRechecks(attemptId, classCode, signal) {
  const payload = await request(attemptRecheckPath(attemptId, classCode), { signal });
  return payload.rechecks || [];
}

export async function submitCriterionRecheck({ attemptId, classCode, criterionId, photo, signal }) {
  const form = new FormData();
  form.set("criterionId", criterionId);
  form.set("photo", photo, photo.name);
  const payload = await request(attemptRecheckPath(attemptId, classCode), { method: "POST", body: form, signal });
  return payload.recheck;
}

export function criterionRecheckPhotoUrl(attemptId, classCode, photoId) {
  return attemptRecheckPath(attemptId, classCode, photoId);
}

export function saveCriterionRecheckComment({ attemptId, classCode, recheckId, comment, version }) {
  return request(attemptRecheckPath(attemptId, classCode, recheckId, "comment"), {
    method: "PATCH", body: JSON.stringify({ comment, version }),
  });
}

export function saveCriterionRecheckReview({ attemptId, classCode, recheckId, ...review }) {
  return request(attemptRecheckPath(attemptId, classCode, recheckId, "review"), {
    method: "PATCH", body: JSON.stringify(review),
  });
}

export function publishCriterionRecheckReference({ attemptId, classCode, recheckId, version }) {
  return request(attemptRecheckPath(attemptId, classCode, recheckId, "reference"), {
    method: "POST", body: JSON.stringify({ version }),
  });
}

export async function fetchSharedReferenceCases(lessonId) {
  const params = new URLSearchParams({ scope: "all", lessonId });
  const payload = await request(`/api/classroom/reference-cases?${params}`);
  return payload.cases || [];
}

export async function fetchPublicReferenceCases(lessonId) {
  const params = new URLSearchParams({ lessonId });
  const payload = await request(`/api/reference-cases?${params}`);
  return payload.cases || [];
}

export function publicReferenceExamplePhotoUrl(id) {
  return `/api/reference-cases/photo/${encodeURIComponent(id)}`;
}

export function submitReferenceCase(example) {
  return request("/api/classroom/reference-submit", { method: "POST", body: JSON.stringify(example) });
}

export function reviewReferenceCase({ id, status }) {
  return request("/api/classroom/reference-decision", {
    method: "POST",
    body: JSON.stringify({ scope: "all", id, status }),
  });
}

export function uploadReferenceCase(form) {
  return request("/api/classroom/reference-upload?scope=all", { method: "POST", body: form });
}

export function sharedReferencePhotoUrl(id) {
  return `/api/classroom/ai-tracking/photo/${encodeURIComponent(id)}?scope=all`;
}

export function referenceExamplePhotoUrl(id, classCode) {
  return `/api/classroom/ai-tracking/photo/${encodeURIComponent(id)}?classCode=${encodeURIComponent(normalizeClassCode(classCode))}`;
}

export function lessonSampleUrl({ classCode, lessonId, photoId, manage = false }) {
  const params = new URLSearchParams({ classCode: normalizeClassCode(classCode) });
  if (manage) params.set("manage", "1");
  const photoPath = photoId ? "/" + encodeURIComponent(photoId) : "";
  return `/api/classroom/lesson-samples/${encodeURIComponent(lessonId)}${photoPath}?${params}`;
}

export function fetchLessonSamples(scope) {
  return request(lessonSampleUrl(scope));
}

export function fetchLessonAiReminders({ classCode, lessonId, studentName }) {
  return request("/api/classroom/lesson-ai-reminders", {
    method: "POST",
    body: JSON.stringify({ classCode: normalizeClassCode(classCode), lessonId, studentName }),
  });
}

export function uploadLessonSample(scope, form) {
  return request(lessonSampleUrl(scope), { method: "POST", body: form });
}

export function setLessonSampleVisibility(scope, photoId, visible) {
  return request(lessonSampleUrl({ ...scope, photoId }), { method: "PATCH", body: JSON.stringify({ visible }) });
}

export async function publishAttemptUpdate(attemptId, classCode, updates, teacherPassword = "", teacherUsername = "") {
  const code = normalizeClassCode(classCode);
  if (!isValidClassCode(code)) return { synced: false };
  return request(`/api/classroom/attempts/${encodeURIComponent(attemptId)}`, {
    method: "PATCH",
    headers: teacherPassword ? { "x-teacher-username": teacherUsername, "x-teacher-password": teacherPassword } : {},
    body: JSON.stringify({ classCode: code, ...updates }),
  });
}

export async function verifyAttempt({ attemptId, classCode, teacherVerification, teacherVerificationNote = "", teacherAiError, teacherSafetyCheck, teacherPhysicalCheck = false, teacherSafetyNote = "", teacherCriterionLabels, teacherImageQuality, teacherUsername = "", teacherPassword = "" }) {
  const code = normalizeClassCode(classCode);
  if (!attemptId) throw new Error("Thiếu lượt kiểm tra cần xác nhận.");
  if (!isValidClassCode(code)) throw new Error("Mã lớp không hợp lệ.");
  if (!teacherPassword) throw new Error("Cần đăng nhập giáo viên để xác nhận.");
  return request(`/api/classroom/attempts/${encodeURIComponent(attemptId)}/verify`, {
    method: "POST",
    headers: { "x-teacher-username": String(teacherUsername || ""), "x-teacher-password": String(teacherPassword || "") },
    body: JSON.stringify({ classCode: code, teacherVerification, teacherVerificationNote: String(teacherVerificationNote || "").slice(0, 500), teacherAiError, teacherSafetyCheck, teacherPhysicalCheck: Boolean(teacherPhysicalCheck), teacherSafetyNote: String(teacherSafetyNote || "").slice(0, 500), teacherCriterionLabels, teacherImageQuality }),
  });
}

export function sharedAttemptImageUrl(attemptId, classCode, imageIndex) {
  const code = normalizeClassCode(classCode);
  return `/api/classroom/attempts/${encodeURIComponent(attemptId)}/images/${imageIndex}?classCode=${encodeURIComponent(code)}`;
}
