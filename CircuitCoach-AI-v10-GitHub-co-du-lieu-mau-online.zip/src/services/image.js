import { ACCEPTED_IMAGE_TYPES, JPEG_QUALITY, MAX_IMAGE_EDGE } from "../config.js";

function loadImage(file) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    const url = URL.createObjectURL(file);
    image.onload = () => { URL.revokeObjectURL(url); resolve(image); };
    image.onerror = () => { URL.revokeObjectURL(url); reject(new Error("Không thể đọc ảnh.")); };
    image.src = url;
  });
}

export function validateImage(file) {
  if (!ACCEPTED_IMAGE_TYPES.includes(file.type)) {
    throw new Error("Chỉ hỗ trợ ảnh JPEG, PNG hoặc WEBP.");
  }
}

export async function inspectPhotoQuality(file) {
  const image = await loadImage(file);
  const size = Math.max(image.naturalWidth, image.naturalHeight);
  const scale = Math.min(1, 160 / size);
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
  canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
  const context = canvas.getContext("2d", { alpha: false });
  if (!context) return [];
  context.drawImage(image, 0, 0, canvas.width, canvas.height);
  const { data, width, height } = context.getImageData(0, 0, canvas.width, canvas.height);
  const light = new Float32Array(width * height);
  let dark = 0;
  let total = 0;
  for (let index = 0; index < light.length; index += 1) {
    const pixel = index * 4;
    const value = .2126 * data[pixel] + .7152 * data[pixel + 1] + .0722 * data[pixel + 2];
    light[index] = value;
    total += value;
    if (value < 42) dark += 1;
  }
  const tips = [];
  if (dark / light.length > .8 && total / light.length < 55) {
    tips.push("Ảnh có vẻ tối. Hãy chụp lại dưới ánh sáng đều để thấy rõ chân linh kiện.");
  }
  if (Math.min(image.naturalWidth, image.naturalHeight) < 360) {
    tips.push("Ảnh có độ phân giải thấp. Hãy dùng ảnh gốc hoặc chụp cận các chân nối.");
  }
  let intensity = 0;
  let edges = 0;
  for (let y = 1; y < height - 1; y += 1) {
    for (let x = 1; x < width - 1; x += 1) {
      const index = y * width + x;
      const edge = 4 * light[index] - light[index - 1] - light[index + 1] - light[index - width] - light[index + width];
      intensity += edge * edge;
      edges += Number(Math.abs(edge) >= 20);
    }
  }
  const inspected = (width - 2) * (height - 2);
  if (tips.length === 0 && width > 2 && height > 2 && intensity / inspected < 35 && edges / inspected < .02) {
    tips.push("Ảnh có thể bị mờ hoặc thiếu chi tiết. Giữ máy chắc và lấy nét vào dây, linh kiện.");
  }
  return tips;
}

export async function prepareImage(file) {
  validateImage(file);
  const image = await loadImage(file);
  const scale = Math.min(1, MAX_IMAGE_EDGE / Math.max(image.naturalWidth, image.naturalHeight));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(image.naturalWidth * scale);
  canvas.height = Math.round(image.naturalHeight * scale);
  canvas.getContext("2d", { alpha: false }).drawImage(image, 0, 0, canvas.width, canvas.height);
  const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/jpeg", JPEG_QUALITY));
  if (!blob) throw new Error("Không thể xử lý ảnh.");
  const safeName = file.name.replace(/\.[^.]+$/, "") || "circuit";
  return new File([blob], `${safeName}.jpg`, { type: "image/jpeg" });
}

export function previewUrl(file) {
  return URL.createObjectURL(file);
}
