let activeStream = null;

export async function startCamera(video, { signal } = {}) {
  if (!navigator.mediaDevices?.getUserMedia) {
    throw new Error("Trình duyệt này không hỗ trợ camera.");
  }
  const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" } }, audio: false });
  if (signal?.aborted) {
    stream.getTracks().forEach(track => track.stop());
    return;
  }
  activeStream = stream;
  video.srcObject = stream;
  try { await video.play(); }
  catch (error) {
    if (video.srcObject === stream) stopCamera(video);
    if (!signal?.aborted) throw error;
  }
}

export function captureFrame(video) {
  const canvas = document.createElement("canvas");
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  canvas.getContext("2d").drawImage(video, 0, 0);
  return new Promise((resolve, reject) => canvas.toBlob((blob) => blob ? resolve(new File([blob], `camera-${Date.now()}.jpg`, { type: "image/jpeg" })) : reject(new Error("Không thể chụp ảnh.")), "image/jpeg", 0.9));
}

export function stopCamera(video) {
  const stream = video ? video.srcObject : activeStream;
  stream?.getTracks().forEach((track) => track.stop());
  if (activeStream === stream) activeStream = null;
  if (video) video.srcObject = null;
}
