import { getLearningAnalytics } from "./analytics.js";

export function getRecommendation() {
  const [top] = getLearningAnalytics().topicCounts;
  if (!top) {
    return { title: "Bắt đầu bài đầu tiên", detail: "Hoàn thành một lần kiểm tra để CircuitCoach đề xuất nội dung ôn tập." };
  }
  return { title: `Ôn lại: ${top[0]}`, detail: `Chủ đề này đã xuất hiện ${top[1]} lần trong các vấn đề cần kiểm tra.` };
}
