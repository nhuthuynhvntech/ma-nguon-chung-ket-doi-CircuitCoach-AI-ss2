import { getAttempts } from "./storage.js";
import { lessons } from "../data/lessons.js";

export function getLearningAnalytics() {
  const attempts = getAttempts();
  const topicCounts = new Map();
  for (const attempt of attempts) {
    for (const problem of attempt.problems) {
      if (problem.status === "possible_error") {
        topicCounts.set(problem.reviewTopic, (topicCounts.get(problem.reviewTopic) || 0) + 1);
      }
    }
  }
  const verified = attempts.filter((attempt) => ["correct", "incorrect"].includes(attempt.verification));
  const verifiedCorrect = verified.filter((attempt) => attempt.verification === "correct").length;
  return {
    attempts,
    completedLessons: new Set(attempts.filter((attempt) => attempt.analysisStatus === "ok").map((attempt) => attempt.lessonId)).size,
    totalLessons: lessons.length,
    topicCounts: [...topicCounts.entries()].sort((a, b) => b[1] - a[1]),
    verification: {
      total: verified.length,
      correct: verifiedCorrect,
      incorrect: verified.length - verifiedCorrect,
      accuracy: verified.length ? Math.round((verifiedCorrect / verified.length) * 100) : null,
    },
  };
}
