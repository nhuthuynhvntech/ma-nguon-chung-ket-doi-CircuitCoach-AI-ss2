import { getLesson } from "../data/lessons.js";
import { AI_ERROR_REASONS } from "../data/ai-error-reasons.js";
import { reportProblems } from "../data/attempt-rechecks.js";
import { attemptNumbers } from "./attempt-order.js";

const DANGEROUS_KINDS = new Set(["short_circuit", "power_polarity", "power_ground", "voltage"]);
const UNCLEAR_STATUSES = new Set(["uncertain", "not_visible"]);

export const GROUP_STATUSES = [
  ["not_started", "Chưa bắt đầu"],
  ["submitted", "Đã gửi ảnh"],
  ["retake", "Cần chụp lại"],
  ["error", "Đang có lỗi"],
  ["danger", "Có lỗi nguy hiểm"],
  ["passed", "Đã đạt"],
  ["awaiting_teacher", "Chờ giáo viên kiểm tra"],
];

export const STATUS_LABELS = Object.fromEntries(GROUP_STATUSES);

function newestFirst(a, b) {
  return new Date(b.time || 0) - new Date(a.time || 0);
}

export function deriveGroupState(attempts, roster = []) {
  const grouped = new Map(roster.map((group) => [group.id, { id: group.id, name: group.name, attempts: [] }]));
  attempts.forEach((attempt) => {
    const id = attempt.studentId || "guest";
    if (!grouped.has(id)) grouped.set(id, { id, name: attempt.studentName || `Nhóm ${String(id).slice(0, 4)}`, attempts: [] });
    grouped.get(id).attempts.push(attempt);
  });

  return [...grouped.values()].map((group) => {
    group.attempts.sort(newestFirst);
    const latest = group.attempts[0] || null;
    const reviewed = reportProblems(latest);
    const updatedByRecheck = reviewed.some(problem => problem.recheckId);
    const problems = reviewed.filter(problem => !["correct", "not_applicable"].includes(problem.status)
      && !problem.ruleEvidence?.physicalCheckRequired);
    const dangerous = problems.filter((problem) => problem.category === "safety" && problem.status === "possible_error" && DANGEROUS_KINDS.has(problem.safetyKind));
    const safetyProblems = problems.filter((problem) => problem.category === "safety" && problem.status === "possible_error");
    const unclear = (!updatedByRecheck && latest?.analysisStatus === "insufficient_image")
      || problems.some((problem) => UNCLEAR_STATUSES.has(problem.status));
    const awaitingPhysicalCheck = reviewed.some(problem => problem.ruleEvidence?.physicalCheckRequired);
    const teacherVerification = latest?.teacherVerification || null;
    const aiPassedTeacherFoundError = latest?.verdict === "pass" && (latest?.verification === "incorrect" || teacherVerification === "incorrect");
    let status = "not_started";
    if (latest?.analysisStatus === "submitted") status = "submitted";
    else if (dangerous.length) status = "danger";
    else if (unclear) status = "retake";
    else if (problems.length || aiPassedTeacherFoundError) status = "error";
    else if (latest?.verdict === "pass" && (latest?.teacherStatus === "approved" || teacherVerification === "correct")) status = "passed";
    else if (latest?.verdict === "pass" || awaitingPhysicalCheck || updatedByRecheck) status = "awaiting_teacher";

    let priority = 0;
    let priorityReason = "Theo dõi";
    if (dangerous.length) { priority = 500; priorityReason = "Nguy cơ chập mạch hoặc sai nguồn"; }
    else if (aiPassedTeacherFoundError) { priority = 400; priorityReason = "AI báo đạt nhưng giáo viên phát hiện lỗi"; }
    else if (group.attempts.length >= 3 && latest?.verdict !== "pass" && status !== "awaiting_teacher") { priority = 300 + group.attempts.length; priorityReason = "Thử nhiều lần chưa đạt"; }
    else if (problems.some((problem) => problem.status === "possible_error")) { priority = 250; priorityReason = "Đang có lỗi cần hỗ trợ"; }
    else if (unclear) { priority = 200; priorityReason = "Ảnh chưa đủ rõ"; }
    else if (status === "awaiting_teacher") { priority = 100; priorityReason = "Chờ giáo viên xác nhận"; }

    return {
      ...group,
      latest,
      teacherVerification,
      problems,
      dangerous,
      safetyProblems,
      status,
      priority,
      priorityReason,
      dangerLevel: dangerous.length ? "Khẩn cấp" : safetyProblems.length ? "Cao" : problems.length ? "Trung bình" : "Không",
    };
  }).sort((a, b) => b.priority - a.priority || newestFirst(a.latest || {}, b.latest || {}));
}

export function commonErrors(groups) {
  const counts = new Map();
  groups.forEach((group) => group.problems.forEach((problem) => {
    const current = counts.get(problem.id) || { id: problem.id, label: problem.label, count: 0, dangerous: false };
    current.count += 1;
    current.dangerous ||= problem.category === "safety";
    counts.set(problem.id, current);
  }));
  return [...counts.values()].sort((a, b) => b.count - a.count || a.label.localeCompare(b.label, "vi"));
}

export function deriveAttemptRows(attempts) {
  const numbers = attemptNumbers(attempts);
  return attempts.map(attempt => {
    const [row] = deriveGroupState([attempt]);
    const number = numbers.get(attempt.id);
    if (number >= 3 && row.priority < 300 && attempt.verdict !== "pass" && !["submitted", "awaiting_teacher"].includes(row.status)) {
      row.priority = 300 + number;
      row.priorityReason = "Thử nhiều lần chưa đạt";
    }
    return { ...row, attemptNumber:number };
  }).sort((a, b) => b.priority - a.priority || newestFirst(a.latest,b.latest));
}

export function buildClassReport(attempts = [], roster = []) {
  const groups = deriveGroupState(attempts, roster).filter((group) => group.attempts.length > 0);
  const totalGroups = groups.length;
  const totalAttempts = attempts.length;
  const statusCounts = Object.fromEntries(GROUP_STATUSES.map(([id]) => [id, groups.filter((group) => group.status === id).length]));
  const verificationCounts = { correct: 0, incorrect: 0, uncertain: 0, pending: 0 };
  groups.forEach((group) => {
    const verification = group.latest?.teacherVerification;
    if (verification && Object.hasOwn(verificationCounts, verification)) verificationCounts[verification] += 1;
    else verificationCounts.pending += 1;
  });
  const verifiedGroups = verificationCounts.correct + verificationCounts.incorrect + verificationCounts.uncertain;
  const lessonIds = [...new Set(attempts.map((attempt) => attempt.lessonId))];
  const lessons = lessonIds.map((lessonId) => {
    const lessonAttempts = attempts.filter((attempt) => attempt.lessonId === lessonId);
    const lessonGroups = deriveGroupState(lessonAttempts, roster).filter((group) => group.attempts.length > 0);
    return {
      lessonId,
      title: getLesson(lessonId)?.title || lessonId,
      attempts: lessonAttempts.length,
      groups: lessonGroups.length,
      passed: lessonGroups.filter((group) => group.status === "passed").length,
      awaiting: lessonGroups.filter((group) => group.status === "awaiting_teacher").length,
      needsReview: lessonGroups.filter((group) => ["error", "danger", "retake"].includes(group.status)).length,
      topError: commonErrors(lessonGroups)[0] || null,
    };
  }).sort((a, b) => b.attempts - a.attempts || a.title.localeCompare(b.title, "vi"));
  const safety = {
    dangerousGroups: groups.filter((group) => group.status === "danger").length,
    safetyIssueGroups: groups.filter((group) => group.safetyProblems.length > 0).length,
    unclearGroups: groups.filter((group) => group.status === "retake").length,
    aiErrorsFound: groups.filter((group) => group.latest?.teacherVerification === "incorrect").length,
  };
  const recentAttempts = [...attempts].sort(newestFirst).slice(0, 8).map((attempt) => ({
    id: attempt.id,
    studentName: attempt.studentName || "Nhóm chưa đặt tên",
    lessonId: attempt.lessonId,
    lessonTitle: getLesson(attempt.lessonId)?.title || attempt.lessonId,
    time: attempt.time,
    verdict: attempt.verdict || "review",
    analysisStatus: attempt.analysisStatus || "ok",
    teacherVerification: attempt.teacherVerification || null,
  }));
  const aiErrors = new Map();
  for (const attempt of attempts) {
    const error = attempt.teacherAiError;
    if (attempt.demo || attempt.teacherVerification !== "incorrect" || !error || !Object.hasOwn(AI_ERROR_REASONS,error.reason)) continue;
    const lesson = getLesson(attempt.lessonId);
    const criterion = lesson?.checks.find(([id]) => id === error.criterionId)?.[1];
    if (!criterion) continue;
    const key = [lesson.id,error.criterionId,error.reason].join(":");
    const row = aiErrors.get(key) || { lesson:lesson.title, criterion, reason:AI_ERROR_REASONS[error.reason], count:0 };
    row.count += 1;
    aiErrors.set(key,row);
  }
  return {
    totalGroups,
    totalAttempts,
    statusCounts,
    verificationCounts,
    passRate: totalGroups ? Math.round(((statusCounts.passed || 0) / totalGroups) * 100) : 0,
    verificationRate: totalGroups ? Math.round((verifiedGroups / totalGroups) * 100) : 0,
    lessons,
    commonErrors: commonErrors(groups),
    aiErrors: [...aiErrors.values()].sort((a,b) => b.count - a.count || a.lesson.localeCompare(b.lesson,"vi")),
    safety,
    recentAttempts,
    generatedAt: new Date().toISOString(),
  };
}

export function demoClassData() {
  const now = Date.now();
  const problem = (id, label, safetyKind, status = "possible_error") => ({ id, label, status, category: safetyKind ? "safety" : "standard", safetyKind: safetyKind || null });
  const attempt = (id, studentId, studentName, lessonId, minutes, verdict, problems, extra = {}) => ({ id, studentId, studentName, lessonId, time: new Date(now - minutes * 60_000).toISOString(), analysisStatus: "ok", verdict, problems, demo: true, ...extra });
  return {
    roster: [{ id: "demo-a1", name: "Nhóm A1" }, { id: "demo-a2", name: "Nhóm A2" }, { id: "demo-a3", name: "Nhóm A3" }, { id: "demo-a4", name: "Nhóm A4" }, { id: "demo-a5", name: "Nhóm A5" }, { id: "demo-a6", name: "Nhóm A6" }],
    attempts: [
      attempt("d1", "demo-a1", "Nhóm A1", "led", 3, "review", [problem("no_short_circuit", "Nguy cơ chập mạch", "short_circuit")]),
      attempt("d2", "demo-a2", "Nhóm A2", "battery-led-switch", 7, "pass", [], { teacherVerification: "incorrect", teacherVerificationNote: "Công tắc chưa nằm trong mạch nối tiếp.", teacherVerifiedBy: "GV", teacherVerifiedAt: new Date(now - 6 * 60_000).toISOString() }),
      attempt("d3", "demo-a3", "Nhóm A3", "hcsr04", 12, "review", [problem("trig_connection", "Kết nối TRIG", null)]),
      attempt("d4", "demo-a3", "Nhóm A3", "hcsr04", 22, "review", [problem("trig_connection", "Kết nối TRIG", null)]),
      attempt("d5", "demo-a3", "Nhóm A3", "hcsr04", 35, "review", [problem("trig_connection", "Kết nối TRIG", null)]),
      attempt("d6", "demo-a4", "Nhóm A4", "servo", 16, "review", [problem("signal_connection", "Kết nối Signal", null, "uncertain")]),
      attempt("d7", "demo-a5", "Nhóm A5", "led", 20, "pass", [], { teacherStatus: "approved", teacherVerification: "correct", teacherVerificationNote: "Đã kiểm tra trực tiếp, mạch đúng.", teacherVerifiedBy: "GV", teacherVerifiedAt: new Date(now - 18 * 60_000).toISOString() }),
    ],
  };
}
