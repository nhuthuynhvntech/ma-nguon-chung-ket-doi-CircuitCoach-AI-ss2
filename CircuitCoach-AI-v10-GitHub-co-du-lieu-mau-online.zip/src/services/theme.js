const THEME_KEY = "circuitcoach.theme";

function currentTheme() {
  return globalThis.document?.documentElement.dataset.theme === "light" ? "light" : "dark";
}

export function themeSwitchLabel() {
  return currentTheme() === "light" ? "Chuyển sang giao diện tối" : "Chuyển sang giao diện sáng";
}

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  const background = getComputedStyle(document.documentElement).getPropertyValue("--bg").trim();
  if (background) document.querySelector('meta[name="theme-color"]')?.setAttribute("content", background);
  const label = themeSwitchLabel();
  document.querySelectorAll("[data-theme-toggle]").forEach(button => {
    button.setAttribute("aria-label", label);
    button.title = label;
  });
}

export function initializeTheme() {
  applyTheme(currentTheme());
  document.addEventListener("click", (event) => {
    if (!(event.target instanceof Element) || !event.target.closest("[data-theme-toggle]")) return;
    const theme = currentTheme() === "light" ? "dark" : "light";
    applyTheme(theme);
    try { localStorage.setItem(THEME_KEY, theme); } catch {}
  });
  window.addEventListener("storage", (event) => {
    if (event.key === THEME_KEY) applyTheme(event.newValue === "light" ? "light" : "dark");
  });
}
