export function attemptNumbers(attempts) {
  const numbers = new Map();
  const counts = new Map();
  const sorted = [...attempts].sort((a, b) =>
    (Date.parse(a.time) || 0) - (Date.parse(b.time) || 0) || String(a.id).localeCompare(String(b.id)));
  for (const attempt of sorted) {
    const student = (attempt.studentName || attempt.studentId || "").trim().normalize("NFC").toLowerCase();
    const key = JSON.stringify([attempt.classCode || "",student,attempt.lessonId]);
    const number = (counts.get(key) || 0) + 1;
    counts.set(key, number);
    numbers.set(attempt.id,number);
  }
  return numbers;
}
