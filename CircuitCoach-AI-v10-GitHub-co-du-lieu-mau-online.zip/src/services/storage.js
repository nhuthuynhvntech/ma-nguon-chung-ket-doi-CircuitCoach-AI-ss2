export const STUDENT_SESSION_KEY = "circuitcoach.student";

const KEYS = {
  student: STUDENT_SESSION_KEY,
  attempts: "circuitcoach.attempts",
  tutorCache: "circuitcoach.tutor-cache",
};

function read(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key)) ?? fallback;
  } catch {
    return fallback;
  }
}

function write(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
  return value;
}

export function getStudent() {
  return read(KEYS.student, null);
}

function groupName(name) {
  return String(name || "").trim().normalize("NFC").toLowerCase();
}

export function sameStudentGroup(first, second) {
  return Boolean(first && second
    && String(first.classCode || "").trim().toUpperCase() === String(second.classCode || "").trim().toUpperCase()
    && groupName(first.studentName ?? first.name) === groupName(second.studentName ?? second.name));
}

function storedAttempts() {
  const attempts = read(KEYS.attempts, []);
  return Array.isArray(attempts) ? attempts : [];
}

export function saveStudent(name, classCode = "", members = [], syncedStudentId) {
  const group = { name, classCode };
  const previous = getStudent();
  const current = sameStudentGroup(previous, group) ? previous : null;
  const saved = storedAttempts().find(attempt => sameStudentGroup(attempt, group));
  const names = members?.length ? members : current?.members || saved?.teamMembers || [];
  return write(KEYS.student, {
    id: syncedStudentId || current?.id || saved?.studentId || crypto.randomUUID(),
    name,
    classCode: String(classCode || "").trim().toUpperCase(),
    members: [...new Set((Array.isArray(names) ? names : []).map((member) => String(member).trim()).filter(Boolean))].slice(0, 3),
    createdAt: current?.createdAt || new Date().toISOString(),
  });
}

export async function logoutStudent() {
  clearStudentSession();
  await fetch("/api/classroom/student-group", { method: "DELETE", keepalive: true, signal: AbortSignal.timeout(1500) }).catch(() => {});
}

export function clearStudentSession() {
  localStorage.removeItem(KEYS.student);
}

export function getAttempts() {
  const student = getStudent();
  return student ? storedAttempts().filter(attempt => sameStudentGroup(attempt, student)) : [];
}

function importStudentAttempts(attempts) {
  if (!attempts.length) return;
  const merged = new Map(storedAttempts().map(attempt => [attempt.id, attempt]));
  attempts.forEach(attempt => merged.set(attempt.id, attempt));
  write(KEYS.attempts, [...merged.values()].sort((a,b) => String(b.time).localeCompare(String(a.time))));
}

export function restoreStudentAttempt(attempt) {
  if (!sameStudentGroup(attempt, getStudent())) return null;
  importStudentAttempts([attempt]);
  return attempt;
}

export async function enterStudentGroup(name, classCode, members) {
  if (!classCode) return saveStudent(name, classCode, members);
  const response = await fetch("/api/classroom/student-group", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ name, classCode }),
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Không thể mở nhóm.");
  const attempts = (Array.isArray(data.attempts) ? data.attempts : []).filter(attempt => sameStudentGroup(attempt, { name, classCode }));
  importStudentAttempts(attempts);
  return saveStudent(name, classCode, members, attempts[0]?.studentId || data.studentId);
}

export function saveAttempt({ lessonId, result, demo }) {
  const student = getStudent();
  const attempt = {
    id: crypto.randomUUID(),
    studentId: student?.id || "guest",
    studentName: student?.name || "Nhóm chưa đặt tên",
    teamMembers: student?.members || [],
    classCode: student?.classCode || "",
    lessonId,
    time: new Date().toISOString(),
    analysisStatus: result.analysisStatus,
    ...(typeof result.analysisModel === "string" && !demo ? { analysisModel: result.analysisModel } : {}),
    ...(["direct_only", "single_read"].includes(result.evidencePolicy) && !demo ? { evidencePolicy: result.evidencePolicy } : {}),
    summary: result.summary,
    verdict: result.verdict || "review",
    safety: result.safety || null,
    captureAdvice: result.captureAdvice || [],
    ...(result.analysisContext ? { analysisContext: result.analysisContext } : {}),
    demo: Boolean(demo),
    problems: result.checks.map(({
      id, criterionId, label, status, certainty, confidence, imageIndex, region, regionRefinement, reviewArea, ruleEvidence, photoReviews,
      evidence, reviewTopic, category, safetyKind,
    }) => ({
      id: id || criterionId,
      criterionId: criterionId || id,
      label,
      status,
      certainty,
      confidence: Number.isFinite(confidence) ? confidence : 0,
      imageIndex: Number.isInteger(imageIndex) ? imageIndex : null,
      region: region || null,
      ...(regionRefinement ? { regionRefinement } : {}),
      ...(ruleEvidence ? { ruleEvidence } : {}),
      ...(reviewArea ? { reviewArea } : {}),
      ...(Array.isArray(photoReviews) && photoReviews.length ? { photoReviews } : {}),
      evidence,
      reviewTopic,
      category: category || "standard",
      safetyKind: safetyKind || null,
    })),
    verification: null,
    teacherSafetyCheck: null,
    teacherSafetyNote: "",
    teacherSafetyCheckedBy: null,
    teacherSafetyCheckedAt: null,
    teacherPhysicallyChecked: false,
  };
  write(KEYS.attempts, [attempt, ...storedAttempts()]);
  return attempt;
}

function updateAttempt(attemptId, fields) {
  const student = getStudent();
  let saved;
  const updated = storedAttempts().map(attempt => {
    if (attempt.id !== attemptId || !sameStudentGroup(attempt, student)) return attempt;
    saved = { ...attempt, ...fields };
    return saved;
  });
  if (!saved) return undefined;
  write(KEYS.attempts, updated);
  return saved;
}

export function updateVerification(attemptId, verification) {
  return updateAttempt(attemptId, { verification });
}

export function updateTeacherStatus(attemptId, teacherStatus) {
  return updateAttempt(attemptId, { teacherStatus });
}

export function updateTeacherVerification(attemptId, verification = {}) {
  return updateAttempt(attemptId, verification);
}

export function cacheAttemptRechecks(attemptId, latestRechecks) {
  return updateAttempt(attemptId, { latestRechecks });
}

export function getAttempt(id) {
  return getAttempts().find((attempt) => attempt.id === id) || null;
}

export function getPreviousAttempt(current) {
  return getAttempts().find((attempt) => attempt.lessonId === current.lessonId && attempt.id !== current.id) || null;
}

export function getCachedHint(key) {
  return read(KEYS.tutorCache, {})[key] || null;
}

export function cacheHint(key, value) {
  const cache = read(KEYS.tutorCache, {});
  cache[key] = value;
  write(KEYS.tutorCache, cache);
}

export function resetLearningData() {
  const student = getStudent();
  write(KEYS.attempts, storedAttempts().filter(attempt => !sameStudentGroup(attempt, student)));
}
