const attemptImages = new Map();
const MAX_SESSION_ATTEMPTS = 10;

function revoke(images = []) {
  images.forEach((image) => URL.revokeObjectURL(image.url));
}

export function setAttemptImages(attemptId, files) {
  const previous = attemptImages.get(attemptId);
  if (previous) revoke(previous);
  attemptImages.set(attemptId, [...files].slice(0, 3).map((file, index) => ({
    index,
    name: file.name || `Ảnh mạch ${index + 1}`,
    file,
    url: URL.createObjectURL(file),
  })));
  while (attemptImages.size > MAX_SESSION_ATTEMPTS) {
    const oldestId = attemptImages.keys().next().value;
    revoke(attemptImages.get(oldestId));
    attemptImages.delete(oldestId);
  }
}

export function getAttemptImages(attemptId) {
  return attemptImages.get(attemptId) || [];
}
