const DATABASE_NAME = "circuitcoach-reference-library";
const STORE_NAME = "approved-images";
const DATABASE_VERSION = 1;

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains(STORE_NAME)) {
        const store = database.createObjectStore(STORE_NAME, { keyPath: "id" });
        store.createIndex("lessonId", "lessonId", { unique: false });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(new Error("Không thể mở thư viện ảnh chuẩn trên thiết bị."));
  });
}

function runTransaction(mode, operation) {
  return openDatabase().then((database) => new Promise((resolve, reject) => {
    const transaction = database.transaction(STORE_NAME, mode);
    const store = transaction.objectStore(STORE_NAME);
    let result;
    try { result = operation(store); } catch (error) { reject(error); return; }
    transaction.oncomplete = () => { database.close(); resolve(result?.result); };
    transaction.onerror = () => { database.close(); reject(new Error("Không thể cập nhật thư viện ảnh chuẩn.")); };
  }));
}

export async function listReferenceImages(lessonId) {
  const database = await openDatabase();
  return new Promise((resolve, reject) => {
    const transaction = database.transaction(STORE_NAME, "readonly");
    const request = transaction.objectStore(STORE_NAME).index("lessonId").getAll(lessonId);
    request.onsuccess = () => resolve(request.result.sort((a, b) => a.createdAt - b.createdAt));
    request.onerror = () => reject(new Error("Không thể đọc ảnh chuẩn của bài học."));
    transaction.oncomplete = () => database.close();
  });
}

export function getBuiltInReferenceImages(lesson) {
  return (lesson?.referenceImages || []).slice(0, 3).map((image, index) => ({
    id: `${lesson.id}-built-in-${index + 1}`,
    lessonId: lesson.id,
    name: `${lesson.id}-reference-${index + 1}.jpg`,
    type: "image/jpeg",
    src: image.src,
    label: image.label,
    crop: image.crop,
    approved: true,
    builtIn: true,
    createdAt: index,
  }));
}

export function mergeReferenceImages(lesson, customRecords = []) {
  const custom = customRecords.slice(0, 3);
  return [...custom, ...getBuiltInReferenceImages(lesson).slice(custom.length)].slice(0, 3);
}

export async function saveReferenceImage({ lessonId, file }) {
  const existing = await listReferenceImages(lessonId);
  if (existing.length >= 3) throw new Error("Mỗi bài học chỉ lưu tối đa 3 ảnh chuẩn.");
  const record = {
    id: `${lessonId}-${Date.now()}-${crypto.randomUUID()}`,
    lessonId,
    name: file.name,
    type: file.type,
    blob: file,
    approved: true,
    createdAt: Date.now(),
  };
  await runTransaction("readwrite", (store) => store.add(record));
  return record;
}

export function deleteReferenceImage(id) {
  return runTransaction("readwrite", (store) => store.delete(id));
}

function rasterizeBuiltInReference(record) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => {
      const crop = record.crop || { x: 0, y: 0, width: 1, height: 1 };
      const canvas = document.createElement("canvas");
      canvas.width = 960;
      canvas.height = 720;
      const context = canvas.getContext("2d");
      context.fillStyle = "#f4f5f6";
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.drawImage(
        image,
        crop.x * image.naturalWidth,
        crop.y * image.naturalHeight,
        crop.width * image.naturalWidth,
        crop.height * image.naturalHeight,
        0,
        0,
        canvas.width,
        canvas.height,
      );
      canvas.toBlob((blob) => blob
        ? resolve(new File([blob], record.name, { type: "image/jpeg" }))
        : reject(new Error("Không thể chuẩn bị ảnh mạch mẫu.")), "image/jpeg", 0.9);
    };
    image.onerror = () => reject(new Error("Không thể tải ảnh mạch mẫu."));
    image.src = record.src;
  });
}

export async function referenceRecordToFile(record) {
  if (record.builtIn) return rasterizeBuiltInReference(record);
  return new File([record.blob], record.name || "approved-reference.jpg", { type: record.type || "image/jpeg" });
}
