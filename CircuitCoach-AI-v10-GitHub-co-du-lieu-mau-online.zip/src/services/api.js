import { getKnowledge } from "../data/knowledge-base.js";
import { getLesson } from "../data/lessons.js";

async function parseResponse(response) {
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error?.message || "Không thể kết nối tới CircuitCoach.");
    error.code = data.error?.code || "NETWORK_ERROR";
    throw error;
  }
  return data;
}

export async function getHealth() {
  return parseResponse(await fetch("/api/health"));
}

export async function analyzeImages({ lessonId, files, referenceFiles = [], demo, classCode, studentName, analysisModel }) {
  if (demo) {
    const lesson = getLesson(lessonId);
    const demoStates = {
      led: { resistor_present: "possible_error", power_connection: "uncertain" },
      hcsr04: { trig_connection: "possible_error", echo_connection: "uncertain" },
      servo: { signal_connection: "possible_error", power_voltage: "uncertain" },
      "battery-led-switch": { switch_in_series: "possible_error", battery_polarity: "uncertain" },
      "soil-moisture": { probe_connection: "possible_error", moisture_signal_connection: "uncertain" },
    };
    await new Promise((resolve) => setTimeout(resolve, 650));
    const checks = lesson.checks.map(([id, label, category]) => {
      const status = demoStates[lessonId][id] || "correct";
      return {
        id,
        criterionId: id,
        label,
        category,
        status,
        certainty: status === "correct" ? "high" : status === "possible_error" ? "medium" : "low",
        confidence: status === "correct" ? 0.94 : status === "possible_error" ? 0.86 : 0.42,
        imageIndex: null,
        region: null,
        evidence: status === "correct" ? `Trong dữ liệu mô phỏng, ${label.toLowerCase()} phù hợp với mạch chuẩn.` : status === "possible_error" ? `Dữ liệu mô phỏng cho thấy ${label.toLowerCase()} cần được học sinh kiểm tra lại.` : `Chưa nhìn rõ ${label.toLowerCase()}; hãy chụp cận cảnh bộ phận này và không để dây bị che.`,
        reviewTopic: getKnowledge(id).topic,
      };
    });
    const safetyChecks = checks.filter((check) => check.category === "safety");
    const unknownSafety = safetyChecks.filter((check) => ["uncertain", "not_visible"].includes(check.status));
    const failedSafety = safetyChecks.filter((check) => check.status !== "correct" && !["uncertain", "not_visible"].includes(check.status));
    const allSafetyPassed = safetyChecks.every((check) => check.status === "correct");
    const allChecksPassed = checks.every((check) => check.status === "correct" || check.status === "not_applicable");
    return {
      analysisStatus: "ok",
      lessonId,
      summary: "Bản mô phỏng đã kiểm tra riêng từng tiêu chí để minh họa giao diện và luồng học tập.",
      checks,
      verdict: allSafetyPassed && allChecksPassed ? "pass" : "review",
      safety: {
        imageQualitySufficient: unknownSafety.length === 0,
        allSafetyPassed,
        failedIds: failedSafety.map((check) => check.id),
        unknownIds: unknownSafety.map((check) => check.id),
        teacherCheckRequired: allSafetyPassed && allChecksPassed,
      },
      captureAdvice: lessonId === "battery-led-switch"
        ? ["Chụp từ trên xuống để nhìn rõ toàn bộ vòng mạch.", "Chụp cận cảnh cực pin và các chân công tắc."]
        : ["Chụp từ trên xuống để nhìn rõ đường dây.", "Chụp thêm cận cảnh nhãn chân Arduino."],
      demo: true,
    };
  }
  const form = new FormData();
  form.set("lessonId", lessonId);
  form.set("demo", "false");
  if (analysisModel) form.set("analysisModel", analysisModel);
  if (classCode && studentName) {
    form.set("classCode", classCode);
    form.set("studentName", studentName);
  }
  files.forEach((file) => form.append("images", file, file.name));
  referenceFiles.forEach((file) => form.append("referenceImages", file, file.name));
  const controller = new AbortController();
  const local = ["127.0.0.1", "localhost"].includes(globalThis.location?.hostname);
  const timer = setTimeout(() => controller.abort(), local ? 82_000 : 70_000);
  try {
    return await parseResponse(await fetch("/api/analyze", { method: "POST", body: form, signal: controller.signal }));
  } catch (error) {
    if (error.name === "AbortError") {
      throw new Error("Phân tích mất quá nhiều thời gian. Vui lòng thử lại.");
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

export async function requestTutorHint(payload, demo) {
  return parseResponse(await fetch(`/api/tutor${demo ? "?demo=true" : ""}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  }));
}

async function requestGuide(path, payload, signal) {
  return parseResponse(await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
    signal,
  }));
}

export function requestGuideChat(payload, signal) {
  return requestGuide("/api/guide-chat", payload, signal);
}

export function requestStudentGuide(payload, signal) {
  return requestGuide("/api/guide-chat/history", payload, signal);
}
