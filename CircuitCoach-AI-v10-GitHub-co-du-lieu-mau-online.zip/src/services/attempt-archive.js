const DATABASE_NAME = "circuitcoach-attempt-archive";
const STORE_NAME = "attempt-images";
const DATABASE_VERSION = 1;

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains(STORE_NAME)) {
        const store = database.createObjectStore(STORE_NAME, { keyPath: "attemptId" });
        store.createIndex("lessonId", "lessonId", { unique: false });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(new Error("Không thể mở thư mục lưu ảnh lịch sử trên thiết bị."));
  });
}

export async function saveAttemptImages(attemptId, lessonId, files) {
  if (!attemptId || !lessonId || !files?.length) return false;
  const database = await openDatabase();
  return new Promise((resolve, reject) => {
    const transaction = database.transaction(STORE_NAME, "readwrite");
    transaction.objectStore(STORE_NAME).put({
      attemptId,
      lessonId,
      savedAt: Date.now(),
      images: [...files].slice(0, 3).map((file, index) => ({
        index,
        name: file.name || `anh-mach-${index + 1}.jpg`,
        type: file.type || "image/jpeg",
        blob: file,
      })),
    });
    transaction.oncomplete = () => { database.close(); resolve(true); };
    transaction.onerror = () => { database.close(); reject(new Error("Không thể lưu ảnh vào thư mục lịch sử.")); };
  });
}

export async function getAttemptImages(attemptId) {
  const database = await openDatabase();
  return new Promise((resolve, reject) => {
    const transaction = database.transaction(STORE_NAME, "readonly");
    const request = transaction.objectStore(STORE_NAME).get(attemptId);
    request.onsuccess = () => {
      const record = request.result;
      resolve((record?.images || []).map((image) => ({
        ...image,
        url: URL.createObjectURL(image.blob),
      })));
    };
    request.onerror = () => reject(new Error("Không thể đọc ảnh lịch sử."));
    transaction.oncomplete = () => database.close();
  });
}

export async function clearAttemptImageArchive() {
  const database = await openDatabase();
  return new Promise((resolve, reject) => {
    const transaction = database.transaction(STORE_NAME, "readwrite");
    transaction.objectStore(STORE_NAME).clear();
    transaction.oncomplete = () => { database.close(); resolve(); };
    transaction.onerror = () => { database.close(); reject(new Error("Không thể xóa ảnh lịch sử.")); };
  });
}
