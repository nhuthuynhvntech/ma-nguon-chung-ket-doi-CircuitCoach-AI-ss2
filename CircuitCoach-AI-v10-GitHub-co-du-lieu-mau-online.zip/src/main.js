import "./style.css";
import { createRouter } from "./router.js";
import { clearStudentSession, logoutStudent } from "./services/storage.js";
import { clearTeacherPassword, getBrowserSession, notifyBrowserSessionChange, setBrowserSession, signOutBrowserSession, withBrowserSessionLock } from "./services/classroom.js";
import { showToast } from "./views/shared.js";
import { initializeTheme } from "./services/theme.js";
import { initializeGuideChat } from "./views/guide-chat.js";

initializeTheme();
initializeGuideChat();
const root = document.querySelector("#app");
const route = createRouter(root);
document.addEventListener("click", async (event) => {
  const button = event.target.closest("[data-browser-logout]");
  if (!button || button.disabled) return;
  button.disabled = true;
  try {
    await withBrowserSessionLock(async () => {
      if (getBrowserSession()) {
        setBrowserSession(await signOutBrowserSession());
        clearStudentSession();
        clearTeacherPassword();
      } else await logoutStudent();
      notifyBrowserSessionChange();
    });
    if (location.hash === "#/home") void route();
    else location.hash = "#/home";
    showToast("Đã đăng xuất. Bạn có thể chọn vai trò mới.", "success");
  } catch (error) {
    showToast(error.message, "error");
    button.disabled = false;
  }
});
