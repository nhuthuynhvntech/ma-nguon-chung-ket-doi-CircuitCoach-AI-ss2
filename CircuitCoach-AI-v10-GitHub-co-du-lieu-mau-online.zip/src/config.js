export const APP_NAME = "CircuitCoach AI";
export const MAX_IMAGES = 3;
export const MAX_IMAGE_EDGE = 1600;
export const JPEG_QUALITY = 0.86;
export const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"];
export const STATUS_LABELS = {
  correct: "Đúng",
  possible_error: "Cần kiểm tra",
  uncertain: "Chưa xác định",
  not_visible: "Không nhìn thấy",
  not_applicable: "Không áp dụng",
};
export const CERTAINTY_LABELS = {
  high: "Cao",
  medium: "Trung bình",
  low: "Thấp",
};
export const TEACHER_VERIFICATION_OPTIONS = {
  correct: "AI đúng",
  incorrect: "AI sai",
  uncertain: "Chưa chắc",
};
export const TEACHER_VERIFICATION_LABELS = {
  correct: "Giáo viên xác nhận AI đúng",
  incorrect: "Giáo viên báo AI sai",
  uncertain: "Giáo viên chưa chắc",
};
export const TEACHER_VERIFICATION_DESCRIPTIONS = {
  correct: "Kết quả AI khớp với mạch thực tế giáo viên đã kiểm tra.",
  incorrect: "AI kết luận chưa đúng so với mạch thực tế.",
  uncertain: "Giáo viên cần thêm ảnh hoặc kiểm tra trực tiếp.",
};
