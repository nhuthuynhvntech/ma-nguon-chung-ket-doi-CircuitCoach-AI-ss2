export const SAFETY_WARNING = "AI chỉ hỗ trợ quan sát qua hình ảnh và có thể chưa chính xác hoàn toàn. Cần giáo viên xác nhận trước khi cắm nguồn.";

export const POWER_GUIDANCE = [
  "Giữ nguồn ở trạng thái ngắt trong khi kiểm tra hoặc chỉnh dây.",
  "Nhờ giáo viên đối chiếu cực nguồn, điện trở và đường GND trên mạch thật.",
  "Chỉ cấp nguồn sau khi giáo viên xác nhận; ngắt nguồn ngay nếu linh kiện nóng, có mùi lạ hoặc hoạt động bất thường.",
];
