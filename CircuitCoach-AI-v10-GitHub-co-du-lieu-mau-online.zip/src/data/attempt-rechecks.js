export function latestCriterionRechecks(entries) {
  const latest = new Map();
  for (const entry of entries) {
    const previous = latest.get(entry.criterionId);
    if (!previous || entry.createdAt > previous.createdAt || (entry.createdAt === previous.createdAt && entry.id > previous.id)) {
      latest.set(entry.criterionId, entry);
    }
  }
  return latest;
}

export function reportProblems(attempt, entries = attempt?.latestRechecks || []) {
  const latest = latestCriterionRechecks(entries);
  return (attempt?.problems || []).map(problem => {
    const entry = latest.get(problem.id || problem.criterionId);
    if (!entry || !["possible_error", "uncertain", "not_visible"].includes(problem.status)
      || problem.ruleEvidence?.physicalCheckRequired) return problem;
    return { ...problem, ...entry.check, category: problem.category, safetyKind: problem.safetyKind,
      imageIndex: null, region: null, recheckId: entry.id };
  });
}

export function reportSummary(attempt, problems = reportProblems(attempt)) {
  const added = problems.filter(problem => problem.recheckId && problem.status === "correct");
  const hasRechecks = problems.some(problem => problem.recheckId);
  if (!hasRechecks) return attempt.summary;
  const waiting = problems.filter(problem => !problem.ruleEvidence?.physicalCheckRequired
    && !["correct", "not_applicable"].includes(problem.status));
  const lines = [];
  if (added.length) lines.push(`Kiểm tra lại đã xác nhận đúng ${added.map(problem => problem.label).join(", ")}.`);
  if (waiting.length) lines.push(`Còn cần đối chiếu ${waiting.map(problem => problem.label).join(", ")}.`);
  if (problems.some(problem => problem.ruleEvidence?.physicalCheckRequired)) {
    lines.push("Giáo viên kiểm tra mạch thật trước khi cấp nguồn.");
  }
  return lines.join(" ");
}
