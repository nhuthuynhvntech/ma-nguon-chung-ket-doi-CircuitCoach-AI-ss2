export const assemblyGuides = {
  led: {
    columns: [
      [{ name: "Arduino Uno", ports: [["d8", "D8"], ["gnd", "GND"]] }],
      [
        { name: "Điện trở", detail: "220–330 Ω", ports: [["r1", "Đầu 1"], ["r2", "Đầu 2"]] },
        { name: "LED", ports: [["anode", "Anode (+)"], ["cathode", "Cathode (−)"]] },
      ],
    ],
    steps: [
      { title: "Nối D8 với điện trở", detail: "Chọn điện trở 220–330 Ω. Cắm hai đầu vào hai nhóm lỗ khác nhau trên breadboard, rồi đưa dây từ D8 đến một đầu điện trở.", check: "Dây D8 và đầu điện trở cần nối nằm trong cùng nhóm lỗ thông nhau.", wires: [["d8", "r1", "signal"]] },
      { title: "Nối điện trở với chân dương LED", detail: "Xác định Anode (+) theo ký hiệu của LED. Nối chân này vào đầu điện trở còn trống.", check: "Dây từ D8 và chân Anode nằm ở hai phía của điện trở.", wires: [["r2", "anode", "signal"]] },
      { title: "Nối chân âm LED về GND", detail: "Nối Cathode (−) của LED đến một chân ghi GND trên Arduino Uno.", check: "Lần theo đường D8 → điện trở → LED → GND trong khi nguồn vẫn ngắt.", wires: [["cathode", "gnd", "ground"]] },
    ],
  },
  hcsr04: {
    columns: [
      [{ name: "Arduino Uno", ports: [["five", "5V"], ["gnd", "GND"], ["d9", "D9"], ["d10", "D10"]] }],
      [{ name: "HC-SR04", ports: [["vcc", "VCC"], ["sensorGnd", "GND"], ["trig", "TRIG"], ["echo", "ECHO"]] }],
    ],
    steps: [
      { title: "Nối chân nguồn VCC", detail: "Tìm chữ VCC in trên HC-SR04. Nối chân đó với chân ghi 5V ở cụm nguồn của Arduino Uno.", check: "Đọc lại nhãn ở hai đầu dây. Một đầu là VCC, đầu kia là 5V.", wires: [["vcc", "five", "power"]] },
      { title: "Nối GND chung", detail: "Dùng một dây riêng nối GND của cảm biến với một chân GND trên Arduino.", check: "Hai đầu của dây này đều ở chân ghi GND.", wires: [["sensorGnd", "gnd", "ground"]] },
      { title: "Nối dây TRIG", detail: "Tìm chân ghi TRIG cạnh cụm chân cảm biến rồi nối đến chân số 9 (D9) trên Arduino.", check: "Lần theo dây từ chữ TRIG đến chân số 9.", wires: [["trig", "d9", "signal"]] },
      { title: "Nối dây ECHO", detail: "Nối chân ECHO đến chân số 10 (D10) trên Arduino.", check: "Đọc từng cặp chân để kiểm tra lần cuối. TRIG đi D9 và ECHO đi D10.", wires: [["echo", "d10", "probe"]] },
    ],
  },
  servo: {
    note: "Sơ đồ của bài dùng servo nhỏ tương thích 5 V. Giáo viên kiểm tra nguồn có đủ dòng cho servo trước khi cấp nguồn.",
    columns: [
      [{ name: "Arduino Uno", ports: [["five", "5V"], ["gnd", "GND"], ["d6", "D6"]] }],
      [{ name: "Servo", ports: [["vcc", "VCC"], ["servoGnd", "GND"], ["signal", "Signal"]] }],
    ],
    steps: [
      { title: "Xác định và nối dây nguồn", detail: "Tra sơ đồ chân của servo trong bộ linh kiện. Với servo 5 V của bài, đưa dây VCC tới chân 5V.", check: "Xác nhận vị trí VCC theo tài liệu của servo trước khi gắn dây.", wires: [["vcc", "five", "power"]] },
      { title: "Nối GND chung", detail: "Tìm dây GND trên đầu cắm servo và đưa dây đó về GND của Arduino.", check: "Đối chiếu lại vị trí hai dây nguồn và GND ở đầu cắm servo.", wires: [["servoGnd", "gnd", "ground"]] },
      { title: "Nối dây tín hiệu", detail: "Nối dây Signal còn lại đến chân số 6 (D6) trên Arduino.", check: "Lần theo dây Signal đến D6 rồi nhờ giáo viên kiểm tra cả ba dây.", wires: [["signal", "d6", "signal"]] },
    ],
  },
  "battery-led-switch": {
    note: "Giữ pin tách khỏi mạch trong lúc lắp. Mở công tắc trước khi giáo viên kiểm tra các đầu nối với pin.",
    columns: [
      [
        { name: "Đầu nối pin", detail: "9 V", ports: [["positive", "Cực +"], ["negative", "Cực −"]] },
        { name: "Công tắc", ports: [["switchIn", "Đầu 1"], ["switchOut", "Đầu 2"]] },
      ],
      [
        { name: "Điện trở", detail: "330 Ω–1 kΩ", ports: [["r1", "Đầu 1"], ["r2", "Đầu 2"]] },
        { name: "LED", ports: [["anode", "Anode (+)"], ["cathode", "Cathode (−)"]] },
      ],
    ],
    steps: [
      { title: "Nối đầu dương với điện trở", detail: "Giữ pin tách khỏi đầu nối. Dùng điện trở 330 Ω–1 kΩ và nối một đầu với dây từ cực dương của đầu nối pin.", check: "Dây dương đi tới điện trở và đầu nối vẫn chưa gắn pin.", wires: [["positive", "r1", "power"]] },
      { title: "Nối điện trở với chân dương LED", detail: "Xác định Anode (+) theo ký hiệu của LED. Nối Anode vào đầu điện trở còn trống.", check: "Lần theo dây từ đầu nối dương qua điện trở rồi tới Anode.", wires: [["r2", "anode", "signal"]] },
      { title: "Đưa chân âm LED qua công tắc", detail: "Nối Cathode (−) của LED với một đầu của công tắc hai chân trong bài. Đặt công tắc ở vị trí mở.", check: "Chân Cathode nối vào một đầu công tắc và đầu kia còn trống.", wires: [["cathode", "switchIn", "probe"]] },
      { title: "Nối công tắc về dây âm", detail: "Nối đầu công tắc còn trống với dây âm của đầu nối pin. Giữ pin tách khỏi mạch để giáo viên kiểm tra.", check: "Lần theo đường từ dây dương qua điện trở, LED, công tắc rồi về dây âm.", wires: [["switchOut", "negative", "ground"]] },
    ],
  },
  "soil-moisture": {
    columns: [
      [
        { name: "Arduino Uno", ports: [["five", "5V"], ["gnd", "GND"], ["a0", "A0"]] },
        { name: "Đầu dò", ports: [["probeOne", "Dây 1"], ["probeTwo", "Dây 2"]] },
      ],
      [{ name: "Module độ ẩm", ports: [["vcc", "VCC"], ["moduleGnd", "GND"], ["analog", "A0 / AO"], ["probePortOne", "Cổng dò 1"], ["probePortTwo", "Cổng dò 2"]] }],
    ],
    steps: [
      { title: "Nối nguồn cho module", detail: "Kiểm tra module trong bộ linh kiện hỗ trợ 5 V. Nối chân VCC của module với 5V trên Arduino Uno.", check: "Dây nguồn đi từ chân 5V tới chân ghi VCC ở cụm chân của module.", wires: [["vcc", "five", "power"]] },
      { title: "Nối GND chung", detail: "Dùng dây riêng nối GND của module với GND của Arduino.", check: "Cả hai đầu dây đều cắm ở chân ghi GND.", wires: [["moduleGnd", "gnd", "ground"]] },
      { title: "Nối tín hiệu analog", detail: "Tìm ngõ analog ghi AO hoặc A0 trên module. Nối ngõ này đến chân A0 trong cụm analog của Arduino.", check: "Đầu dây ở module nằm tại AO hoặc A0. Đầu dây ở Arduino nằm tại A0.", wires: [["analog", "a0", "signal"]] },
      { title: "Cắm đầu dò vào module", detail: "Gắn đầu cắm hai dây của đầu dò vào cổng hai chân dành cho đầu dò trên module.", check: "Cả hai dây đều vào đúng cổng đầu dò. Đầu cắm nằm chắc và không xiên.", wires: [["probeOne", "probePortOne", "probe"], ["probeTwo", "probePortTwo", "probe"]] },
    ],
  },
};
