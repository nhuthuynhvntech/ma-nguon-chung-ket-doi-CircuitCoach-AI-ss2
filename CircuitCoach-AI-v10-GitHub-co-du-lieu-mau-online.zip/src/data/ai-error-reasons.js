export const AI_ERROR_REASONS = Object.freeze({
  wrong_pin: "Đọc nhầm chân hoặc đường dây",
  wrong_polarity: "Nhầm chiều hoặc cực linh kiện",
  wrong_component: "Nhận nhầm linh kiện hoặc trị số",
  hidden_detail: "Suy đoán phần ảnh mờ hoặc bị che",
  false_pass: "Báo đạt nhầm",
  false_alarm: "Cảnh báo nhầm",
  other: "Nguyên nhân khác",
});

export const AI_ERROR_REVIEW_GUIDANCE = Object.freeze({
  wrong_pin: "Lần theo cả hai đầu của đúng dây. Kiểm tra lỗ cắm, hàng chân và thứ tự nhãn hai chân kề bên để tránh đọc lệch lỗ. Nếu chưa lần được dây hoặc chưa biết nhãn ứng với lỗ nào, ghi chưa xác định.",
  wrong_polarity: "Đối chiếu ký hiệu cực và đường dây ở cả hai phía. Kiểm tra thêm mép phẳng và hai chân nếu đây là LED.",
  wrong_component: "Xác định linh kiện bằng hình dạng và ký hiệu nhìn rõ. Chỉ đọc trị số từ vạch màu hoặc chữ in trên đúng linh kiện.",
  hidden_detail: "Kiểm tra phần từng bị che hoặc mờ ở tất cả góc chụp. Khi vẫn thiếu bằng chứng, ghi chưa xác định hoặc không nhìn thấy.",
  false_pass: "Tìm bằng chứng trực tiếp cho tiêu chí. Nếu đoạn mạch quyết định còn khuất, ghi chưa xác định.",
  false_alarm: "Chỉ ghi có lỗi khi thấy dấu hiệu trái yêu cầu. Nếu mới thấy một phần đoạn nối, ghi chưa xác định.",
  other: "Kiểm tra lại tiêu chí dựa trên dấu hiệu nhìn thấy và yêu cầu của sơ đồ.",
});

export function parseTeacherAiError(input, lesson) {
  const id = input?.criterionId;
  const reason = input?.reason;
  if (typeof id !== "string" || !lesson?.checks.some(([criterionId]) => criterionId === id) ||
      typeof reason !== "string" || !Object.hasOwn(AI_ERROR_REASONS, reason)) {
    throw new Error("Chọn đúng tiêu chí và lý do AI sai trong bài này.");
  }
  return { criterionId: id, reason };
}
