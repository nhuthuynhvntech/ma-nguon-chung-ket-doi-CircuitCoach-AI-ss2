export const SESSION_ROLES = Object.freeze({
  student: { label: "Học sinh", home: "#/lessons" },
  teacher: { label: "Giáo viên", home: "#/teacher" },
  admin: { label: "Quản trị viên", home: "#/admin" },
});
