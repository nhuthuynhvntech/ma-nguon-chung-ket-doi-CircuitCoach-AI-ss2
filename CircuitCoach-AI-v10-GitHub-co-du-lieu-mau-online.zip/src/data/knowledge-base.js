export const knowledgeBase = {
  component_visibility: {
    title: "Quan sát linh kiện",
    topic: "Chụp ảnh mạch",
    facts: ["Ảnh rõ và đủ sáng giúp xác định đúng linh kiện và đường dây."],
    basicHints: ["Chụp toàn cảnh từ trên xuống.", "Chụp thêm cận cảnh phần bị che."],
  },
  led_orientation: {
    title: "Chiều LED",
    topic: "Anode và Cathode",
    facts: ["LED có cực Anode và Cathode.", "Chân dài thường là Anode.", "Chân ngắn thường là Cathode.", "LED cần mắc đúng chiều để dẫn điện."],
    basicHints: ["Quan sát chiều dài hai chân LED.", "Xác định phía đang nối về GND."],
  },
  resistor_present: {
    title: "Điện trở hạn dòng",
    topic: "Điện trở hạn dòng",
    facts: ["LED cần điện trở hạn dòng để tránh dòng điện quá lớn.", "Giá trị 220–330Ω phù hợp với bài học này."],
    basicHints: ["Tìm linh kiện có các vòng màu.", "Kiểm tra xem điện trở có nằm trên nhánh LED."],
  },
  resistor_in_series: {
    title: "Điện trở mắc nối tiếp",
    topic: "Mạch nối tiếp",
    facts: ["Điện trở hạn dòng phải nằm trên cùng đường dòng điện đi qua LED."],
    basicHints: ["Lần theo dây từ D8 đến LED.", "Kiểm tra xem dòng điện có đi qua điện trở trước hoặc sau LED."],
  },
  power_connection: {
    title: "Kết nối nguồn",
    topic: "Nguồn điện – VCC – GND",
    facts: ["Nguồn và GND tạo thành đường cấp điện hoàn chỉnh.", "Không đổi VCC và GND cho nhau."],
    basicHints: ["Tìm chân 5V hoặc đường nguồn dương.", "Lần theo dây nguồn đến linh kiện."],
  },
  ground_connection: {
    title: "Kết nối GND",
    topic: "Nguồn điện – VCC – GND",
    facts: ["Các linh kiện phải có đường về GND chung để mạch hoạt động ổn định."],
    basicHints: ["Tìm nhãn GND trên Arduino.", "Lần theo toàn bộ dây về GND."],
  },
  power_voltage: {
    title: "Mức nguồn phù hợp",
    topic: "Điện áp nguồn an toàn",
    facts: ["Nguồn phải đúng với yêu cầu của bài và linh kiện.", "Không cấp nguồn khi chưa xác định được điện áp và cực nguồn."],
    basicHints: ["Chụp rõ nhãn điện áp trên nguồn hoặc bo mạch.", "Đối chiếu mức nguồn với sơ đồ bài học và hỏi giáo viên trước khi cấp điện."],
  },
  no_short_circuit: {
    title: "Nguy cơ chập mạch",
    topic: "An toàn chống chập mạch",
    facts: ["Không được có đường nối trực tiếp giữa cực dương và cực âm của nguồn.", "Chập mạch có thể làm nóng dây, pin hoặc linh kiện."],
    basicHints: ["Giữ nguồn ngắt và lần riêng đường dương, đường GND.", "Chụp cận cảnh các điểm dây giao nhau hoặc chân linh kiện sát nhau."],
  },
  sensor_visibility: {
    title: "Quan sát HC-SR04",
    topic: "Chụp ảnh mạch",
    facts: ["Cần nhìn rõ cả bốn chân VCC, TRIG, ECHO và GND."],
    basicHints: ["Chụp gần hàng chân cảm biến.", "Để nhãn chân hướng về camera."],
  },
  vcc_connection: {
    title: "Chân VCC",
    topic: "Nguồn điện – VCC – GND",
    facts: ["Trong bài này, VCC của HC-SR04 nối với 5V trên Arduino Uno."],
    basicHints: ["Tìm chân VCC trên cảm biến.", "Lần dây tới chân 5V."],
  },
  gnd_connection: {
    title: "Chân GND",
    topic: "Nguồn điện – VCC – GND",
    facts: ["GND của cảm biến cần nối với GND của Arduino."],
    basicHints: ["Tìm nhãn GND ở hai đầu.", "Kiểm tra dây có bị che hay đứt quãng trong ảnh."],
  },
  trig_connection: {
    title: "Chân TRIG",
    topic: "Tín hiệu Trigger",
    facts: ["Trong bài này, TRIG được cấu hình nối với Arduino D9."],
    basicHints: ["Tìm nhãn TRIG.", "Lần dây đến vị trí D9 trên Arduino."],
  },
  echo_connection: {
    title: "Chân ECHO",
    topic: "Tín hiệu Echo",
    facts: ["Trong bài này, ECHO được cấu hình nối với Arduino D10."],
    basicHints: ["Tìm nhãn ECHO.", "Lần dây đến vị trí D10 trên Arduino."],
  },
  servo_visibility: {
    title: "Quan sát Servo",
    topic: "Chụp ảnh mạch",
    facts: ["Cần nhìn rõ ba dây nguồn, GND và tín hiệu của servo."],
    basicHints: ["Chụp rõ đầu cắm ba dây.", "Chụp thêm đầu dây nối với Arduino."],
  },
  signal_connection: {
    title: "Dây Signal",
    topic: "Tín hiệu điều khiển Servo",
    facts: ["Trong bài này, dây Signal được cấu hình nối với Arduino D6."],
    basicHints: ["Xác định dây Signal theo đầu cắm servo.", "Lần dây tới vị trí D6."],
  },
  battery_visibility: {
    title: "Pin và cực nguồn",
    topic: "Pin 9V và cực nguồn",
    facts: ["Pin 9V có cực dương (+) và cực âm (–).", "Không nối trực tiếp hai cực pin với nhau vì có thể làm pin nóng và nhanh hỏng."],
    basicHints: ["Chụp rõ ký hiệu + và – trên đầu pin.", "Để toàn bộ đầu nối pin xuất hiện trong ảnh."],
  },
  switch_present: {
    title: "Công tắc bật/tắt",
    topic: "Công tắc đóng và mở",
    facts: ["Công tắc mở làm ngắt đường dòng điện nên LED tắt.", "Công tắc đóng hoàn tất đường dòng điện nên LED có thể sáng."],
    basicHints: ["Tìm linh kiện có cần gạt hoặc nút bật/tắt.", "Chụp rõ các chân đang được sử dụng trên công tắc."],
  },
  switch_in_series: {
    title: "Công tắc mắc nối tiếp",
    topic: "Công tắc trong mạch nối tiếp",
    facts: ["Công tắc phải nằm trên cùng vòng mạch với pin, điện trở và LED để điều khiển dòng điện."],
    basicHints: ["Lần dây từ Cathode LED tới công tắc.", "Kiểm tra dây còn lại của công tắc có về cực âm pin."],
  },
  battery_polarity: {
    title: "Đúng cực pin",
    topic: "Cực tính nguồn và LED",
    facts: ["Nhánh từ cực dương pin đi qua điện trở tới Anode LED.", "Cathode LED đi về cực âm pin qua công tắc."],
    basicHints: ["Bắt đầu từ dấu + và lần theo dây đến điện trở.", "Kiểm tra chân còn lại của LED có đường về dấu –."],
  },
  circuit_continuity: {
    title: "Mạch kín khi bật",
    topic: "Đường dòng điện khép kín",
    facts: ["Khi bật công tắc, đường dòng điện phải khép kín từ cực dương qua điện trở, LED, công tắc rồi về cực âm."],
    basicHints: ["Lần toàn bộ vòng dây và tìm điểm bị hở.", "Nếu LED không sáng, tắt nguồn trước khi chỉnh dây."],
  },
  moisture_sensor_visibility: {
    title: "Quan sát cảm biến độ ẩm",
    topic: "Chụp ảnh mạch",
    facts: ["Cần nhìn rõ module cảm biến, các chân VCC, GND, DO, AO và đầu dò."],
    basicHints: ["Chụp gần hàng chân của module.", "Để nhãn chân hướng về camera."],
  },
  probe_connection: {
    title: "Đầu dò độ ẩm",
    topic: "Đầu dò độ ẩm",
    facts: ["Hai dây của đầu dò phải cắm chắc vào cổng 2 chân trên module; phần kim loại chạm đất để đo độ ẩm."],
    basicHints: ["Kiểm tra hai dây đầu dò có lỏng hay đứt.", "Giữ phần mạch khô ráo, chỉ để phần kim loại chạm đất."],
  },
  moisture_vcc_connection: {
    title: "Chân VCC",
    topic: "Nguồn điện – VCC – GND",
    facts: ["Trong bài này, VCC của module độ ẩm nối với 5V trên Arduino Uno."],
    basicHints: ["Tìm chân VCC trên module.", "Lần dây tới chân 5V trên Arduino."],
  },
  moisture_gnd_connection: {
    title: "Chân GND",
    topic: "Nguồn điện – VCC – GND",
    facts: ["GND của module cần nối với GND của Arduino để có đường về chung."],
    basicHints: ["Tìm nhãn GND ở hai đầu.", "Kiểm tra dây có bị che hay đứt quãng trong ảnh."],
  },
  moisture_signal_connection: {
    title: "Chân tín hiệu A0",
    topic: "Tín hiệu Analog A0",
    facts: ["Trong bài này, ngõ ra A0 của module nối với chân Analog A0 trên Arduino để đọc giá trị độ ẩm."],
    basicHints: ["Tìm nhãn A0 trên module.", "Lần dây tới chân A0 trên Arduino."],
  },
};

export function getKnowledge(checkId) {
  return knowledgeBase[checkId] || knowledgeBase.component_visibility;
}
