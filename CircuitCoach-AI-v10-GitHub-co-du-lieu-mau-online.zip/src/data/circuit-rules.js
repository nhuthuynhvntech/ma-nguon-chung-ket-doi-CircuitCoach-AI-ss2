const pin = (target, expected) => ({ type: "pin", target, expected });
const state = (type, target, expected) => ({ type, target, expected });
const resistor = (min, max) => ({ type: "resistance", target: "Điện trở hạn dòng trên đường đi qua LED", min, max });
const series = target => state("series", target, "series");
const voltage = (target, expected) => ({ type: "voltage", target, expected });
const separated = target => state("short", target, "separate");
const visible = target => state("visibility", target, "visible");
const ledPolarity = state("led_polarity", "Hai chân LED và đường nối tới phía cấp điện hoặc tín hiệu", "anode_to_feed");
const fiveVolt = voltage("Nhãn 5V trên chân cấp nguồn hoặc điện áp danh định ghi trên nguồn đang nối", 5);

const ledRules = {
  component_visibility: visible("Arduino, LED và đường dây của mạch LED"),
  led_orientation: ledPolarity,
  resistor_present: resistor(220, 330),
  resistor_in_series: series("Điện trở trên đường đi qua LED"),
  power_connection: pin("Đầu cắm Arduino của đường tín hiệu nối vào mạch LED", "D8"),
  ground_connection: pin("Đầu cắm Arduino của đường nối từ cathode LED", "GND"),
  power_voltage: {
    ...voltage("Mức điện áp thực tế ở đường tín hiệu D8 đang nối với LED", 5),
    physicalCheck: "Bài LED nhận tín hiệu từ D8. Cần giáo viên xác minh mức điện áp thực tế của đường tín hiệu.",
  },
  no_short_circuit: separated("Các đường nguồn và GND của mạch LED"),
};

const range = rule => `${rule.min}–${rule.max} Ω`;
const hcsr04Rules = {
  sensor_visibility: visible("Cảm biến HC-SR04 và hàng chân của cảm biến"),
  vcc_connection: pin("Dây từ chân VCC của HC-SR04", "5V"),
  gnd_connection: pin("Dây từ chân GND của HC-SR04", "GND"),
  power_voltage: fiveVolt,
  no_short_circuit: separated("Các đường nguồn và GND của HC-SR04"),
  trig_connection: pin("Dây từ chân TRIG của HC-SR04", "D9"),
  echo_connection: pin("Dây từ chân ECHO của HC-SR04", "D10"),
};

const servoRules = {
  servo_visibility: visible("Servo và giắc ba dây của servo"),
  power_connection: pin("Dây từ chân VCC của servo theo nhãn hoặc sơ đồ đúng mẫu giắc", "5V"),
  ground_connection: pin("Dây từ chân GND của servo theo nhãn hoặc sơ đồ đúng mẫu giắc", "GND"),
  power_voltage: fiveVolt,
  no_short_circuit: separated("Các đường nguồn và GND của servo"),
  signal_connection: pin("Dây tín hiệu Signal của servo theo nhãn hoặc sơ đồ đúng mẫu giắc", "D6"),
};

const batteryRules = {
  battery_visibility: visible("Pin, đầu kẹp và hai cực nguồn"),
  led_orientation: ledPolarity,
  resistor_present: resistor(330, 1000),
  resistor_in_series: series("Điện trở trên đường đi qua LED"),
  switch_present: state("presence", "Công tắc trong toàn bộ đoạn mạch liên quan", "present"),
  switch_in_series: series("Công tắc trên đường từ cathode LED về cực âm pin"),
  battery_polarity: state("battery_polarity", "Dấu + và – trên pin và đường nối từ chúng đến điện trở", "positive_to_resistor"),
  power_voltage: { ...voltage("Điện áp danh định in trên pin đang nối vào mạch", 9), requires: "resistor_present" },
  no_short_circuit: separated("Đường dây giữa cực dương và cực âm của pin"),
  circuit_continuity: state("continuity", "Đường nối qua LED và công tắc ở trạng thái bật", "closed_visible"),
};

const soilRules = {
  moisture_sensor_visibility: visible("Đầu dò, module cảm biến độ ẩm và Arduino"),
  probe_connection: state("probe", "Hai dây đầu dò và cổng hai chân của module", "two_wires_in_port"),
  moisture_vcc_connection: pin("Dây từ chân VCC của module cảm biến độ ẩm", "5V"),
  moisture_gnd_connection: pin("Dây từ chân GND của module cảm biến độ ẩm", "GND"),
  power_voltage: fiveVolt,
  no_short_circuit: separated("Các đường VCC và GND của module cảm biến độ ẩm"),
  moisture_signal_connection: {
    ...pin("Dây tín hiệu từ AO/A0 của module cảm biến độ ẩm", "A0"),
    wrongSource: "digital_output",
  },
};

export const CIRCUIT_LESSON_SPECS = {
  led: {
    rules: ledRules,
    connections: [
      `Arduino ${ledRules.power_connection.expected} → điện trở ${range(ledRules.resistor_present)}`,
      "Điện trở → Anode LED",
      `Cathode LED → Arduino ${ledRules.ground_connection.expected}`,
    ],
  },
  hcsr04: {
    rules: hcsr04Rules,
    connections: [
      `HC-SR04 VCC → Arduino ${hcsr04Rules.vcc_connection.expected}`,
      `HC-SR04 GND → Arduino ${hcsr04Rules.gnd_connection.expected}`,
      `HC-SR04 TRIG → Arduino ${hcsr04Rules.trig_connection.expected}`,
      `HC-SR04 ECHO → Arduino ${hcsr04Rules.echo_connection.expected}`,
    ],
  },
  servo: {
    rules: servoRules,
    connections: [
      `Servo VCC → Arduino ${servoRules.power_connection.expected}`,
      `Servo GND → Arduino ${servoRules.ground_connection.expected}`,
      `Servo Signal → Arduino ${servoRules.signal_connection.expected}`,
    ],
  },
  "battery-led-switch": {
    rules: batteryRules,
    connections: [
      `Cực dương (+) pin ${batteryRules.power_voltage.expected}V → điện trở ${range(batteryRules.resistor_present)}`,
      "Điện trở → Anode LED",
      "Cathode LED → công tắc",
      "Công tắc → cực âm (–) pin 9V",
    ],
  },
  "soil-moisture": {
    rules: soilRules,
    connections: [
      `Cảm biến độ ẩm VCC → Arduino ${soilRules.moisture_vcc_connection.expected}`,
      `Cảm biến độ ẩm GND → Arduino ${soilRules.moisture_gnd_connection.expected}`,
      `Cảm biến độ ẩm A0 → Arduino ${soilRules.moisture_signal_connection.expected}`,
      "Hai dây đầu dò cắm chắc vào cổng 2 chân của module",
    ],
  },
};
