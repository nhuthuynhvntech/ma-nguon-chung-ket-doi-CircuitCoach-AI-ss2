const captureTips = Object.freeze({
  component_visibility: "Chụp từ trên xuống để thấy toàn bộ Arduino, LED, điện trở và dây nối.",
  led_orientation: "Ngắt nguồn để LED tắt, rồi chụp ngang thân LED đủ sáng để thấy hai bản cực bên trong và chỗ hai chân LED đang nối.",
  resistor_present: "Chụp rõ thân điện trở và các vạch màu dưới ánh sáng đều.",
  resistor_in_series: "Chụp rõ hai đầu điện trở và đường nối từ điện trở đến LED trong cùng khung hình.",
  power_connection: "Chụp cận nhãn chân cấp tín hiệu hoặc chân nguồn cùng đầu dây đang cắm.",
  ground_connection: "Chụp rõ nhãn GND và cả hai đầu dây nối về GND.",
  power_voltage: "Chụp rõ nhãn nguồn, ký hiệu chân nguồn và dây đang dùng. Nhờ giáo viên kiểm tra mức điện áp trực tiếp.",
  no_short_circuit: "Giữ nguồn ngắt. Chụp rõ hai đường nguồn và GND, gồm các hàng lỗ và đầu dây nơi chúng đi gần nhau.",
  sensor_visibility: "Chụp mặt có chữ của cảm biến HC-SR04 và cả bốn chân.",
  vcc_connection: "Chụp rõ chân VCC trên cảm biến và vị trí đầu dây tương ứng trên Arduino.",
  gnd_connection: "Chụp rõ hai đầu dây GND và nhãn chân ở cảm biến lẫn Arduino.",
  trig_connection: "Chụp nhãn TRIG và lần theo dây từ cảm biến đến chân Arduino.",
  echo_connection: "Chụp nhãn ECHO và lần theo dây từ cảm biến đến chân Arduino.",
  servo_visibility: "Chụp rõ đầu cắm ba dây của servo và vị trí chúng nối vào bo mạch.",
  signal_connection: "Chụp cận dây tín hiệu servo và nhãn chân Arduino nơi dây đang cắm.",
  battery_visibility: "Chụp trọn pin, đầu kẹp pin, công tắc và đường dây.",
  switch_present: "Chụp cận công tắc cùng các chân đang nối dây.",
  switch_in_series: "Chụp rõ hai chân công tắc và đường nối từ công tắc đến các phần còn lại của mạch.",
  battery_polarity: "Chụp dấu cộng, dấu trừ trên pin và cả hai đầu dây nối.",
  circuit_continuity: "Chụp từ trên xuống để lần được toàn tuyến nối qua công tắc, điện trở và LED.",
  moisture_sensor_visibility: "Chụp rõ đầu dò, bo cảm biến và hàng chân có chữ.",
  probe_connection: "Chụp cận hai đầu cáp nối giữa đầu dò và bo cảm biến.",
  moisture_vcc_connection: "Chụp nhãn VCC trên bo cảm biến và đầu dây nguồn ở Arduino.",
  moisture_gnd_connection: "Chụp nhãn GND trên cả hai bo và đầu dây đang nối.",
  moisture_signal_connection: "Chụp rõ nhãn ngõ ra trên cảm biến và chân nhận tín hiệu ở Arduino.",
});

export function getCaptureTip(criterionId, lessonId, { electrodesSeen = false } = {}) {
  if (criterionId === "led_orientation" && electrodesSeen) {
    return "Giữ góc cận hai bản cực và thêm góc thấy đường nối từ mỗi chân LED đến điện trở và nhánh hồi.";
  }
  if (lessonId === "led" && criterionId === "power_connection") {
    return "Chụp cận nhãn D8 trên Arduino, đầu dây và chân điện trở mà dây đó nối tới.";
  }
  return Object.hasOwn(captureTips, criterionId) ? captureTips[criterionId]
    : "Chụp cận linh kiện và cả hai đầu dây liên quan, ở góc đủ sáng và tránh dây che khuất.";
}

export function getTargetedCaptureAdvice(lesson, checks, modelAdvice = []) {
  const byId = new Map(checks.map(check => [check.id || check.criterionId, check]));
  const unresolved = lesson.checkList.filter(check => ["uncertain", "not_visible"].includes(byId.get(check.id)?.status));
  const prioritised = [...unresolved].sort((a,b) => Number(b.category === "safety") - Number(a.category === "safety"));
  const tips = prioritised.map(check => getCaptureTip(check.id, lesson.id, {
    electrodesSeen: Number.isInteger(byId.get(check.id)?.ruleEvidence?.electrodesImageIndex),
  }));
  const fallback = Array.isArray(modelAdvice) ? modelAdvice.filter(text => typeof text === "string" && text.trim()) : [];
  return [...new Set([...tips, ...fallback])].slice(0, 5);
}
