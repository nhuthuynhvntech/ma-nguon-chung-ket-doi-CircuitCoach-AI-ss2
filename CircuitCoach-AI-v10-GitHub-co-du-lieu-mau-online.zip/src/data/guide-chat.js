export const GUIDE_QUESTION_LIMIT = 500;
export const GUIDE_REPLY_LIMIT = 1400;
export const GUIDE_HISTORY_LIMIT = 7;

export const GUIDE_CHAT_QUESTIONS = {
  photos: {
    label: "Gửi ảnh",
    question: "Em gửi ảnh mạch thế nào?",
    answer: "Mở bài học và chọn Gửi ảnh. Em có thể chọn ảnh hoặc dùng camera, rồi bấm Phân tích mạch. Gửi tối đa 3 ảnh của cùng một mạch. Nên có ảnh toàn cảnh, ảnh cận chân cắm trên bo và ảnh cận linh kiện. Tránh chụp mặt hoặc thông tin cá nhân.",
  },
  results: {
    label: "Đọc kết quả",
    question: "Em đọc kết quả AI thế nào?",
    answer: "Tóm tắt hiển thị ảnh mạch, vùng khoanh, bằng chứng và kết quả từng tiêu chí. Nếu ảnh còn mờ hoặc bị che, em có thể chụp bổ sung góc được gợi ý. Mục Phản hồi có nhận xét và xác nhận của giáo viên.",
  },
  assembly: {
    label: "Cách lắp mạch",
    question: "Em lắp mạch của bài này thế nào?",
    answer: "Chọn bài học ở mục Chủ đề, rồi hỏi lại. Trong bài học, em cũng có thể mở Hướng dẫn và ảnh mẫu → Hướng dẫn lắp mạch để xem từng bước.",
  },
  safety: {
    label: "An toàn",
    question: "Khi nào em được cấp nguồn?",
    answer: "Giữ nguồn ngắt trong khi lắp hoặc chỉnh dây. Nhờ giáo viên kiểm tra mạch thật. Chỉ cấp nguồn khi giáo viên đã kiểm tra trực tiếp và cho phép, kể cả khi kết quả AI hiện Đạt.",
  },
};
