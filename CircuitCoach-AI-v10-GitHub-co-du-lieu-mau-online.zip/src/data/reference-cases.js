export const REFERENCE_ERROR_TYPES = Object.freeze({
  missing: "Thiếu linh kiện hoặc dây",
  reversed: "Sai cực hoặc ngược chiều",
  miswired: "Nối nhầm chân hoặc sai vị trí",
  wrong_value: "Sai trị số hoặc mức nguồn",
  short_risk: "Nguy cơ chập mạch",
  other: "Lỗi khác",
});

export const REFERENCE_REVIEW_STATES = Object.freeze({
  approved: "Đã duyệt",
  pending: "Chờ duyệt",
  rejected: "Từ chối",
  retired: "Ngừng dùng",
});
