import { getKnowledge } from "./knowledge-base.js";

export function getLocalHint(problem, level) {
  const item = getKnowledge(problem.id);
  const fact = item.facts[Math.min(level - 1, item.facts.length - 1)];
  const prompt = item.basicHints[Math.min(level - 1, item.basicHints.length - 1)];
  if (level === 1) {
    return { title: `Quan sát lại: ${item.title}`, hint: prompt, question: "Em nhìn thấy chi tiết nào trong mạch giúp kiểm tra điều này?", reviewTopic: item.topic, source: "local" };
  }
  if (level === 2) {
    return { title: `Kiến thức cần nhớ: ${item.title}`, hint: fact, question: "Kiến thức này liên hệ với phần nào em đang nhìn thấy?", reviewTopic: item.topic, source: "local" };
  }
  return { title: `Thử kiểm tra: ${item.title}`, hint: `${fact} ${prompt}`, question: "Sau khi chỉnh, em có thể chụp lại để kiểm tra không?", reviewTopic: item.topic, source: "local" };
}
