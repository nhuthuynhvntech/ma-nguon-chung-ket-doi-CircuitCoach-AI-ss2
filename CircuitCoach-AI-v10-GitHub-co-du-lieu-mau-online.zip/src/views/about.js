import { appShell, icon } from "./shared.js";

export function renderAbout(root) {
  const steps = [
    ["01", "Bạn cung cấp ảnh", "Tối đa 3 ảnh được thu nhỏ trên thiết bị trước khi gửi."],
    ["02", "AI Vision kiểm tra", "Ảnh đi kèm mạch chuẩn và danh sách tiêu chí riêng của bài."],
    ["03", "CircuitCoach xử lý", "Kết quả JSON được kiểm tra schema trước khi hiển thị."],
    ["04", "AI Tutor gợi ý", "Tutor chỉ dùng vấn đề đã phát hiện và kho kiến thức của bài."],
    ["05", "Bạn sửa và thử lại", "Lịch sử loại lỗi giúp đề xuất nội dung cần ôn."],
  ];
  root.innerHTML = appShell(`
    <section class="about-page">
      <header class="about-hero"><div><p class="eyebrow">MINH BẠCH AI</p><h1>AI quan sát.<br>Bạn là người <span>quyết định.</span></h1></div><p>CircuitCoach được thiết kế để nói “chưa xác định” khi ảnh không đủ rõ, thay vì đoán một kết nối mà AI không nhìn thấy.</p></header>
      <section class="process-grid">${steps.map(([number, title, detail]) => `<article><b>${number}</b><h2>${title}</h2><p>${detail}</p></article>`).join("")}</section>
      <section class="role-grid"><article><span>${icon("camera", 24)}</span><p class="eyebrow">OPENAI VISION</p><h2>Phân tích hình ảnh</h2><p>Đánh giá riêng từng tiêu chí dựa trên ảnh và mạch chuẩn.</p></article><article><span>${icon("help", 24)}</span><p class="eyebrow">OPENAI AI TUTOR</p><h2>Tạo câu hỏi học tập</h2><p>Đưa gợi ý theo 3 cấp, không tự chẩn đoán lại ảnh.</p></article><article><span>${icon("zap", 24)}</span><p class="eyebrow">CIRCUITCOACH</p><h2>Logic do nhóm xây dựng</h2><p>Định nghĩa bài học, mạch chuẩn, tiêu chí, kho kiến thức, lịch sử và cá nhân hóa.</p></article></section>
      <section class="scope-note"><strong>Tuyên bố phạm vi</strong><p>CircuitCoach AI là công cụ hỗ trợ học tập. Kết quả phân tích hình ảnh có thể không chính xác trong mọi trường hợp. Phiên bản MVP tập trung vào mạch LED dùng pin 9V và công tắc, LED Arduino, HC-SR04 và Servo đã được định nghĩa trong hệ thống. Với những phần không đủ rõ trong hình ảnh, CircuitCoach sẽ yêu cầu người dùng chụp lại thay vì cố gắng đưa ra kết luận.</p></section>
    </section>
  `, "about");
}
