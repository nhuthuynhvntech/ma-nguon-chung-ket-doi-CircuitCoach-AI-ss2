import { getLesson, lessons } from "../data/lessons.js";
import { REFERENCE_ERROR_TYPES, REFERENCE_REVIEW_STATES } from "../data/reference-cases.js";
import { getTeacherClassCode, referenceExamplePhotoUrl } from "../services/classroom.js";
import { appShell, escapeHtml } from "./shared.js";

const numbers = new Intl.NumberFormat("vi-VN", { maximumFractionDigits: 1 });
const dayFormat = new Intl.DateTimeFormat("vi-VN", { dateStyle: "medium", timeZone: "Asia/Ho_Chi_Minh" });
const timeFormat = new Intl.DateTimeFormat("vi-VN", { dateStyle: "short", timeStyle: "short", timeZone: "Asia/Ho_Chi_Minh" });
const periods = [["7", "7 ngày"], ["30", "30 ngày"], ["90", "90 ngày"], ["0", "Toàn bộ"]];
const rate = (value, total) => total ? (100 * value) / total : null;

function ratio(value, total) {
  return total ? `${numbers.format(rate(value, total))}% <small>${value}/${total}</small>` : "—";
}

function deltaLabel(a, b, total) {
  if (!total) return "—";
  const delta = rate(b - a, total);
  return `${delta > 0 ? "+" : ""}${numbers.format(delta)} đpt`;
}

function pairCounts(a,b,total) {
  return total ? `${a}/${total} · ${b}/${total}` : "—";
}

function comparisonStatus(run) {
  if (run.statusA !== "succeeded" || run.statusB !== "succeeded") return "Có luồng lỗi";
  if (!run.referencesUsed) return "B thiếu tham chiếu";
  if (run.paired === null) return "Lượt cũ, chưa chốt nhãn";
  return run.paired ? "Đã đối chiếu" : "Chưa đủ nhãn đối chiếu";
}

function renderExample(photo, label, title, detail = "") {
  return `<figure class="ai-tracking-example">
    <a href="${escapeHtml(photo)}" target="_blank" rel="noopener" aria-label="Mở ảnh ${escapeHtml(label)}"><img src="${escapeHtml(photo)}" alt="${escapeHtml(label)}" loading="lazy" width="280" height="190"></a>
    <figcaption><strong>${escapeHtml(label)}</strong><span>${escapeHtml(title)}</span>${detail ? `<small>${escapeHtml(detail)}</small>` : ""}</figcaption>
  </figure>`;
}

function renderData(data, lesson, publicView) {
  const row = data.lessons.find(item => item.lesson === lesson.id);
  const metrics = row?.metrics;
  const approved = data.libraryCounts.find(item => item.lesson === lesson.id && item.status === "approved")?.count || 0;
  const daily = data.daily.filter(day => day.paired).slice().reverse();
  const dailyRows = daily.map(row => `<tr>
    <th scope="row">${escapeHtml(dayFormat.format(new Date(`${row.day}T00:00:00+07:00`)))}</th>
    <td><div class="ai-tracking-meter"><meter min="0" max="100" value="${rate(row.a, row.paired)}" aria-label="Tỷ lệ đúng của A"></meter><span>${ratio(row.a,row.paired)}</span></div></td>
    <td><div class="ai-tracking-meter"><meter min="0" max="100" value="${rate(row.b, row.paired)}" aria-label="Tỷ lệ đúng của B"></meter><span>${ratio(row.b,row.paired)}</span></div></td>
    <td>${deltaLabel(row.a,row.b,row.paired)}</td>
  </tr>`).join("");
  const examples = publicView
    ? lesson.referenceImages.map(image => renderExample(image.src, image.label, lesson.title)).join("")
    : data.library.map(example => {
      const criterion = lesson.checks.find(check => check[0] === example.criterion)?.[1] || example.criterion;
      const label = example.label === "correct" ? "Đúng ở tiêu chí này" : REFERENCE_ERROR_TYPES[example.errorType] || "Có lỗi";
      return renderExample(referenceExamplePhotoUrl(example.id, data.classCode), criterion, lesson.title, `${label} · ${REFERENCE_REVIEW_STATES[example.status] || example.status}`);
    }).join("");
  const recent = (data.recent || []).map(run => `<tr>
    <th scope="row">${escapeHtml(timeFormat.format(new Date(run.completedAt)))}</th>
    <td>${escapeHtml(run.model)} <small title="${escapeHtml(run.configuration)}">${escapeHtml(run.configuration.slice(0, 8))}</small></td>
    <td>${run.referencesUsed ? run.referenceIds.map((id,index) => `<a href="${referenceExamplePhotoUrl(id, data.classCode)}" target="_blank" rel="noopener">Ảnh ${index + 1}</a>`).join(" · ") : "—"}</td>
    <td>${ratio(run.a,run.paired)}</td><td>${ratio(run.b,run.paired)}</td>
    <td>${escapeHtml(comparisonStatus(run))}</td>
  </tr>`).join("");
  return `
    <section class="ai-tracking-band">
      <h3>Kết quả A/B</h3>
      <p class="muted">A phân tích độc lập. B dùng ảnh từ kho chung của cùng bài học. Điểm chỉ tính tiêu chí có nhãn rõ ràng, đủ kết quả A/B và có ảnh tham chiếu được dùng ở B.</p>
      <dl class="ai-tracking-metrics">
        <div><dt>Ảnh đã duyệt trong kho chung</dt><dd>${approved}</dd></div>
        <div><dt>Lượt A/B</dt><dd>${row?.runs || 0}</dd></div>
        <div><dt>A đúng</dt><dd>${ratio(row?.a, row?.paired)}</dd></div>
        <div><dt>B đúng</dt><dd>${ratio(row?.b, row?.paired)}</dd></div>
        <div><dt>B so với A</dt><dd>${deltaLabel(row?.a, row?.b, row?.paired)}</dd></div>
        <div><dt>Bỏ sót an toàn A · B</dt><dd>${row?.safetyErrors ? `${row.missedA}/${row.safetyErrors} · ${row.missedB}/${row.safetyErrors}` : "—"}</dd></div>
        <div><dt>Mạch có lỗi an toàn bị báo đạt A · B</dt><dd>${pairCounts(metrics?.falsePassA, metrics?.falsePassB, metrics?.unsafeRuns)}</dd></div>
        <div><dt>Cảnh báo nhầm A · B</dt><dd>${pairCounts(metrics?.falseAlarmA, metrics?.falseAlarmB, metrics?.correctLabels)}</dd></div>
        <div><dt>Tiêu chí chưa xác định dù ảnh rõ A · B</dt><dd>${pairCounts(metrics?.unknownClearA, metrics?.unknownClearB, metrics?.clearChecks)}</dd></div>
      </dl>
    </section>
    <section class="ai-tracking-band">
      <h3>So sánh theo ngày</h3>
      ${dailyRows ? `<div class="report-table-wrap" tabindex="0" aria-label="Bảng so sánh theo ngày"><table class="report-table">
        <thead><tr><th>Ngày</th><th>A đúng</th><th>B đúng</th><th>B so với A</th></tr></thead><tbody>${dailyRows}</tbody>
      </table></div><p class="muted">Đpt là điểm phần trăm. Các ngày có thể dùng những bài làm khác nhau.</p>`
      : `<p class="muted">Chưa có lượt đủ điều kiện để tính tỷ lệ.${publicView ? "" : " Hãy lưu nhãn cho bài làm rồi chạy A/B với ảnh tham chiếu đã duyệt."}</p>`}
    </section>
    <section class="ai-tracking-band">
      <h3>${publicView ? "Ảnh mẫu bài học" : "Thư viện ảnh có nhãn"}</h3>
      <p><a class="text-button" href="#/references/${lesson.id}">Mở kho chung của bài</a></p>
      ${examples ? `<div class="ai-tracking-library">${examples}</div>` : '<p class="muted">Chưa có ảnh trong thư viện của bài học này.</p>'}
    </section>
    ${publicView ? "" : `<section class="ai-tracking-band">
      <h3>Lịch sử chạy A/B</h3>
      ${recent ? `<p class="muted">Hiển thị ${data.recent.length}/${data.runCount} lượt trong bộ lọc. Mỗi lần chạy là một phép đo riêng.</p>
      <div class="report-table-wrap" tabindex="0" aria-label="Bảng lịch sử chạy A/B"><table class="report-table">
        <thead><tr><th>Thời điểm</th><th>Model và cấu hình</th><th>Ảnh tham chiếu</th><th>A đúng</th><th>B đúng</th><th>Trạng thái</th></tr></thead><tbody>${recent}</tbody>
      </table></div>` : '<p class="muted">Chưa có lượt A/B trong khoảng thời gian này.</p>'}
    </section>`}`;
}

export function renderAiTracking(root, { publicView = false, lessonId, days } = {}) {
  const classCode = publicView ? "" : getTeacherClassCode();
  const lesson = getLesson(lessonId) || lessons[0];
  const initialDays = periods.some(([value]) => value === days) ? days : "30";
  const base = publicView ? "#/ai-progress" : "#/ai-tracking";
  const lessonLink = (id, periodValue) => `${base}/${id}${periodValue === "30" ? "" : "?days=" + periodValue}`;
  root.innerHTML = appShell(`<section class="teacher-page ai-tracking">
    ${publicView ? "" : '<nav class="teacher-view-tabs" aria-label="Chế độ xem giáo viên"><a href="#/teacher">Bảng điều khiển</a><a class="selected" href="#/ai-tracking">Theo dõi AI</a></nav>'}
    <header class="page-head compact-head"><div><h1>Theo dõi cải tiến AI</h1>${classCode ? `<p>Lớp ${escapeHtml(classCode)}</p>` : ""}</div></header>
    <nav class="ai-tracking-lessons" aria-label="Bài học theo dõi AI">
      ${lessons.map(item => `<a href="${lessonLink(item.id, initialDays)}" data-lesson-link="${item.id}"${item.id === lesson.id ? ' aria-current="page"' : ""}>${escapeHtml(item.title)}</a>`).join("")}
    </nav>
    <section class="ai-tracking-lesson" aria-labelledby="tracking-lesson-title">
      <div class="ai-tracking-lesson-head">
        <h2 id="tracking-lesson-title">${escapeHtml(lesson.title)}</h2>
        <div class="ai-tracking-filters">
          <label>Thời gian<select id="tracking-period">${periods.map(([value, label]) => `<option value="${value}"${initialDays === value ? " selected" : ""}>${label}</option>`).join("")}</select></label>
          <button class="btn btn-secondary" id="tracking-refresh" type="button">Làm mới</button>
          <button class="btn btn-ghost" id="tracking-export" type="button" disabled>Tải CSV</button>
        </div>
      </div>
      <p class="muted" id="tracking-status" role="status"></p>
      <div id="tracking-data"></div>
    </section>
  </section>`, publicView ? "ai-progress" : "teacher");
  const lessonLinks = root.querySelectorAll("[data-lesson-link]");
  const period = root.querySelector("#tracking-period");
  const status = root.querySelector("#tracking-status");
  const output = root.querySelector("#tracking-data");
  const refresh = root.querySelector("#tracking-refresh");
  const exportButton = root.querySelector("#tracking-export");
  let request;
  let report;

  async function load() {
    request?.abort();
    request = new AbortController();
    const { signal } = request;
    report = null;
    exportButton.disabled = refresh.disabled = true;
    output.replaceChildren();
    status.textContent = "Đang tải dữ liệu…";
    try {
      if (!publicView && !classCode) throw new Error("Hãy đăng nhập và mở lớp từ trang Giáo viên.");
      const query = new URLSearchParams({ lessonId: lesson.id, days: period.value });
      if (!publicView) query.set("classCode", classCode);
      const endpoint = publicView ? "/api/ai-progress" : "/api/classroom/ai-tracking";
      const response = await fetch(endpoint + "?" + query, { signal });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Không thể tải báo cáo.");
      if (signal.aborted || !output.isConnected) return;
      report = data;
      output.innerHTML = renderData(data, lesson, publicView);
      status.textContent = "";
      exportButton.disabled = !data.daily.length;
    } catch (error) {
      if (!signal.aborted && output.isConnected) status.textContent = error.message;
    } finally {
      if (!signal.aborted && output.isConnected) refresh.disabled = false;
    }
  }

  period.addEventListener("change", () => {
    history.replaceState(history.state, "", lessonLink(lesson.id, period.value));
    lessonLinks.forEach(link => { link.href = lessonLink(link.dataset.lessonLink, period.value); });
    void load();
  });
  refresh.addEventListener("click", load);
  exportButton.addEventListener("click", () => {
    if (!report?.daily.length) return;
    const header = "lesson_id,day,runs,paired,correct_a,correct_b,failed,missing_references,legacy,unscored,safety_errors,missed_a,missed_b,correct_labels,false_alarm_a,false_alarm_b,clear_checks,unknown_clear_a,unknown_clear_b,unsafe_runs,false_pass_a,false_pass_b";
    const rows = report.daily.map(row => {
      const metrics = row.metrics || {};
      return [lesson.id,row.day,row.runs,row.paired,row.a,row.b,row.failed,row.missingReferences,row.legacy,row.unscored,row.safetyErrors,row.missedA,row.missedB,
        metrics.correctLabels,metrics.falseAlarmA,metrics.falseAlarmB,metrics.clearChecks,metrics.unknownClearA,metrics.unknownClearB,metrics.unsafeRuns,metrics.falsePassA,metrics.falsePassB].join(",");
    });
    const url = URL.createObjectURL(new Blob([[header, ...rows].join("\n")], { type: "text/csv;charset=utf-8" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = `circuitcoach-ai-${classCode || "overview"}-${lesson.id}.csv`;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });
  void load();
}
