import { fetchStaffAccounts, getBrowserSession, notifyBrowserSessionChange, saveStaffAccount, setBrowserSession, updateAdminPassword, withBrowserSessionLock } from "../services/classroom.js";
import { escapeHtml, showToast } from "./shared.js";

export function mountAdminAccounts(section) {
  section.innerHTML = `<h2>Tài khoản giáo viên</h2>
    <div class="admin-table-wrap"><table class="admin-table">
      <thead><tr><th scope="col">Tên đăng nhập</th><th scope="col">Lớp phụ trách</th><th scope="col">Trạng thái</th><th scope="col">Mật khẩu</th></tr></thead>
      <tbody data-staff-list></tbody></table></div>
    <details class="admin-account-form"><summary>Tạo tài khoản</summary>
      <form>
        <label data-account-role>Vai trò<select name="role"><option value="teacher">Giáo viên</option><option value="admin">Quản trị viên</option></select></label>
        <label>Tên đăng nhập<input name="username" minlength="3" maxlength="40" autocomplete="off" required /></label>
        <label>Mật khẩu<input name="password" type="password" minlength="12" maxlength="128" autocomplete="new-password" required /></label>
        <div class="reference-library-actions">
          <button class="btn btn-ghost" type="button" data-show-staff-input aria-pressed="false">Hiện mật khẩu</button>
          <button class="btn btn-ghost" type="button" data-generate-password>Tạo mật khẩu</button>
        </div>
        <div class="reference-library-actions">
          <button class="btn btn-primary" type="submit">Tạo tài khoản giáo viên</button>
          <button class="btn btn-ghost" type="button" data-cancel-reset hidden>Hủy đặt lại</button>
        </div>
      </form>
    </details>
    <p data-account-status role="status"></p>
    <div class="admin-issued-account" data-issued-account hidden>
      <p><strong>Tên đăng nhập</strong> <code data-issued-username></code></p>
      <p><strong>Mật khẩu vừa cấp</strong> <code data-issued-password>••••••••</code></p>
      <div class="reference-library-actions">
        <button type="button" class="btn btn-secondary" data-issued-reveal aria-pressed="false">Hiện mật khẩu vừa cấp</button>
        <button type="button" class="btn btn-ghost" data-issued-dismiss>Đóng</button>
      </div>
    </div>
    <p data-admin-file-password hidden>Mật khẩu quản trị được quản lý trong tệp .env.</p>
    <details class="admin-account-form" data-admin-password-editor>
      <summary>Đổi mật khẩu quản trị của tôi</summary>
      <form data-admin-password>
        <label>Mật khẩu hiện tại<input name="currentPassword" type="password" maxlength="128" autocomplete="current-password" required /></label>
        <label>Mật khẩu mới<input name="password" type="password" minlength="12" maxlength="128" autocomplete="new-password" required /></label>
        <label>Nhập lại mật khẩu mới<input name="confirmPassword" type="password" minlength="12" maxlength="128" autocomplete="new-password" required /></label>
        <p data-admin-password-status role="status"></p>
        <button class="btn btn-primary" type="submit">Đổi mật khẩu</button>
      </form>
    </details>`;
  const list = section.querySelector("[data-staff-list]");
  const details = section.querySelector(".admin-account-form");
  const heading = details.querySelector("summary");
  const form = details.querySelector("form");
  const submit = form.querySelector('[type="submit"]');
  const cancel = form.querySelector("[data-cancel-reset]");
  const role = form.querySelector("[data-account-role]");
  const showInput = form.querySelector("[data-show-staff-input]");
  const status = section.querySelector("[data-account-status]");
  const issued = section.querySelector("[data-issued-account]");
  const issuedToggle = section.querySelector("[data-issued-reveal]");
  const issuedPassword = section.querySelector("[data-issued-password]");
  let reset;
  let issuedValue = "";
  let accounts = [];

  async function load() {
    try {
      const result = await fetchStaffAccounts();
      if (!section.isConnected) return;
      accounts = result.accounts;
      const teachers = accounts.filter(account => account.roles.split(",").includes("teacher"));
      list.innerHTML = teachers.map(account => `<tr><th scope="row">${escapeHtml(account.username)}</th><td>${escapeHtml(account.classCodes?.split(",").join(", ") || "Chưa có lớp")}</td>
        <td>${account.disabled ? "Đã khóa" : "Đang hoạt động"}</td><td>${account.configuredByFile ? "Quản lý trong tệp .env"
          : `<button type="button" class="text-button" data-reset-staff="${escapeHtml(account.id)}" ${account.disabled ? "disabled" : ""}>Đặt lại mật khẩu</button>`}</td></tr>`).join("")
        || '<tr><td colspan="4">Chưa có tài khoản giáo viên.</td></tr>';
      const currentUser = getBrowserSession()?.username;
      const fileManaged = accounts.some(account => account.configuredByFile && account.username === currentUser);
      section.querySelector("[data-admin-file-password]").hidden = !fileManaged;
      section.querySelector("[data-admin-password-editor]").hidden = fileManaged;
      section.hidden = false;
    } catch (error) {
      if (error.status !== 404 && section.isConnected) {
        section.hidden = false;
        status.textContent = error.message;
      }
    }
  }

  function revealInput(visible) {
    form.elements.password.type = visible ? "text" : "password";
    showInput.textContent = visible ? "Ẩn mật khẩu" : "Hiện mật khẩu";
    showInput.setAttribute("aria-pressed",String(visible));
  }

  function setIssuedVisible(visible) {
    issuedPassword.textContent = visible ? issuedValue : "••••••••";
    issuedToggle.textContent = visible ? "Ẩn mật khẩu vừa cấp" : "Hiện mật khẩu vừa cấp";
    issuedToggle.setAttribute("aria-pressed",String(visible));
  }

  function resetForm(account) {
    reset = account;
    form.reset();
    revealInput(false);
    role.hidden = Boolean(account);
    form.elements.role.disabled = Boolean(account);
    form.elements.username.readOnly = Boolean(account);
    form.elements.username.value = account?.username || "";
    cancel.hidden = !account;
    heading.textContent = account ? "Đặt lại mật khẩu giáo viên" : "Tạo tài khoản";
    submit.textContent = account ? "Lưu mật khẩu mới" : "Tạo tài khoản giáo viên";
  }

  showInput.addEventListener("click", () => revealInput(form.elements.password.type === "password"));
  form.elements.role.addEventListener("change", () => {
    submit.textContent = form.elements.role.value === "teacher" ? "Tạo tài khoản giáo viên" : "Tạo tài khoản quản trị";
  });
  form.querySelector("[data-generate-password]").addEventListener("click", () => {
    const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
    form.elements.password.value = Array.from(crypto.getRandomValues(new Uint8Array(18)), value => alphabet[value % alphabet.length]).join("");
    revealInput(true);
    form.elements.password.focus();
  });
  list.addEventListener("click", event => {
    const button = event.target.closest("[data-reset-staff]");
    if (!button || submit.disabled) return;
    const account = accounts.find(item => item.id === button.dataset.resetStaff);
    if (!account) return;
    issuedValue = "";
    setIssuedVisible(false);
    issued.hidden = true;
    resetForm(account);
    status.textContent = "";
    details.open = true;
    form.elements.password.focus();
  });
  cancel.addEventListener("click", () => { resetForm(); details.open = false; });
  issuedToggle.addEventListener("click", () => setIssuedVisible(issuedToggle.getAttribute("aria-pressed") === "false"));
  issued.querySelector("[data-issued-dismiss]").addEventListener("click", () => {
    issuedValue = "";
    setIssuedVisible(false);
    issued.hidden = true;
  });
  form.addEventListener("submit", async event => {
    event.preventDefault();
    if (submit.disabled) return;
    const values = Object.fromEntries(new FormData(form));
    const account = reset;
    submit.disabled = true;
    cancel.disabled = true;
    status.textContent = "Đang lưu tài khoản…";
    try {
      if (account) await saveStaffAccount({ id:account.id, password:values.password }, "PATCH");
      else await saveStaffAccount(values);
      if (!section.isConnected) return;
      issuedValue = values.password;
      resetForm();
      details.open = false;
      status.textContent = account ? "Đã đặt lại mật khẩu và kết thúc các phiên đăng nhập cũ." : "Đã tạo tài khoản.";
      issued.querySelector("[data-issued-username]").textContent = account?.username || values.username.trim();
      setIssuedVisible(false);
      issued.hidden = false;
      await load();
    } catch (error) { status.textContent = error.message; }
    finally { submit.disabled = false; cancel.disabled = false; }
  });
  const passwordForm = section.querySelector("[data-admin-password]");
  const passwordSubmit = passwordForm.querySelector('[type="submit"]');
  const passwordStatus = passwordForm.querySelector("[data-admin-password-status]");
  passwordForm.addEventListener("submit", async event => {
    event.preventDefault();
    if (passwordSubmit.disabled) return;
    const { currentPassword, password, confirmPassword } = Object.fromEntries(new FormData(passwordForm));
    if (password !== confirmPassword) {
      passwordStatus.textContent = "Hai lần nhập mật khẩu mới cần giống nhau.";
      return;
    }
    passwordSubmit.disabled = true;
    passwordStatus.textContent = "Đang đổi mật khẩu…";
    try {
      await withBrowserSessionLock(async () => {
        await updateAdminPassword(currentPassword, password);
        setBrowserSession(null);
        notifyBrowserSessionChange();
      });
      passwordForm.reset();
      location.hash = "#/home";
      showToast("Đã đổi mật khẩu quản trị. Hãy đăng nhập lại.", "success");
    } catch (error) {
      passwordStatus.textContent = error.message;
    } finally {
      passwordSubmit.disabled = false;
    }
  });
  void load();
}
