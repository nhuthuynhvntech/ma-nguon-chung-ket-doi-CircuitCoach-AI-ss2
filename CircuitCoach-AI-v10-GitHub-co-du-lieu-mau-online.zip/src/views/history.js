import { CERTAINTY_LABELS, STATUS_LABELS } from "../config.js";
import { getLesson } from "../data/lessons.js";
import { reportProblems, reportSummary } from "../data/attempt-rechecks.js";
import { getAttempts, resetLearningData } from "../services/storage.js";
import { attemptNumbers } from "../services/attempt-order.js";
import { clearAttemptImageArchive } from "../services/attempt-archive.js";
import { appShell, emptyState, escapeHtml, icon, showToast } from "./shared.js";

export function renderHistory(root) {
  const attempts = getAttempts();
  const numbers = attemptNumbers(attempts);
  const content = attempts.length ? attempts.map((attempt) => {
    const lesson = getLesson(attempt.lessonId);
    const current = reportProblems(attempt);
    const noteworthy = current.filter((item) => item.status !== "correct" && item.status !== "not_applicable" && !item.ruleEvidence?.physicalCheckRequired).slice(0, 3);
    const verification = attempt.teacherVerification || attempt.verification;
    const outcome = verification === "correct" ? "AI đúng" : verification === "incorrect" ? "AI sai" : "Không chắc";
    return `<article class="history-item"><div class="history-date"><strong>${new Date(attempt.time).toLocaleDateString("vi-VN", { day: "2-digit", month: "2-digit" })}</strong><small>${new Date(attempt.time).toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" })}</small></div><div class="history-body"><div class="history-head"><div><small>${lesson?.icon || "⚡"} ${escapeHtml(lesson?.title || attempt.lessonId)} · Lần ${numbers.get(attempt.id)} ${attempt.demo ? "· DEMO" : ""}</small><h2>${escapeHtml(reportSummary(attempt, current))}</h2></div><a class="text-button" href="#/result/${encodeURIComponent(attempt.id)}">Xem chi tiết →</a></div><div class="history-problems">${noteworthy.map((item) => `<span class="status-${item.status}">${STATUS_LABELS[item.status]} · ${escapeHtml(item.label)} · ${CERTAINTY_LABELS[item.certainty]}</span>`).join("")}</div>${verification ? `<p class="verified-line">${attempt.teacherVerification ? "Giáo viên xác nhận" : "Nhóm phản hồi"} · <b>${outcome}</b></p>` : ""}</div></article>`;
  }).join("") : emptyState("Chưa có lịch sử", "Kết quả đầu tiên sẽ xuất hiện ở đây sau khi bạn phân tích mạch.", '<a class="btn btn-primary" href="#/lessons">Bắt đầu học</a>');
  root.innerHTML = appShell(`<section class="history-page"><header class="page-head compact-head"><div><p class="eyebrow">NHẬT KÝ HỌC TẬP</p><h1>Mỗi lần sửa là một bước tiến</h1><p>Lịch sử theo bài học lưu kết quả và ảnh trên trình duyệt của thiết bị này.</p></div>${attempts.length ? `<button id="clear-history" class="btn btn-ghost">${icon("trash", 17)} Xóa dữ liệu học tập</button>` : ""}</header><div class="history-list">${content}</div></section>`, "history");
  root.querySelector("#clear-history")?.addEventListener("click", async () => {
    if (!confirm("Xóa toàn bộ lịch sử và bộ nhớ gợi ý trên thiết bị này?")) return;
    resetLearningData();
    try {
      await clearAttemptImageArchive();
      showToast("Đã xóa lịch sử và ảnh trên thiết bị này.", "success");
    } catch {
      showToast("Đã xóa kết quả; một số ảnh lưu chưa xóa được.", "error");
    }
    renderHistory(root);
  });
}
