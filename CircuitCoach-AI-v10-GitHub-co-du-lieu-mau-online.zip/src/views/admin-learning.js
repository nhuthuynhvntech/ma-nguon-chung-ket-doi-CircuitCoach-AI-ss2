import { getLesson, lessons } from "../data/lessons.js";
import { AI_ERROR_REASONS } from "../data/ai-error-reasons.js";
import { reportProblems, reportSummary } from "../data/attempt-rechecks.js";
import { REFERENCE_REVIEW_STATES } from "../data/reference-cases.js";
import { fetchLearningReport, lessonSampleUrl, referenceExamplePhotoUrl, sharedAttemptImageUrl } from "../services/classroom.js";
import { createPhotoViewer } from "./photo-tools.js";
import { appShell, escapeHtml } from "./shared.js";

const aiLabels = { correct: "Đúng", incorrect: "Có lỗi", uncertain: "Chưa xác định", possible_error: "Cần kiểm tra", not_visible: "Không nhìn thấy", not_applicable: "Không áp dụng" };
const verification = { correct: "AI đúng", incorrect: "AI sai", uncertain: "Chưa chắc" };
const photoStatuses = { ...REFERENCE_REVIEW_STATES, visible:"Đang hiển thị", hidden:"Đã ẩn" };
const date = new Intl.DateTimeFormat("vi-VN", { dateStyle:"short", timeStyle:"short" });
const fmt = value => value && Number.isFinite(Date.parse(value)) ? date.format(new Date(value)) : "—";
const title = id => getLesson(id)?.title || id || "Chưa chọn bài";
const label = (lessonId, id) => getLesson(lessonId)?.checks.find(([key]) => key === id)?.[1] || id || "Ảnh mẫu bài học";
const ratio = (value, total) => total ? `${(100 * value / total).toLocaleString("vi-VN", { maximumFractionDigits:1 })}% (${value}/${total})` : "—";

function table(headers, rows, empty) {
  return `<div class="admin-table-wrap"><table class="admin-table"><thead><tr>${headers.map(header => `<th scope="col">${header}</th>`).join("")}</tr></thead>
    <tbody>${rows || `<tr><td colspan="${headers.length}">${empty}</td></tr>`}</tbody></table></div>`;
}

function studentSkills(data, lessonId) {
  const chosen = lessonId ? [getLesson(lessonId)] : lessons;
  const totals = chosen.map(lesson => {
    const metrics = data.lessons.find(row => row.lessonId === lesson.id) || {};
    const labelled = data.labels.filter(row => row.lessonId === lesson.id);
    const correct = labelled.reduce((sum,row) => sum + row.correct, 0);
    const incorrect = labelled.reduce((sum,row) => sum + row.incorrect, 0);
    const unsure = labelled.reduce((sum,row) => sum + row.uncertain, 0);
    const progress = data.progress.find(row => row.lessonId === lesson.id);
    return `<tr><th scope="row"><button class="text-button" type="button" data-learning-lesson="${lesson.id}">${escapeHtml(lesson.title)}</button></th>
      <td>${metrics.realAttempts || 0}</td><td>${metrics.labelledAttempts || 0}</td><td>${ratio(correct, correct+incorrect)}</td><td>${unsure}</td>
      <td>${progress?.groups || 0}</td><td>${ratio(progress?.firstCorrect,progress?.paired)}</td>
      <td>${ratio(progress?.lastCorrect,progress?.paired)}</td><td>${progress ? progress.improved : "—"}</td></tr>`;
  }).join("");
  const labels = data.labels.map(row => `<tr><td>${escapeHtml(title(row.lessonId))}</td><th scope="row">${escapeHtml(label(row.lessonId,row.criterionId))}</th>
    <td>${row.correct}</td><td>${row.incorrect}</td><td>${row.uncertain}</td></tr>`).join("");
  const groups = data.groupSkills.map(row => `<tr><th scope="row">${escapeHtml(row.name)}</th><td>${escapeHtml(row.classCode)}</td><td>${escapeHtml(title(row.lessonId))}</td>
    <td>${row.labelledAttempts}</td><td>${ratio(row.correct,row.correct+row.incorrect)}</td><td>${row.uncertain}</td></tr>`).join("");
  return `<section class="admin-learning-section"><h3>Năng lực học sinh theo bài</h3>
    <p class="muted">Kết quả dựa trên nhãn tiêu chí của giáo viên trên bài làm thật. Tiến bộ so sánh các tiêu chí có nhãn rõ ở cả lần đầu và lần gần nhất được gắn nhãn của cùng nhóm và bài học.</p>
    ${table(["Bài học","Lượt nộp thật","Lượt có nhãn rõ","Tiêu chí được xác nhận đúng","Nhãn chưa xác định","Nhóm có số liệu tiến bộ","Lần đầu đúng","Lần gần nhất đúng","Tiêu chí sửa từ sai sang đúng"],totals,"Chưa đủ dữ liệu.")}
    </section><section class="admin-learning-section"><h3>Kết quả từng học sinh hoặc nhóm</h3>
    ${table(["Học sinh hoặc nhóm","Lớp","Bài học","Lượt có nhãn rõ","Tiêu chí được xác nhận đúng","Nhãn chưa xác định"],groups,"Chưa có nhóm được gắn nhãn trong bộ lọc này.")}
    </section><section class="admin-learning-section"><h3>Kỹ năng theo từng tiêu chí</h3>
    ${table(["Bài học","Tiêu chí","Đúng","Có lỗi","Chưa xác định"],labels,"Chưa có nhãn trong bộ lọc này.")}</section>`;
}

function aiPerformance(data, lessonId) {
  const chosen = lessonId ? [getLesson(lessonId)] : lessons;
  const totals = chosen.map(lesson => {
    const row = data.lessons.find(item => item.lessonId === lesson.id) || {};
    const correct = row.aiCorrect || 0;
    const incorrect = row.aiIncorrect || 0;
    const uncertain = row.aiUncertain || 0;
    return `<tr><th scope="row">${escapeHtml(lesson.title)}</th><td>${row.analysed || 0}</td><td>${row.aiPass || 0}</td>
      <td>${correct}</td><td>${incorrect}</td><td>${uncertain}</td><td>${ratio(correct,correct+incorrect)}</td></tr>`;
  }).join("");
  const aiErrors = (data.aiErrors || []).map(row => `<tr><td>${escapeHtml(title(row.lessonId))}</td>
    <th scope="row">${escapeHtml(label(row.lessonId,row.criterionId))}</th><td>${escapeHtml(AI_ERROR_REASONS[row.reason] || "Nguyên nhân khác")}</td><td>${row.count}</td></tr>`).join("");
  const rechecks = (data.recheckedCriteria || []).map(row => `<tr><td>${escapeHtml(title(row.lessonId))}</td>
    <th scope="row">${escapeHtml(label(row.lessonId,row.criterionId))}</th><td>${row.total}</td><td>${row.correct}</td></tr>`).join("");
  const pair = (a,b,total) => total ? `${a}/${total} · ${b}/${total}` : "—";
  const comparisons = data.comparisons.map(row => {
    const m = row.metrics || {};
    return `<tr><th scope="row">${escapeHtml(title(row.lesson))}</th><td>${row.runs}</td>
      <td>${ratio(row.a,row.paired)}</td><td>${ratio(row.b,row.paired)}</td><td>${pair(row.missedA,row.missedB,row.safetyErrors)}</td>
      <td>${pair(m.falsePassA,m.falsePassB,m.unsafeRuns)}</td><td>${pair(m.falseAlarmA,m.falseAlarmB,m.correctLabels)}</td>
      <td>${pair(m.unknownClearA,m.unknownClearB,m.clearChecks)}</td><td>${row.failed}</td><td>${row.missingReferences}</td></tr>`;
  }).join("");
  return `<section class="admin-learning-section"><h3>Năng lực AI theo bài</h3>
    <p class="muted">Tỷ lệ AI đúng tính trên lượt phân tích thật có đánh giá AI đúng hoặc AI sai của giáo viên.</p>
    ${table(["Bài học","Đã phân tích","AI báo đạt","GV xác nhận AI đúng","GV xác nhận AI sai","GV chưa chắc","Tỷ lệ AI đúng"],totals,"Chưa có dữ liệu.")}
    </section><section class="admin-learning-section"><h3>Kết quả kiểm tra lại theo tiêu chí</h3>
    <p class="muted">Mỗi bài làm dùng lần kiểm tra lại gần nhất của từng tiêu chí.</p>
    ${table(["Bài học","Tiêu chí","Bài có kiểm tra lại","AI báo đúng sau kiểm tra"],rechecks,"Chưa có ảnh kiểm tra lại trong bộ lọc này.")}
    </section><section class="admin-learning-section"><h3>Nguyên nhân AI sai</h3>
    ${table(["Bài học","Tiêu chí","Lý do","Số lượt"], aiErrors, "Chưa có nguyên nhân AI sai đã lưu.")}
    </section><section class="admin-learning-section"><h3>Thử nghiệm A/B</h3>
    <p class="muted">Mỗi bài nộp tính lần chạy A/B gần nhất. Tỷ lệ đúng tính trên các tiêu chí đủ điều kiện đối chiếu.</p>
    ${table(["Bài học","Lượt A/B","A đúng","B đúng","Bỏ sót an toàn A · B","Báo đạt nhầm A · B","Cảnh báo nhầm A · B","Ảnh rõ chưa xác định A · B","Lượt lỗi","B thiếu tham chiếu"], comparisons, "Chưa có lượt A/B trong bộ lọc này.")}
    </section>`;
}

function systemOverview(data, classCode, teacher) {
  const classes = data.classes.filter(row => !classCode || row.code === classCode);
  const groupCounts = new Map();
  for (const group of data.groups) groupCounts.set(group.classCode, (groupCounts.get(group.classCode) || 0) + 1);
  const rows = classes.map(row => {
    const activity = data.classActivity.find(item => item.classCode === row.code);
    return `<tr><th scope="row">${escapeHtml(row.code)}</th><td>${escapeHtml(row.teachers || "Chưa phân công")}</td>
      <td>${groupCounts.get(row.code) || 0}</td><td>${activity?.attempts || 0}</td><td>${activity?.analysed || 0}</td>
      <td>${activity?.images || 0}</td><td>${fmt(activity?.lastAttemptAt)}</td></tr>`;
  }).join("");
  const attempts = data.lessons.reduce((sum,row) => sum + row.attempts,0);
  const real = data.lessons.reduce((sum,row) => sum + row.realAttempts,0);
  const analysed = data.lessons.reduce((sum,row) => sum + row.analysed,0);
  const images = data.classActivity.reduce((sum,row) => sum + row.images,0);
  const references = data.sampleCounts.filter(row => row.status === "approved").reduce((sum,row) => sum + row.count,0);
  const cards = [[classes.length,"lớp"],[data.groups.length,"nhóm học sinh"],[attempts,"lượt nộp"],[analysed,"lượt phân tích thật"],
    [real-analysed,"lượt chờ phân tích"],[attempts-real,"lượt demo"],[images,"ảnh bài nộp đã đồng bộ"],[references,"ảnh tham chiếu đã duyệt"]];
  const teacherAccounts = data.staff.find(row => row.role === "teacher");
  const adminAccounts = data.staff.find(row => row.role === "admin");
  return `<section class="admin-learning-section"><h3>${teacher ? "Tổng quan lớp phụ trách" : "Tổng quan hệ thống"}</h3>
    <div class="report-kpis">${cards.map(([count,label]) => `<article><span>${count}</span><small>${label}</small></article>`).join("")}</div>
    ${teacher ? "" : `<p class="muted">Tài khoản đang hoạt động toàn hệ thống · ${teacherAccounts?.active || 0}/${teacherAccounts?.total || 0} giáo viên · ${adminAccounts?.active || 0}/${adminAccounts?.total || 0} quản trị viên</p>`}
    ${table(["Lớp","Giáo viên","Nhóm trong lớp","Lượt nộp","Đã phân tích","Ảnh đã đồng bộ","Nộp gần nhất"],rows,"Chưa có lớp trong phạm vi báo cáo.")}
    </section>`;
}

function pager(kind, offset, limit, total) {
  if (total <= limit) return "";
  return `<div class="admin-learning-pager"><button class="btn btn-ghost" type="button" data-learning-page="${kind}" data-offset="${Math.max(0,offset-limit)}" ${offset ? "" : "disabled"}>Trang trước</button>
    <span>${offset+1}–${Math.min(offset+limit,total)} / ${total}</span>
    <button class="btn btn-ghost" type="button" data-learning-page="${kind}" data-offset="${offset+limit}" ${offset+limit < total ? "" : "disabled"}>Trang sau</button></div>`;
}

function studentWork(data, offset) {
  const roster = data.groups.map(group => `<tr><th scope="row">${escapeHtml(group.name)}</th><td>${escapeHtml(group.classCode)}</td>
    <td>${group.attempts}</td><td>${fmt(group.lastSeenAt)}</td></tr>`).join("");
  const work = data.attempts.map((attempt, index) => `<tr><td>${fmt(attempt.time)}</td><th scope="row">${escapeHtml(attempt.studentName || "Nhóm chưa đặt tên")}</th><td>Lần ${attempt.attemptNumber}</td>
    <td>${escapeHtml(attempt.classCode)}</td><td>${escapeHtml(title(attempt.lessonId))}</td><td>${attempt.analysisStatus === "submitted" ? "Chờ phân tích" : attempt.verdict === "pass" ? "Đạt" : "Cần kiểm tra"}${attempt.demo ? " · Demo" : ""}</td>
    <td>${verification[attempt.teacherVerification] || "Chờ giáo viên"}</td><td><button type="button" class="text-button" data-learning-attempt="${index}">Xem bài</button></td></tr>`).join("");
  const total = data.lessons.reduce((sum, row) => sum + row.attempts, 0);
  return `<section class="admin-learning-section"><h3>Danh sách học sinh và nhóm</h3>
    ${table(["Tên học sinh hoặc nhóm","Lớp","Bài nộp trong bộ lọc","Hoạt động gần nhất"], roster, "Chưa có học sinh hoặc nhóm trong lớp.")}
    </section><section class="admin-learning-section"><h3>Bài làm</h3>
    ${table(["Thời gian","Nhóm","Lần làm","Lớp","Bài học","Kết quả AI","Xác nhận","Chi tiết"], work, "Chưa có bài làm trong bộ lọc này.")}
    ${pager("attemptOffset",offset,data.attemptLimit,total)}</section>`;
}

function photoGallery(data, offset) {
  const total = data.sampleCounts.reduce((sum, row) => sum + row.count, 0);
  const rows = data.sampleCounts.map(row => `<tr><td>${escapeHtml(title(row.lessonId))}</td><td>${aiLabels[row.label] || "Có nhãn"}</td>
    <td>${photoStatuses[row.status] || "—"}</td><td>${row.count}</td></tr>`).join("");
  const photos = data.photos.map((photo,index) => {
    const url = photo.source === "sample"
      ? lessonSampleUrl({ classCode:photo.classCode, lessonId:photo.lessonId, photoId:photo.id, manage:true })
      : referenceExamplePhotoUrl(photo.id,photo.classCode);
    const name = photo.title || label(photo.lessonId,photo.criterionId);
    return `<article class="lesson-sample-photo">
      <button class="lesson-sample-thumbnail" type="button" data-learning-photo="${index}" aria-label="Phóng to ${escapeHtml(name)}"><img src="${escapeHtml(url)}" alt="${escapeHtml(name)}" loading="lazy" /></button>
      <div class="lesson-sample-details"><strong>${escapeHtml(name)}</strong><p>${escapeHtml(title(photo.lessonId))} · ${escapeHtml(photo.classCode)}</p>
      <p>${aiLabels[photo.label] || "Có nhãn"} · ${photoStatuses[photo.status] || "—"}${photo.annotations?.length ? ` · ${photo.annotations.length} chú thích hoặc nét vẽ` : ""}</p>
      ${photo.caption ? `<p>${escapeHtml(photo.caption)}</p>` : ""}</div></article>`;
  }).join("");
  return `<section class="admin-learning-section"><h3>Thống kê ảnh mẫu và ảnh tham chiếu</h3>
    ${table(["Bài học","Nhãn","Trạng thái","Số ảnh"],rows,"Chưa có ảnh mẫu trong bộ lọc này.")}
    </section><section class="admin-learning-section"><h3>Xem ảnh</h3>
    ${photos ? `<div class="lesson-sample-grid">${photos}</div>` : '<p class="muted">Chưa có ảnh.</p>'}
    ${pager("photoOffset",offset,data.photoLimit,total)}</section>`;
}

export function mountLearningReport(section, { role = "admin", onReady = () => {} } = {}) {
  const teacher = role === "teacher";
  const tabs = { system: teacher ? "Tổng quan lớp phụ trách" : "Tổng quan hệ thống", students: "Năng lực học sinh", ai: "Năng lực AI", work: "Học sinh và bài làm", photos: "Ảnh mẫu" };
  const allClasses = teacher ? "Tất cả lớp phụ trách" : "Tất cả lớp";
  const filters = { classCode:"", lessonId:"", attemptOffset:0, photoOffset:0 };
  let active = "system";
  let data;
  let pending;
  section.innerHTML = `<h2>Lớp học và báo cáo</h2><div class="admin-learning-filters">
    <label>Lớp<select name="classCode"><option value="">${allClasses}</option></select></label>
    <label>Bài học<select name="lessonId"><option value="">Tất cả bài học</option>
      ${lessons.map(lesson => `<option value="${lesson.id}">${escapeHtml(lesson.title)}</option>`).join("")}</select></label>
    <span data-learning-teachers class="muted"></span>
    </div><nav class="teacher-view-tabs admin-learning-tabs" aria-label="Dữ liệu lớp học">${Object.entries(tabs).map(([id,name]) =>
      `<button type="button" data-learning-tab="${id}">${name}</button>`).join("")}</nav>
    <p role="status" data-learning-status></p><div data-learning-body></div>
    <dialog class="reference-dialog admin-attempt-dialog" aria-label="Bài làm học sinh"><div class="dialog-head">
      <h2>Chi tiết bài làm</h2><button class="btn btn-ghost" type="button" data-attempt-close>Đóng</button>
    </div><div data-attempt-body></div></dialog>`;
  const body = section.querySelector("[data-learning-body]");
  const message = section.querySelector("[data-learning-status]");
  const classSelect = section.querySelector('[name="classCode"]');
  const lessonSelect = section.querySelector('[name="lessonId"]');
  const dialog = section.querySelector(".admin-attempt-dialog");
  const viewer = createPhotoViewer();
  section.append(viewer.element);

  function render() {
    for (const button of section.querySelectorAll("[data-learning-tab]")) {
      const selected = button.dataset.learningTab === active;
      button.classList.toggle("selected",selected);
      button.setAttribute("aria-pressed",String(selected));
    }
    switch (active) {
      case "students": body.innerHTML = studentSkills(data,filters.lessonId); break;
      case "ai": body.innerHTML = aiPerformance(data,filters.lessonId); break;
      case "work": body.innerHTML = studentWork(data,filters.attemptOffset); break;
      case "photos": body.innerHTML = photoGallery(data,filters.photoOffset); break;
      default: body.innerHTML = systemOverview(data,filters.classCode,teacher);
    }
  }

  async function load() {
    pending?.abort();
    const request = pending = new AbortController();
    body.setAttribute("aria-busy","true");
    message.textContent = "Đang tải dữ liệu…";
    try {
      const result = await fetchLearningReport(filters, request.signal, role);
      if (request.signal.aborted || !section.isConnected) return;
      data = result;
      classSelect.innerHTML = `<option value="">${allClasses}</option>` + data.classes.map(row =>
        `<option value="${escapeHtml(row.code)}">${escapeHtml(row.code)}</option>`).join("");
      classSelect.value = filters.classCode;
      section.querySelector("[data-learning-teachers]").textContent = filters.classCode
        ? `Giáo viên phụ trách: ${data.classes.find(row => row.code === filters.classCode)?.teachers || "Chưa phân công"}` : "";
      message.textContent = "";
      render();
      onReady();
    } catch (error) {
      if (request.signal.aborted || !section.isConnected || (error.status === 404 && !teacher)) return;
      body.replaceChildren();
      message.textContent = error.message;
      onReady();
    } finally {
      if (pending === request) body.removeAttribute("aria-busy");
    }
  }

  function updateFilter(key,value) {
    filters[key] = value;
    filters.attemptOffset = filters.photoOffset = 0;
    void load();
  }

  function openAttempt(attempt) {
    const photos = Array.from({ length:Math.min(3,attempt.imageCount || 0) }, (_,index) => `<button class="lesson-sample-thumbnail" type="button" data-attempt-picture aria-label="Phóng to ảnh ${index+1}"><img src="${sharedAttemptImageUrl(attempt.id,attempt.classCode,index)}" alt="Ảnh mạch ${index+1}" /></button>`).join("");
    const current = reportProblems(attempt);
    const checks = current.map(problem => `<tr><th scope="row">${escapeHtml(problem.label || problem.id)}</th>
      <td>${problem.ruleEvidence?.physicalCheckRequired ? "Cần kiểm tra trực tiếp" : aiLabels[problem.status] || "—"}</td><td>${aiLabels[attempt.teacherCriterionLabels?.[problem.id || problem.criterionId]] || "—"}</td>
      <td>${problem.recheckId ? "Ảnh kiểm tra lại · " : ""}${escapeHtml(problem.evidence || "")}</td></tr>`).join("");
    dialog.querySelector("[data-attempt-body]").innerHTML = `<p><strong>${escapeHtml(attempt.studentName)}</strong> · ${escapeHtml(attempt.classCode)} · ${escapeHtml(title(attempt.lessonId))} · Lần ${attempt.attemptNumber} · ${fmt(attempt.time)}</p>
      <p>${escapeHtml(reportSummary(attempt, current) || "Chưa có tóm tắt.")}</p><p><strong>Nhận xét giáo viên</strong> ${escapeHtml(attempt.teacherComment || "Chưa có")}</p>
      <p><strong>An toàn mạch thật</strong> ${attempt.teacherPhysicallyChecked
        ? escapeHtml({ safe_to_power:"Cho phép cấp nguồn",unsafe:"Phát hiện nguy cơ",uncertain:"Chưa thể kết luận" }[attempt.teacherSafetyCheck] || "Đã kiểm tra")
        : "Chưa kiểm tra trực tiếp"}</p>
      ${photos ? `<div class="lesson-sample-grid">${photos}</div>` : ""}${table(["Tiêu chí","AI","Nhãn giáo viên","Dấu hiệu trên ảnh"],checks,"Chưa có đánh giá tiêu chí.")}`;
    dialog.showModal();
  }

  classSelect.addEventListener("change", () => updateFilter("classCode",classSelect.value));
  lessonSelect.addEventListener("change", () => updateFilter("lessonId",lessonSelect.value));
  section.addEventListener("click", event => {
    const button = event.target.closest("button");
    if (!button) return;
    if (button.hasAttribute("data-attempt-close")) { dialog.close(); return; }
    const { learningTab, learningLesson, learningAttempt, learningPhoto, learningPage, offset } = button.dataset;
    if (!data || body.getAttribute("aria-busy") === "true") return;
    if (learningTab) { active = learningTab; render(); }
    if (learningLesson) {
      lessonSelect.value = learningLesson;
      updateFilter("lessonId",learningLesson);
    }
    if (learningPage) { filters[learningPage] = Number(offset); void load(); }
    if (learningAttempt !== undefined) openAttempt(data.attempts[Number(learningAttempt)]);
    if (learningPhoto !== undefined || button.hasAttribute("data-attempt-picture")) {
      const image = button.querySelector("img");
      const photo = data.photos[Number(learningPhoto)];
      viewer.open(image.src,image.alt,photo?.annotations);
    }
  });
  void load();
}

export function renderTeacherLearningReport(root) {
  root.innerHTML = appShell(`<section class="teacher-page">
    <nav class="teacher-view-tabs" aria-label="Chế độ xem giáo viên">
      <a href="#/teacher">Bảng điều khiển</a><a href="#/teacher-reports" class="selected" aria-current="page">Báo cáo thống kê</a>
    </nav>
    <section class="panel admin-learning" data-teacher-learning></section>
  </section>`, "teacher");
  mountLearningReport(root.querySelector("[data-teacher-learning]"), { role:"teacher" });
}
