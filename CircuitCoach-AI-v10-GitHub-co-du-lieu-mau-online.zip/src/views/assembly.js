import { assemblyGuides } from "../data/assembly-guides.js";
import { getLesson } from "../data/lessons.js";
import { getStudent } from "../services/storage.js";
import { appShell, escapeHtml, icon } from "./shared.js";

const wireColors = { power: "#ff817c", ground: "#c0c9d0", signal: "#ffca71", probe: "#71e0ff" };
const drawMilliseconds = 650;
const stepMilliseconds = 4200;

function renderDevice({ name, detail, ports }) {
  return `<section class="assembly-device" aria-label="${escapeHtml(name)}">
    <div class="assembly-device-name"><strong>${escapeHtml(name)}</strong>${detail ? `<small>${escapeHtml(detail)}</small>` : ""}</div>
    <ul>${ports.map(([id, title]) => `<li>${escapeHtml(title)}<i class="assembly-pin" data-pin="${id}" aria-hidden="true"></i></li>`).join("")}</ul>
  </section>`;
}

function traceWire(context, wire, progress, active) {
  const { points, lengths, length, color } = wire;
  let distance = length * progress;
  context.beginPath();
  context.moveTo(...points[0]);
  for (let index = 0; index < lengths.length; index += 1) {
    const next = points[index + 1];
    if (distance >= lengths[index]) {
      context.lineTo(...next);
      distance -= lengths[index];
      continue;
    }
    const start = points[index];
    const fraction = distance / lengths[index];
    context.lineTo(start[0] + (next[0] - start[0]) * fraction, start[1] + (next[1] - start[1]) * fraction);
    break;
  }
  context.strokeStyle = color;
  context.lineWidth = active ? 4 : 3;
  context.globalAlpha = active ? 1 : 0.68;
  context.lineJoin = "round";
  context.lineCap = "round";
  context.stroke();
}

export function renderAssembly(root, lessonId) {
  const lesson = getLesson(lessonId);
  const guide = Object.hasOwn(assemblyGuides, lessonId) ? assemblyGuides[lessonId] : null;
  if (!lesson || !guide) {
    location.hash = "#/lessons";
    return;
  }
  const { steps } = guide;
  root.innerHTML = appShell(`
    <section class="assembly-page">
      <div class="breadcrumb"><a href="#/lessons">Bài học</a><span>/</span><a href="#/analyzer/${lesson.id}">${escapeHtml(lesson.title)}</a><span>/</span><strong>Lắp mạch</strong></div>
      <header class="page-head compact-head assembly-header"><div><h1>Lắp mạch ${escapeHtml(lesson.title)}</h1><p>Theo dõi từng dây trên sơ đồ và đối chiếu với nhãn chân trên linh kiện thật.</p></div></header>
      <p class="assembly-safety">${icon("alert", 20)} <span>Ngắt nguồn trong lúc lắp. Chỉ cấp nguồn sau khi giáo viên kiểm tra trực tiếp và cho phép.</span></p>
      <div class="assembly-workspace">
        <div class="assembly-diagram">
          <div class="assembly-diagram-header">
            <span>Sơ đồ chân nối</span>
            <p class="assembly-step-index" role="status" aria-atomic="true">Bước 1 / ${steps.length}</p>
          </div>
          <div class="assembly-action">
            <strong>Cách làm</strong>
            <p class="assembly-step-detail" aria-live="polite"></p>
          </div>
          <div class="assembly-stage" aria-label="Sơ đồ chân nối">
            <canvas aria-hidden="true"></canvas>
            ${guide.columns.map(column => `<div class="assembly-devices">${column.map(renderDevice).join("")}</div>`).join("")}
          </div>
        </div>
        <section class="assembly-instructions" id="assembly-current-step">
          <div aria-live="polite" aria-atomic="true">
            <h2></h2>
            <p class="assembly-connection"></p>
            <div class="assembly-check">
              <strong>Tự kiểm tra</strong>
              <p class="assembly-step-check"></p>
            </div>
          </div>
          ${guide.note ? `<p class="assembly-note">${escapeHtml(guide.note)}</p>` : ""}
          <div class="assembly-controls">
            <button class="btn btn-secondary" type="button" data-assembly="previous">Bước trước</button>
            <button class="btn btn-primary" type="button" data-assembly="next">Bước tiếp theo</button>
            <button class="btn btn-ghost" type="button" data-assembly="play">Tự chạy</button>
            <button class="btn btn-ghost" type="button" data-assembly="replay">Xem lại bước</button>
          </div>
          <a class="text-button assembly-result-link" href="#/analyzer/${lesson.id}" hidden>${getStudent() ? "Mở phân tích ảnh mạch" : "Mở bài học"}</a>
        </section>
      </div>
      <ol class="assembly-step-list" aria-label="Các bước lắp mạch">
        ${steps.map((step, index) => `<li><button type="button" data-assembly-step="${index}" aria-controls="assembly-current-step">
          <span>${index + 1}</span>${escapeHtml(step.title)}<small class="assembly-current-tag" aria-hidden="true">Đang xem</small>
        </button></li>`).join("")}
      </ol>
    </section>`, "lessons");
  window.scrollTo({ top: 0, left: 0, behavior: "instant" });

  const stage = root.querySelector(".assembly-stage");
  const columns = [...stage.querySelectorAll(".assembly-devices")];
  const pinElements = new Map([...stage.querySelectorAll("[data-pin]")].map(pin => [pin.dataset.pin, pin]));
  const canvas = stage.querySelector("canvas");
  const context = canvas.getContext("2d");
  const stepIndex = root.querySelector(".assembly-step-index");
  const title = root.querySelector(".assembly-instructions h2");
  const connection = root.querySelector(".assembly-connection");
  const detail = root.querySelector(".assembly-step-detail");
  const check = root.querySelector(".assembly-step-check");
  const stepButtons = [...root.querySelectorAll("[data-assembly-step]")];
  const previous = root.querySelector('[data-assembly="previous"]');
  const next = root.querySelector('[data-assembly="next"]');
  const play = root.querySelector('[data-assembly="play"]');
  const replay = root.querySelector('[data-assembly="replay"]');
  const resultLink = root.querySelector(".assembly-result-link");
  const noMotion = matchMedia("(prefers-reduced-motion: reduce)");
  const events = new AbortController();
  const { signal } = events;
  const lastStep = steps.length - 1;
  let current = 0;
  let progress = 1;
  let playing = false;
  let frame = 0;
  let timer = 0;
  let geometry = [];
  let width = 0;
  let height = 0;

  function draw() {
    if (!context) return;
    context.clearRect(0, 0, width, height);
    for (let index = 0; index <= current; index += 1) {
      for (const wire of geometry[index] || []) traceWire(context, wire, index === current ? progress : 1, index === current);
    }
    context.globalAlpha = 1;
  }

  function measure() {
    if (!context) return;
    const bounds = canvas.getBoundingClientRect();
    if (!bounds.width || !bounds.height) return;
    width = bounds.width;
    height = bounds.height;
    const density = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.round(width * density);
    canvas.height = Math.round(height * density);
    context.setTransform(density, 0, 0, density, 0, 0);
    const channelStart = columns[0].getBoundingClientRect().right - bounds.left;
    const channelEnd = columns[1].getBoundingClientRect().left - bounds.left;
    const portPositions = new Map([...pinElements].map(([id, pin]) => {
      const rect = pin.getBoundingClientRect();
      return [id, [rect.left + rect.width / 2 - bounds.left, rect.top + rect.height / 2 - bounds.top]];
    }));
    const channels = steps.reduce((sum, step) => sum + step.wires.length, 1);
    let lane = 0;
    geometry = steps.map(step => step.wires.map(([from, to, kind]) => {
      const start = portPositions.get(from);
      const end = portPositions.get(to);
      lane += 1;
      const channel = channelStart + (channelEnd - channelStart) * lane / channels;
      const points = [start, [channel, start[1]], [channel, end[1]], end];
      const lengths = points.slice(1).map(([x, y], index) => Math.hypot(x - points[index][0], y - points[index][1]));
      return { points, lengths, length: lengths.reduce((sum, length) => sum + length, 0), color: wireColors[kind] };
    }));
    draw();
  }

  function setPlaying(value) {
    playing = value;
    clearTimeout(timer);
    play.textContent = playing ? "Tạm dừng" : current === lastStep ? "Tự chạy lại" : "Tự chạy";
  }

  function showStep(index) {
    clearTimeout(timer);
    cancelAnimationFrame(frame);
    current = index;
    const step = steps[current];
    stepIndex.textContent = `Bước ${current + 1} / ${steps.length}`;
    title.textContent = step.title;
    connection.textContent = lesson.expectedConnections[current];
    detail.textContent = step.detail;
    check.textContent = step.check;
    previous.disabled = current === 0;
    next.disabled = current === lastStep;
    resultLink.hidden = current !== lastStep;
    for (const [position, button] of stepButtons.entries()) button.setAttribute("aria-current", position === current ? "step" : "false");
    for (const pin of pinElements.values()) pin.classList.remove("active");
    for (const [from, to, kind] of step.wires) {
      for (const id of [from, to]) {
        const pin = pinElements.get(id);
        pin.classList.add("active");
        pin.style.setProperty("--wire-color", wireColors[kind]);
      }
    }
    if (context && !noMotion.matches) {
      const started = performance.now();
      progress = 0;
      draw();
      function animate(now) {
        progress = Math.min(1, (now - started) / drawMilliseconds);
        draw();
        if (progress < 1) frame = requestAnimationFrame(animate);
      }
      frame = requestAnimationFrame(animate);
    } else {
      progress = 1;
      draw();
    }
    setPlaying(playing);
    if (playing) timer = setTimeout(() => {
      if (current < lastStep) showStep(current + 1);
      else setPlaying(false);
    }, stepMilliseconds);
  }

  function select(index) {
    setPlaying(false);
    showStep(index);
  }

  previous.addEventListener("click", () => select(current - 1), { signal });
  next.addEventListener("click", () => select(current + 1), { signal });
  replay.addEventListener("click", () => select(current), { signal });
  stepButtons.forEach((button, index) => button.addEventListener("click", () => select(index), { signal }));
  play.addEventListener("click", () => {
    if (playing) setPlaying(false);
    else {
      setPlaying(true);
      showStep(current === lastStep ? 0 : current);
    }
  }, { signal });
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      setPlaying(false);
      cancelAnimationFrame(frame);
      progress = 1;
      draw();
    }
  }, { signal });
  noMotion.addEventListener("change", () => {
    cancelAnimationFrame(frame);
    progress = 1;
    draw();
  }, { signal });

  const observer = new ResizeObserver(measure);
  observer.observe(stage);
  stage.querySelectorAll(".assembly-device").forEach(device => observer.observe(device));
  measure();
  showStep(0);

  return () => {
    events.abort();
    observer.disconnect();
    clearTimeout(timer);
    cancelAnimationFrame(frame);
  };
}
