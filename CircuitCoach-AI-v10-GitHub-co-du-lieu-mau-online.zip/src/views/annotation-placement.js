// Match the number size and offset in the .annotation-number style.
const badgeSize = 24;
const badgeGap = 10;

export function placeAnnotationBadges(areas, imageWidth, imageHeight) {
  const regions = areas.map(area => {
    const { x, y, width, height } = area.region || area.problems[0].region;
    return {
      number: area.number,
      left: x * imageWidth / 100,
      top: y * imageHeight / 100,
      right: (x + width) * imageWidth / 100,
      bottom: (y + height) * imageHeight / 100,
    };
  });
  const occupied = [...regions];
  const positions = new Map();
  for (const { number, left, top, right, bottom } of regions) {
    const centeredX = (left + right - badgeSize) / 2;
    const centeredY = (top + bottom - badgeSize) / 2;
    const offset = badgeSize + badgeGap;
    const candidates = [
      { side: "top", x: centeredX, y: top - offset, room: top },
      { side: "right", x: right + badgeGap, y: centeredY, room: imageWidth - right },
      { side: "bottom", x: centeredX, y: bottom + badgeGap, room: imageHeight - bottom },
      { side: "left", x: left - offset, y: centeredY, room: left },
    ];
    candidates.sort((a, b) => b.room - a.room);
    for (const { side, x, y } of candidates) {
      const box = { left: x, top: y, right: x + badgeSize, bottom: y + badgeSize };
      if (box.left < 1 || box.top < 1 || box.right > imageWidth - 1 || box.bottom > imageHeight - 1) continue;
      if (occupied.some(item => box.left < item.right && box.right > item.left && box.top < item.bottom && box.bottom > item.top)) continue;
      positions.set(number, side);
      occupied.push(box);
      break;
    }
  }
  return positions;
}
