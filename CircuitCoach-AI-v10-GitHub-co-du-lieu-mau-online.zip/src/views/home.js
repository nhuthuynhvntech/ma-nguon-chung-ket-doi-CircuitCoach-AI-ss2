import { enterStudentGroup, getStudent } from "../services/storage.js";
import { applyTeacherSession, getBrowserSession, notifyBrowserSessionChange, saveTeacherClassCode, saveTeacherPassword, saveTeacherUsername, verifyAdminAccount, verifyTeacherAccount, withBrowserSessionLock } from "../services/classroom.js";
import { SAFETY_WARNING } from "../data/safety.js";
import { SESSION_ROLES } from "../data/session-roles.js";
import { appShell, escapeHtml, icon, renderGuideChatTrigger, renderThemeToggle } from "./shared.js";

export function renderHome(root, { initialRole = "", refresh = () => {} } = {}) {
  const session = getBrowserSession();
  const active = SESSION_ROLES[session?.role || (getStudent() ? "student" : "")];
  if (active) {
    root.innerHTML = appShell(`<section class="login-page"><div class="login-active-group">
      <h1>CircuitCoach AI</h1><a class="btn btn-primary" href="${active.home}">Tiếp tục với vai trò ${active.label}</a>
      </div></section>`, "home");
    return;
  }
  root.innerHTML = `
    <div class="ai-warning-bar home-warning-bar" role="note" aria-label="Cảnh báo về độ chính xác của AI">
      ${icon("alert", 18)}
      <p><strong>Cảnh báo AI:</strong> ${escapeHtml(SAFETY_WARNING)}</p>
    </div>
    <main class="login-page">
      <header class="login-brand">
        <img class="brand-logo" src="/images/circuitcoach-logo.png" alt="" width="44" height="44" />
        <h1>CircuitCoach AI</h1>
        ${renderThemeToggle()}
      </header>
      <section class="login-section" aria-labelledby="login-title">
        <h2 id="login-title">Đăng nhập</h2>
        <fieldset class="login-roles">
          <legend>Bạn vào với vai trò nào?</legend>
          <div id="role-picker" class="role-picker">
            <button class="role-choice" type="button" data-role="student" aria-pressed="false" aria-controls="login-form">${icon("user", 20)}<span>Học sinh</span></button>
            <button class="role-choice" type="button" data-role="teacher" aria-pressed="false" aria-controls="login-form">${icon("teacher", 20)}<span>Giáo viên</span></button>
            <button class="role-choice" type="button" data-role="admin" aria-pressed="false" aria-controls="login-form">${icon("lock", 20)}<span>Quản trị viên</span></button>
          </div>
        </fieldset>
        <form id="login-form" class="login-form" aria-labelledby="login-title" hidden>
          <div class="login-fields" id="login-fields"></div>
          <p class="login-status" role="status" id="login-status"></p>
          <button class="btn btn-primary" type="submit"><span>Đăng nhập</span> ${icon("arrow", 18)}</button>
        </form>
        <p class="privacy-mini" id="login-privacy" hidden>Giáo viên có thể xem kết quả và ảnh mạch của nhóm. Không tải ảnh có khuôn mặt hoặc thông tin cá nhân.</p>
      </section>
      <nav class="login-public-nav" aria-label="Trang xem không cần đăng nhập">
        ${renderGuideChatTrigger()}
        <a class="text-button" href="#/references">${icon("book", 18)} Kho tham chiếu</a>
        <a class="text-button" href="#/ai-progress">${icon("spark", 18)} Theo dõi AI ${icon("arrow", 16)}</a>
        ${session?.localOpenAISettings || session?.browserOpenAISettings ? `<a class="text-button" href="#/settings">${icon("settings", 18)} Cấu hình OpenAI</a>` : ""}
      </nav>
    </main>`;
  const form = root.querySelector("#login-form");
  const choices = root.querySelectorAll("#role-picker [data-role]");
  const fields = form.querySelector("#login-fields");
  const status = form.querySelector("#login-status");
  const submit = form.querySelector('button[type="submit"]');
  const privacy = root.querySelector("#login-privacy");
  let role = "";
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const data = new FormData(form);
    if (submit.disabled) return;
    submit.disabled = true;
    choices.forEach(choice => { choice.disabled = true; });
    delete status.dataset.error;
    status.textContent = "Đang đăng nhập…";
    try {
      await withBrowserSessionLock(async () => {
        if (role === "student") {
          const name = data.get("name").trim();
          const classCode = data.get("classCode").trim().toUpperCase();
          if (name.length < 2 || !/^[A-Z0-9]{4,12}$/.test(classCode)) throw new Error("Kiểm tra tên nhóm và mã lớp (4–12 chữ cái hoặc chữ số).");
          await enterStudentGroup(name, classCode, []);
        } else if (role === "admin") {
          await verifyAdminAccount(data.get("username"), data.get("password"));
        } else {
          const username = data.get("username").trim();
          const password = data.get("password");
          const session = await verifyTeacherAccount(username, password);
          if (session.personalSession) {
            applyTeacherSession({ ...session, username: session.username || username });
          } else {
            saveTeacherClassCode(data.get("classCode"));
            saveTeacherUsername(username);
            saveTeacherPassword(password);
          }
        }
        notifyBrowserSessionChange();
      });
      const page = SESSION_ROLES[role].home;
      if (location.hash === page) void refresh();
      else location.hash = page;
    } catch (error) {
      status.dataset.error = "true";
      status.textContent = error.message;
    } finally {
      submit.disabled = false;
      choices.forEach(choice => { choice.disabled = false; });
    }
  });
  choices.forEach(choice => choice.addEventListener("click", () => {
    if (role === choice.dataset.role) return;
    role = choice.dataset.role;
    choices.forEach(item => item.setAttribute("aria-pressed", String(item === choice)));
    submit.querySelector("span").textContent = {
      student: "Vào lớp", teacher: "Đăng nhập giáo viên", admin: "Đăng nhập quản trị",
    }[role];
    status.textContent = "";
    delete status.dataset.error;
    if (role === "student") {
      fields.innerHTML = '<label>Tên hoặc tên nhóm<input name="name" autocomplete="off" minlength="2" maxlength="40" placeholder="Tên em dùng trong lớp" required></label><label>Mã lớp<input name="classCode" autocapitalize="characters" spellcheck="false" minlength="4" maxlength="12" placeholder="Mã giáo viên cung cấp" required></label>';
    } else {
      fields.innerHTML = '<label>Tên đăng nhập<input name="username" autocomplete="username" maxlength="40" required></label><label>Mật khẩu<input name="password" type="password" autocomplete="current-password" maxlength="128" required></label>';
      if (role === "teacher" && !getBrowserSession() && !["localhost", "127.0.0.1"].includes(location.hostname)) {
        fields.insertAdjacentHTML("beforeend", '<label>Mã lớp<input name="classCode" maxlength="12" required></label>');
      }
    }
    form.hidden = false;
    privacy.hidden = role !== "student";
    fields.querySelector("input").focus({ preventScroll: true });
  }));
  [...choices].find(choice => choice.dataset.role === initialRole)?.click();
}
