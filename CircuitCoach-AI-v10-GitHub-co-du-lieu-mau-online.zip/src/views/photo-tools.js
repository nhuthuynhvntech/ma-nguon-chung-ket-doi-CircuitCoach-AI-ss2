import { escapeHtml, icon } from "./shared.js";

export function drawPhotoAnnotations(layer, annotations) {
  const shapes = [];
  const notes = [];
  for (const { kind, points, text } of annotations) {
    const [[x, y], end] = points;
    if (kind === "line") {
      shapes.push(`<polyline points="${points.map(point => point.join(",")).join(" ")}" />`);
    } else if (kind === "circle") {
      const [right, bottom] = end;
      shapes.push(`<ellipse cx="${(x + right) / 2}" cy="${(y + bottom) / 2}" rx="${Math.abs(right - x) / 2}" ry="${Math.abs(bottom - y) / 2}" />`);
    } else if (kind === "rect") {
      const [right, bottom] = end;
      shapes.push(`<rect x="${x}" y="${y}" width="${right - x}" height="${bottom - y}" />`);
    } else if (kind === "note") {
      notes.push(`<span class="photo-mark-note ${x > 500 ? "on-left" : ""}" style="left:${x / 10}%;top:${y / 10}%">${escapeHtml(text)}</span>`);
    }
  }
  layer.innerHTML = `<svg class="photo-mark-shapes" aria-hidden="true" viewBox="0 0 1000 1000" preserveAspectRatio="none">${shapes.join("")}</svg>${notes.join("")}`;
}

export function photoAnnotationEditor() {
  return `<section class="photo-annotation-editor" data-annotation-editor hidden>
    <div class="reference-library-actions photo-mark-tools" role="group" aria-label="Công cụ chú thích">
      <button class="btn btn-secondary" type="button" data-mark="circle" aria-pressed="true">Khoanh vùng</button>
      <button class="btn btn-secondary" type="button" data-mark="line" aria-pressed="false">Vẽ tự do</button>
      <button class="btn btn-secondary" type="button" data-mark="note" aria-pressed="false">Chú thích</button>
      <button class="btn btn-secondary" type="button" data-mark="pan" aria-pressed="false">Di chuyển ảnh</button>
    </div>
    <div class="reference-library-actions photo-mark-controls" role="group" aria-label="Thu phóng và lịch sử đánh dấu">
      <button class="btn btn-ghost" type="button" data-mark-scale="-1" aria-label="Thu nhỏ ảnh" disabled>−</button>
      <output data-mark-percent aria-label="Mức thu phóng">100%</output>
      <button class="btn btn-ghost" type="button" data-mark-scale="1" aria-label="Phóng to ảnh" disabled>+</button>
      <button class="btn btn-ghost" type="button" data-mark-fit disabled>Vừa khung</button>
      <button class="btn btn-ghost" type="button" data-mark-undo disabled>Hoàn tác</button>
      <button class="btn btn-ghost" type="button" data-mark-redo disabled>Làm lại</button>
    </div>
    <label data-mark-note hidden>Nội dung chú thích<input data-mark-text maxlength="80" placeholder="Ví dụ: Chân LED đang cắm ngược" /></label>
    <small data-mark-help role="status"></small>
    <div class="photo-mark-viewport" data-mark-viewport role="region" aria-label="Ảnh để khoanh lỗi" tabindex="0" hidden>
      <div class="photo-mark-stage" data-mark-stage data-tool="circle">
        <img alt="Ảnh mạch đang chú thích" data-mark-image draggable="false" />
        <div class="photo-mark-layer" data-mark-layer aria-hidden="true"></div>
        <div class="photo-mark-layer photo-mark-preview" data-mark-preview aria-hidden="true"></div>
      </div>
    </div>
  </section>`;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function circleBounds(start, end, width, height) {
  const pixelsMoved = Math.hypot((end[0] - start[0]) * width / 1000, (end[1] - start[1]) * height / 1000);
  const minDiameter = pixelsMoved < 5 ? 36 : 12;
  const bounds = [width, height].map((size, axis) => {
    const center = (start[axis] + end[axis]) / 2;
    const span = Math.abs(end[axis] - start[axis]);
    const diameter = Math.ceil(Math.min(1000, Math.max(span, minDiameter * 1000 / size)));
    const low = clamp(Math.round(center - diameter / 2), 0, 1000 - diameter);
    return [low, low + diameter];
  });
  return [[bounds[0][0], bounds[1][0]], [bounds[0][1], bounds[1][1]]];
}

export function mountPhotoAnnotationEditor(editor) {
  const viewport = editor.querySelector("[data-mark-viewport]");
  const stage = editor.querySelector("[data-mark-stage]");
  const image = editor.querySelector("[data-mark-image]");
  const layer = editor.querySelector("[data-mark-layer]");
  const preview = editor.querySelector("[data-mark-preview]");
  const noteField = editor.querySelector("[data-mark-note]");
  const text = editor.querySelector("[data-mark-text]");
  const help = editor.querySelector("[data-mark-help]");
  const tools = editor.querySelectorAll("[data-mark]");
  const undo = editor.querySelector("[data-mark-undo]");
  const redo = editor.querySelector("[data-mark-redo]");
  const zoomOut = editor.querySelector('[data-mark-scale="-1"]');
  const zoomIn = editor.querySelector('[data-mark-scale="1"]');
  const fit = editor.querySelector("[data-mark-fit]");
  const percent = editor.querySelector("[data-mark-percent]");
  const hints = {
    circle: "Kéo chéo qua vùng lỗi hoặc chạm một lần để khoanh một chi tiết nhỏ.",
    line: "Kéo trên ảnh để vẽ tự do.",
    note: "Nhập chú thích rồi chạm vào vị trí cần đặt trên ảnh.",
    pan: "Phóng to rồi kéo ảnh tới vị trí cần xem.",
  };
  const photoDrafts = new Map();
  let history = { marks: [], undone: [] };
  let gesture;
  let level = 1;
  let pendingImage = 0;
  let tool = "circle";

  function renderMarks() {
    drawPhotoAnnotations(layer, history.marks);
    undo.disabled = history.marks.length === 0;
    redo.disabled = history.undone.length === 0;
  }

  function changed() {
    renderMarks();
    help.textContent = hints[tool];
    editor.dispatchEvent(new Event("annotationchange", { bubbles: true }));
  }

  function commit(mark) {
    history.marks.push(mark);
    history.undone.length = 0;
    changed();
  }

  function endGesture() {
    const active = gesture;
    gesture = undefined;
    stage.classList.remove("is-panning");
    preview.replaceChildren();
    if (active && stage.hasPointerCapture(active.id)) stage.releasePointerCapture(active.id);
  }

  function zoom(next) {
    endGesture();
    const oldBounds = stage.getBoundingClientRect();
    const windowBounds = viewport.getBoundingClientRect();
    const viewLeft = windowBounds.left + viewport.clientLeft;
    const viewTop = windowBounds.top + viewport.clientTop;
    const centerX = oldBounds.width ? clamp((viewLeft + viewport.clientWidth / 2 - oldBounds.left) / oldBounds.width, 0, 1) : .5;
    const centerY = oldBounds.height ? clamp((viewTop + viewport.clientHeight / 2 - oldBounds.top) / oldBounds.height, 0, 1) : .5;
    level = clamp(next, 1, 3);
    stage.style.setProperty("--photo-zoom", level);
    const bounds = stage.getBoundingClientRect();
    viewport.scrollBy(
      bounds.left + bounds.width * centerX - viewLeft - viewport.clientWidth / 2,
      bounds.top + bounds.height * centerY - viewTop - viewport.clientHeight / 2,
    );
    percent.value = `${level * 100}%`;
    zoomOut.disabled = level <= 1;
    zoomIn.disabled = level >= 3 || viewport.hidden;
    fit.disabled = level === 1;
  }

  function point(event, bounds) {
    return [
      Math.round(1000 * clamp((event.clientX - bounds.left) / bounds.width, 0, 1)),
      Math.round(1000 * clamp((event.clientY - bounds.top) / bounds.height, 0, 1)),
    ];
  }

  function moveDraft(event, finished = false) {
    const bounds = stage.getBoundingClientRect();
    const next = point(event, bounds);
    const { mark, start } = gesture;
    if (mark.kind === "circle") {
      mark.points = circleBounds(start, next, bounds.width, bounds.height);
      return;
    }
    const last = mark.points.at(-1);
    const distance = Math.hypot(next[0] - last[0], next[1] - last[1]);
    if (distance < (finished ? 1 : 4)) return;
    if (mark.points.length === 100) {
      mark.points = mark.points.filter((_, index) => index % 2 === 0 || index === 99);
    }
    mark.points.push(next);
  }

  function chooseTool(button) {
    endGesture();
    tool = button.dataset.mark;
    stage.dataset.tool = tool;
    for (const item of tools) item.setAttribute("aria-pressed", String(item === button));
    noteField.hidden = tool !== "note";
    help.textContent = hints[tool];
  }

  for (const button of tools) button.addEventListener("click", () => {
    chooseTool(button);
    if (tool === "note" && !viewport.hidden) text.focus();
  });
  zoomOut.addEventListener("click", () => zoom(level - .5));
  zoomIn.addEventListener("click", () => zoom(level + .5));
  fit.addEventListener("click", () => zoom(1));
  undo.addEventListener("click", () => {
    endGesture();
    if (!history.marks.length) return;
    history.undone.push(history.marks.pop());
    changed();
  });
  redo.addEventListener("click", () => {
    endGesture();
    if (!history.undone.length) return;
    history.marks.push(history.undone.pop());
    changed();
  });
  stage.addEventListener("dragstart", event => event.preventDefault());
  stage.addEventListener("pointerdown", event => {
    if (event.button !== 0 || gesture || viewport.hidden || editor.closest("fieldset:disabled")) return;
    event.preventDefault();
    if (tool === "pan") {
      if (level === 1) { help.textContent = "Bấm + để phóng to trước khi kéo ảnh."; return; }
      gesture = { id: event.pointerId, x: event.clientX, y: event.clientY, left: viewport.scrollLeft, top: viewport.scrollTop };
      stage.setPointerCapture(event.pointerId);
      stage.classList.add("is-panning");
      return;
    }
    if (history.marks.length >= 20) { help.textContent = "Mỗi ảnh lưu tối đa 20 nét hoặc chú thích."; return; }
    const bounds = stage.getBoundingClientRect();
    const start = point(event, bounds);
    if (tool === "note") {
      const note = text.value.trim();
      if (!note) { help.textContent = "Nhập nội dung trước khi đặt chú thích."; text.focus(); return; }
      commit({ kind: "note", points: [start], text: note });
      text.value = "";
      return;
    }
    const mark = { kind: tool, points: tool === "circle" ? circleBounds(start, start, bounds.width, bounds.height) : [start] };
    gesture = { id: event.pointerId, start, mark };
    stage.setPointerCapture(event.pointerId);
    drawPhotoAnnotations(preview, [mark]);
  });
  stage.addEventListener("pointermove", event => {
    if (event.pointerId !== gesture?.id) return;
    if (!gesture.mark) {
      viewport.scrollTo(gesture.left + gesture.x - event.clientX, gesture.top + gesture.y - event.clientY);
      return;
    }
    moveDraft(event);
    drawPhotoAnnotations(preview, [gesture.mark]);
  });
  stage.addEventListener("pointerup", event => {
    if (event.pointerId !== gesture?.id) return;
    const { mark } = gesture;
    if (mark) moveDraft(event, true);
    endGesture();
    if (mark?.points.length > 1) commit(mark);
  });
  for (const event of ["pointercancel", "lostpointercapture"]) {
    stage.addEventListener(event, ({ pointerId }) => {
      if (pointerId === gesture?.id) endGesture();
    });
  }

  async function show(src, { remember = false, marks = [] } = {}) {
    const request = ++pendingImage;
    viewport.hidden = true;
    zoom(1);
    editor.hidden = !src;
    text.value = "";
    history = photoDrafts.get(remember ? src : undefined) || { marks: [...marks], undone: [] };
    renderMarks();
    if (!src) { image.removeAttribute("src"); return; }
    if (remember) photoDrafts.set(src, history);
    help.textContent = "Đang mở ảnh…";
    image.src = src;
    try {
      await image.decode();
    } catch (error) {
      if (request !== pendingImage) return;
      help.textContent = "Không thể mở ảnh để đánh dấu.";
      throw error;
    }
    if (request !== pendingImage) return;
    stage.style.setProperty("--photo-natural-width", `${image.naturalWidth}px`);
    stage.style.setProperty("--photo-aspect", image.naturalWidth / image.naturalHeight);
    viewport.hidden = false;
    viewport.scrollTo(0, 0);
    zoom(1);
    if (tool === "pan") chooseTool(tools[0]);
    help.textContent = hints[tool];
  }

  return { show, reset() { photoDrafts.clear(); return show(); }, marks: () => history.marks };
}

export function createPhotoViewer({ renderOverlay = drawPhotoAnnotations } = {}) {
  const dialog = document.createElement("dialog");
  dialog.className = "reference-dialog photo-viewer";
  dialog.setAttribute("aria-label", "Xem ảnh mạch");
  dialog.innerHTML = `<div class="dialog-head">
    <h2 data-photo-title>Ảnh mạch</h2>
    <button class="icon-button" type="button" data-photo-close aria-label="Đóng ảnh">${icon("x", 22)}</button>
  </div><div class="reference-library-actions photo-viewer-actions">
    <button class="btn btn-ghost" type="button" data-photo-scale="-1" aria-label="Thu nhỏ">−</button>
    <span data-photo-percent>100%</span>
    <button class="btn btn-ghost" type="button" data-photo-scale="1" aria-label="Phóng to">+</button>
  </div><div class="photo-viewer-viewport"><div class="photo-viewer-image">
    <img alt="" /><div class="photo-mark-layer" data-photo-marks></div>
  </div></div><p class="reference-zoom-label" data-photo-caption hidden></p>`;
  const image = dialog.querySelector("img");
  const title = dialog.querySelector("[data-photo-title]");
  const caption = dialog.querySelector("[data-photo-caption]");
  const layer = dialog.querySelector("[data-photo-marks]");
  const canvas = dialog.querySelector(".photo-viewer-image");
  const viewport = dialog.querySelector(".photo-viewer-viewport");
  const scale = dialog.querySelector("[data-photo-percent]");
  const zoomOut = dialog.querySelector('[data-photo-scale="-1"]');
  const zoomIn = dialog.querySelector('[data-photo-scale="1"]');
  let level = 1;
  let fitWidth = 0;
  function zoom(next) {
    level = Math.max(1, Math.min(3, next));
    canvas.classList.toggle("is-zoomed", level > 1);
    canvas.style.width = level > 1 ? `${fitWidth * level}px` : "";
    scale.textContent = `${level * 100}%`;
    zoomOut.disabled = level <= 1;
    zoomIn.disabled = level >= 3 || !fitWidth;
  }
  image.addEventListener("load", () => { fitWidth = image.clientWidth; zoom(1); });
  zoomOut.addEventListener("click", () => zoom(level - .5));
  zoomIn.addEventListener("click", () => zoom(level + .5));
  dialog.querySelector("[data-photo-close]").addEventListener("click", () => dialog.close());
  dialog.addEventListener("click", event => { if (event.target === dialog) dialog.close(); });
  dialog.addEventListener("close", () => image.removeAttribute("src"));
  return {
    element: dialog,
    open(src, label, annotations = [], description = "") {
      fitWidth = 0;
      zoom(1);
      title.textContent = label || "Ảnh mạch";
      image.alt = title.textContent;
      caption.textContent = description;
      caption.hidden = !description;
      renderOverlay(layer, annotations);
      image.src = src;
      dialog.showModal();
      viewport.scrollTo(0, 0);
    },
  };
}
