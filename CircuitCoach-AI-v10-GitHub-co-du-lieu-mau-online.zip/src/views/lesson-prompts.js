import { ANALYZE_DEVELOPER_PROMPT, ARDUINO_PIN_LAYOUT_INSTRUCTIONS, buildLedPhotoInstructions, buildLessonAnalysisInstructions } from "../../server/ai/analyze-prompt.js";
import { CIRCUIT_VISUAL_PROOF_INSTRUCTIONS } from "../../server/ai/circuit-proof.js";
import { TUTOR_DEVELOPER_PROMPT } from "../../server/ai/tutor-prompt.js";
import { AI_ERROR_REASONS, AI_ERROR_REVIEW_GUIDANCE } from "../data/ai-error-reasons.js";
import { getLesson, lessons } from "../data/lessons.js";
import { getStudent } from "../services/storage.js";
import { mountLessonAiReminders } from "./lesson-ai-reminders.js";
import { appShell, emptyState, escapeHtml } from "./shared.js";

function promptSection(title, prompt, open = false) {
  return `<details class="lesson-prompt-panel"${open ? " open" : ""}>
    <summary>${escapeHtml(title)}</summary>
    <pre>${escapeHtml(prompt)}</pre>
  </details>`;
}

export function renderLessonPrompts(root, lessonId, { teacherClassCode } = {}) {
  const lesson = lessonId ? getLesson(lessonId) : lessons[0];
  if (!lesson) {
    root.innerHTML = appShell(emptyState("Không tìm thấy bài học", "Chọn một bài để xem prompt AI.", '<a class="btn btn-secondary" href="#/lessons">Về danh sách bài học</a>'), "lessons");
    return;
  }

  const checkList = lesson.checks.map(([id, label, category]) => ({ id, label, category }));
  const instructions = buildLessonAnalysisInstructions({ ...lesson, checkList });
  const ledInstructions = buildLedPhotoInstructions({ ...lesson, checkList }).map(item => item.text).join("\n");
  const lessonLinks = lessons.map(item =>
    `<a href="#/lesson-prompts/${item.id}"${item.id === lesson.id ? ' aria-current="page"' : ""}>${escapeHtml(item.title)}</a>`
  ).join("");
  const feedbackGuidance = Object.entries(AI_ERROR_REASONS).map(([id, label]) =>
    `<div><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(AI_ERROR_REVIEW_GUIDANCE[id])}</dd></div>`
  ).join("");

  root.innerHTML = appShell(`
    <section class="lesson-prompt-page">
      <div class="breadcrumb"><a href="#/lessons">Bài học</a><span>/</span><a href="#/analyzer/${lesson.id}">${escapeHtml(lesson.title)}</a><span>/</span><strong>Prompt AI</strong></div>
      <header class="page-head compact-head">
        <div><h1>Prompt AI theo bài học</h1><p>Hệ thống gửi yêu cầu của bài, ảnh và lời nhắc từ giáo viên trong cùng một lượt phân tích.</p></div>
      </header>
      <nav class="lesson-prompt-nav" aria-label="Chọn bài để xem prompt AI">${lessonLinks}</nav>
      <section class="lesson-prompt-panels" aria-labelledby="lesson-prompt-title">
        <h2 id="lesson-prompt-title">${escapeHtml(lesson.title)}</h2>
        <section class="side-card lesson-ai-reminders"></section>
        ${promptSection("Kết nối và tiêu chí của bài", instructions, true)}
        ${promptSection("Prompt phân tích ảnh dùng chung", ANALYZE_DEVELOPER_PROMPT)}
        ${ledInstructions ? promptSection("Prompt đọc cận hai bản cực LED", ledInstructions) : ""}
        ${lesson.board === "Arduino Uno" ? promptSection("Prompt đối chiếu vị trí chân Arduino Uno", ARDUINO_PIN_LAYOUT_INSTRUCTIONS) : ""}
        ${promptSection("Prompt gợi ý cho học sinh", TUTOR_DEVELOPER_PROMPT)}
        ${promptSection("Yêu cầu bằng chứng trước khi chấm", CIRCUIT_VISUAL_PROOF_INSTRUCTIONS)}
        <details class="lesson-prompt-panel">
          <summary>Các mẫu lời nhắc theo loại lỗi</summary>
          <dl>${feedbackGuidance}</dl>
        </details>
      </section>
    </section>`, "lessons");
  void mountLessonAiReminders(root.querySelector(".lesson-ai-reminders"), { lessonId: lesson.id, student: getStudent(), teacherClassCode });
}
