import { getLesson, lessons } from "../data/lessons.js";
import { REFERENCE_ERROR_TYPES } from "../data/reference-cases.js";
import { AI_ERROR_REASONS } from "../data/ai-error-reasons.js";
import { reportProblems, reportSummary } from "../data/attempt-rechecks.js";
import { getAttempts, updateTeacherVerification } from "../services/storage.js";
import { applyTeacherSession, clearTeacherPassword, createTeacherClass, fetchClassAttempts, fetchCriterionRechecks, getTeacherClassCode, getTeacherPassword, getTeacherUsername, logoutTeacherAccount, publishAttemptUpdate, saveCriterionRecheckComment, saveTeacherClassCode, saveTeacherPassword, saveTeacherUsername, sharedAttemptImageUrl, submitReferenceCase, verifyAttempt, verifyTeacherAccount } from "../services/classroom.js";
import { buildClassReport, commonErrors, demoClassData, deriveAttemptRows, deriveGroupState, GROUP_STATUSES, STATUS_LABELS } from "../services/teacher-dashboard.js";
import { TEACHER_VERIFICATION_DESCRIPTIONS, TEACHER_VERIFICATION_OPTIONS } from "../config.js";
import { appShell, escapeHtml, icon, renderPhotoReviews, showToast } from "./shared.js";
import { renderTeacherReport } from "./teacher-report.js";
import { createPhotoViewer, mountPhotoAnnotationEditor, photoAnnotationEditor } from "./photo-tools.js";
import { mountTeacherRecheckReviews, renderTeacherRechecks } from "./criterion-recheck.js";

const timeFormatter = new Intl.DateTimeFormat("vi-VN", { hour: "2-digit", minute: "2-digit", day: "2-digit", month: "2-digit" });

function latestTime(group) {
  return group.latest?.time ? timeFormatter.format(new Date(group.latest.time)) : "Chưa có";
}

function teacherVerificationText(attempt) {
  if (attempt?.teacherVerification === "correct") return "Đã xác nhận AI đúng";
  if (attempt?.teacherVerification === "incorrect") return "Giáo viên báo AI sai";
  if (attempt?.teacherVerification === "uncertain") return "Giáo viên chưa chắc";
  if (attempt?.teacherStatus === "approved") return "Đã xác nhận";
  return "Chưa xác nhận";
}

function errorSummary(group) {
  if (!group.problems.length) return group.status === "not_started" ? "Chưa gửi lần kiểm tra nào" : "Không phát hiện lỗi hiện tại";
  return group.problems.slice(0, 2).map((problem) => problem.label).join(", ");
}

function withinAttemptTime(attempt, range) {
  if (range === "all" || !attempt?.time) return true;
  const age = Date.now() - new Date(attempt.time).getTime();
  return range === "60m" ? age <= 3_600_000 : age <= 86_400_000;
}

function renderTeacherVerification(attempt) {
  const current = attempt.teacherVerification;
  const criteria = getLesson(attempt.lessonId)?.checks || [];
  const savedError = attempt.teacherAiError;
  const savedAt = attempt.teacherVerifiedAt ? timeFormatter.format(new Date(attempt.teacherVerifiedAt)) : "";
  const meta = current
    ? `Đã xác nhận bởi ${escapeHtml(attempt.teacherVerifiedBy || "giáo viên")}${savedAt ? ` lúc ${savedAt}` : ""}`
    : "Chưa có xác nhận chính thức của giáo viên.";
  return `<section class="teacher-verification-panel">
    <div class="teacher-verification-head"><div><p class="eyebrow">XÁC NHẬN CHÍNH THỨC</p><h5>Kết quả AI có chính xác không?</h5></div><span class="verification-status-badge ${current ? `is-${current}` : "is-pending"}">${current ? escapeHtml(TEACHER_VERIFICATION_OPTIONS[current]) : "Chờ xác nhận"}</span></div>
    <p class="teacher-verification-help">Đây chỉ là nhãn đánh giá độ đúng của AI. Nhãn này không xác nhận mạch thật an toàn hoặc cho phép cấp nguồn. Khi chọn AI đúng, ảnh của lượt có ảnh sẽ xuất hiện trong Thư mục mạch đúng của lớp.</p>
    <form class="teacher-verification-form" data-teacher-verify-form="${attempt.id}">
      <div class="verification-choices">${Object.entries(TEACHER_VERIFICATION_OPTIONS).map(([value, label]) => `<label class="verification-choice is-${value}"><input type="radio" name="teacherVerification" value="${value}" ${current === value ? "checked" : ""} required /><span><b>${escapeHtml(label)}</b><small>${escapeHtml(TEACHER_VERIFICATION_DESCRIPTIONS[value])}</small></span></label>`).join("")}</div>
      ${criteria.length ? `<fieldset class="teacher-ai-error-fields" data-ai-error-fields ${current === "incorrect" ? "" : "hidden disabled"}>
        <legend>Ghi nhận lỗi AI</legend>
        <p class="muted">Tiêu chí và lý do đã lưu sẽ nhắc AI kiểm tra kỹ hơn ở những lượt phân tích cùng bài của lớp.</p>
        <label>Tiêu chí bị sai<select name="aiErrorCriterion" required><option value="">Chọn tiêu chí</option>
          ${criteria.map(([id,label]) => `<option value="${escapeHtml(id)}" ${savedError?.criterionId === id ? "selected" : ""}>${escapeHtml(label)}</option>`).join("")}</select></label>
        <label>Lý do AI sai<select name="aiErrorReason" required><option value="">Chọn lý do</option>
          ${Object.entries(AI_ERROR_REASONS).map(([id,label]) => `<option value="${id}" ${savedError?.reason === id ? "selected" : ""}>${escapeHtml(label)}</option>`).join("")}</select></label>
      </fieldset>` : ""}
      <textarea name="teacherVerificationNote" maxlength="500" rows="3" placeholder="Ghi chú cho nhóm (không bắt buộc)">${escapeHtml(attempt.teacherVerificationNote || "")}</textarea>
      <div class="teacher-verification-actions"><small>${meta}</small><button class="btn btn-primary" type="submit">Lưu xác nhận</button></div>
    </form>
  </section>`;
}

function renderTeacherSafetyCheck(attempt) {
  const current = attempt.teacherPhysicallyChecked ? attempt.teacherSafetyCheck : "not_checked";
  const meta = attempt.teacherSafetyCheckedAt
    ? `Đã ghi nhận bởi ${escapeHtml(attempt.teacherSafetyCheckedBy || "giáo viên")} lúc ${timeFormatter.format(new Date(attempt.teacherSafetyCheckedAt))}`
    : "Chưa có xác nhận giáo viên kiểm tra mạch thật.";
  const options = {
    not_checked: "Chưa kiểm tra trực tiếp",
    safe_to_power: "Đã kiểm tra trực tiếp — an toàn, cho phép cấp nguồn",
    unsafe: "Đã phát hiện nguy cơ — không cấp nguồn",
    uncertain: "Đã kiểm tra nhưng chưa thể kết luận — chưa cấp nguồn",
  };
  return `<section class="teacher-verification-panel teacher-safety-check-panel">
    <div class="teacher-verification-head"><div><p class="eyebrow">XÁC NHẬN AN TOÀN MẠCH THẬT</p><h5>Giáo viên đã kiểm tra trực tiếp chưa?</h5></div><span class="verification-status-badge ${current === "safe_to_power" ? "is-correct" : current === "unsafe" ? "is-incorrect" : "is-pending"}">${escapeHtml(options[current] || options.not_checked)}</span></div>
    <p class="teacher-verification-help">Phần này độc lập với nhãn AI đúng/sai. Chỉ chọn “an toàn, cho phép cấp nguồn” sau khi tự kiểm tra trực tiếp mạch thật.</p>
    <form class="teacher-verification-form" data-teacher-safety-form="${attempt.id}">
      <label>Trạng thái kiểm tra<select name="teacherSafetyCheck" required>${Object.entries(options).map(([value, label]) => `<option value="${value}" ${current === value ? "selected" : ""}>${escapeHtml(label)}</option>`).join("")}</select></label>
      <label class="teacher-physical-check"><input type="checkbox" name="teacherPhysicalCheck" ${attempt.teacherPhysicallyChecked ? "checked" : ""} /> Tôi đã kiểm tra trực tiếp mạch thật</label>
      <textarea name="teacherSafetyNote" maxlength="500" rows="2" placeholder="Ghi chú kiểm tra an toàn (không bắt buộc)">${escapeHtml(attempt.teacherSafetyNote || "")}</textarea>
      <div class="teacher-verification-actions"><small>${meta}</small><button class="btn btn-primary" type="submit">Lưu xác nhận an toàn</button></div>
    </form>
  </section>`;
}

function renderTeacherLabels(attempt) {
  const labels = attempt.teacherCriterionLabels || {};
  const options = { correct: "Đúng", incorrect: "Có lỗi", uncertain: "Chưa xác định / thiếu bằng chứng" };
  const quality = { clear: "Rõ", blurred: "Mờ", occluded: "Bị che", unassessable: "Không đánh giá được" };
  const rows = attempt.problems.map((problem) => `<label class="teacher-label-row"><span>${escapeHtml(problem.label)} <small>AI: ${escapeHtml(problem.status)}</small></span><select data-criterion-id="${escapeHtml(problem.id || problem.criterionId)}"><option value="">Chưa gắn nhãn</option>${Object.entries(options).map(([value, title]) => `<option value="${value}" ${labels[problem.id || problem.criterionId] === value ? "selected" : ""}>${title}</option>`).join("")}</select></label>`).join("");
  const meta = attempt.teacherLabelsAt ? `Đã lưu bởi ${escapeHtml(attempt.teacherLabelsBy || "giáo viên")} lúc ${timeFormatter.format(new Date(attempt.teacherLabelsAt))}` : "Chưa có nhãn giáo viên cho từng tiêu chí.";
  return `<section class="teacher-verification-panel"><div class="teacher-verification-head"><div><p class="eyebrow">NHÃN THỬ NGHIỆM CỦA GIÁO VIÊN</p><h5>Đối chiếu từng tiêu chí với mạch thật</h5></div></div><p class="teacher-verification-help">Nhãn này độc lập với kết quả AI và xác nhận an toàn trước khi cấp nguồn.</p><form class="teacher-verification-form" data-teacher-label-form="${attempt.id}"><label>Chất lượng ảnh<select name="teacherImageQuality"><option value="">Chưa gắn nhãn</option>${Object.entries(quality).map(([value, title]) => `<option value="${value}" ${attempt.teacherImageQuality === value ? "selected" : ""}>${title}</option>`).join("")}</select></label><div class="teacher-label-grid">${rows}</div><div class="teacher-verification-actions"><small>${meta}</small><button class="btn btn-primary" type="submit">Lưu nhãn thử nghiệm</button></div></form></section>`;
}

function renderReferenceSubmission(attempt) {
  const count = Math.min(3, Number(attempt.imageCount) || 0);
  const labels = attempt.teacherCriterionLabels || {};
  const criteria = (getLesson(attempt.lessonId)?.checks || []).filter(([id]) => ["correct", "incorrect"].includes(labels[id]));
  const available = !attempt.demo && count > 0 && criteria.length > 0;
  return `<section class="teacher-verification-panel">
    <h5>Thêm ví dụ vào kho tham chiếu</h5>
    ${available ? `<form class="teacher-verification-form" data-reference-case-form="${escapeHtml(attempt.id)}"><fieldset class="reference-case-fields">
      <div class="teacher-label-grid">
        <label>Tiêu chí đã lưu<select name="criterionId" required>
          <option value="">Chọn tiêu chí</option>
          ${criteria.map(([id, title]) => `<option value="${escapeHtml(id)}" data-label="${labels[id]}">${escapeHtml(title)} · ${labels[id] === "correct" ? "Đúng" : "Có lỗi"}</option>`).join("")}
        </select></label>
        <label>Góc chụp thấy rõ tiêu chí<select name="photoIndex" required>
          <option value="">Chọn ảnh</option>
          ${Array.from({ length: count }, (_, index) => `<option value="${index}">Ảnh ${index + 1}</option>`).join("")}
        </select></label>
      </div>
      <label data-reference-error-field hidden>Dạng lỗi<select name="errorType" disabled>
        <option value="">Chọn dạng lỗi</option>
        ${Object.entries(REFERENCE_ERROR_TYPES).map(([id, label]) => `<option value="${id}">${escapeHtml(label)}</option>`).join("")}
      </select></label>
      <label>Dấu hiệu nhìn thấy trên ảnh<textarea name="evidence" rows="2" maxlength="300" placeholder="Ví dụ: Chân âm LED nối về phía điện trở"></textarea></label>
      ${photoAnnotationEditor()}
      ${count > 1 ? '<p class="muted">Khi gửi ví dụ, giáo viên gửi ảnh đang chọn cùng các dấu trên ảnh đó.</p>' : ""}
      <p class="muted">Ảnh tham chiếu và chú thích đã duyệt sẽ xuất hiện trong kho công khai của bài học.</p>
      <div class="teacher-verification-actions"><a class="text-button" href="#/references/${escapeHtml(attempt.lessonId)}?view=manage">Mở kho chung để duyệt</a><button class="btn btn-secondary" type="submit">Gửi ví dụ để duyệt</button></div>
      </fieldset><p role="status" data-reference-submit-status></p>
    </form>` : '<p class="teacher-verification-help">Cần ảnh thật đã đồng bộ và ít nhất một nhãn Đúng hoặc Có lỗi đã lưu.</p>'}
  </section>`;
}

function renderReviewPanel(group, canUseReferences) {
  const attempt = group.latest;
  const images = Number(attempt.imageCount) > 0
    ? `<div class="teacher-image-gallery">${Array.from({ length: Math.min(3, attempt.imageCount) }, (_, index) => `<figure><button class="lesson-sample-thumbnail" type="button" data-teacher-photo aria-label="Phóng to ảnh mạch ${index + 1}"><img src="${sharedAttemptImageUrl(attempt.id, attempt.classCode, index)}" alt="Ảnh mạch ${index + 1} của ${escapeHtml(attempt.studentName)}" loading="lazy" /></button><figcaption>Ảnh ${index + 1}</figcaption></figure>`).join("")}</div>`
    : '<div class="teacher-no-images"><b>Chưa có ảnh dùng chung</b><span>Lượt kiểm tra cũ hoặc ảnh chưa đồng bộ thành công.</span></div>';
  const current = reportProblems(attempt);
  const checks = current.length ? current.map((problem) => {
    const label = problem.ruleEvidence?.physicalCheckRequired ? "Cần kiểm tra trực tiếp" : problem.status === "correct" ? "Đạt"
      : problem.status === "possible_error" ? "Cần kiểm tra" : "Chưa xác định";
    return `<li class="review-check status-${problem.status}"><div><b>${escapeHtml(problem.label)}</b><span>${problem.recheckId ? "Ảnh kiểm tra lại · " : ""}${escapeHtml(problem.evidence || "Không có mô tả bổ sung")}</span>${renderPhotoReviews(problem.photoReviews)}</div><strong>${label}</strong></li>`;
  }).join("") : '<li class="review-check"><span>Không có tiêu chí chi tiết.</span></li>';
  return `<section class="teacher-review-panel">
    <div class="teacher-review-head"><div><p class="eyebrow">CHI TIẾT LẦN KIỂM TRA</p><h4>${escapeHtml(reportSummary(attempt, current) || "Kết quả phân tích mạch")}</h4></div><span>${group.status === "awaiting_teacher" ? "CHỜ GIÁO VIÊN" : attempt.verdict === "pass" ? "AI: ĐẠT" : "AI: CẦN KIỂM TRA"}</span></div>
    ${images}
    <form class="teacher-comment-form" data-comment-form="${attempt.id}"><label for="comment-${attempt.id}">Nhận xét cho học sinh</label><textarea id="comment-${attempt.id}" name="comment" maxlength="1000" rows="3" placeholder="Ghi việc nhóm cần sửa hoặc làm tiếp.">${escapeHtml(attempt.teacherComment || "")}</textarea><div><small role="status">${attempt.teacherCommentAt ? `Đã lưu ${timeFormatter.format(new Date(attempt.teacherCommentAt))}` : "Nhóm sẽ thấy nhận xét trên trang kết quả."}</small><button class="btn btn-primary" type="submit">Lưu nhận xét</button></div></form>
    <details class="teacher-review-section" data-review-section="safety">
      <summary>Kiểm tra an toàn mạch thật</summary>
      ${renderTeacherSafetyCheck(attempt)}
    </details>
    <details class="teacher-review-section" data-review-section="verdict">
      <summary>Kết quả và xác nhận AI</summary>
      <ul class="review-checks">${checks}</ul>
      ${renderTeacherVerification(attempt)}
    </details>
    ${canUseReferences && !attempt.demo ? `<details class="teacher-review-section" data-review-section="criterion-rechecks" data-criterion-history="${escapeHtml(attempt.id)}">
      <summary>Ảnh kiểm tra lại từng tiêu chí</summary>
      <div data-criterion-history-content></div>
    </details>` : ""}
    <details class="teacher-review-section" data-review-section="labels">
      <summary>Nhãn tiêu chí và ảnh tham chiếu</summary>
      ${renderTeacherLabels(attempt)}
      ${canUseReferences ? renderReferenceSubmission(attempt) : ""}
    </details>
    ${canUseReferences ? `<details class="teacher-review-section" data-review-section="comparison">
      <summary>Thử nghiệm A/B</summary>
      <button class="btn btn-secondary" type="button" data-experiment="compare">Chạy A/B với ảnh đã lưu</button>
      <button class="btn btn-secondary" type="button" data-experiment="comparison-report">Báo cáo A/B của lớp</button>
      <p role="status" data-experiment-status></p>
    </details>` : ""}
  </section>`;
}

export async function saveTeacherComment({ attemptId, classCode, teacherUsername, teacherPassword, comment, attempts, publish = publishAttemptUpdate }) {
  const response = await publish(attemptId, classCode, { teacherComment: comment }, teacherPassword, teacherUsername);
  const index = attempts.findIndex((item) => item.id === attemptId);
  if (index >= 0 && response?.attempt) attempts[index] = { ...attempts[index], ...response.attempt };
  return response;
}

export async function saveTeacherVerification({ attemptId, classCode, teacherUsername, teacherPassword, teacherVerification, teacherVerificationNote, teacherAiError, teacherSafetyCheck, teacherPhysicalCheck, teacherSafetyNote, attempts = [], publish = verifyAttempt }) {
  const response = await publish({ attemptId, classCode, teacherUsername, teacherPassword, teacherVerification, teacherVerificationNote, teacherAiError, teacherSafetyCheck, teacherPhysicalCheck, teacherSafetyNote });
  const index = attempts.findIndex((item) => item.id === attemptId);
  if (index >= 0 && response?.attempt) attempts[index] = { ...attempts[index], ...response.attempt };
  return response;
}

export function renderTeacher(root, teacherSession) {
  const localAttempts = getAttempts();
  const localIds = new Set(localAttempts.map((attempt) => attempt.id));
  const state = {
    view: "dashboard", demo: false, lesson: "all", status: "all", time: "all",
    classCode: getTeacherClassCode(), classCodes: teacherSession?.classCodes || [],
    teacherUsername: getTeacherUsername(), teacherPassword: getTeacherPassword(),
    authenticated: Boolean(teacherSession), attempts: [], loading: false, creating: false, classDraft: "",
    signingOut: false, error: "", refreshedAt: null, selectedAttemptId: null,
  };
  let refreshTimer = null;
  let editingReview = false;
  let shell;
  const routeHash = location.hash;
  const current = () => location.hash === routeHash && (!shell || shell.isConnected);

  function redrawReview() {
    const position = window.scrollY;
    const opened = new Set([...root.querySelectorAll("[data-review-section][open]")].map(item => item.dataset.reviewSection));
    editingReview = false;
    draw();
    for (const item of root.querySelectorAll("[data-review-section]")) item.open = opened.has(item.dataset.reviewSection);
    window.scrollTo(0, position);
  }

  function applyLocalVerification(attemptId, updated) {
    if (!updated || !localIds.has(attemptId)) return;
    updateTeacherVerification(attemptId, {
      teacherVerification: updated.teacherVerification,
      teacherVerificationNote: updated.teacherVerificationNote,
      teacherAiError: updated.teacherAiError,
      teacherVerifiedBy: updated.teacherVerifiedBy,
      teacherVerifiedAt: updated.teacherVerifiedAt,
      teacherStatus: updated.teacherStatus,
      teacherSafetyCheck: updated.teacherSafetyCheck,
      teacherSafetyNote: updated.teacherSafetyNote,
      teacherSafetyCheckedBy: updated.teacherSafetyCheckedBy,
      teacherSafetyCheckedAt: updated.teacherSafetyCheckedAt,
      teacherPhysicallyChecked: updated.teacherPhysicallyChecked,
      teacherCriterionLabels: updated.teacherCriterionLabels,
      teacherImageQuality: updated.teacherImageQuality,
      teacherLabelsBy: updated.teacherLabelsBy,
      teacherLabelsAt: updated.teacherLabelsAt,
    });
  }

  function scheduleRefresh() {
    clearTimeout(refreshTimer);
    if (state.classCode && state.authenticated && !state.demo && current()) refreshTimer = setTimeout(refresh, 15_000);
  }

  async function refresh() {
    if (!current() || state.loading || state.creating || state.signingOut) return;
    if (editingReview || root.querySelector('.teacher-review-panel :focus, #create-teacher-class-form :focus')) { scheduleRefresh(); return; }
    if (!state.classCode || !state.teacherPassword) return;
    state.loading = true; state.error = ""; draw();
    try {
      const attempts = await fetchClassAttempts(state.classCode, state.teacherPassword, state.teacherUsername);
      if (!current()) return;
      state.attempts = attempts;
      state.authenticated = true;
      state.refreshedAt = new Date();
    } catch (error) {
      if (!current()) return;
      state.error = error.message;
      if (error.status === 401 || error.status === 403) {
        state.authenticated = false;
        state.attempts = [];
        clearTeacherPassword();
        state.teacherPassword = "";
        state.view = "dashboard";
      }
    } finally {
      state.loading = false;
      if (current() && !editingReview && !root.querySelector('.teacher-review-panel :focus, #create-teacher-class-form :focus')) redrawReview();
      scheduleRefresh();
    }
  }

  async function logoutTeacher() {
    if (state.signingOut) return;
    state.signingOut = true;
    clearTimeout(refreshTimer);
    root.querySelectorAll("[data-teacher-logout]").forEach(button => { button.disabled = true; });
    try {
      if (state.teacherPassword === "cookie-session") await logoutTeacherAccount();
      clearTeacherPassword();
      if (current()) location.hash = "#/home";
      showToast("Đã đăng xuất giáo viên.", "success");
    } catch (error) {
      showToast(error.message, "error");
      state.signingOut = false;
      draw();
      scheduleRefresh();
    }
  }

  async function openClass(code) {
    if (!state.classCodes.includes(code) || !current()) return;
    state.classCode = saveTeacherClassCode(code);
    state.attempts = [];
    state.refreshedAt = null;
    state.selectedAttemptId = null;
    state.view = "dashboard";
    editingReview = false;
    await refresh();
  }

  function classroomAccess() {
    const feedback = state.error
      ? `<small class="sync-error" role="status">${escapeHtml(state.error)}</small>`
      : state.refreshedAt ? `<small>Cập nhật lúc ${state.refreshedAt.toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" })}</small>` : "";
    if (state.authenticated && state.teacherPassword === "cookie-session") {
      const disabled = state.loading || state.creating || state.signingOut ? "disabled" : "";
      return `<section class="classroom-connect teacher-class-access">
        <div><p>Đã đăng nhập giáo viên <strong>${escapeHtml(state.teacherUsername)}</strong></p>
          <h2>${state.classCode ? `Mã lớp <code>${escapeHtml(state.classCode)}</code>` : "Tạo lớp đầu tiên"}</h2>
          <p>${state.classCode ? "Gửi mã lớp này cho học sinh. Khi vào lớp, các nhóm chỉ cần nhập tên nhóm và mã này." : "Tạo mã lớp rồi gửi mã cho học sinh."}</p></div>
        <div class="teacher-class-actions">
          ${state.classCodes.length > 1 ? `<label>Chọn lớp<select id="teacher-class-select" ${disabled}>${state.classCodes.map(code => `<option value="${escapeHtml(code)}" ${code === state.classCode ? "selected" : ""}>${escapeHtml(code)}</option>`).join("")}</select></label>` : ""}
          <form id="create-teacher-class-form" class="teacher-class-actions">
            <label>Mã lớp mới<input name="classCode" value="${escapeHtml(state.classDraft)}" minlength="4" maxlength="12" pattern="[A-Za-z0-9]{4,12}" placeholder="Ví dụ: STEM26A" title="4 đến 12 chữ cái hoặc chữ số" autocapitalize="characters" spellcheck="false" required ${disabled} /></label>
            <button id="create-teacher-class" class="btn btn-primary" type="submit" ${disabled}>${state.creating ? "Đang tạo mã…" : "Tạo mã lớp"}</button>
          </form>
          ${state.classCode ? `<button id="copy-class-code" class="btn btn-secondary" type="button" ${disabled}>Sao chép mã lớp</button><button id="refresh-class" class="btn btn-ghost" type="button" ${disabled}>Làm mới</button>` : ""}
        </div>${feedback}
      </section>`;
    }
    const showClassInput = state.authenticated || !["127.0.0.1", "localhost"].includes(location.hostname);
    return `<section class="classroom-connect">
      <div><h2>${state.authenticated ? `Lớp ${escapeHtml(state.classCode)}` : "Đăng nhập giáo viên"}</h2><p>Nhập tên đăng nhập và mật khẩu do quản trị viên cấp.</p></div>
      <form id="teacher-class-form">
        ${showClassInput ? `<input name="classCode" maxlength="12" value="${escapeHtml(state.classCode)}" placeholder="Mã lớp" aria-label="Mã lớp" />` : ""}
        <input name="teacherUsername" maxlength="40" value="${escapeHtml(state.teacherUsername)}" autocomplete="username" placeholder="Tên đăng nhập" aria-label="Tên đăng nhập giáo viên" required />
        <input name="teacherPassword" type="password" maxlength="128" autocomplete="current-password" placeholder="Mật khẩu giáo viên" aria-label="Mật khẩu giáo viên" required />
        <button class="btn btn-primary" type="submit" ${state.loading ? "disabled" : ""}>${state.loading ? "Đang kiểm tra…" : state.authenticated ? "Đổi lớp" : "Đăng nhập giáo viên"}</button>
        ${state.authenticated ? '<button id="refresh-class" class="btn btn-ghost" type="button">Làm mới</button>' : ""}
      </form>${feedback}
    </section>`;
  }

  function draw() {
    if (!current()) return;
    const source = state.demo ? demoClassData() : { attempts: state.attempts, roster: [] };
    const allGroups = deriveGroupState(source.attempts, source.roster);
    const reportAttempts = source.attempts.filter((attempt) => (state.lesson === "all" || attempt.lessonId === state.lesson) && withinAttemptTime(attempt, state.time));
    const report = buildClassReport(reportAttempts, source.roster);
    const reportIds = new Set(reportAttempts.map(attempt => attempt.id));
    const rows = deriveAttemptRows(source.attempts).filter(row => reportIds.has(row.latest.id));
    const groups = rows.filter(row => state.status === "all" || row.status === state.status);
    const counts = Object.fromEntries(GROUP_STATUSES.map(([id]) => [id, rows.filter((row) => row.status === id).length]));
    const errors = commonErrors(deriveGroupState(groups.map(row => row.latest)));
    const feedback = source.attempts.filter((attempt) => attempt.verification === "incorrect" || attempt.teacherVerification === "incorrect").sort((a, b) => new Date(b.time) - new Date(a.time));

    const groupRows = groups.length ? groups.map((group) => {
      const lesson = getLesson(group.latest?.lessonId);
      const isLocal = localIds.has(group.latest?.id);
      const detailAction = state.demo ? '<span class="demo-result-note">Kết quả minh họa</span>' : isLocal ? `<a class="text-button" href="#/result/${group.latest.id}">Xem kết quả →</a>` : '<span class="demo-result-note">Từ thiết bị của nhóm</span>';
      return `<article class="teacher-group status-${group.status}">
        <div class="group-rank"><span>${group.priority || "—"}</span><small>ƯU TIÊN</small></div>
        <div class="group-main"><div class="group-heading"><div><span class="status-pill status-${group.status}">${STATUS_LABELS[group.status]}</span><h3>${escapeHtml(group.name)}</h3></div><span class="danger danger-${group.dangerLevel === "Khẩn cấp" ? "critical" : group.dangerLevel === "Cao" ? "high" : "normal"}">${escapeHtml(group.dangerLevel)}</span></div>
          <div class="group-meta"><span><b>Bài học</b>${escapeHtml(lesson?.title || "Chưa chọn")}</span><span><b>Thời điểm</b>${latestTime(group)}</span><span><b>Lần làm</b>Lần ${group.attemptNumber}</span><span><b>Giáo viên</b>${escapeHtml(teacherVerificationText(group.latest))}</span></div>
          <p class="group-error"><b>${escapeHtml(group.priorityReason)}</b> · ${escapeHtml(errorSummary(group))}</p>
        </div>
        <div class="group-actions">${detailAction}${!state.demo ? `<button class="btn btn-secondary teacher-review-toggle" data-review="${group.latest.id}" type="button">${state.selectedAttemptId === group.latest.id ? "Đóng chi tiết" : "Xem & xác nhận"}</button>` : ""}${!state.demo && group.latest?.verdict === "pass" ? `<button class="btn btn-ghost teacher-confirm" data-attempt="${group.latest.id}" type="button" ${group.latest.teacherStatus === "approved" || group.latest.teacherVerification === "correct" ? "disabled" : ""}>${group.latest.teacherStatus === "approved" || group.latest.teacherVerification === "correct" ? "Đã xác nhận AI đúng" : "Xác nhận AI đúng"}</button>` : ""}</div>
        ${state.selectedAttemptId === group.latest.id ? renderReviewPanel(group, state.teacherPassword === "cookie-session" && !state.demo) : ""}
      </article>`;
    }).join("") : `<div class="teacher-empty">${icon("teacher", 30)}<h3>${state.loading ? "Đang tải dữ liệu lớp…" : "Chưa thấy nhóm nào"}</h3><p>${state.demo ? "Hãy đổi bộ lọc để xem dữ liệu demo." : state.classCode ? "Hãy yêu cầu các nhóm nhập đúng mã lớp và gửi một lần phân tích, sau đó bấm Làm mới." : "Tạo hoặc nhập mã lớp bên trên rồi chia sẻ mã đó cho các nhóm."}</p></div>`;

    root.innerHTML = appShell(`<section class="teacher-page">
      ${state.demo ? `<div class="demo-data-banner"><b>DỮ LIỆU DEMO</b><span>Các nhóm và kết quả dưới đây chỉ dùng để minh họa giao diện.</span><button id="close-demo" class="text-button" type="button">Quay lại dữ liệu thật</button></div>` : ""}
      <header class="teacher-hero"><div><p class="eyebrow">TRUNG TÂM ĐIỀU PHỐI LỚP HỌC</p><h1>Dành cho giáo viên</h1><p>Tạo mã lớp, chia sẻ cho học sinh và theo dõi bài làm của từng nhóm.</p></div><div class="teacher-hero-actions"><div class="teacher-clock"><span>ĐANG THEO DÕI</span><strong>${allGroups.length}</strong><small>nhóm</small></div>${state.authenticated && state.teacherPassword !== "cookie-session" ? '<button class="btn btn-logout" data-teacher-logout type="button">Đăng xuất giáo viên</button>' : ""}${!state.demo ? '<button id="show-demo" class="btn btn-ghost" type="button">Xem dữ liệu demo</button>' : ""}</div></header>
      ${state.demo ? "" : classroomAccess()}
      <div ${state.demo || (state.authenticated && state.classCode) ? "" : "hidden"}>
      ${state.authenticated && !state.demo ? `<nav class="teacher-view-tabs" aria-label="Chế độ xem giáo viên"><button class="${state.view === "dashboard" ? "selected" : ""}" data-teacher-view="dashboard" type="button">Bảng điều khiển</button>${state.teacherPassword === "cookie-session" ? `<a href="#/teacher-reports">Báo cáo thống kê</a><a href="#/ai-tracking">Theo dõi AI</a><a href="#/lesson-samples">Thư viện ảnh mẫu</a><a href="#/reference-upload">Tải ảnh theo tiêu chí</a><a href="#/references/${escapeHtml(state.lesson)}?view=manage">Quản lý kho tham chiếu</a>` : `<button class="${state.view === "report" ? "selected" : ""}" data-teacher-view="report" type="button">Báo cáo phân tích</button>`}</nav>` : ""}
      <section class="status-overview" aria-label="Tổng quan trạng thái" ${state.view === "report" ? "hidden" : ""}>${GROUP_STATUSES.map(([id, label]) => `<button class="status-summary ${state.status === id ? "selected" : ""}" data-status-shortcut="${id}" type="button"><span class="status-dot status-${id}"></span><b>${counts[id]}</b><small>${label}</small></button>`).join("")}</section>
      <section class="teacher-filters ${state.view === "report" ? "is-report" : ""}"><label><span>Bài học</span><select id="teacher-lesson"><option value="all">Tất cả bài học</option>${lessons.map((lesson) => `<option value="${lesson.id}" ${state.lesson === lesson.id ? "selected" : ""}>${lesson.title}</option>`).join("")}</select></label><label ${state.view === "report" ? "hidden" : ""}><span>Trạng thái</span><select id="teacher-status"><option value="all">Tất cả trạng thái</option>${GROUP_STATUSES.map(([id, label]) => `<option value="${id}" ${state.status === id ? "selected" : ""}>${label}</option>`).join("")}</select></label><label><span>Thời gian</span><select id="teacher-time"><option value="all">Toàn bộ</option><option value="60m" ${state.time === "60m" ? "selected" : ""}>60 phút gần đây</option><option value="today" ${state.time === "today" ? "selected" : ""}>24 giờ gần đây</option></select></label><button id="reset-teacher-filters" class="btn btn-ghost" type="button">Đặt lại bộ lọc</button></section>
      ${state.view === "report" && state.authenticated && !state.demo ? renderTeacherReport({ report, classCode: state.classCode, teacherUsername: state.teacherUsername, refreshedAt: state.refreshedAt }) : ""}
      <div class="teacher-dashboard-grid" ${state.view === "report" ? "hidden" : ""}><section class="teacher-priority-panel"><div class="section-title"><div><p class="eyebrow">CẦN HỖ TRỢ TRƯỚC</p><h2>Danh sách lượt làm</h2></div><span>${groups.length} lượt</span></div><div class="teacher-group-list">${groupRows}</div></section>
        <aside class="teacher-insights"><section class="teacher-insight"><div class="section-title"><div><p class="eyebrow">LỖI PHỔ BIẾN</p><h2>Nhiều nhóm cùng mắc</h2></div></div>${errors.length ? `<ol class="common-errors">${errors.slice(0, 6).map((error) => `<li><span>${escapeHtml(error.label)}</span><b>${error.count} nhóm</b></li>`).join("")}</ol>` : '<p class="insight-empty">Chưa có lỗi chung trong dữ liệu đang lọc.</p>'}</section>
          <section class="teacher-insight ai-feedback"><div class="section-title"><div><p class="eyebrow">PHẢN HỒI AI</p><h2>“AI sai rồi”</h2></div><span>${feedback.length}</span></div>${feedback.length ? `<div class="feedback-list">${feedback.slice(0, 5).map((attempt) => `<div class="feedback-demo"><b>${escapeHtml(attempt.studentName || "Nhóm chưa đặt tên")}</b><span>${escapeHtml(getLesson(attempt.lessonId)?.title || attempt.lessonId)} · ${timeFormatter.format(new Date(attempt.time))}</span></div>`).join("")}</div>` : '<p class="insight-empty">Chưa có phản hồi AI sai.</p>'}</section>
          <section class="teacher-insight priority-guide"><p class="eyebrow">QUY TẮC ƯU TIÊN</p><ol><li>Chập mạch hoặc sai nguồn</li><li>AI báo đạt nhưng giáo viên thấy lỗi</li><li>Thử nhiều lần chưa đạt</li><li>Ảnh chưa rõ</li><li>Chờ giáo viên xác nhận</li></ol></section></aside></div>
      </div>
    </section>`, "teacher");
    shell = root.firstElementChild;

    root.querySelector("#show-demo")?.addEventListener("click", () => { state.demo = true; state.view = "dashboard"; clearTimeout(refreshTimer); draw(); });
    root.querySelector("#close-demo")?.addEventListener("click", () => { state.demo = false; state.view = "dashboard"; draw(); scheduleRefresh(); });
    root.querySelector("#teacher-class-form")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const data = new FormData(event.currentTarget);
      try {
        const teacherUsername = String(data.get("teacherUsername") || "").trim();
        const teacherPassword = String(data.get("teacherPassword") || "");
        state.loading = true; state.error = ""; draw();
        const session = await verifyTeacherAccount(teacherUsername, teacherPassword);
        const requestedClass = String(data.get("classCode") || "").trim().toUpperCase();
        if (session.personalSession) {
          state.classCode = applyTeacherSession({ ...session, username: session.username || teacherUsername });
          state.classCodes = session.classCodes;
        } else {
          state.classCode = saveTeacherClassCode(requestedClass);
          saveTeacherUsername(teacherUsername);
          saveTeacherPassword(teacherPassword);
        }
        state.teacherUsername = getTeacherUsername();
        state.teacherPassword = getTeacherPassword();
        state.authenticated = true;
        state.loading = false;
        state.view = "dashboard";
        showToast("Đã đăng nhập giáo viên.", "success");
        if (state.classCode) await refresh();
        else draw();
      } catch (error) {
        state.loading = false; state.authenticated = false; state.view = "dashboard"; state.error = error.message;
        clearTeacherPassword(); state.teacherPassword = ""; draw();
        showToast(error.message, "error");
      }
    });
    const classForm = root.querySelector("#create-teacher-class-form");
    classForm?.elements.classCode.addEventListener("input", event => { state.classDraft = event.target.value; });
    classForm?.addEventListener("submit", async event => {
      event.preventDefault();
      if (state.creating || state.loading || state.signingOut) return;
      const typedCode = String(new FormData(classForm).get("classCode") || "");
      state.creating = true;
      state.error = "";
      draw();
      try {
        const { classCode } = await createTeacherClass(typedCode);
        if (!current() || state.signingOut) return;
        state.classCodes = [...state.classCodes, classCode].sort();
        state.creating = false;
        state.classDraft = "";
        await openClass(classCode);
        showToast(`Đã tạo mã lớp ${classCode}.`, "success");
      } catch (error) {
        state.creating = false;
        state.error = error.message;
        draw();
        scheduleRefresh();
      }
    });
    root.querySelector("#teacher-class-select")?.addEventListener("change", event => void openClass(event.target.value));
    root.querySelector("#copy-class-code")?.addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(state.classCode);
        showToast("Đã sao chép mã lớp.", "success");
      } catch {
        showToast(`Mã lớp ${state.classCode}. Bạn có thể sao chép mã hiển thị trên trang.`);
      }
    });
    root.querySelector("#refresh-class")?.addEventListener("click", refresh);
    root.querySelectorAll("[data-teacher-logout]").forEach((button) => button.addEventListener("click", logoutTeacher));
    root.querySelector("#teacher-lesson")?.addEventListener("change", (event) => { state.lesson = event.target.value; draw(); });
    root.querySelector("#teacher-status")?.addEventListener("change", (event) => { state.status = event.target.value; draw(); });
    root.querySelector("#teacher-time")?.addEventListener("change", (event) => { state.time = event.target.value; draw(); });
    root.querySelector("#reset-teacher-filters")?.addEventListener("click", () => { state.lesson = "all"; state.status = "all"; state.time = "all"; draw(); });
    root.querySelectorAll("[data-teacher-view]").forEach((button) => button.addEventListener("click", () => { state.view = button.dataset.teacherView; draw(); }));
    root.querySelector("#print-teacher-report")?.addEventListener("click", () => window.print());
    root.querySelectorAll("[data-status-shortcut]").forEach((button) => button.addEventListener("click", () => { state.status = state.status === button.dataset.statusShortcut ? "all" : button.dataset.statusShortcut; draw(); }));
    root.querySelectorAll(".teacher-review-toggle").forEach((button) => button.addEventListener("click", () => { state.selectedAttemptId = state.selectedAttemptId === button.dataset.review ? null : button.dataset.review; editingReview = false; draw(); }));
    const rechecks = root.querySelector("[data-criterion-history]");
    rechecks?.addEventListener("toggle", async () => {
      if (!rechecks.open || rechecks.querySelector("form[data-dirty]") || rechecks.getAttribute("aria-busy") === "true") return;
      const output = rechecks.querySelector("[data-criterion-history-content]");
      const attempt = state.attempts.find(item => item.id === rechecks.dataset.criterionHistory);
      if (!attempt) return;
      rechecks.setAttribute("aria-busy", "true");
      output.textContent = "Đang tải các lần kiểm tra lại…";
      try {
        const entries = await fetchCriterionRechecks(attempt.id, attempt.classCode);
        if (rechecks.isConnected) {
          output.innerHTML = renderTeacherRechecks(entries, attempt);
          mountTeacherRecheckReviews(output, entries, attempt, () => {
            editingReview = Boolean(root.querySelector(".teacher-review-panel form[data-dirty]"));
          });
        }
      } catch (error) {
        if (rechecks.isConnected) output.textContent = error.message;
      } finally {
        rechecks.removeAttribute("aria-busy");
      }
    });
    rechecks?.addEventListener("input", event => {
      const form = event.target.closest("[data-recheck-comment]");
      if (!form) return;
      editingReview = true;
      form.dataset.dirty = "";
    });
    rechecks?.addEventListener("submit", async event => {
      const form = event.target.closest("[data-recheck-comment]");
      if (!form) return;
      event.preventDefault();
      const button = form.querySelector("button[type='submit']");
      const textarea = form.elements.comment;
      const status = form.querySelector("[role='status']");
      if (button.disabled) return;
      const comment = textarea.value;
      button.disabled = true;
      form.dataset.dirty = "";
      editingReview = true;
      status.textContent = "Đang lưu…";
      try {
        const saved = await saveCriterionRecheckComment({ attemptId: rechecks.dataset.criterionHistory, classCode: state.classCode,
          recheckId: form.dataset.recheckComment, version: Number(form.dataset.commentVersion), comment });
        if (!form.isConnected) return;
        form.dataset.commentVersion = String(saved.teacherCommentVersion);
        if (textarea.value === comment) {
          textarea.value = saved.teacherComment;
          delete form.dataset.dirty;
        }
        status.textContent = `Đã lưu ${timeFormatter.format(new Date(saved.teacherCommentAt))}`;
      } catch (error) {
        if (form.isConnected) status.textContent = error.message;
      } finally {
        button.disabled = false;
        if (form.isConnected) editingReview = Boolean(root.querySelector(".teacher-review-panel form[data-dirty]"));
      }
    });
    const photoButtons = root.querySelectorAll("[data-teacher-photo]");
    if (photoButtons.length || rechecks) {
      const viewer = createPhotoViewer();
      shell.append(viewer.element);
      for (const button of photoButtons) button.addEventListener("click", () => {
        const image = button.querySelector("img");
        viewer.open(image.src, image.alt);
      });
      rechecks?.addEventListener("click", event => {
        const button = event.target.closest("[data-recheck-teacher-photo]");
        const image = button?.querySelector("img");
        if (image) viewer.open(image.src, image.alt, JSON.parse(button.dataset.recheckAnnotations || "[]"));
      });
    }
    root.querySelectorAll(".teacher-review-panel form").forEach((form) => {
      const markDirty = () => { editingReview = true; form.dataset.dirty = ""; };
      for (const event of ["input", "change", "annotationchange"]) form.addEventListener(event, markDirty);
    });
    root.querySelectorAll("[data-reference-case-form]").forEach((form) => {
      const criterion = form.elements.criterionId;
      const photo = form.elements.photoIndex;
      const errorType = form.elements.errorType;
      const evidence = form.elements.evidence;
      const status = form.querySelector("[data-reference-submit-status]");
      const fieldset = form.querySelector("fieldset");
      const editor = mountPhotoAnnotationEditor(form.querySelector("[data-annotation-editor]"));
      photo.addEventListener("change", () => {
        status.textContent = "";
        if (!photo.value) { editor.show(); return; }
        editor.show(sharedAttemptImageUrl(form.dataset.referenceCaseForm, state.classCode, Number(photo.value)), { remember: true })
          .catch(() => { if (form.isConnected) status.textContent = "Không thể mở ảnh đã chọn."; });
      });
      function updateErrorField() {
        const incorrect = criterion.selectedOptions[0]?.dataset.label === "incorrect";
        errorType.disabled = !incorrect;
        errorType.required = incorrect;
        errorType.closest("label").hidden = !incorrect;
        evidence.required = incorrect && errorType.value === "other";
      }
      criterion.addEventListener("change", updateErrorField);
      errorType.addEventListener("change", updateErrorField);
      form.addEventListener("submit", async (event) => {
        event.preventDefault();
        if (fieldset.disabled) return;
        const values = new FormData(form);
        editingReview = true;
        fieldset.disabled = true;
        status.textContent = "Đang gửi ví dụ…";
        try {
          await submitReferenceCase({
            id: form.dataset.referenceCaseForm, classCode: state.classCode,
            criterionId: values.get("criterionId"), photoIndex: Number(values.get("photoIndex")),
            errorType: values.get("errorType"), evidence: values.get("evidence"),
            annotations: editor.marks(),
          });
          form.reset();
          editor.reset();
          delete form.dataset.dirty;
          editingReview = Boolean(root.querySelector(".teacher-review-panel form[data-dirty]"));
          updateErrorField();
          status.textContent = "Đã gửi ảnh vào hàng chờ kiểm duyệt.";
        } catch (error) {
          status.textContent = error.message;
        } finally {
          fieldset.disabled = false;
        }
      });
    });
    root.querySelectorAll("[data-experiment]").forEach(button => button.addEventListener("click", async () => {
      const status = button.parentElement.querySelector("[data-experiment-status]");
      const action = button.dataset.experiment;
      const attempt = state.attempts.find(item => item.id === state.selectedAttemptId);
      if (!attempt) return;
      status.textContent = "Đang xử lý…";
      button.disabled = true;
      editingReview = true;
      try {
        const body = { id: attempt.id, attemptId: attempt.id, lessonId: attempt.lessonId, classCode: state.classCode };
        const response = await (action === "compare"
          ? fetch("/api/analyze/compare", { method: "POST", body: new URLSearchParams(body) })
          : fetch("/api/classroom/comparison-report?classCode=" + encodeURIComponent(state.classCode)));
        const data = await response.json();
        if (!response.ok) throw new Error(data.error?.message || data.error);
        if (data.lessons) {
          status.textContent = data.lessons.map(row => `${row.lesson}: ${row.runs} bài, A đúng ${row.a}/${row.paired}, B đúng ${row.b}/${row.paired}, bỏ sót lỗi an toàn A ${row.missedA}/${row.safetyErrors}, B ${row.missedB}/${row.safetyErrors}, ${row.failed} lượt lỗi, ${row.missingReferences} lượt thiếu tham chiếu`).join(" | ") || "Chưa có kết quả A/B.";
          if (data.lessons.length) {
            const csv = ["lesson,runs,paired,correct_a,correct_b,failed,missing_references,safety_errors,missed_a,missed_b", ...data.lessons.map(row => [row.lesson,row.runs,row.paired,row.a,row.b,row.failed,row.missingReferences,row.safetyErrors,row.missedA,row.missedB].join(","))].join("\n");
            const link = document.createElement("a");
            link.textContent = "Tải CSV";
            link.download = "circuitcoach-ab.csv";
            link.href = "data:text/csv;charset=utf-8," + encodeURIComponent(csv);
            status.append(" ",link);
          }
        } else if (data.results) {
          status.textContent = data.results.map((row,index) => `${index ? "B" : "A"}: ${row.status === "failed" ? row.error : row.result.summary} (${row.referencesUsed} ví dụ)`).join(" | ");
          status.append(` · Đã lưu ${data.scoredCriteria ?? 0} tiêu chí đối chiếu. `);
          const link = document.createElement("a");
          link.href = "#/ai-tracking";
          link.textContent = "Theo dõi AI";
          status.append(link);
        }
      } catch (error) { status.textContent = error.message; }
      finally { button.disabled = false; }
    }));
    if (state.teacherPassword !== "cookie-session") root.querySelectorAll("[data-experiment]").forEach(button => button.remove());
    root.querySelectorAll("[data-comment-form]").forEach((form) => form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const submittedForm = event.currentTarget;
      const attemptId = submittedForm.dataset.commentForm;
      const button = submittedForm.querySelector("button");
      const status = submittedForm.querySelector("[role=status]");
      const textarea = submittedForm.elements.comment;
      const comment = String(new FormData(submittedForm).get("comment") || "").trim();
      button.disabled = true;
      editingReview = true;
      status.textContent = "Đang lưu…";
      try {
        await saveTeacherComment({ attemptId, classCode: state.classCode, teacherUsername: state.teacherUsername, teacherPassword: state.teacherPassword, comment, attempts: state.attempts });
        if (textarea.value.trim() === comment) delete submittedForm.dataset.dirty;
        status.textContent = comment ? "Đã gửi nhận xét cho nhóm." : "Đã xóa nhận xét.";
        if (submittedForm.isConnected) editingReview = Boolean(root.querySelector(".teacher-review-panel form[data-dirty]"));
      } catch (error) { status.textContent = error.message; }
      finally { button.disabled = false; }
    }));
    root.querySelectorAll("[data-teacher-label-form]").forEach((form) => form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const submittedForm = event.currentTarget;
      const attemptId = submittedForm.dataset.teacherLabelForm;
      const button = submittedForm.querySelector('button[type="submit"]');
      const teacherCriterionLabels = {};
      submittedForm.querySelectorAll("[data-criterion-id]").forEach((select) => { if (select.value) teacherCriterionLabels[select.dataset.criterionId] = select.value; });
      const teacherImageQuality = submittedForm.elements.teacherImageQuality.value || null;
      button.disabled = true;
      try {
        const response = await verifyAttempt({ attemptId, classCode: state.classCode, teacherUsername: state.teacherUsername, teacherPassword: state.teacherPassword, teacherCriterionLabels, teacherImageQuality });
        const attempt = state.attempts.find((item) => item.id === attemptId);
        if (attempt && response?.attempt) Object.assign(attempt, response.attempt);
        applyLocalVerification(attemptId, response?.attempt);
        showToast("Đã lưu nhãn giáo viên theo tiêu chí và chất lượng ảnh.", "success");
        redrawReview();
      } catch (error) { button.disabled = false; showToast(error.message, "error"); }
    }));
    root.querySelectorAll("[data-teacher-safety-form]").forEach((form) => form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const submittedForm = event.currentTarget;
      const attemptId = submittedForm.dataset.teacherSafetyForm;
      const button = submittedForm.querySelector('button[type="submit"]');
      const data = new FormData(submittedForm);
      const teacherSafetyCheck = String(data.get("teacherSafetyCheck") || "not_checked");
      const teacherPhysicalCheck = data.get("teacherPhysicalCheck") === "on";
      const teacherSafetyNote = String(data.get("teacherSafetyNote") || "").trim();
      if (teacherSafetyCheck !== "not_checked" && !teacherPhysicalCheck) {
        showToast("Hãy xác nhận đã kiểm tra trực tiếp mạch thật.", "error");
        return;
      }
      button.disabled = true;
      try {
        const response = await saveTeacherVerification({ attemptId, classCode: state.classCode, teacherUsername: state.teacherUsername, teacherPassword: state.teacherPassword, teacherSafetyCheck, teacherPhysicalCheck, teacherSafetyNote });
        const attempt = state.attempts.find((item) => item.id === attemptId);
        if (attempt && response?.attempt) Object.assign(attempt, response.attempt);
        applyLocalVerification(attemptId, response?.attempt);
        showToast("Đã lưu xác nhận kiểm tra an toàn mạch thật.", "success");
        redrawReview();
      } catch (error) { button.disabled = false; showToast(error.message, "error"); }
    }));
    root.querySelectorAll("[data-teacher-verify-form]").forEach((form) => {
      const errorFields = form.querySelector("[data-ai-error-fields]");
      for (const option of form.querySelectorAll('[name="teacherVerification"]')) {
        option.addEventListener("change", () => {
          if (errorFields) errorFields.hidden = errorFields.disabled = form.elements.teacherVerification.value !== "incorrect";
        });
      }
      form.addEventListener("submit", async (event) => {
        event.preventDefault();
        const attemptId = form.dataset.teacherVerifyForm;
        const button = form.querySelector('button[type="submit"]');
        if (button.disabled) return;
        const data = new FormData(form);
        const teacherVerification = String(data.get("teacherVerification") || "");
        const teacherVerificationNote = String(data.get("teacherVerificationNote") || "").trim();
        const teacherAiError = teacherVerification === "incorrect" && errorFields
          ? { criterionId: data.get("aiErrorCriterion"), reason: data.get("aiErrorReason") } : undefined;
        if (!teacherVerification) { showToast("Hãy chọn kết quả xác nhận của giáo viên.", "error"); return; }
        button.disabled = true;
        try {
          const response = await saveTeacherVerification({ attemptId, classCode: state.classCode, teacherUsername: state.teacherUsername, teacherPassword: state.teacherPassword, teacherVerification, teacherVerificationNote, teacherAiError });
          const attempt = state.attempts.find((item) => item.id === attemptId);
          if (attempt && response?.attempt) Object.assign(attempt, response.attempt);
          applyLocalVerification(attemptId, response?.attempt);
          showToast("Đã lưu xác nhận của giáo viên.", "success");
          redrawReview();
        } catch (error) { button.disabled = false; showToast(error.message, "error"); }
      });
    });
    root.querySelectorAll(".teacher-confirm").forEach((button) => button.addEventListener("click", async () => {
      button.disabled = true;
      const attemptId = button.dataset.attempt;
      try {
        const response = await saveTeacherVerification({ attemptId, classCode: state.classCode, teacherUsername: state.teacherUsername, teacherPassword: state.teacherPassword, teacherVerification: "correct", teacherVerificationNote: "Giáo viên xác nhận AI đúng theo ảnh; nội dung này không phải xác nhận an toàn mạch thật." });
        const attempt = state.attempts.find((item) => item.id === attemptId);
        if (attempt && response?.attempt) Object.assign(attempt, response.attempt);
        applyLocalVerification(attemptId, response?.attempt);
        showToast("Đã xác nhận AI đúng cho nhóm.", "success"); redrawReview();
      } catch (error) { button.disabled = false; showToast(error.message, "error"); }
    }));
  }

  draw();
  if (state.classCode && state.teacherPassword) refresh();
}
