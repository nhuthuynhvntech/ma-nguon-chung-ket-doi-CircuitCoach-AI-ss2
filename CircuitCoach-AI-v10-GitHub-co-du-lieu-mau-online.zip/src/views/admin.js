import { lessons } from "../data/lessons.js";
import { fetchAdminSummary, getBrowserSession, logoutAdmin, verifyAdminAccount } from "../services/classroom.js";
import { mountAdminAccounts } from "./admin-accounts.js";
import { mountLearningReport } from "./admin-learning.js";
import { appShell, emptyState, escapeHtml, icon, showToast } from "./shared.js";

const lessonTitles = new Map(lessons.map((lesson) => [lesson.id, `${lesson.icon} ${lesson.title}`]));
const verificationTitles = { correct: "Giáo viên xác nhận AI đúng", incorrect: "Giáo viên xác nhận AI sai", uncertain: "Giáo viên chưa kết luận" };

function dateLabel(value) {
  return value ? new Date(value).toLocaleString("vi-VN", { dateStyle: "short", timeStyle: "short" }) : "Chưa có";
}

export function renderAdmin(root) {
  const routeHash = location.hash;
  let shell;
  const state = { username: "", summary: null, classCode: "all", page: "learning", loading: false, error: "" };

  function draw() {
    if (location.hash !== routeHash || (shell && !shell.isConnected)) return;
    if (!state.summary) {
      root.innerHTML = appShell(`<section class="admin-login-page"><div class="admin-login-card"><p class="eyebrow">KHU VỰC QUẢN TRỊ</p><h1>Quản lý toàn hệ thống</h1><p>Đăng nhập bằng tài khoản quản trị được cấu hình trên máy chủ. Phiên đăng nhập tự hết hạn sau 30 phút.</p>${state.error ? `<p class="admin-error" role="alert">${escapeHtml(state.error)}</p>` : ""}<form id="admin-login-form"><label>Tên đăng nhập<input name="username" autocomplete="username" maxlength="40" required /></label><label>Mật khẩu<input name="password" type="password" autocomplete="current-password" maxlength="128" required /></label><button class="btn btn-primary" type="submit" ${state.loading ? "disabled" : ""}>${state.loading ? "Đang xác thực…" : "Đăng nhập quản trị"}</button></form><small>Tài khoản quản trị chỉ xem dữ liệu tổng hợp và bài làm; mật khẩu không được lưu trong trình duyệt.</small><a class="text-button" href="#/teacher">Đến trang Giáo viên →</a></div></section>`, "admin");
      shell = root.firstElementChild;
      root.querySelector("#admin-login-form")?.addEventListener("submit", submitLogin);
      return;
    }

    const classes = state.summary.classes || [];
    const allAttempts = state.summary.attempts || [];
    const filtered = state.classCode === "all" ? allAttempts : allAttempts.filter((attempt) => attempt.classCode === state.classCode);
    const stats = state.summary.stats || {};
    const rows = filtered.length ? filtered.map((attempt) => `<tr>
      <td>${escapeHtml(dateLabel(attempt.time))}</td>
      <td><strong>${escapeHtml(attempt.studentName || "Nhóm chưa đặt tên")}</strong><small>${escapeHtml((attempt.teamMembers || []).filter(Boolean).join(", "))}</small></td>
      <td>${escapeHtml(attempt.classCode || "—")}</td>
      <td>${escapeHtml(lessonTitles.get(attempt.lessonId) || attempt.lessonId || "—")}</td>
      <td><span class="admin-result ${attempt.demo ? "is-demo" : attempt.verdict === "pass" ? "is-pass" : "is-review"}">${attempt.demo ? "DEMO" : attempt.verdict === "pass" ? "Đạt" : "Cần xem lại"}</span></td>
      <td>${escapeHtml(verificationTitles[attempt.teacherVerification] || "Chờ giáo viên")}</td>
      <td>${Number(attempt.imageCount) || 0} ảnh</td>
    </tr>`).join("") : `<tr><td colspan="7">Chưa có bài làm trong bộ lọc này.</td></tr>`;

    root.innerHTML = appShell(`<section class="admin-page">
      <header class="page-head compact-head admin-page-head"><div><p class="eyebrow">QUẢN TRỊ TOÀN HỆ THỐNG</p><h1>Trung tâm quản trị</h1><p>Thống kê lớp, nhóm và trạng thái xác nhận của giáo viên.</p></div><div class="admin-actions"><button id="admin-refresh" class="btn btn-secondary" ${state.loading ? "disabled" : ""}>Làm mới</button>${getBrowserSession()?.role === "admin" ? "" : '<button id="admin-logout" class="btn btn-logout">Đăng xuất quản trị</button>'}</div></header>
      ${state.error ? `<p class="admin-error" role="alert">${escapeHtml(state.error)}</p>` : ""}
      <section class="admin-stat-grid"><article><small>Mã lớp</small><strong>${Number(stats.classCount) || 0}</strong></article><article><small>Nhóm</small><strong>${Number(stats.groupCount) || 0}</strong></article><article><small>Lượt kiểm tra</small><strong>${Number(stats.attemptCount) || 0}</strong></article><article><small>Chờ giáo viên xác nhận</small><strong>${Number(stats.awaitingTeacher) || 0}</strong></article></section>
      <section class="panel admin-class-panel"><div class="section-title"><div><p class="eyebrow">DANH SÁCH LỚP</p><h2>Tổng quan theo lớp</h2></div><span>${classes.length} lớp</span></div>${classes.length ? `<div class="admin-class-grid">${classes.map((item) => `<button type="button" class="admin-class-card ${state.classCode === item.classCode ? "selected" : ""}" data-class-code="${escapeHtml(item.classCode)}"><strong>${escapeHtml(item.classCode)}</strong><span>${item.groupCount} nhóm · ${item.attemptCount} lượt</span><small>Gần nhất: ${escapeHtml(dateLabel(item.latestActivity))}</small></button>`).join("")}</div>` : emptyState("Chưa có lớp", "Giáo viên tạo mã lớp ở trang Giáo viên.")}</section>
      <section class="panel admin-attempt-panel"><div class="section-title"><div><p class="eyebrow">BÀI LÀM GẦN ĐÂY</p><h2>${state.classCode === "all" ? "Toàn hệ thống" : `Lớp ${escapeHtml(state.classCode)}`}</h2></div><label class="admin-filter">Lọc lớp<select id="admin-class-filter"><option value="all" ${state.classCode === "all" ? "selected" : ""}>Tất cả lớp</option>${classes.map((item) => `<option value="${escapeHtml(item.classCode)}" ${state.classCode === item.classCode ? "selected" : ""}>${escapeHtml(item.classCode)}</option>`).join("")}</select></label></div><div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Thời gian</th><th>Nhóm / thành viên</th><th>Lớp</th><th>Bài học</th><th>Kết quả AI</th><th>Xác nhận</th><th>Ảnh</th></tr></thead><tbody>${rows}</tbody></table></div>${state.summary.truncated ? "<p class='muted'>Danh sách hiện hiển thị tối đa 1.000 lượt gần nhất.</p>" : ""}</section>
    </section>`, "admin");

    shell = root.firstElementChild;
    root.querySelector("#admin-refresh")?.addEventListener("click", refresh);
    const workspace = document.createElement("div");
    workspace.hidden = true;
    workspace.innerHTML = `<nav class="teacher-view-tabs" aria-label="Quản trị">
      <button type="button" data-admin-page="learning">Lớp học và báo cáo</button>
      <button type="button" data-admin-page="accounts">Tài khoản giáo viên</button>
      <a href="#/references/all?view=manage">Quản lý kho tham chiếu</a>
    </nav><section class="panel admin-learning"></section><div data-admin-accounts><section class="panel admin-accounts" hidden></section></div>`;
    root.querySelector(".admin-page > header").after(workspace);
    const learning = workspace.querySelector(".admin-learning");
    const accounts = workspace.querySelector("[data-admin-accounts]");
    const legacy = root.querySelectorAll(".admin-stat-grid, .admin-class-panel, .admin-attempt-panel");
    function selectPage(page) {
      state.page = page;
      learning.hidden = page !== "learning";
      accounts.hidden = page !== "accounts";
      for (const button of workspace.querySelectorAll("[data-admin-page]")) {
        const selected = page === button.dataset.adminPage;
        button.classList.toggle("selected",selected);
        button.setAttribute("aria-pressed",String(selected));
      }
    }
    for (const button of workspace.querySelectorAll("[data-admin-page]")) {
      button.addEventListener("click", () => selectPage(button.dataset.adminPage));
    }
    mountLearningReport(learning, { onReady: () => {
      workspace.hidden = false;
      for (const section of legacy) section.hidden = true;
      selectPage(state.page);
    } });
    mountAdminAccounts(accounts.querySelector(".admin-accounts"));
    root.querySelector("#admin-logout")?.addEventListener("click", signOut);
    root.querySelector("#admin-class-filter")?.addEventListener("change", (event) => { state.classCode = event.target.value; draw(); });
    root.querySelectorAll("[data-class-code]").forEach((button) => button.addEventListener("click", () => { state.classCode = button.dataset.classCode; draw(); }));
  }

  async function refresh({ silent = false } = {}) {
    state.loading = true;
    state.error = "";
    draw();
    try {
      state.summary = await fetchAdminSummary();
    } catch (error) {
      state.summary = null;
      state.error = silent && /phiên quản trị đã hết hạn/i.test(error.message) ? "" : error.message;
    } finally {
      state.loading = false;
      draw();
    }
  }

  async function submitLogin(event) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const username = String(data.get("username") || "").trim();
    const password = String(data.get("password") || "");
    state.loading = true;
    state.error = "";
    draw();
    try {
      await verifyAdminAccount(username, password);
      state.summary = await fetchAdminSummary();
      state.username = username;
      state.classCode = "all";
      showToast("Đã đăng nhập quản trị.", "success");
    } catch (error) {
      state.error = error.message;
    } finally {
      state.loading = false;
      draw();
    }
  }

  async function signOut() {
    const button = root.querySelector("#admin-logout");
    if (!button || button.disabled) return;
    button.disabled = true;
    try {
      await logoutAdmin();
      if (location.hash === routeHash) location.hash = "#/home";
      showToast("Đã đăng xuất quản trị.", "success");
    } catch (error) {
      button.disabled = false;
      showToast(error.message, "error");
    }
  }

  draw();
  refresh({ silent: true });
}
