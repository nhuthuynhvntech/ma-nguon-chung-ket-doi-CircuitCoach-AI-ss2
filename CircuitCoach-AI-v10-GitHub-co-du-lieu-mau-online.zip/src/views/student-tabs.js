import { escapeHtml } from "./shared.js";

export function renderStudentTabs(label, tabs) {
  return `<div class="student-task-tabs" role="tablist" aria-label="${escapeHtml(label)}">
    ${tabs.map(([id, title], index) => `<button type="button" role="tab" id="${id}-tab" aria-controls="${id}" aria-selected="${index === 0}" tabindex="${index === 0 ? 0 : -1}">${escapeHtml(title)}</button>`).join("")}
  </div>`;
}

export function mountStudentTabs(root) {
  const tabList = root.querySelector(".student-task-tabs");
  const tabs = Array.from(tabList.querySelectorAll("[role='tab']"));
  const panels = tabs.map(tab => root.querySelector("#" + tab.getAttribute("aria-controls")));

  function selectTab(activeIndex) {
    tabs.forEach((tab, index) => {
      const active = index === activeIndex;
      tab.setAttribute("aria-selected", String(active));
      tab.tabIndex = active ? 0 : -1;
      panels[index].hidden = !active;
    });
  }

  tabList.addEventListener("click", (event) => {
    const index = tabs.indexOf(event.target.closest("[role='tab']"));
    if (index >= 0) selectTab(index);
  });
  tabList.addEventListener("keydown", (event) => {
    const index = tabs.indexOf(event.target);
    if (index < 0) return;
    let next;
    switch (event.key) {
      case "ArrowLeft": next = (index + tabs.length - 1) % tabs.length; break;
      case "ArrowRight": next = (index + 1) % tabs.length; break;
      case "Home": next = 0; break;
      case "End": next = tabs.length - 1; break;
      default: return;
    }
    event.preventDefault();
    selectTab(next);
    tabs[next].focus();
  });
}
