import { getLesson, lessons } from "../data/lessons.js";
import { REFERENCE_ERROR_TYPES, REFERENCE_REVIEW_STATES } from "../data/reference-cases.js";
import { fetchPublicReferenceCases, fetchSharedReferenceCases, publicReferenceExamplePhotoUrl, reviewReferenceCase, sharedReferencePhotoUrl } from "../services/classroom.js";
import { appShell, escapeHtml, icon, showToast } from "./shared.js";
import { createPhotoViewer } from "./photo-tools.js";

const unclassifiedError = "unclassified";
const errorFolderNames = { ...REFERENCE_ERROR_TYPES, [unclassifiedError]: "Chưa phân loại dạng lỗi" };
const errorFolderDescriptions = {
  missing: "Thiếu linh kiện hoặc dây cần thiết, ví dụ thiếu điện trở hoặc dây GND.",
  reversed: "Linh kiện lắp ngược chiều hoặc đấu nhầm cực dương và cực âm.",
  miswired: "Dây hoặc linh kiện nối sai chân, sai hàng trên breadboard hoặc sai vị trí trong mạch.",
  wrong_value: "Trị số linh kiện hoặc mức nguồn lệch yêu cầu của bài.",
  short_risk: "Có dấu hiệu nối tắt nguồn với GND hoặc nối tắt hai cực nguồn.",
  other: "Các lỗi có dấu hiệu rõ trên ảnh, nằm ngoài các nhóm trên.",
  [unclassifiedError]: "Ảnh lỗi được lưu trước khi có danh mục dạng lỗi.",
};

export function renderReferences(root, lessonId = "all", { manage = false, role, errorType } = {}) {
  const lesson = getLesson(lessonId);
  const canManage = role === "teacher" || role === "admin";
  const managing = canManage && manage;
  const state = { loading: Boolean(lesson), error: "", cases: [] };
  const routeHash = location.hash;
  const selectedError = Object.hasOwn(errorFolderNames, errorType) ? errorType : "";
  const lessonHref = (id, manageLibrary = managing, error = "") => {
    const params = new URLSearchParams();
    if (manageLibrary) params.set("view", "manage");
    if (error) params.set("error", error);
    return `#/references${id ? "/" + id : manageLibrary ? "/all" : ""}${params.size ? "?" + params : ""}`;
  };

  function criterionName(id) {
    return lesson.checks.find(([criterionId]) => criterionId === id)?.[1] || id;
  }

  function errorFolderId(example) {
    return Object.hasOwn(REFERENCE_ERROR_TYPES, example.errorType) ? example.errorType : unclassifiedError;
  }

  function reviewActions(example) {
    if (!managing || !example.canManage) return "";
    if (example.status === "pending") {
      return `<div class="reference-case-actions">
        <button class="btn btn-primary" type="button" data-reference-decision="approved">Duyệt và công khai</button>
        <button class="btn btn-ghost" type="button" data-reference-decision="rejected">Từ chối</button>
      </div>`;
    }
    if (example.status === "approved") {
      return '<div class="reference-case-actions"><button class="btn btn-ghost" type="button" data-reference-decision="retired">Ngừng dùng</button></div>';
    }
    return "";
  }

  function caseCard(example) {
    const src = managing ? sharedReferencePhotoUrl(example.id) : publicReferenceExamplePhotoUrl(example.id);
    const criterion = criterionName(example.criterionId);
    const result = example.label === "correct" ? "Đúng ở tiêu chí này" : example.label === "incorrect" ? errorFolderNames[errorFolderId(example)] : "Chưa đủ bằng chứng";
    return `<article class="lesson-sample-photo reference-case-photo" data-reference-id="${escapeHtml(example.id)}">
      <button class="lesson-sample-thumbnail" data-zoom="${escapeHtml(src)}" data-label="${escapeHtml(criterion)}" type="button">
        <img src="${escapeHtml(src)}" alt="${escapeHtml(criterion)}" loading="lazy" decoding="async" />
      </button>
      <div class="lesson-sample-details"><strong>${escapeHtml(criterion)}</strong>
        <p>${escapeHtml(result)}${managing ? ` · ${escapeHtml(REFERENCE_REVIEW_STATES[example.status] || example.status)}${example.source === "upload" ? " · Tải trực tiếp" : ""}` : ""}</p>
        ${managing && example.evidence ? `<p>${escapeHtml(example.evidence)}</p>` : ""}
        ${example.annotations?.length ? `<p>${example.annotations.length} nét và chú thích</p>` : ""}
        ${reviewActions(example)}
      </div>
    </article>`;
  }

  function folder(title, count, content, opened = false) {
    return `<details class="reference-case-folder"${opened ? " open" : ""}>
      <summary><strong>${escapeHtml(title)}</strong><span>${count} ảnh</span></summary>
      ${content}
    </details>`;
  }

  function caseGrid(examples) {
    return `<div class="lesson-sample-grid">${examples.map(caseCard).join("")}</div>`;
  }

  function errorFolderList(errors) {
    const categoryIds = Object.keys(REFERENCE_ERROR_TYPES);
    if (errors.has(unclassifiedError)) categoryIds.push(unclassifiedError);
    return `<nav class="reference-error-folders" aria-label="Thư mục dạng lỗi">
      ${categoryIds.map(id => `<a class="reference-error-folder" href="${escapeHtml(lessonHref(lesson.id, managing, id))}">
        <div><strong>${escapeHtml(errorFolderNames[id])}</strong><span>${errors.get(id)?.length || 0} ảnh</span></div>
        <p>${escapeHtml(errorFolderDescriptions[id])}</p>
      </a>`).join("")}
    </nav>`;
  }

  function errorFolderContents(examples) {
    const byCriterion = new Map();
    for (const example of examples) {
      const group = byCriterion.get(example.criterionId) || [];
      group.push(example);
      byCriterion.set(example.criterionId, group);
    }
    return `<section class="reference-case-folders" aria-labelledby="reference-error-title">
      <a class="text-button" href="${lessonHref(lesson.id)}">Tất cả thư mục của bài</a>
      <div class="reference-error-folder-heading"><h3 id="reference-error-title">${escapeHtml(errorFolderNames[selectedError])}</h3><span>${examples.length} ảnh</span></div>
      <p class="muted">${escapeHtml(errorFolderDescriptions[selectedError])}</p>
      ${[...byCriterion].map(([criterionId, group]) => `<section class="reference-error-criterion">
        <h4>${escapeHtml(criterionName(criterionId))} <small>${group.length} ảnh</small></h4>${caseGrid(group)}
      </section>`).join("") || '<p class="reference-case-folder reference-folder-empty">Chưa có ảnh lỗi đã duyệt trong thư mục này.</p>'}
    </section>`;
  }

  function folders() {
    if (state.loading) return '<p class="references-loading" role="status">Đang tải ảnh của bài…</p>';
    if (state.error) return `<p class="references-error" role="status">${escapeHtml(state.error)}</p>`;
    const correct = [];
    const errors = new Map();
    const pending = [];
    const other = [];
    for (const example of state.cases) {
      if (managing && example.status === "pending") pending.push(example);
      else if (managing && example.status !== "approved") other.push(example);
      else if (example.label === "correct") correct.push(example);
      else if (example.label === "incorrect") {
        const key = errorFolderId(example);
        const group = errors.get(key) || [];
        group.push(example);
        errors.set(key, group);
      } else other.push(example);
    }
    if (selectedError) return errorFolderContents(errors.get(selectedError) || []);
    return `<section class="reference-case-folders" aria-label="Thư mục trường hợp của bài">
      ${managing ? folder("Ảnh chờ duyệt", pending.length, pending.length ? caseGrid(pending) : '<p class="muted">Chưa có ảnh chờ duyệt cho bài này.</p>', true) : ""}
      <h3>Mẫu đúng</h3>
      ${folder("Đúng theo tiêu chí", correct.length, correct.length ? caseGrid(correct) : '<p class="muted">Chưa có ảnh đúng theo tiêu chí được duyệt.</p>', true)}
      <h3>Mẫu có lỗi</h3>
      ${errorFolderList(errors)}
      ${other.length ? folder("Ảnh chưa đủ điều kiện tham chiếu", other.length, caseGrid(other)) : ""}
    </section>`;
  }

  function builtInFolder() {
    const images = lesson.referenceImages.map(image => `<figure class="lesson-sample-photo reference-case-photo">
      <button class="lesson-sample-thumbnail" data-zoom="${escapeHtml(image.src)}" data-label="${escapeHtml(image.label)}" type="button">
        <img src="${escapeHtml(image.src)}" alt="${escapeHtml(image.label)}" loading="lazy" decoding="async" />
      </button><figcaption class="lesson-sample-details">${escapeHtml(image.label)}</figcaption>
    </figure>`).join("");
    return folder("Ảnh và sơ đồ có sẵn của bài", lesson.referenceImages.length, `<div class="lesson-sample-grid">${images}</div>`, true);
  }

  function template() {
    return appShell(`
      <section class="references-page">
        <header class="references-hero">
          <div><h1>Kho tham chiếu</h1><p>Kho ảnh chung của toàn hệ thống, sắp xếp theo bài học và dạng lỗi.</p></div>
          ${role === "teacher" ? `<div class="reference-library-actions">
            <a class="btn btn-primary" href="#/reference-upload${lesson ? "/" + lesson.id : ""}${lesson && Object.hasOwn(REFERENCE_ERROR_TYPES, selectedError) ? "?error=" + selectedError : ""}">${icon("upload", 17)} Tải ảnh theo tiêu chí</a>
          </div>` : ""}
        </header>
        ${canManage ? `<nav class="teacher-view-tabs" aria-label="Chế độ xem kho tham chiếu">
          <a href="${escapeHtml(lessonHref(lesson?.id, false, lesson ? selectedError : ""))}"${managing ? "" : ' class="selected" aria-current="page"'}>Kho công khai</a>
          <a href="${escapeHtml(lessonHref(lesson?.id, true, lesson ? selectedError : ""))}"${managing ? ' class="selected" aria-current="page"' : ""}>Quản lý kho chung</a>
        </nav>` : ""}
        <nav class="${lesson ? "ai-tracking-lessons" : "reference-lesson-folders"}" aria-label="Thư mục bài học">
          ${lessons.map(item => `<a href="${lessonHref(item.id)}"${lesson?.id === item.id ? ' aria-current="page"' : ""}>
            ${lesson ? "" : `<img src="${escapeHtml(item.image)}" alt="" />`}${escapeHtml(item.title)}
          </a>`).join("")}
        </nav>
        ${lesson ? `<div class="references-class-note reference-lesson-heading">
          <div><h2>${escapeHtml(lesson.title)}</h2><p>${managing && role === "teacher" ? "Bạn có thể duyệt ảnh mình tải lên và ảnh gửi từ các lớp được phân công." : "Ảnh đã duyệt của bài học được chia sẻ cho mọi người."}</p></div>
          <button id="refresh-references" class="btn btn-ghost" type="button" ${state.loading ? "disabled" : ""}>Làm mới</button>
        </div><div id="reference-case-results">${folders()}</div>${managing || selectedError ? "" : builtInFolder()}` : managing ? '<p class="muted">Chọn bài học để xem và duyệt ảnh trong kho chung.</p>' : ""}
      </section>
    `, "references");
  }

  function bind() {
    const view = root.firstElementChild;
    const viewer = createPhotoViewer();
    view.append(viewer.element);
    root.querySelector("#refresh-references")?.addEventListener("click", load);
    view.addEventListener("click", (event) => {
      const action = event.target.closest("[data-reference-decision]");
      if (action) {
        void saveReview(view, action);
        return;
      }
      const button = event.target.closest("[data-zoom]");
      if (!button) return;
      const id = button.closest("[data-reference-id]")?.dataset.referenceId;
      const annotations = state.cases.find(example => example.id === id)?.annotations;
      viewer.open(button.dataset.zoom, button.dataset.label, annotations);
    });
  }

  async function saveReview(view, action) {
    const { referenceDecision: status } = action.dataset;
    const { referenceId: id } = action.closest("[data-reference-id]").dataset;
    const results = view.querySelector("#reference-case-results");
    const refresh = view.querySelector("#refresh-references");
    const buttons = results.querySelectorAll("[data-reference-decision]");
    const isCurrent = () => view.isConnected && location.hash === routeHash;
    refresh.disabled = true;
    for (const button of buttons) button.disabled = true;
    try {
      const { reviewedAt } = await reviewReferenceCase({ id, status });
      if (!isCurrent()) return;
      const example = state.cases.find(item => item.id === id);
      Object.assign(example, { status, reviewedAt });
      const opened = new Map([...results.querySelectorAll("details")].map(folder => [folder.querySelector("summary strong").textContent, folder.open]));
      const scrollY = window.scrollY;
      results.innerHTML = folders();
      for (const folder of results.querySelectorAll("details")) {
        const label = folder.querySelector("summary strong").textContent;
        if (opened.has(label)) folder.open = opened.get(label);
      }
      (results.querySelector(".reference-case-folder summary") || refresh).focus({ preventScroll: true });
      window.scrollTo(0, scrollY);
      const messages = { approved: "Đã duyệt ảnh.", rejected: "Đã từ chối ảnh.", retired: "Đã ngừng dùng ảnh." };
      showToast(messages[status], "success");
    } catch (error) {
      if (isCurrent()) showToast(error.message, "error");
    } finally {
      refresh.disabled = false;
      for (const button of buttons) button.disabled = false;
    }
  }

  function draw() {
    root.innerHTML = template();
    bind();
  }

  async function load() {
    if (!lesson) return;
    state.loading = true;
    state.error = "";
    draw();
    const view = root.firstElementChild;
    const current = () => view.isConnected && location.hash === routeHash;
    try {
      const cases = await (managing ? fetchSharedReferenceCases(lesson.id) : fetchPublicReferenceCases(lesson.id).catch(error => {
        if (error.status === 404) return [];
        throw error;
      }));
      if (current()) state.cases = cases;
    } catch (error) {
      if (current()) {
        state.error = error.message;
      }
    } finally {
      if (current()) {
        state.loading = false;
        draw();
      }
    }
  }

  if (lesson) void load();
  else draw();
}
