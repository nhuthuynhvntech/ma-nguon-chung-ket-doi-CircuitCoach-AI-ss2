import { lessons } from "../data/lessons.js";
import { getLearningAnalytics } from "../services/analytics.js";
import { getRecommendation } from "../services/recommendation.js";
import { getStudent } from "../services/storage.js";
import { appShell, escapeHtml, icon } from "./shared.js";

export function renderLessons(root) {
  const student = getStudent();
  const analytics = student && getLearningAnalytics();
  const recommendation = student && getRecommendation();
  const cards = lessons.map((lesson, index) => `
    <article class="lesson-card" style="--delay:${index * 70}ms">
      <div class="lesson-visual"><img src="${lesson.image}" alt="Minh họa ${escapeHtml(lesson.title)}" /><span>${lesson.eyebrow}</span></div>
      <div class="lesson-body">
        <div class="lesson-title"><span>${lesson.icon}</span><div><small>${lesson.board}</small><h2>${lesson.title}</h2></div></div>
        <ul>${lesson.learn.map((item) => `<li>${icon("check", 15)}${escapeHtml(item)}</li>`).join("")}</ul>
        <a class="btn btn-secondary btn-full" href="#/analyzer/${lesson.id}">Mở bài học ${icon("arrow", 18)}</a>
        ${student ? "" : `
          <a class="lesson-history-link" href="#/assembly/${lesson.id}">${icon("book", 17)} Hướng dẫn lắp mạch</a>
          <a class="lesson-history-link" href="#/lesson-prompts/${lesson.id}">${icon("info", 17)} Xem prompt AI</a>`}
      </div>
    </article>`).join("");
  root.innerHTML = appShell(`
    <section class="page-head compact-head">
      <div><p class="eyebrow">PHÒNG THÍ NGHIỆM SỐ</p><h1>Chọn mạch để bắt đầu</h1><p>Năm bài cốt lõi, từ mạch pin đơn giản đến Arduino, mỗi bài có bộ tiêu chí kiểm tra riêng.</p></div>
      ${analytics ? `<aside class="progress-card"><span>${analytics.completedLessons}/${analytics.totalLessons}</span><div><strong>Bài đã trải nghiệm</strong><small>${analytics.attempts.length} lần kiểm tra</small></div></aside>` : ""}
    </section>
    <section class="lesson-grid">${cards}</section>
    ${recommendation ? `<section class="recommendation-banner"><div>${icon("spark", 24)}<span><small>GỢI Ý HÔM NAY</small><strong>${escapeHtml(recommendation.title)}</strong></span></div><p>${escapeHtml(recommendation.detail)}</p></section>` : ""}
  `, "lessons");
}
