import { GUIDE_CHAT_QUESTIONS, GUIDE_HISTORY_LIMIT, GUIDE_QUESTION_LIMIT } from "../data/guide-chat.js";
import { getLesson, lessons } from "../data/lessons.js";
import { requestGuideChat, requestStudentGuide } from "../services/api.js";
import { CLASSROOM_SESSION_CHANGE, getBrowserSession } from "../services/classroom.js";
import { getAttempt, getStudent, STUDENT_SESSION_KEY } from "../services/storage.js";
import { escapeHtml, icon } from "./shared.js";
import { renderStudentGuide } from "./student-guide.js";

function lessonOnPage() {
  const [page, id] = location.hash.replace(/^#\/?/, "").split("/");
  if (page === "result") return getAttempt(id)?.lessonId || "";
  return getLesson(id?.split("?")[0])?.id || "";
}

function guideStudentSession() {
  if (getBrowserSession()?.role !== "student") return null;
  const student = getStudent();
  return student?.classCode ? { classCode: student.classCode, name: student.name } : null;
}

function quickGuideReply(topic, lesson) {
  const { answer } = GUIDE_CHAT_QUESTIONS[topic];
  if (topic === "assembly" && lesson) {
    return {
      answer: [lesson.title, ...lesson.expectedConnections, "Giữ nguồn ngắt trong lúc lắp. Nhờ giáo viên kiểm tra trước khi cấp nguồn."].join("\n"),
      link: { title: "Xem từng bước lắp mạch", href: "#/assembly/" + lesson.id },
    };
  }
  return {
    answer,
    link: topic === "photos" && lesson ? { title: "Mở trang gửi ảnh", href: "#/analyzer/" + lesson.id } : null,
  };
}

export function initializeGuideChat() {
  const dialog = document.createElement("dialog");
  dialog.className = "guide-chat-dialog";
  dialog.setAttribute("aria-labelledby", "guide-chat-title");
  dialog.innerHTML = `
    <div class="guide-chat">
      <header class="guide-chat-header">
        <h2 id="guide-chat-title">Trợ lý hướng dẫn</h2>
        <button class="icon-button" type="button" data-guide-close aria-label="Đóng trợ lý">${icon("x", 20)}</button>
      </header>
      <label class="guide-chat-topic">Chủ đề
        <select id="guide-chat-topic">
          <option value="">Cách dùng CircuitCoach</option>
          ${lessons.map(lesson => `<option value="${lesson.id}">${escapeHtml(lesson.title)}</option>`).join("")}
        </select>
      </label>
      <div class="guide-chat-quick" role="group" aria-label="Câu hỏi nhanh">
        ${Object.entries(GUIDE_CHAT_QUESTIONS).map(([id, item]) => `<button type="button" data-guide-question="${id}">${escapeHtml(item.label)}</button>`).join("")}
      </div>
      <div class="guide-chat-log" role="log" aria-label="Cuộc trò chuyện" aria-live="polite" tabindex="0"></div>
      <p class="guide-chat-status" role="status" hidden>Trợ lý đang trả lời…</p>
      <form class="guide-chat-form">
        <label for="guide-chat-message">Câu hỏi của em</label>
        <div>
          <input id="guide-chat-message" name="message" type="text" maxlength="${GUIDE_QUESTION_LIMIT}" autocomplete="off" placeholder="Ví dụ: Em nên chụp ảnh ở góc nào?" aria-describedby="guide-chat-note" required />
          <button class="btn btn-primary" type="submit">Gửi</button>
        </div>
        <small id="guide-chat-note">Chỉ nhập câu hỏi về bài. Tránh chia sẻ thông tin cá nhân.</small>
      </form>
    </div>`;
  document.body.append(dialog);
  const topic = dialog.querySelector("#guide-chat-topic");
  const log = dialog.querySelector(".guide-chat-log");
  const status = dialog.querySelector(".guide-chat-status");
  const title = dialog.querySelector("h2");
  const note = dialog.querySelector("#guide-chat-note");
  const guidePanel = document.createElement("section");
  guidePanel.className = "guide-chat-personal";
  const form = dialog.querySelector("form");
  const input = form.elements.message;
  const send = form.querySelector('button[type="submit"]');
  const quickButtons = Array.from(dialog.querySelectorAll("[data-guide-question]"));
  let opener;
  let lastPage;
  let pending;
  let pendingGuide;
  let messages = [];

  function addMessage(role, text, link) {
    const entry = document.createElement("div");
    entry.className = `guide-chat-message is-${role}`;
    const speaker = document.createElement("strong");
    speaker.textContent = role === "user" ? "Em" : "Trợ lý";
    const paragraph = document.createElement("p");
    paragraph.textContent = text;
    entry.append(speaker, paragraph);
    if (link) {
      const action = document.createElement("a");
      action.className = "text-button";
      action.href = link.href;
      action.textContent = link.title;
      action.addEventListener("click", () => dialog.close());
      entry.append(action);
    }
    log.append(entry);
    log.scrollTop = log.scrollHeight;
  }

  function setBusy(value) {
    status.hidden = !value;
    send.disabled = value;
    quickButtons.forEach(button => { button.disabled = value; });
  }

  function resetConversation() {
    pending?.abort();
    pending = undefined;
    pendingGuide?.abort();
    pendingGuide = undefined;
    guidePanel.replaceChildren();
    setBusy(false);
    messages = [];
    input.value = "";
    log.replaceChildren();
    const lesson = getLesson(topic.value);
    addMessage("assistant", lesson ? `Em cần giúp ở bước nào trong bài ${lesson.title}?` : "Em có thể hỏi cách gửi ảnh, đọc kết quả hoặc chọn một bài để hỏi cách lắp mạch.");
  }

  async function refreshPersonalGuide() {
    pendingGuide?.abort();
    pendingGuide = undefined;
    const student = guideStudentSession();
    title.textContent = student ? "Trợ lý cá nhân" : "Trợ lý hướng dẫn";
    note.textContent = student ? "AI dùng tóm tắt tiêu chí trong lịch sử của nhóm khi trả lời. Tránh nhập thông tin cá nhân."
      : "Chỉ nhập câu hỏi về bài. Tránh chia sẻ thông tin cá nhân.";
    if (!student) {
      guidePanel.remove();
      guidePanel.replaceChildren();
      return;
    }
    const lesson = getLesson(topic.value);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    pendingGuide = controller;
    log.prepend(guidePanel);
    renderStudentGuide(guidePanel, { message: "Đang xem lịch sử làm bài…" });
    try {
      const { guide } = await requestStudentGuide({ lessonId: topic.value, student }, controller.signal);
      if (pendingGuide === controller) renderStudentGuide(guidePanel, { guide, lesson, onOpenLink: () => dialog.close() });
    } catch (error) {
      if (pendingGuide === controller) renderStudentGuide(guidePanel, {
        message: error.code === "GUIDE_STUDENT_SESSION" ? error.message : "Chưa tải được lịch sử. Em có thể mở lại trợ lý để thử lại.",
      });
    } finally {
      clearTimeout(timer);
      if (pendingGuide === controller) pendingGuide = undefined;
    }
  }

  function showAnswer({ answer, link }) {
    messages.push({ role: "assistant", content: answer });
    addMessage("assistant", answer, link);
  }

  async function ask(question, quickReply) {
    if (!question || pending) return;
    messages.push({ role: "user", content: question });
    addMessage("user", question);
    if (quickReply) {
      showAnswer(quickReply);
      return;
    }

    const controller = new AbortController();
    pending = controller;
    const timer = setTimeout(() => controller.abort(), 28_000);
    setBusy(true);
    try {
      const student = guideStudentSession();
      const reply = await requestGuideChat({
        lessonId: topic.value,
        messages: messages.slice(-GUIDE_HISTORY_LIMIT),
        ...(student ? { student } : {}),
      }, controller.signal);
      if (pending === controller) showAnswer(reply);
    } catch (error) {
      if (pending !== controller) return;
      messages.pop();
      addMessage("assistant", ["RATE_LIMITED", "GUIDE_STUDENT_SESSION"].includes(error.code)
        ? error.message : "Trợ lý đang bận. Em có thể thử gửi lại hoặc chọn một câu hỏi nhanh.");
      if (!input.value) input.value = question;
    } finally {
      clearTimeout(timer);
      if (pending === controller) {
        pending = undefined;
        setBusy(false);
      }
    }
  }

  form.addEventListener("submit", event => {
    event.preventDefault();
    const question = input.value.trim();
    if (!question || pending) return;
    input.value = "";
    void ask(question);
  });
  quickButtons.forEach(button => button.addEventListener("click", () => {
    const topicId = button.dataset.guideQuestion;
    void ask(GUIDE_CHAT_QUESTIONS[topicId].question, quickGuideReply(topicId, getLesson(topic.value)));
  }));
  topic.addEventListener("change", () => {
    resetConversation();
    void refreshPersonalGuide();
  });
  dialog.querySelector("[data-guide-close]").addEventListener("click", () => dialog.close());
  dialog.addEventListener("close", () => { if (opener?.isConnected) opener.focus(); });

  function resetSession() {
    if (dialog.open) dialog.close();
    lastPage = undefined;
    topic.value = "";
    resetConversation();
  }

  window.addEventListener("storage", event => {
    if ([CLASSROOM_SESSION_CHANGE, STUDENT_SESSION_KEY].includes(event.key)) resetSession();
  });
  document.addEventListener("click", event => {
    if (!(event.target instanceof Element)) return;
    if (event.target.closest("[data-browser-logout]")) resetSession();
    const trigger = event.target.closest("[data-open-guide-chat]");
    if (!trigger || dialog.open) return;
    opener = trigger;
    if (lastPage !== location.hash) {
      const lessonId = lessonOnPage();
      if (!lastPage || topic.value !== lessonId) {
        topic.value = lessonId;
        resetConversation();
      }
      lastPage = location.hash;
    }
    dialog.showModal();
    void refreshPersonalGuide();
    input.focus();
  });
}
