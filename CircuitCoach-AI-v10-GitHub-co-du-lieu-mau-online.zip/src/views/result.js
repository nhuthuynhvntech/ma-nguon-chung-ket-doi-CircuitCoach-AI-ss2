import { CERTAINTY_LABELS, STATUS_LABELS, TEACHER_VERIFICATION_DESCRIPTIONS, TEACHER_VERIFICATION_LABELS } from "../config.js";
import { circuitAnnotation } from "../../server/ai/annotation-policy.js";
import { getLesson } from "../data/lessons.js";
import { getCaptureTip } from "../data/capture-tips.js";
import { latestCriterionRechecks, reportProblems, reportSummary } from "../data/attempt-rechecks.js";
import { getLocalHint } from "../data/local-hints.js";
import { SAFETY_WARNING } from "../data/safety.js";
import { requestTutorHint } from "../services/api.js";
import { getAttemptImages } from "../services/session-images.js";
import { getAttemptImages as getArchivedImages } from "../services/attempt-archive.js";
import { cacheAttemptRechecks, cacheHint, getAttempt, getCachedHint, getPreviousAttempt, getStudent, restoreStudentAttempt, updateTeacherVerification, updateVerification } from "../services/storage.js";
import { fetchSharedAttempt, getBrowserSession, publishAttempt, publishAttemptUpdate, sharedAttemptImageUrl } from "../services/classroom.js";
import { createPhotoViewer } from "./photo-tools.js";
import { placeAnnotationBadges } from "./annotation-placement.js";
import { appShell, emptyState, escapeHtml, icon, renderPhotoReviews, showToast } from "./shared.js";
import { mountStudentTabs, renderStudentTabs } from "./student-tabs.js";
import { mountCriterionRechecks, renderCriterionRecheck } from "./criterion-recheck.js";

const statusIcons = { correct: "check", possible_error: "alert", uncertain: "help", not_visible: "help", not_applicable: "info" };
const annotationGroups = {
  short: "Nguy cơ chập mạch",
  power: "Nguồn và GND",
  polarity: "Chiều LED",
  resistor: "Điện trở",
  wiring: "Dây tín hiệu và kết nối",
  other: "Linh kiện và lỗi khác",
};
const groupBySafetyKind = {
  short_circuit: "short",
  power_polarity: "power",
  power_ground: "power",
  voltage: "power",
  led_polarity: "polarity",
  current_limiting: "resistor",
};

function annotationGroup(problem) {
  const kind = groupBySafetyKind[problem.safetyKind];
  if (typeof kind === "string") return kind;
  const id = problem.id || problem.criterionId || "";
  if (id === "no_short_circuit") return "short";
  if (id === "led_orientation") return "polarity";
  if (id.startsWith("resistor_")) return "resistor";
  if (/^(power_|ground_|battery_|(?:moisture_)?(?:vcc|gnd)_)/.test(id)) return "power";
  if (id.endsWith("_connection") || id === "switch_in_series") return "wiring";
  return "other";
}

function relatedPhotoIndex(problem, imageCount) {
  const annotation = circuitAnnotation(problem, imageCount);
  const fallback = problem.status === "possible_error" ? problem.imageIndex
    : problem.status === "uncertain" ? problem.ruleEvidence?.electrodesImageIndex : null;
  const index = annotation?.imageIndex ?? fallback;
  return Number.isInteger(index) && index >= 0 && index < imageCount ? index : null;
}

function collectAnnotationAreas(problems, imageCount) {
  const byLocation = new Map();
  for (const problem of problems) {
    const annotation = circuitAnnotation(problem, imageCount);
    if (!annotation) continue;
    const { imageIndex, kind, region } = annotation;
    const { x, y, width, height } = region;
    const group = annotationGroup(problem);
    const key = [imageIndex, kind, group, x, y, width, height].join(":");
    if (!byLocation.has(key)) byLocation.set(key, { ...annotation, number: byLocation.size + 1, group, problems: [] });
    byLocation.get(key).problems.push(problem);
  }
  return [...byLocation.values()];
}

function renderAnnotationRegion({ number, group, problems, kind, region }, interactive = true) {
  const { x, y, width, height } = region;
  const tag = interactive ? "button" : "span";
  const label = `${kind === "review" ? "Vùng cần xem lại" : "Vùng có dấu hiệu lỗi"} ${number} · ${problems.map(item => item.label).join(", ")}`;
  const attributes = interactive ? `type="button" data-annotation="${number}" aria-label="${escapeHtml(label)}"` : 'aria-hidden="true"';
  return `<${tag} class="annotation-box" ${attributes} data-annotation-group="${group}" data-annotation-kind="${kind}" data-region-number="${number}"
    style="left:${x}%;top:${y}%;width:${width}%;height:${height}%">
    <span class="annotation-pointer" aria-hidden="true"><span class="annotation-arrow"></span><span class="annotation-number">${number}</span></span>
  </${tag}>`;
}

function renderAnnotationNotes(areas, imageIndex) {
  if (!areas.length) return "";
  return `<ul class="annotation-notes" aria-label="Chú thích ảnh ${imageIndex + 1}">
    ${areas.map(({ number, group, problems, kind }) => `<li>
      <button class="annotation-note" type="button" data-annotation-note="${number}" data-annotation-group="${group}">
        <span class="annotation-note-number">${number}</span>
        <span class="annotation-note-details">${problems.map(problem =>
          `<span><strong>${kind === "review" ? "Vùng cần xem lại · " : ""}${escapeHtml(problem.label)}</strong>${problem.evidence ? `<span>${escapeHtml(problem.evidence)}</span>` : ""}</span>`
        ).join("")}</span>
      </button></li>`).join("")}
  </ul>`;
}

function renderAnnotationGallery(images, areas) {
  if (!images.length) {
    return `<section class="annotation-panel annotation-empty"><div><p class="eyebrow">ẢNH MẠCH</p><h2>Ảnh không còn trên thiết bị này</h2><p>Em vẫn có thể xem nhận xét của AI và giáo viên về lượt kiểm tra này.</p></div></section>`;
  }
  const groups = [...new Set(areas.map(area => area.group))];
  const guide = [areas.some(area => area.kind === "error") ? "Nét liền chỉ vùng có dấu hiệu lỗi." : "",
    areas.some(area => area.kind === "review") ? "Nét đứt chỉ vùng cần xem lại." : ""].filter(Boolean).join(" ");
  return `<section class="annotation-panel">
    <div class="annotation-head"><div><p class="eyebrow">VỊ TRÍ CẦN KIỂM TRA</p><h2>Đánh dấu trên ảnh mạch gốc</h2><p>${areas.length ? guide : "Chưa có vị trí đủ rõ để đánh dấu trên ảnh."}</p></div>${areas.length ? `<button id="toggle-annotations" class="btn btn-ghost" type="button" aria-pressed="true">Ẩn đánh dấu</button>` : ""}</div>
    ${groups.length ? `<ul class="annotation-key" aria-label="Màu nhóm lỗi">${groups.map(group => `<li data-annotation-group="${group}">${annotationGroups[group]}</li>`).join("")}</ul>` : ""}
    <div class="annotation-gallery">${images.map(image => {
      const photoAreas = areas.filter(area => area.imageIndex === image.index);
      return `<figure class="annotated-figure" data-image="${image.index}">
      <div class="annotation-stage"><button class="annotation-photo-button" type="button" data-student-photo="${image.index}" aria-label="Phóng to ảnh mạch ${image.index + 1}"><img src="${escapeHtml(image.url)}" alt="Ảnh mạch học sinh ${image.index + 1}" /></button>
        ${photoAreas.map(area => renderAnnotationRegion(area)).join("")}
      </div><figcaption>Ảnh ${image.index + 1}${renderAnnotationNotes(photoAreas, image.index)}</figcaption>
    </figure>`;
    }).join("")}</div>
  </section>`;
}

function getVerdict(attempt) {
  const lesson = getLesson(attempt.lessonId);
  const ids = attempt.problems.map((problem) => problem.id || problem.criterionId);
  const expectedIds = lesson?.checks.map(([id]) => id) || [];
  const complete = expectedIds.length > 0 && expectedIds.every((id) => ids.filter((candidate) => candidate === id).length === 1);
  const safetyChecks = attempt.problems.filter((problem) => problem.category === "safety");
  const allSafetyPassed = safetyChecks.length > 0 && safetyChecks.every((problem) => problem.status === "correct");
  const allChecksPassed = attempt.problems.every((problem) => problem.status === "correct" || problem.status === "not_applicable");
  const safeVisualVerdict = attempt.analysisStatus === "ok" && complete && allSafetyPassed && allChecksPassed;
  return safeVisualVerdict && attempt.verdict === "pass" ? "pass" : safeVisualVerdict && !attempt.verdict ? "pass" : "review";
}

function renderSafetyGate(attempt, currentProblems = attempt.problems) {
  const verdict = getVerdict(attempt);
  const safetyCheck = attempt.teacherPhysicallyChecked ? attempt.teacherSafetyCheck : "not_checked";
  const checkedBy = attempt.teacherSafetyCheckedBy ? ` · ${escapeHtml(attempt.teacherSafetyCheckedBy)}` : "";
  const checkedAt = attempt.teacherSafetyCheckedAt ? ` · ${new Date(attempt.teacherSafetyCheckedAt).toLocaleString("vi-VN")}` : "";
  const teacherSafetyStatus = safetyCheck === "safe_to_power"
    ? `<p class="teacher-safety-status is-safe"><strong>Giáo viên đã kiểm tra trực tiếp và cho phép cấp nguồn${checkedBy}${checkedAt}.</strong> Hãy làm theo hướng dẫn trực tiếp của giáo viên; AI không cấp phép.</p>`
    : safetyCheck === "unsafe"
      ? `<p class="teacher-safety-status is-unsafe"><strong>Giáo viên đã phát hiện nguy cơ${checkedBy}${checkedAt}. Không cấp nguồn.</strong> ${escapeHtml(attempt.teacherSafetyNote || "")}</p>`
      : safetyCheck === "uncertain"
        ? `<p class="teacher-safety-status is-pending"><strong>Giáo viên chưa thể xác nhận an toàn${checkedBy}${checkedAt}. Chưa cấp nguồn.</strong> ${escapeHtml(attempt.teacherSafetyNote || "")}</p>`
        : `<p id="teacher-safety-pending" class="teacher-safety-status is-pending"><strong>Chưa có xác nhận kiểm tra mạch thật của giáo viên. Giữ nguồn ngắt.</strong></p>`;
  const powerInstruction = safetyCheck === "safe_to_power"
    ? "Giáo viên đã ghi nhận việc kiểm tra trực tiếp. Hãy làm theo chỉ dẫn của giáo viên; AI không cấp phép."
    : safetyCheck === "unsafe"
      ? "Giáo viên đã phát hiện nguy cơ. Không cấp nguồn."
      : safetyCheck === "uncertain"
        ? "Chưa thể xác nhận an toàn. Giữ nguồn ở trạng thái ngắt."
        : "Giữ nguồn ở trạng thái ngắt cho đến khi giáo viên kiểm tra trực tiếp mạch thật.";
  if (verdict === "pass") {
    return `<section class="safety-gate safety-pass" role="status">
      <div class="safety-gate-icon">${icon("check", 25)}</div>
      <div><p class="eyebrow">AI: CÁC TIÊU CHÍ NHÌN THẤY ĐỀU ĐẠT</p><h2>Kết quả ảnh không phải xác nhận an toàn</h2><p class="safety-warning">${escapeHtml(SAFETY_WARNING)}</p>
      <p><strong>${powerInstruction}</strong> Kết quả AI hoặc phản hồi của học sinh không thay thế bước kiểm tra của giáo viên.</p>${teacherSafetyStatus}</div>
    </section>`;
  }
  const missingIds = attempt.safety?.missingIds || [];
  const lesson = getLesson(attempt.lessonId);
  const incompleteIds = [...missingIds, ...(attempt.safety?.duplicateIds || [])];
  const incompleteLabels = [...new Set(incompleteIds)].map((id) => lesson?.checks.find(([checkId]) => checkId === id)?.[1] || id);
  const unknownLabels = [...currentProblems.filter((problem) => problem.category === "safety" && ["uncertain", "not_visible"].includes(problem.status)).map((problem) => problem.label), ...incompleteLabels];
  const failedLabels = currentProblems.filter((problem) => problem.category === "safety" && problem.status !== "correct" && !["uncertain", "not_visible"].includes(problem.status)).map((problem) => problem.label);
  const detail = failedLabels.length
    ? `Cần sửa hoặc kiểm tra: ${failedLabels.join(", ")}.`
    : unknownLabels.length
      ? `Chưa đủ bằng chứng cho tiêu chí: ${unknownLabels.join(", ")}.`
      : "Ảnh chưa cho thấy đủ bằng chứng để đánh giá an toàn.";
  const reviewHeading = safetyCheck === "safe_to_power" ? "AI yêu cầu kiểm tra thêm; giáo viên đã ghi nhận quyết định riêng" : "Chưa được cấp nguồn";
  return `<section class="safety-gate safety-review" role="alert"><div class="safety-gate-icon">${icon("alert", 25)}</div><div><p class="eyebrow">CỔNG AN TOÀN · CẦN KIỂM TRA</p><h2>${reviewHeading}</h2><p>${escapeHtml(detail)}</p><p><strong>${powerInstruction}</strong></p>${teacherSafetyStatus}</div></section>`;
}

function progressMessage(attempt, previous) {
  if (!previous) return "";
  const fixed = previous.problems.filter((problem) => problem.status === "possible_error" && attempt.problems.find((current) => current.id === problem.id)?.status === "correct");
  if (!fixed.length) return "";
  return `<section class="success-banner">${icon("spark", 24)}<div><strong>Tuyệt vời! Có tiến bộ sau lần sửa.</strong><p>${fixed.map((item) => escapeHtml(item.label)).join(", ")} không còn được phát hiện là vấn đề trong lần kiểm tra mới.</p></div></section>`;
}

function teacherFeedbackMarkup(attempt) {
  if (!attempt?.teacherComment) return "";
  const savedAt = attempt.teacherCommentAt ? new Date(attempt.teacherCommentAt).toLocaleString("vi-VN", { hour: "2-digit", minute: "2-digit", day: "2-digit", month: "2-digit" }) : "";
  return `<section class="teacher-feedback-card" role="status"><div class="teacher-feedback-icon">${icon("teacher", 26)}</div><div><p class="eyebrow">NHẬN XÉT CỦA GIÁO VIÊN</p><blockquote>${escapeHtml(attempt.teacherComment)}</blockquote>${savedAt ? `<small>Cập nhật ${savedAt}</small>` : ""}</div></section>`;
}

function teacherVerificationMarkup(attempt) {
  const verification = attempt?.teacherVerification;
  const savedAt = attempt?.teacherVerifiedAt ? new Date(attempt.teacherVerifiedAt).toLocaleString("vi-VN", { hour: "2-digit", minute: "2-digit", day: "2-digit", month: "2-digit" }) : "";
  if (!verification) {
    return `<section class="teacher-verification-card is-pending" role="status"><div class="teacher-verification-icon">${icon("lock", 26)}</div><div><p class="eyebrow">XÁC NHẬN CỦA GIÁO VIÊN</p><h2>Chờ giáo viên xác nhận</h2><p>Giáo viên có thể xác nhận kết quả AI và ghi nhãn riêng cho từng tiêu chí.</p></div></section>`;
  }
  const note = attempt.teacherVerificationNote ? `<blockquote>${escapeHtml(attempt.teacherVerificationNote)}</blockquote>` : "";
  const meta = [attempt.teacherVerifiedBy ? `Xác nhận bởi ${escapeHtml(attempt.teacherVerifiedBy)}` : "", savedAt ? `lúc ${savedAt}` : ""].filter(Boolean).join(" · ");
  const folderLink = verification === "correct" && attempt.verdict === "pass" && attempt.teacherSafetyCheck === "safe_to_power" && attempt.teacherPhysicallyChecked
    ? `<a class="text-button" href="#/references/${attempt.lessonId}">Mở kho tham chiếu của bài</a>`
    : "";
  return `<section class="teacher-verification-card is-${verification}" role="status"><div class="teacher-verification-icon">${icon(verification === "correct" ? "check" : "alert", 26)}</div><div><p class="eyebrow">GIÁO VIÊN ĐÃ XÁC NHẬN</p><h2>${escapeHtml(TEACHER_VERIFICATION_LABELS[verification] || "Đã xác nhận")}</h2><p>${escapeHtml(TEACHER_VERIFICATION_DESCRIPTIONS[verification] || "")}</p>${note}${folderLink ? `<p class="teacher-verification-folder-link">${folderLink}</p>` : ""}${meta ? `<small>${meta}</small>` : ""}</div></section>`;
}

function resultCounts(problems) {
  return problems.reduce((counts, item) => {
    const status = item.ruleEvidence?.physicalCheckRequired ? "physical_check" : item.status;
    counts[status] = (counts[status] || 0) + 1;
    return counts;
  }, {});
}

function renderResultMetrics(counts) {
  return `<span class="metric good"><b>${counts.correct || 0}</b> Đúng</span><span class="metric warn"><b>${counts.possible_error || 0}</b> Cần kiểm tra</span><span class="metric neutral"><b>${(counts.uncertain || 0) + (counts.not_visible || 0)}</b> Chưa xác định</span>${counts.physical_check ? `<span class="metric neutral"><b>${counts.physical_check}</b> Cần kiểm tra trực tiếp</span>` : ""}`;
}

export async function renderResult(root, attemptId, isCurrent = () => true) {
  let attempt = getAttempt(attemptId);
  let restored;
  const student = getStudent();
  if (!attempt && attemptId && student?.classCode && getBrowserSession()?.role === "student") {
    const shared = await fetchSharedAttempt(attemptId, student.classCode).catch(() => null);
    if (!isCurrent()) return;
    attempt = restored = restoreStudentAttempt(shared);
  }
  if (!attempt) {
    root.innerHTML = appShell(emptyState("Không tìm thấy kết quả", "Kết quả có thể đã bị xóa khỏi thiết bị này.", '<a class="btn btn-primary" href="#/lessons">Chọn bài học</a>'));
    return;
  }
  const lesson = getLesson(attempt.lessonId);
  const memoryImages = getAttemptImages(attempt.id);
  const archivedImages = memoryImages.length ? [] : await getArchivedImages(attempt.id).catch(() => []);
  const sharedImages = !memoryImages.length && !archivedImages.length && attempt.classCode
    ? restored || await fetchSharedAttempt(attempt.id, attempt.classCode).catch(() => null) : null;
  const remoteImages = Array.from({ length: Math.min(3, Number(sharedImages?.imageCount) || 0) }, (_, index) => ({
    index, url: sharedAttemptImageUrl(attempt.id, attempt.classCode, index),
  }));
  let badgeObserver;
  let disposeRechecks;
  const dispose = () => {
    disposeRechecks?.();
    badgeObserver?.disconnect();
    archivedImages.forEach(({ url }) => URL.revokeObjectURL(url));
  };
  if (!isCurrent()) { dispose(); return; }
  const sessionImages = memoryImages.length ? memoryImages : archivedImages.length ? archivedImages : remoteImages;
  const areas = collectAnnotationAreas(attempt.problems, sessionImages.length);
  const annotationNumbers = new Map(areas.flatMap(area => area.problems.map(problem => [problem.id, area.number])));
  const previous = getPreviousAttempt(attempt);
  const limited = attempt.analysisStatus === "insufficient_image";
  const directEvidence = ["direct_only", "single_read"].includes(attempt.evidencePolicy);
  const canRecheck = !attempt.demo && Boolean(attempt.classCode) && getBrowserSession()?.role === "student";
  let currentProblems = reportProblems(attempt);
  let safetyAttempt = attempt;
  const counts = resultCounts(currentProblems);
  const { approvedExamples = 0, reviewReminders = 0, recheckedCriteria, pinLayoutChecks, markedReferences, markedViews } = attempt.analysisContext || {};
  const reviewInputs = [
    Number.isInteger(reviewReminders) && reviewReminders > 0 ? `${reviewReminders} điểm cần kiểm tra từ phản hồi của giáo viên` : "",
    Number.isInteger(approvedExamples) && approvedExamples > 0
      ? `${approvedExamples} ảnh tham chiếu đã duyệt${markedReferences ? ` (${markedReferences} ảnh có vùng giáo viên khoanh)` : ""}` : "",
  ].filter(Boolean).join(" và ");
  const advice = (attempt.captureAdvice || []).map(item => `<li>${escapeHtml(item)}</li>`).join("");
  const cards = attempt.problems.map((problem) => {
    const photoIndex = relatedPhotoIndex(problem, sessionImages.length);
    const unresolved = ["uncertain", "not_visible"].includes(problem.status);
    const physicalCheck = problem.ruleEvidence?.physicalCheckRequired;
    const needsReview = ["possible_error", "uncertain", "not_visible"].includes(problem.status);
    const recheck = canRecheck && needsReview && !physicalCheck;
    const number = annotationNumbers.get(problem.id);
    const group = annotationGroup(problem);
    return `
    <article class="check-card status-${problem.status} ${number ? "has-annotation" : ""}" data-problem="${escapeHtml(problem.id)}" ${problem.status === "possible_error" ? `data-annotation-group="${group}"` : ""} tabindex="0">
      <div class="check-status-icon">${icon(statusIcons[problem.status], 22)}</div>
      <div class="check-content">
        <div class="check-title"><div><small ${recheck ? 'data-original-check-status' : ""}>${physicalCheck ? "Cần kiểm tra trực tiếp" : STATUS_LABELS[problem.status]} · ${problem.category === "safety" ? "AN TOÀN QUAN TRỌNG" : "THÔNG THƯỜNG"}</small><h2>${escapeHtml(problem.label)}</h2>
          ${recheck ? '<strong class="criterion-recheck-badge" data-recheck-badge hidden></strong>' : ""}</div>
          ${directEvidence ? (problem.ruleEvidence?.visualProof?.length ? '<span class="certainty">Đã đối chiếu bằng chứng</span>' : "")
            : `<span class="certainty">Mức chắc chắn: <b>${Number.isFinite(problem.confidence) ? `${Math.round(problem.confidence * 100)}%` : CERTAINTY_LABELS[problem.certainty]}</b></span>`}
        </div>
        ${problem.status === "possible_error" ? `<p class="annotation-group-label">${number ? `<b>Vùng ${number}</b> · ` : ""}${annotationGroups[group]}</p>` : ""}
        <div class="evidence"><span>${recheck ? "AI quan sát từ ảnh ban đầu" : "AI quan sát"}</span><p>${escapeHtml(problem.evidence)}</p>${photoIndex !== null
          ? `<button class="text-button evidence-photo-link" type="button" data-check-photo="${escapeHtml(problem.id)}">${number ? "Xem vùng trên ảnh" : "Xem ảnh liên quan"} ${photoIndex + 1}</button>`
          : ""}${problem.regionRefinement?.outcome === "refined" ? "<p class=\"muted\">Vùng khoanh đã được AI kiểm tra cận cảnh.</p>" : ""}
          ${problem.regionRefinement?.outcome === "photo_only" ? "<p class=\"muted\">Ảnh liên quan có thể xem lại. AI chưa định vị được bằng chứng khi kiểm tra cận cảnh.</p>" : ""}</div>
        ${renderPhotoReviews(problem.photoReviews, unresolved)}
        ${unresolved && !physicalCheck ? `<p class="capture-tip"><strong>Gợi ý góc chụp bổ sung</strong> ${escapeHtml(getCaptureTip(problem.id || problem.criterionId, attempt.lessonId, {
          electrodesSeen: Number.isInteger(problem.ruleEvidence?.electrodesImageIndex),
        }))}</p>` : ""}
        ${recheck ? renderCriterionRecheck(problem) : ""}
        ${needsReview ? `<div class="hint-area"><button class="btn btn-hint" type="button" data-hint="${problem.id}" data-level="1">${icon("spark", 17)} Nhận gợi ý</button><div class="hint-output" data-output="${problem.id}" hidden></div></div>` : ""}
      </div>
    </article>`;
  }).join("");
  root.innerHTML = appShell(`
    <section class="result-wrap">
      <div class="breadcrumb"><a href="#/lessons">Bài học</a><span>/</span><a href="#/analyzer/${attempt.lessonId}">${escapeHtml(lesson.title)}</a><span>/</span><strong>Kết quả</strong></div>
      ${attempt.demo ? `<div class="demo-banner"><b>DEMO MODE</b><span>Đây là kết quả mô phỏng để trình diễn luồng sản phẩm, không phải phân tích OpenAI.</span></div>` : ""}
      <header class="result-hero"><div><p class="eyebrow">${limited ? "NHẬN XÉT SƠ BỘ" : "KẾT QUẢ PHÂN TÍCH"}</p><h1>${escapeHtml(lesson.title)}</h1><p data-current-result-summary>${escapeHtml(reportSummary(attempt, currentProblems))}</p></div>${limited ? "" : `<div class="result-score"><strong>${attempt.problems.length}</strong><span>tiêu chí<br>đã kiểm tra</span></div>`}</header>
      <div id="safety-gate-slot">${renderSafetyGate(attempt, currentProblems)}</div>
      ${renderStudentTabs("Nội dung kết quả", [["student-summary", "Tóm tắt"], ["student-feedback", "Phản hồi"]])}
      <section class="student-task-panel" id="student-summary" role="tabpanel" aria-labelledby="student-summary-tab" tabindex="0">
        <div class="result-metrics" data-current-result-metrics>${renderResultMetrics(counts)}</div>
        ${attempt.analysisModel && !attempt.demo ? `<p class="classroom-sync-note">Model phân tích <strong>${escapeHtml(attempt.analysisModel)}</strong></p>` : ""}
        ${attempt.evidencePolicy === "single_read"
          ? '<p class="classroom-sync-note">AI đọc tất cả góc ảnh trong một lượt. Hệ thống kiểm tra bằng chứng trước khi chấm từng tiêu chí.</p>'
          : directEvidence ? '<p class="classroom-sync-note">AI chỉ kết luận khi hai lượt đọc cùng chỉ ra bằng chứng trên ảnh của em.</p>' : ""}
        ${limited ? "" : progressMessage(attempt, previous)}
        ${attempt.classCode ? '<div id="classroom-image-sync" class="classroom-sync-note">Đang kiểm tra ảnh đã gửi cho giáo viên…</div>' : ""}
        ${(limited || counts.uncertain || counts.not_visible) && advice ? `<details class="capture-tip"><summary>Gợi ý nếu muốn gửi thêm ảnh</summary><ul>${advice}</ul></details>` : ""}
        ${reviewInputs ? `<p class="classroom-sync-note">Lượt phân tích đã dùng ${reviewInputs}.</p>` : ""}
        ${Number.isInteger(markedViews) && markedViews > 0
          ? `<p class="classroom-sync-note">Đã đưa vùng giáo viên khoanh trên ${markedViews} ảnh của lượt này vào đối chiếu.</p>` : ""}
        ${Number.isInteger(recheckedCriteria) ? `<p class="classroom-sync-note">${recheckedCriteria
          ? `AI đã đọc lại độc lập ${recheckedCriteria} tiêu chí từng nhận diện sai trên ảnh của lượt này.`
          : "Lượt đọc lại các tiêu chí từng nhận diện sai chưa hoàn tất."}</p>` : ""}
        ${Number.isInteger(pinLayoutChecks) && pinLayoutChecks > 0
          ? `<p class="classroom-sync-note">Đã đối chiếu lỗ cắm của ${pinLayoutChecks} tiêu chí theo sơ đồ chân Arduino Uno.</p>` : ""}
        ${renderAnnotationGallery(sessionImages, areas)}
        <section class="check-list" aria-label="Kết quả từng tiêu chí">${cards || '<p class="muted">Ảnh hiện chưa cho thấy đủ chi tiết để nhận xét từng tiêu chí.</p>'}</section>
        <div class="result-actions"><a class="btn ${limited ? "btn-secondary" : "btn-primary btn-large"}" href="#/analyzer/${attempt.lessonId}">${icon("camera", 18)} Phân tích lại toàn bộ mạch</a><a class="btn btn-secondary" href="#/history">Xem lịch sử</a></div>
      </section>
      <section class="student-task-panel" id="student-feedback" role="tabpanel" aria-labelledby="student-feedback-tab" tabindex="0" hidden>
        <div id="teacher-feedback-slot">${teacherFeedbackMarkup(attempt)}</div>
        <div id="teacher-verification-slot">${teacherVerificationMarkup(attempt)}</div>
        <section class="verification-panel">
          <div><h2>Nhóm thấy AI nhận xét thế nào?</h2></div>
          <div class="verification-actions">
            <button class="verify-btn ${attempt.verification === "correct" ? "selected" : ""}" data-verify="correct">AI đúng</button>
            <button class="verify-btn ${attempt.verification === "incorrect" ? "selected" : ""}" data-verify="incorrect">AI sai</button>
            <button class="verify-btn ${attempt.verification === "uncertain" ? "selected" : ""}" data-verify="uncertain">Không chắc</button>
          </div>
        </section>
      </section>
    </section>
  `, "lessons");

  mountStudentTabs(root);
  const metrics = root.querySelector("[data-current-result-metrics]");
  const summary = root.querySelector("[data-current-result-summary]");
  const safetySlot = root.querySelector("#safety-gate-slot");
  disposeRechecks = mountCriterionRechecks(root, attempt, entries => {
    currentProblems = reportProblems(attempt, entries);
    metrics.innerHTML = renderResultMetrics(resultCounts(currentProblems));
    summary.textContent = reportSummary(attempt, currentProblems);
    safetySlot.innerHTML = renderSafetyGate(safetyAttempt, currentProblems);
    try { cacheAttemptRechecks(attempt.id, [...latestCriterionRechecks(entries).values()]); } catch { /* The server has already saved the result. */ }
  });
  const areasByStage = new WeakMap();
  function positionBadges(stage) {
    const placements = placeAnnotationBadges(areasByStage.get(stage), stage.clientWidth, stage.clientHeight);
    for (const box of stage.querySelectorAll("[data-region-number]")) {
      const side = placements.get(Number(box.dataset.regionNumber));
      if (side) box.dataset.badgeSide = side;
      else delete box.dataset.badgeSide;
    }
  }
  if (areas.length) {
    badgeObserver = new ResizeObserver(entries => {
      for (const { target } of entries) positionBadges(target);
    });
    for (const figure of root.querySelectorAll(".annotated-figure")) {
      const stage = figure.querySelector(".annotation-stage");
      const photoAreas = areas.filter(area => area.imageIndex === Number(figure.dataset.image));
      if (!photoAreas.length) continue;
      areasByStage.set(stage, photoAreas);
      badgeObserver.observe(stage);
    }
  }
  const toggle = root.querySelector("#toggle-annotations");
  toggle?.addEventListener("click", () => {
    const hidden = root.querySelector(".annotation-panel").classList.toggle("annotations-hidden");
    toggle.textContent = hidden ? "Hiện đánh dấu" : "Ẩn đánh dấu";
    toggle.setAttribute("aria-pressed", String(!hidden));
  });
  const photoButtons = root.querySelectorAll("[data-student-photo]");
  if (photoButtons.length) {
    const viewer = createPhotoViewer({
      renderOverlay(layer, visibleAreas) {
        layer.innerHTML = visibleAreas.map(area => renderAnnotationRegion(area, false)).join("");
        areasByStage.set(layer, visibleAreas);
        badgeObserver?.observe(layer);
        positionBadges(layer);
      },
    });
    viewer.element.classList.add("annotation-viewer");
    root.firstElementChild.append(viewer.element);
    function openPhoto(button, selected) {
      const image = button.querySelector("img");
      const imageIndex = Number(button.dataset.studentPhoto);
      const showAll = toggle?.getAttribute("aria-pressed") === "true";
      const markers = areas.filter(area => area.imageIndex === imageIndex && (selected ? area.problems.includes(selected) : showAll));
      const caption = markers.flatMap(area => (selected ? [selected] : area.problems).map(problem =>
        `${area.number}. ${problem.label}${problem.evidence ? ` — ${problem.evidence}` : ""}`
      )).join("\n") || selected?.evidence || "";
      viewer.open(image.src, image.alt, markers, caption);
    }
    for (const button of photoButtons) button.addEventListener("click", () => openPhoto(button));
    root.querySelectorAll("[data-check-photo]").forEach(button => button.addEventListener("click", () => {
      const problem = attempt.problems.find(item => item.id === button.dataset.checkPhoto);
      const index = problem ? relatedPhotoIndex(problem, sessionImages.length) : null;
      const photo = Array.from(photoButtons).find(item => Number(item.dataset.studentPhoto) === index);
      if (photo) openPhoto(photo, problem);
    }));
  }

  function highlightAnnotation(number, scrollToPhoto = true) {
    const target = root.querySelector(`[data-annotation="${number}"]`);
    if (!target) return;
    root.querySelector(".annotation-panel")?.classList.remove("annotations-hidden");
    if (toggle) { toggle.textContent = "Ẩn đánh dấu"; toggle.setAttribute("aria-pressed", "true"); }
    root.querySelectorAll("[data-annotation]").forEach((item) => item.classList.toggle("active", item === target));
    root.querySelectorAll("[data-annotation-note]").forEach(item => {
      item.classList.toggle("active", Number(item.dataset.annotationNote) === number);
    });
    root.querySelectorAll(".check-card").forEach((item) => item.classList.toggle("annotation-selected", annotationNumbers.get(item.dataset.problem) === number));
    if (scrollToPhoto) target.closest(".annotated-figure")?.scrollIntoView({ behavior: "smooth", block: "center" });
  }

  root.querySelectorAll(".check-card.has-annotation").forEach((card) => {
    const number = annotationNumbers.get(card.dataset.problem);
    card.addEventListener("click", (event) => { if (!event.target.closest("button, details, .criterion-recheck")) highlightAnnotation(number); });
    card.addEventListener("keydown", (event) => { if (event.target === card && ["Enter", " "].includes(event.key)) { event.preventDefault(); highlightAnnotation(number); } });
  });
  root.querySelectorAll("[data-annotation]").forEach((marker) => marker.addEventListener("click", () => {
    highlightAnnotation(Number(marker.dataset.annotation), false);
    const note = root.querySelector(`[data-annotation-note="${marker.dataset.annotation}"]`);
    note?.focus({ preventScroll: true });
    note?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }));
  root.querySelectorAll("[data-annotation-note]").forEach(note => note.addEventListener("click", () => {
    highlightAnnotation(Number(note.dataset.annotationNote));
  }));

  root.querySelectorAll("[data-hint]").forEach((button) => button.addEventListener("click", async () => {
    const problem = attempt.problems.find((item) => item.id === button.dataset.hint);
    const output = root.querySelector(`[data-output="${problem.id}"]`);
    const level = Number(button.dataset.level);
    const cacheKey = `${attempt.id}:${problem.id}:${level}`;
    button.disabled = true;
    button.textContent = "Đang chuẩn bị gợi ý…";
    try {
      let hint = getCachedHint(cacheKey);
      if (!hint) {
        try {
          hint = await requestTutorHint({ lessonId: attempt.lessonId, problem: { id: problem.id, status: problem.status, certainty: problem.certainty, evidence: problem.evidence }, studentContext: { previousCount: previous ? 1 : 0, hintLevel: level } }, attempt.demo);
        } catch {
          hint = getLocalHint(problem, level);
        }
        cacheHint(cacheKey, hint);
      }
      output.hidden = false;
      output.innerHTML = `<small>GỢI Ý CẤP ${level}</small><h3>${escapeHtml(hint.title)}</h3><p>${escapeHtml(hint.hint)}</p><blockquote>${escapeHtml(hint.question)}</blockquote>${level < 3 ? `<button class="text-button next-hint" type="button">Cần thêm gợi ý →</button>` : ""}`;
      const number = annotationNumbers.get(problem.id);
      if (number) highlightAnnotation(number);
      const next = output.querySelector(".next-hint");
      if (next) next.addEventListener("click", () => { button.dataset.level = String(level + 1); button.click(); });
      button.hidden = true;
    } finally { button.disabled = false; }
  }));

  root.querySelectorAll("[data-verify]").forEach((button) => button.addEventListener("click", async () => {
    const buttons = root.querySelectorAll("[data-verify]");
    buttons.forEach(item => { item.disabled = true; });
    try {
      if (attempt.classCode) {
        const saved = await publishAttemptUpdate(attempt.id, attempt.classCode, { verification: button.dataset.verify });
        if (!saved.synced) throw new Error("Máy chủ chưa xác nhận lưu.");
      }
      updateVerification(attempt.id, button.dataset.verify);
      buttons.forEach(item => item.classList.toggle("selected", item === button));
      showToast(attempt.classCode ? "Đã đồng bộ phản hồi của nhóm." : "Đã lưu phản hồi trên thiết bị.", "success");
    } catch (error) { showToast(error.message, "error"); }
    finally { buttons.forEach(item => { item.disabled = false; }); }
  }));

  if (attempt.classCode) {
    const view = root.firstElementChild;
    const feedback = restored || sharedImages ? Promise.resolve(restored || sharedImages) : fetchSharedAttempt(attempt.id, attempt.classCode);
    feedback.then(async (sharedAttempt) => {
      if (!view.isConnected) return;
      const slot = root.querySelector("#teacher-feedback-slot");
      if (slot) slot.innerHTML = teacherFeedbackMarkup(sharedAttempt);
      const verificationSlot = root.querySelector("#teacher-verification-slot");
      if (verificationSlot) verificationSlot.innerHTML = teacherVerificationMarkup(sharedAttempt);
      safetyAttempt = { ...attempt, ...sharedAttempt };
      safetySlot.innerHTML = renderSafetyGate(safetyAttempt, currentProblems);
      if (sharedAttempt?.teacherVerification || sharedAttempt?.teacherSafetyCheck) {
        updateTeacherVerification(attempt.id, {
          teacherVerification: sharedAttempt.teacherVerification,
          teacherVerificationNote: sharedAttempt.teacherVerificationNote,
          teacherVerifiedBy: sharedAttempt.teacherVerifiedBy,
          teacherVerifiedAt: sharedAttempt.teacherVerifiedAt,
          teacherStatus: sharedAttempt.teacherStatus,
          teacherSafetyCheck: sharedAttempt.teacherSafetyCheck,
          teacherSafetyNote: sharedAttempt.teacherSafetyNote,
          teacherSafetyCheckedBy: sharedAttempt.teacherSafetyCheckedBy,
          teacherSafetyCheckedAt: sharedAttempt.teacherSafetyCheckedAt,
        });
      }
      const syncNote = root.querySelector("#classroom-image-sync");
      if (Number(sharedAttempt?.imageCount) > 0) {
        if (syncNote) { syncNote.className = "classroom-sync-note success"; syncNote.textContent = `Giáo viên có thể xem ${sharedAttempt.imageCount} ảnh của lượt kiểm tra này.`; }
        return;
      }
      showSyncRetry();
    }).catch(showSyncRetry);
  }

  function showSyncRetry() {
    const note = root.querySelector("#classroom-image-sync");
    if (!note || location.hash !== "#/result/" + attempt.id) return;
    note.className = "classroom-sync-note warning";
    note.textContent = "Chưa xác nhận đồng bộ đủ kết quả và ảnh. ";
    const retry = document.createElement("button");
    retry.type = "button";
    retry.textContent = "Thử đồng bộ lại";
    note.append(retry);
    retry.addEventListener("click", async () => {
      retry.disabled = true;
      try {
        let files = sessionImages.map(image => image.file).filter(Boolean);
        if (!files.length) {
          const archived = await getArchivedImages(attempt.id);
          files = archived.map(image => {
            URL.revokeObjectURL(image.url);
            return new File([image.blob], "circuit-image", { type: image.blob.type });
          });
        }
        const saved = await publishAttempt(attempt, files);
        if (!saved.synced || !saved.imagesSynced) throw new Error(saved.imageError || "Chưa đồng bộ được.");
        note.className = "classroom-sync-note success";
        note.textContent = `Đã đồng bộ kết quả và ${saved.imageCount} ảnh.`;
      } catch (error) { showToast(error.message, "error"); }
      finally { retry.disabled = false; }
    });
  }
  return dispose;
}
