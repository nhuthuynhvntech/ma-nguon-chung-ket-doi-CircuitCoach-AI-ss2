import { getStudent } from "../services/storage.js";
import { getBrowserSession, getTeacherClassCode } from "../services/classroom.js";
import { SAFETY_WARNING } from "../data/safety.js";
import { SESSION_ROLES } from "../data/session-roles.js";
import { themeSwitchLabel } from "../services/theme.js";

export function escapeHtml(value = "") {
  return String(value).replace(/[&<>'"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[character]);
}

const photoAssessmentLabels = {
  supports: "Có bằng chứng",
  context: "Giúp định hướng",
  unclear: "Chưa rõ",
  not_visible: "Không thấy chi tiết",
  conflicting: "Mâu thuẫn",
};

export function renderPhotoReviews(reviews, expanded = false) {
  if (!Array.isArray(reviews)) return "";
  const items = reviews.slice(0, 3).filter(review => Number.isInteger(review?.imageIndex) && review.imageIndex >= 0
    && review.imageIndex < 3 && Object.hasOwn(photoAssessmentLabels, review.assessment) && typeof review.detail === "string");
  if (!items.length) return "";
  return `<details class="photo-reviews"${expanded ? " open" : ""}>
    <summary>${items.length > 1 ? "Đối chiếu từng góc chụp" : "Nhận xét theo ảnh"}</summary>
    <ul>${items.map(({ imageIndex, assessment, detail }) =>
      `<li><b>Ảnh ${imageIndex + 1} · ${photoAssessmentLabels[assessment]}</b> ${escapeHtml(detail)}</li>`).join("")}</ul>
  </details>`;
}

export function icon(name, size = 20) {
  const paths = {
    zap: '<path d="m13 2-9 12h7l-1 8 9-12h-7z"/>',
    home: '<path d="m3 11 9-8 9 8v9a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
    book: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V3H6.5A2.5 2.5 0 0 0 4 5.5z"/><path d="M4 5.5v14"/>',
    history: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5M12 7v5l3 2"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>',
    camera: '<path d="M14.5 4 16 7h4a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h4l1.5-3z"/><circle cx="12" cy="13" r="4"/>',
    upload: '<path d="M12 16V4m0 0L7 9m5-5 5 5"/><path d="M4 15v5h16v-5"/>',
    arrow: '<path d="M5 12h14m-5-5 5 5-5 5"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    alert: '<path d="M12 3 2.5 20h19z"/><path d="M12 9v4m0 3h.01"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.8 2.8 0 1 1 4 2.5c-1 .5-1.5 1.2-1.5 2.5m0 3h.01"/>',
    x: '<path d="m6 6 12 12M18 6 6 18"/>',
    trash: '<path d="M4 7h16M9 7V4h6v3m3 0-1 14H7L6 7m4 4v6m4-6v6"/>',
    spark: '<path d="m12 3 1.5 5.5L19 10l-5.5 1.5L12 17l-1.5-5.5L5 10l5.5-1.5z"/>',
    teacher: '<path d="m3 10 9-5 9 5-9 5z"/><path d="M7 12.5V17c3 2 7 2 10 0v-4.5M21 10v6"/>',
    lock: '<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/>',
    logout: '<path d="M10 5H5v14h5M14 8l4 4-4 4M18 12H9"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4m0-14.2-1.4 1.4M6.3 17.7l-1.4 1.4"/>',
    moon: '<path d="M20.9 13.3A9 9 0 0 1 10.7 3.1 9 9 0 1 0 20.9 13.3Z"/>',
    chat: '<path d="M21 11.5a8 8 0 0 1-8.5 8H4l1.6-3.3A7.8 7.8 0 0 1 4 11.5a8.5 8.5 0 0 1 17 0Z"/><path d="M8 11.5h9m-9 3h6"/>',
    settings: '<path d="M4 6h16M9 4v4M4 12h16m-5-2v4M4 18h16M8 16v4"/>',
  };
  return `<svg class="icon" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.spark}</svg>`;
}

export function renderThemeToggle() {
  const label = themeSwitchLabel();
  return `<button class="theme-toggle" type="button" data-theme-toggle aria-label="${label}" title="${label}">
    <span class="theme-to-light">${icon("sun", 17)} Sáng</span>
    <span class="theme-to-dark">${icon("moon", 17)} Tối</span>
  </button>`;
}

export function renderGuideChatTrigger() {
  return `<button class="guide-chat-trigger" type="button" data-open-guide-chat aria-haspopup="dialog" aria-label="Hỏi trợ lý" title="Hỏi trợ lý">${icon("chat", 18)} <span>Hỏi trợ lý</span></button>`;
}

export function appShell(content, active = "lessons") {
  const student = getStudent();
  const session = getBrowserSession();
  const role = session?.role || (student ? "student" : "");
  const roleLabel = SESSION_ROLES[role]?.label;
  const name = role === "student" ? student?.name : session?.username;
  const classCode = role === "teacher" ? getTeacherClassCode() : role === "student" ? student?.classCode : "";
  const nav = [
    ["lessons", "#/lessons", "book", "Bài học"],
    ["references", "#/references", "check", "Kho tham chiếu"],
    ["ai-progress", "#/ai-progress", "spark", "Theo dõi AI"],
    ["history", "#/history", "history", "Lịch sử"],
    ["teacher", "#/teacher", "teacher", "Giáo viên"],
    ["admin", "#/admin", "lock", "Quản trị"],
    ["profile", "#/profile", "user", "Hồ sơ"],
    ["settings", "#/settings", "settings", "Cấu hình"],
    ["about", "#/about", "info", "Về AI"],
  ];
  return `
    <div class="app-shell">
      <header class="app-header">
        <div class="topbar">
          <a class="brand" href="#/lessons" aria-label="CircuitCoach AI">
            <img class="brand-logo" src="/images/circuitcoach-logo.png" alt="" />
            <span><strong>CircuitCoach</strong><small>AI LAB</small></span>
          </a>
          <nav class="main-nav" aria-label="Điều hướng chính">
            ${nav.filter(([id]) => {
              if (["history", "profile"].includes(id)) return role === "student" && Boolean(student);
              if (["teacher", "admin"].includes(id)) return !role || role === id;
              if (id === "settings") return session?.localOpenAISettings || session?.browserOpenAISettings;
              return true;
            }).map(([id, href, glyph, label]) => `<a href="${href}" aria-label="${label}" title="${label}"${active === id ? ' class="active" aria-current="page"' : ""}>${icon(glyph, 18)}<span>${label}</span></a>`).join("")}
          </nav>
          <div class="student-actions">${renderGuideChatTrigger()}${renderThemeToggle()}${roleLabel ? "" : `<a class="admin-login-button" href="#/home" aria-label="Chọn vai trò">${icon("user", 16)}<span>Chọn vai trò</span></a>`}</div>
        </div>
        ${roleLabel ? `<div class="session-role-bar">
          <div class="session-role-status" role="status">${icon("lock", 17)}<div>
            <p>Bạn đang đăng nhập với vai trò <strong>${roleLabel}</strong>${name ? ` · ${escapeHtml(name)}` : ""}${classCode ? ` · Lớp ${escapeHtml(classCode)}` : ""}.</p>
            <small>Đăng xuất trước khi đổi vai trò.</small>
          </div></div>
          <button class="btn btn-logout" type="button" data-browser-logout>${icon("logout", 17)} Đăng xuất</button>
        </div>` : ""}
        <div class="ai-warning-bar" role="note" aria-label="Cảnh báo về độ chính xác của AI">
          ${icon("alert", 18)}
          <p><strong>Cảnh báo AI:</strong> ${escapeHtml(SAFETY_WARNING)}</p>
        </div>
      </header>
      <main id="main-content" class="main-content">${content}</main>
      <footer class="app-footer"><span>CircuitCoach AI · MVP Bảng A</span><span>Ảnh chỉ chia sẻ trong lớp khi có mã lớp</span></footer>
    </div>`;
}

export function emptyState(title, detail, action = "") {
  return `<section class="empty-state">${icon("spark", 30)}<h2>${escapeHtml(title)}</h2><p>${escapeHtml(detail)}</p>${action}</section>`;
}

export function showToast(message, type = "info") {
  document.querySelector(".toast")?.remove();
  const element = document.createElement("div");
  element.className = `toast toast-${type}`;
  element.setAttribute("role", "status");
  element.textContent = message;
  document.body.append(element);
  setTimeout(() => element.remove(), 4200);
}
