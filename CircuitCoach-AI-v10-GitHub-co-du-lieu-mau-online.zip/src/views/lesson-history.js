import { CERTAINTY_LABELS, STATUS_LABELS } from "../config.js";
import { getLesson } from "../data/lessons.js";
import { reportProblems } from "../data/attempt-rechecks.js";
import { getAttemptImages } from "../services/attempt-archive.js";
import { getAttempts } from "../services/storage.js";
import { attemptNumbers } from "../services/attempt-order.js";
import { fetchSharedAttempt, sharedAttemptImageUrl } from "../services/classroom.js";
import { appShell, emptyState, escapeHtml, icon } from "./shared.js";

const verificationLabels = { correct: "Nhóm đánh giá AI đúng", incorrect: "Nhóm đánh giá AI sai", uncertain: "Nhóm chưa chắc" };
const teacherLabels = { correct: "Giáo viên xác nhận đúng", incorrect: "Giáo viên xác nhận sai", uncertain: "Giáo viên chưa kết luận" };

function formatDate(value) {
  return new Date(value).toLocaleString("vi-VN", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

async function loadPhotos(attempt) {
  const local = await getAttemptImages(attempt.id).catch(() => []);
  if (local.length || !attempt.classCode) return local;
  const shared = await fetchSharedAttempt(attempt.id, attempt.classCode).catch(() => null);
  if (!shared) return local;
  const imageCount = Math.min(3, Number(shared.imageCount || attempt.imageCount) || 0);
  const remote = [];
  for (let index = 0; index < imageCount; index += 1) {
    try {
      const response = await fetch(sharedAttemptImageUrl(attempt.id, attempt.classCode, index));
      if (!response.ok) break;
      remote.push({ index, name: `Ảnh mạch ${index + 1}`, url: URL.createObjectURL(await response.blob()) });
    } catch { break; }
  }
  return remote;
}

function resultLabel(attempt) {
  if (attempt.demo) return "Kết quả mô phỏng · Demo";
  if (attempt.analysisStatus === "submitted") return "Đã gửi ảnh · Chờ phân tích";
  return attempt.verdict === "pass" ? "AI: đạt các tiêu chí đã kiểm tra" : "AI: cần xem lại";
}

export function renderLessonHistory(root, lessonId) {
  const lesson = getLesson(lessonId);
  if (!lesson) {
    root.innerHTML = appShell(emptyState("Không tìm thấy bài học", "Hãy quay lại danh sách bài học để chọn bài khác.", '<a class="btn btn-primary" href="#/lessons">Danh sách bài học</a>'));
    return;
  }
  const attempts = getAttempts().filter((attempt) => attempt.lessonId === lessonId).sort((a, b) => new Date(b.time) - new Date(a.time));
  const numbers = attemptNumbers(attempts);
  const cards = attempts.map((attempt, index) => {
    const problemSummary = reportProblems(attempt).map((problem) => `<span class="status-${problem.status}">${escapeHtml(problem.ruleEvidence?.physicalCheckRequired ? "Cần kiểm tra trực tiếp" : STATUS_LABELS[problem.status] || problem.status)} · ${escapeHtml(problem.label)}${problem.recheckId ? " · Qua ảnh kiểm tra lại" : problem.certainty ? ` · ${escapeHtml(CERTAINTY_LABELS[problem.certainty] || problem.certainty)}` : ""}</span>`).join("");
    const members = (attempt.teamMembers || []).filter(Boolean).map(escapeHtml).join("、");
    return `<article class="archive-attempt">
      <header class="archive-attempt-head"><div><p class="eyebrow">${escapeHtml(formatDate(attempt.time))}${attempt.demo ? " · DEMO" : ""}</p><h2>Lần ${numbers.get(attempt.id)} · ${escapeHtml(attempt.studentName || "Nhóm chưa đặt tên")}</h2><p>${attempt.classCode ? `Mã lớp ${escapeHtml(attempt.classCode)}` : "Lưu trên thiết bị này"}${members ? ` · Thành viên: ${members}` : ""}</p></div><a class="text-button" href="#/result/${encodeURIComponent(attempt.id)}">Xem kết quả →</a></header>
      <div class="archive-verdict"><strong class="${attempt.verdict === "pass" && !attempt.demo ? "status-correct" : "status-possible_error"}">${escapeHtml(resultLabel(attempt))}</strong><span data-archive-verification="${index}">${attempt.teacherVerification ? escapeHtml(teacherLabels[attempt.teacherVerification]) : attempt.verification ? escapeHtml(verificationLabels[attempt.verification]) : "Chưa có xác nhận đúng/sai"}</span></div>
      <div class="history-problems">${problemSummary || "<span>Chưa có tiêu chí lưu</span>"}</div>
      <div class="archive-images" data-archive-index="${index}"><p class="muted">Đang tải ảnh đã lưu…</p></div>
    </article>`;
  }).join("");
  const content = attempts.length ? `<div class="archive-attempt-list">${cards}</div>` : emptyState("Chưa có lượt trong thư mục này", "Sau khi nhóm phân tích mạch thuộc bài học này, kết quả và ảnh sẽ được lưu tại đây.", `<a class="btn btn-primary" href="#/analyzer/${lesson.id}">Bắt đầu bài học ${icon("arrow", 18)}</a>`);
  root.innerHTML = appShell(`<section class="lesson-history-page"><header class="page-head compact-head"><div><p class="eyebrow">THƯ MỤC LỊCH SỬ · ${escapeHtml(lesson.eyebrow)}</p><h1>${lesson.icon} ${escapeHtml(lesson.title)}</h1><p>${attempts.length} lượt đã lưu. Ảnh được lưu trong trình duyệt trên thiết bị này; nếu có mã lớp, ảnh cũng được gửi để giáo viên xem.</p></div><a class="btn btn-secondary" href="#/analyzer/${lesson.id}">${icon("camera", 18)} Phân tích mạch</a></header><a class="text-button archive-back" href="#/lessons">← Tất cả bài học</a>${content}</section>`, "lessons");

  root.querySelectorAll("[data-archive-index]").forEach(async (container) => {
    const attempt = attempts[Number(container.dataset.archiveIndex)];
    const verificationLabel = root.querySelector(`[data-archive-verification="${container.dataset.archiveIndex}"]`);
    if (attempt.classCode && verificationLabel) {
      const shared = await fetchSharedAttempt(attempt.id, attempt.classCode).catch(() => null);
      const teacherVerification = shared?.teacherVerification;
      if (teacherVerification) verificationLabel.textContent = teacherLabels[teacherVerification] || "Đã có xác nhận của giáo viên";
    }
    const images = await loadPhotos(attempt);
    if (!container.isConnected) {
      images.forEach((image) => URL.revokeObjectURL(image.url));
      return;
    }
    if (!images.length) {
      container.innerHTML = `<p class="muted">Chưa có ảnh lưu cho lượt này. Ảnh của các lượt mới sẽ được giữ trong thư mục lịch sử.</p>`;
      return;
    }
    container.innerHTML = images.map((image, index) => `<figure><img src="${image.url}" alt="Ảnh mạch ${index + 1} của ${escapeHtml(attempt.studentName || "nhóm")}" loading="lazy" /><figcaption>${escapeHtml(image.name || `Ảnh ${index + 1}`)}</figcaption></figure>`).join("");
  });
}
