import { getLesson, lessons } from "../data/lessons.js";
import { REFERENCE_ERROR_TYPES } from "../data/reference-cases.js";
import { uploadReferenceCase } from "../services/classroom.js";
import { prepareImage, validateImage } from "../services/image.js";
import { mountPhotoAnnotationEditor, photoAnnotationEditor } from "./photo-tools.js";
import { appShell, emptyState, escapeHtml, icon } from "./shared.js";

export function renderReferenceUpload(root, lessonId, { canUpload, presetError }) {
  const initialLesson = getLesson(lessonId) || lessons[0];
  const libraryLink = `#/references/${initialLesson.id}?view=manage`;
  root.innerHTML = appShell(`
    <section class="reference-upload-page">
      <div class="breadcrumb"><a href="${libraryLink}" data-upload-library>Kho tham chiếu</a><span>/</span><strong>Tải ảnh theo tiêu chí</strong></div>
      <header class="page-head compact-head">
        <div><h1>Tải ảnh mẫu theo tiêu chí</h1>${canUpload ? "<p>Chọn bài học và tiêu chí. Ảnh được chia sẻ cho mọi người sau khi duyệt.</p>" : ""}</div>
      </header>
      ${canUpload ? `<form class="lesson-sample-form" id="reference-upload-form">
        <fieldset>
          <legend>Thông tin ảnh mẫu</legend>
          <label>Bài học<select name="lessonId">${lessons.map(lesson => `<option value="${lesson.id}" ${lesson.id === initialLesson.id ? "selected" : ""}>${escapeHtml(lesson.title)}</option>`).join("")}</select></label>
          <label>Tiêu chí được minh họa<select name="criterionId" required></select></label>
          <label>Nhãn của tiêu chí<select name="label" required>
            <option value="">Chọn nhãn</option><option value="correct">Đúng ở tiêu chí này</option><option value="incorrect">Có lỗi ở tiêu chí này</option>
          </select></label>
          <label data-reference-error-field hidden>Dạng lỗi<select name="errorType" disabled>
            <option value="">Chọn dạng lỗi</option>
            ${Object.entries(REFERENCE_ERROR_TYPES).map(([id, title]) => `<option value="${id}">${escapeHtml(title)}</option>`).join("")}
          </select></label>
          <label>Dấu hiệu nhìn thấy trên ảnh<textarea name="evidence" maxlength="300" rows="3" placeholder="Ví dụ: Chân dương LED cắm về phía GND."></textarea></label>
          <label>Ảnh mạch thật<input name="image" type="file" accept="image/jpeg,image/png,image/webp" required /></label>
          ${photoAnnotationEditor()}
          <p>Chọn ảnh nhìn rõ tiêu chí, tránh khuôn mặt và thông tin cá nhân. Hỗ trợ JPEG, PNG và WebP.</p>
          <button class="btn btn-primary" type="submit">${icon("upload", 17)} Gửi ảnh để duyệt</button>
        </fieldset>
        <p class="lesson-sample-status" role="status"></p>
        <a class="text-button" href="${libraryLink}" data-upload-library data-upload-success hidden>Mở kho chung để duyệt</a>
      </form>` : emptyState("Cần đăng nhập giáo viên", "Đăng nhập giáo viên để tải ảnh vào kho.", '<a class="btn btn-secondary" href="#/home">Đăng nhập</a>')}
    </section>`, "references");
  const form = root.querySelector("#reference-upload-form");
  if (!form) return;

  const { lessonId: lessonSelect, criterionId, label, errorType, evidence, image } = form.elements;
  const fieldset = form.querySelector("fieldset");
  const editor = mountPhotoAnnotationEditor(form.querySelector("[data-annotation-editor]"));
  const status = form.querySelector(".lesson-sample-status");
  const success = form.querySelector("[data-upload-success]");
  const links = root.querySelectorAll("[data-upload-library]");

  function updateLesson() {
    const lesson = getLesson(lessonSelect.value);
    criterionId.innerHTML = '<option value="">Chọn tiêu chí</option>' + lesson.checks
      .map(([id, title]) => `<option value="${escapeHtml(id)}">${escapeHtml(title)}</option>`).join("");
    links.forEach(link => { link.href = `#/references/${lesson.id}?view=manage`; });
    success.hidden = true;
  }

  function updateLabel() {
    const incorrect = label.value === "incorrect";
    errorType.disabled = !incorrect;
    errorType.required = incorrect;
    errorType.closest("label").hidden = !incorrect;
    evidence.required = incorrect && errorType.value === "other";
  }

  lessonSelect.addEventListener("change", updateLesson);
  label.addEventListener("change", updateLabel);
  errorType.addEventListener("change", updateLabel);
  image.addEventListener("change", async () => {
    const file = image.files[0];
    editor.show();
    status.textContent = "";
    success.hidden = true;
    if (!file) return;
    let url;
    try {
      validateImage(file);
      url = URL.createObjectURL(file);
      await editor.show(url);
    } catch {
      if (image.files[0] === file) {
        editor.show();
        status.textContent = "Không thể đọc ảnh. Hãy chọn tệp JPEG, PNG hoặc WebP.";
      }
    } finally {
      if (url) URL.revokeObjectURL(url);
    }
  });

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (fieldset.disabled) return;
    const data = new FormData(form);
    data.set("annotations", JSON.stringify(editor.marks()));
    fieldset.disabled = true;
    success.hidden = true;
    status.textContent = "Đang tải ảnh…";
    try {
      const photo = await prepareImage(data.get("image"));
      data.set("image", photo, "circuit.jpg");
      await uploadReferenceCase(data);
      image.value = "";
      evidence.value = "";
      label.value = "";
      errorType.value = "";
      updateLabel();
      editor.show();
      status.textContent = "Đã lưu ảnh. Trạng thái đang chờ duyệt.";
      success.hidden = false;
    } catch (error) {
      status.textContent = error.message;
    } finally {
      fieldset.disabled = false;
    }
  });
  updateLesson();
  if (Object.hasOwn(REFERENCE_ERROR_TYPES, presetError)) {
    label.value = "incorrect";
    errorType.value = presetError;
    updateLabel();
  }
}
