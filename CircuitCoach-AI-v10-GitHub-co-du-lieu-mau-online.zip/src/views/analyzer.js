import { getLesson } from "../data/lessons.js";
import { MAX_IMAGES } from "../config.js";
import { analyzeImages, getHealth } from "../services/api.js";
import { captureFrame, startCamera, stopCamera } from "../services/camera.js";
import { inspectPhotoQuality, prepareImage, previewUrl, validateImage } from "../services/image.js";
import { deleteReferenceImage, listReferenceImages, mergeReferenceImages, referenceRecordToFile, saveReferenceImage } from "../services/reference-images.js";
import { getStudent, sameStudentGroup, saveAttempt } from "../services/storage.js";
import { fetchPublicReferenceCases, publicReferenceExamplePhotoUrl, publishAttempt } from "../services/classroom.js";
import { setAttemptImages } from "../services/session-images.js";
import { saveAttemptImages } from "../services/attempt-archive.js";
import { mountLessonAiReminders } from "./lesson-ai-reminders.js";
import { mountLessonSampleGallery } from "./lesson-samples.js";
import { createPhotoViewer } from "./photo-tools.js";
import { appShell, escapeHtml, icon, showToast } from "./shared.js";
import { mountStudentTabs, renderStudentTabs } from "./student-tabs.js";

function renderLessonLinks(lesson) {
  return `<div class="analyzer-lesson-links">
    <a class="btn btn-secondary" href="#/assembly/${lesson.id}">${icon("book", 18)} Hướng dẫn lắp mạch</a>
    <a class="btn btn-secondary" href="#/lesson-prompts/${lesson.id}">${icon("info", 18)} Xem prompt AI</a>
  </div>`;
}

function renderLessonPreview(root, lesson, classCode) {
  root.innerHTML = appShell(`
    <section class="analyzer-layout">
      <div class="analyzer-main">
        <div class="breadcrumb"><a href="#/lessons">Bài học</a><span>/</span><strong>${escapeHtml(lesson.title)}</strong></div>
        <header class="page-head analyzer-head"><div><p class="eyebrow">${escapeHtml(lesson.board)}</p><h1>${escapeHtml(lesson.title)}</h1></div></header>
        ${renderLessonLinks(lesson)}
        <section class="side-card lesson-ai-reminders"></section>
        <section class="side-card expected-card">
          <h2>Kết nối cần kiểm tra</h2>
          <ol>${lesson.expectedConnections.map(item => `<li>${escapeHtml(item)}</li>`).join("")}</ol>
          <h2>Ảnh và sơ đồ đối chiếu</h2>
          <div class="lesson-sample-grid">${lesson.referenceImages.map(image => `
            <article class="lesson-sample-photo">
              <a class="lesson-sample-thumbnail" href="${escapeHtml(image.src)}" target="_blank" rel="noopener"><img src="${escapeHtml(image.src)}" alt="${escapeHtml(image.label)}" loading="lazy" /></a>
              <div class="lesson-sample-details"><strong>${escapeHtml(image.label)}</strong></div>
            </article>`).join("")}</div>
          <a class="text-button" href="#/references/${lesson.id}">Mở kho tham chiếu của bài</a>
        </section>
      </div>
      <aside class="analyzer-side">
        ${classCode ? '<section class="side-card lesson-samples" id="lesson-sample-gallery"></section>' : ""}
        <section class="side-card">
          <h2>Phân tích ảnh mạch</h2>
          <p>Vào nhóm học sinh để gửi ảnh và lưu kết quả của nhóm.</p>
          <a class="btn btn-secondary" href="#/home">Vào nhóm học sinh</a>
        </section>
      </aside>
    </section>`, "lessons");
  void mountLessonAiReminders(root.querySelector(".lesson-ai-reminders"), { lessonId: lesson.id, teacherClassCode: classCode });
  if (classCode) mountLessonSampleGallery(root.querySelector("#lesson-sample-gallery"), { lessonId: lesson.id, classCode });
}

export function renderAnalyzer(root, lessonId, { teacherClassCode = "" } = {}) {
  const lesson = getLesson(lessonId);
  if (!lesson) { location.hash = "#/lessons"; return; }
  const student = getStudent();
  if (!student) { renderLessonPreview(root, lesson, teacherClassCode); return; }
  let files = [];
  const qualityByFile = new WeakMap();
  let demo = false;
  let busy = false;
  let referenceRecords = [];
  let customReferenceRecords = [];
  const classCode = student?.classCode || "";
  root.innerHTML = appShell(`
    <section class="student-lesson">
      <div class="breadcrumb"><a href="#/lessons">Bài học</a><span>/</span><strong>Thực hành</strong></div>
      <header class="page-head compact-head"><div><p class="eyebrow">${escapeHtml(lesson.board)}</p><h1>${escapeHtml(lesson.title)}</h1></div></header>
      <div class="student-task-bar">
        ${renderStudentTabs("Thực hành bài học", [["student-upload", "Gửi ảnh"], ["student-guide", "Hướng dẫn và ảnh mẫu"], ["student-ai", "Tùy chọn AI"]])}
        <a class="student-history-link text-button" href="#/lesson-history/${lesson.id}">${icon("history", 17)} Lịch sử bài</a>
      </div>
      <section class="student-task-panel" id="student-upload" role="tabpanel" aria-labelledby="student-upload-tab" tabindex="0">
        <p class="student-capture-guide">Chụp từ 1 đến 3 góc của cùng một mạch. Nên có một ảnh toàn cảnh và ảnh cận các chân cắm. Chỉ chụp mạch, tránh thông tin cá nhân.</p>
        <div id="upload-zone" class="upload-zone" tabindex="0" role="button" aria-label="Chọn hoặc thả ảnh mạch">
          <div class="upload-icon">${icon("upload", 28)}</div>
          <strong>Kéo ảnh mạch vào đây</strong><p>hoặc chọn một cách thêm ảnh</p>
          <div class="upload-actions"><button id="pick-files" class="btn btn-secondary" type="button">${icon("upload", 18)} Chọn ảnh</button><button id="open-camera" class="btn btn-ghost" type="button">${icon("camera", 18)} Mở camera</button></div>
          <input id="file-input" type="file" accept="image/jpeg,image/png,image/webp" multiple hidden />
          <small>JPEG, PNG, WEBP · Tối đa ${MAX_IMAGES} ảnh · Ảnh được thu nhỏ trước khi gửi</small>
        </div>
        <div id="preview-grid" class="preview-grid"></div>
        <div id="photo-quality-notes" class="photo-quality-notes" role="status" hidden></div>
        <div id="error-box" class="error-box" hidden></div>
        <div class="analyze-controls">
          <div id="analysis-model-field" class="analysis-model-field" hidden>
            <label for="analysis-model">Model phân tích</label>
            <select id="analysis-model"></select>
          </div>
          <p id="student-demo-status" class="student-demo-status" role="status" hidden>Đang bật chế độ demo. Kết quả sẽ là mô phỏng.</p>
          <button id="analyze-button" class="btn btn-primary btn-large" type="button" disabled>${icon("spark", 19)} Phân tích mạch</button>
        </div>
        <div id="loading-panel" class="loading-panel" hidden><div class="scanner"></div><strong>CircuitCoach đang quan sát mạch…</strong><p>Đang đọc bằng chứng trên ảnh và đối chiếu với sơ đồ của bài.</p></div>
        <section class="side-card lesson-ai-reminders"></section>
      </section>
      <section class="student-task-panel student-detail-grid" id="student-guide" role="tabpanel" aria-labelledby="student-guide-tab" tabindex="0" hidden>
        <section class="side-card expected-card">
          <h2>Kết nối theo sơ đồ</h2>
          <ol>${lesson.expectedConnections.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ol>
          ${lesson.referenceImage ? `<div class="circuit-reference"><img src="${lesson.referenceImage}" alt="Mạch LED nối trực tiếp với pin 9V, chưa có công tắc" /><div><strong>So sánh trước khi lắp</strong><p>Không có công tắc, LED sáng liên tục. Thêm công tắc nối tiếp để chủ động đóng hoặc ngắt mạch.</p></div></div><p class="safety-note">⚠️ Luôn dùng điện trở hạn dòng, không nối tắt hai cực pin và ngắt pin trước khi chỉnh dây.</p>` : ""}
          <a class="btn btn-primary" href="#/assembly/${lesson.id}">${icon("book", 18)} Hướng dẫn lắp mạch</a>
        </section>
        <section class="side-card lesson-samples" id="lesson-sample-gallery"></section>
        <section class="side-card capture-card"><h2>3 góc chụp nên có</h2><p><b>01</b> Toàn cảnh mạch</p><p><b>02</b> ${lesson.id === "battery-led-switch" ? "Cận cảnh cực pin" : "Cận cảnh Arduino"}</p><p><b>03</b> ${lesson.id === "battery-led-switch" ? "Cận cảnh công tắc" : "Cận cảnh linh kiện"}</p></section>
        <section class="side-card reference-library-card">
          <div class="reference-library-head"><div><p class="eyebrow">BỘ ẢNH ĐỐI CHIẾU</p><h2>Ảnh đúng đã kiểm duyệt</h2></div><span id="reference-count">0/3</span></div>
          <p>Mỗi bài có sẵn 3 góc mạch chuẩn đã duyệt. AI dùng để hỗ trợ đối chiếu, đồng thời vẫn ưu tiên sơ đồ nối dây, checklist và kiến thức kỹ thuật.</p>
          <div id="reference-grid" class="reference-grid"><p class="reference-empty">Chưa có ảnh chuẩn.</p></div>
        </section>
        <section class="side-card approved-class-card">
          <div class="reference-library-head"><h2>Ảnh đã duyệt trong kho chung</h2><span id="approved-reference-count"></span></div>
          <div id="approved-reference-grid" class="approved-class-grid"><p class="reference-empty">Đang tải ảnh tham chiếu…</p></div>
          <a class="text-button" href="#/references/${lesson.id}">Mở kho tham chiếu của bài</a>
        </section>
      </section>
      <section class="student-task-panel student-detail-grid" id="student-ai" role="tabpanel" aria-labelledby="student-ai-tab" tabindex="0" hidden>
        <section class="side-card student-ai-settings">
          <h2>Cách chạy phân tích</h2>
          <label class="demo-switch"><input id="demo-toggle" type="checkbox" /><span></span><div><strong>Chế độ demo</strong><small>Kết quả mô phỏng, không gọi OpenAI</small></div></label>
          <a class="text-button" href="#/lesson-prompts/${lesson.id}">${icon("info", 17)} Xem prompt AI</a>
        </section>
        <section class="side-card reference-library-card">
          <h2>Ảnh đối chiếu của giáo viên</h2>
          <label class="approval-check"><input id="reference-approved" type="checkbox" /><span>Tôi xác nhận ảnh thay thế đã được giáo viên kiểm duyệt và mạch hoạt động đúng.</span></label>
          <button id="pick-reference" class="btn btn-ghost btn-full" type="button" disabled>${icon("upload", 17)} Thay bằng ảnh của giáo viên</button>
          <input id="reference-input" type="file" accept="image/jpeg,image/png,image/webp" multiple hidden />
          <small class="device-note">Ảnh thay thế xuất hiện trong mục Hướng dẫn và ảnh mẫu.</small>
        </section>
        <section class="side-card privacy-card"><div>${icon("info", 20)}<h2>Quyền riêng tư</h2></div><p>Ảnh được dùng để phân tích AI. Khi nhóm nhập mã lớp, tối đa 3 ảnh đã nén cũng được lưu để giáo viên xem bài.</p><p>Không chụp khuôn mặt, tên đầy đủ hoặc thông tin cá nhân trong ảnh.</p></section>
      </section>
    </section>
    <dialog id="camera-dialog" class="camera-dialog"><div class="dialog-head"><div><p class="eyebrow">CAMERA</p><h2>Chụp ảnh mạch</h2></div><button id="close-camera" class="icon-button" aria-label="Đóng camera">${icon("x", 22)}</button></div><video id="camera-video" playsinline muted></video><p class="camera-help">Giữ camera ổn định, chụp từ trên xuống và tránh để tay che dây.</p><button id="capture-button" class="btn btn-primary btn-full" type="button">${icon("camera", 18)} Chụp ảnh</button></dialog>
    <dialog id="reference-dialog" class="reference-dialog" aria-labelledby="reference-dialog-title"><div class="dialog-head"><div><p class="eyebrow">ẢNH MẠCH CHUẨN</p><h2 id="reference-dialog-title">Xem ảnh đối chiếu</h2></div><button id="close-reference" class="icon-button" type="button" aria-label="Đóng ảnh phóng to">${icon("x", 22)}</button></div><div class="reference-zoom-stage"><img id="reference-zoom-image" alt="" /></div><p id="reference-zoom-label" class="reference-zoom-label"></p></dialog>
  `, "lessons");

  const input = root.querySelector("#file-input");
  const zone = root.querySelector("#upload-zone");
  const previews = root.querySelector("#preview-grid");
  const analyzeButton = root.querySelector("#analyze-button");
  const modelField = root.querySelector("#analysis-model-field");
  const modelSelect = root.querySelector("#analysis-model");
  const errorBox = root.querySelector("#error-box");
  const loading = root.querySelector("#loading-panel");
  const demoToggle = root.querySelector("#demo-toggle");
  const demoStatus = root.querySelector("#student-demo-status");
  const cameraDialog = root.querySelector("#camera-dialog");
  const cameraVideo = root.querySelector("#camera-video");
  const referenceDialog = root.querySelector("#reference-dialog");
  const referenceZoomImage = root.querySelector("#reference-zoom-image");
  const referenceZoomLabel = root.querySelector("#reference-zoom-label");
  const referenceGrid = root.querySelector("#reference-grid");
  const referenceCount = root.querySelector("#reference-count");
  const referenceApproved = root.querySelector("#reference-approved");
  const referenceButton = root.querySelector("#pick-reference");
  const referenceInput = root.querySelector("#reference-input");
  const approvedGrid = root.querySelector("#approved-reference-grid");
  const approvedCount = root.querySelector("#approved-reference-count");
  const approvedViewer = createPhotoViewer();
  approvedGrid.closest(".approved-class-card").append(approvedViewer.element);
  mountStudentTabs(root);

  function setDemo(value) {
    demo = value;
    demoToggle.checked = value;
    demoStatus.hidden = !value;
    modelSelect.disabled = value || busy;
  }

  async function loadApprovedReferences() {
    try {
      const examples = await fetchPublicReferenceCases(lessonId);
      if (!approvedGrid.isConnected) return;
      approvedCount.textContent = `${examples.length} ảnh`;
      const entries = examples.slice(0, 6).map(example => ({
        src: publicReferenceExamplePhotoUrl(example.id),
        verdict: { correct: "Đúng tiêu chí", incorrect: "Có lỗi" }[example.label] || "Chưa rõ",
        criterion: lesson.checks.find(([id]) => id === example.criterionId)?.[1] || example.criterionId,
        annotations: example.annotations,
      }));
      approvedGrid.innerHTML = entries.length ? entries.map((entry, index) =>
        `<button class="approved-class-thumb" data-approved-index="${index}" type="button" aria-label="Phóng to ${escapeHtml(entry.criterion)}"><img src="${escapeHtml(entry.src)}" alt="${escapeHtml(entry.criterion)}" loading="lazy" /><span>${escapeHtml(entry.verdict)}</span></button>`
      ).join("") : '<p class="reference-empty">Chưa có ảnh tham chiếu đã duyệt cho bài này.</p>';
      approvedGrid.querySelectorAll("[data-approved-index]").forEach(button => button.addEventListener("click", () => {
        const { src, criterion, verdict, annotations } = entries[Number(button.dataset.approvedIndex)];
        approvedViewer.open(src, `${criterion} · ${verdict}`, annotations);
      }));
    } catch {
      if (approvedGrid.isConnected) approvedGrid.innerHTML = '<p class="reference-empty">Chưa tải được ảnh tham chiếu.</p>';
    }
  }

  function renderReferenceImages() {
    referenceCount.textContent = `${referenceRecords.length}/3`;
    referenceGrid.innerHTML = referenceRecords.length
      ? referenceRecords.map((record, index) => `<article class="reference-thumb ${record.builtIn ? "is-built-in" : ""}"><button class="reference-zoom-button" data-index="${index}" type="button" aria-label="Phóng to ${escapeHtml(record.label || `ảnh chuẩn ${index + 1}`)}"><img src="${record.builtIn ? record.src : URL.createObjectURL(record.blob)}" alt="${escapeHtml(record.label || `Ảnh chuẩn ${index + 1}`)}" style="--reference-x:${((record.crop?.x || 0) + (record.crop?.width || 1) / 2) * 100}%;--reference-y:${((record.crop?.y || 0) + (record.crop?.height || 1) / 2) * 100}%;--reference-scale:${record.crop ? Math.min(1 / record.crop.width, 1 / record.crop.height) : 1}"></button><span>${record.builtIn ? "Chuẩn có sẵn" : "GV duyệt"}</span>${record.builtIn ? "" : `<button class="icon-button remove-reference" data-id="${record.id}" type="button" aria-label="Xóa ảnh chuẩn ${index + 1}">${icon("trash", 16)}</button>`}<small>${escapeHtml(record.label || `Góc ${index + 1}`)}</small></article>`).join("")
      : `<p class="reference-empty">Chưa có ảnh chuẩn.</p>`;
    referenceButton.disabled = !referenceApproved.checked || customReferenceRecords.length >= 3;
    referenceGrid.querySelectorAll(".reference-zoom-button").forEach((button) => button.addEventListener("click", () => {
      const image = button.querySelector("img");
      const record = referenceRecords[Number(button.dataset.index)];
      if (!image || !record) return;
      referenceZoomImage.src = image.src;
      referenceZoomImage.alt = record.label || "Ảnh mạch chuẩn";
      referenceZoomLabel.textContent = record.label || "Ảnh mạch chuẩn";
      referenceDialog.showModal();
    }));
    referenceGrid.querySelectorAll(".remove-reference").forEach((button) => button.addEventListener("click", async () => {
      await deleteReferenceImage(button.dataset.id);
      customReferenceRecords = await listReferenceImages(lessonId);
      referenceRecords = mergeReferenceImages(lesson, customReferenceRecords);
      renderReferenceImages();
      showToast("Đã khôi phục ảnh chuẩn có sẵn cho vị trí này.");
    }));
  }

  async function loadReferenceImages() {
    try {
      customReferenceRecords = await listReferenceImages(lessonId);
      referenceRecords = mergeReferenceImages(lesson, customReferenceRecords);
      renderReferenceImages();
    } catch (error) { showToast(error.message, "error"); }
  }

  const qualityNotes = root.querySelector("#photo-quality-notes");

  function renderPhotoQuality() {
    const pending = files.some(file => !qualityByFile.has(file));
    const warnings = files.flatMap((file,index) => (qualityByFile.get(file) || []).map(tip => `Ảnh ${index + 1}. ${tip}`));
    analyzeButton.disabled = busy || !files.length || pending;
    qualityNotes.hidden = !pending && warnings.length === 0;
    qualityNotes.innerHTML = warnings.length
      ? `<strong>Kiểm tra ảnh trước khi gửi</strong><ul>${warnings.map(tip => `<li>${escapeHtml(tip)}</li>`).join("")}</ul>`
      : pending ? "Đang kiểm tra độ sáng và độ rõ của ảnh…" : "";
  }

  function renderPreviews() {
    previews.innerHTML = files.map((file, index) => `<article class="preview-card"><img src="${previewUrl(file)}" alt="Ảnh mạch ${index + 1}" /><div><span><b>Ảnh ${index + 1}</b><small>${index === 0 ? "Tổng thể" : "Góc bổ sung"}</small></span><button class="icon-button remove-image" data-index="${index}" aria-label="Xóa ảnh ${index + 1}">${icon("trash", 18)}</button></div></article>`).join("");
    zone.classList.toggle("has-files", files.length > 0);
    renderPhotoQuality();
    previews.querySelectorAll(".remove-image").forEach((button) => button.addEventListener("click", () => { files.splice(Number(button.dataset.index), 1); renderPreviews(); }));
  }

  async function addFiles(selected) {
    const available = MAX_IMAGES - files.length;
    if (available <= 0) { showToast("Bạn đã thêm đủ 3 ảnh.", "error"); return; }
    try {
      const accepted = [...selected].slice(0, available);
      accepted.forEach(validateImage);
      files.push(...accepted);
      renderPreviews();
      for (const file of accepted) {
        void inspectPhotoQuality(file)
          .catch(() => ["Chưa đọc được ảnh này. Hãy thử chọn một ảnh khác."])
          .then(tips => {
            qualityByFile.set(file, tips);
            if (qualityNotes.isConnected && files.includes(file)) renderPhotoQuality();
          });
      }
      if (selected.length > available) showToast("CircuitCoach chỉ nhận tối đa 3 ảnh mỗi lần.");
    } catch (error) { showToast(error.message, "error"); }
  }

  root.querySelector("#pick-files").addEventListener("click", () => input.click());
  input.addEventListener("change", () => { addFiles(input.files); input.value = ""; });
  zone.addEventListener("keydown", (event) => { if (["Enter", " "].includes(event.key) && event.target === zone) input.click(); });
  ["dragenter", "dragover"].forEach((name) => zone.addEventListener(name, (event) => { event.preventDefault(); zone.classList.add("dragging"); }));
  ["dragleave", "drop"].forEach((name) => zone.addEventListener(name, (event) => { event.preventDefault(); zone.classList.remove("dragging"); }));
  zone.addEventListener("drop", (event) => addFiles(event.dataTransfer.files));
  demoToggle.addEventListener("change", () => setDemo(demoToggle.checked));
  referenceApproved.addEventListener("change", renderReferenceImages);
  referenceButton.addEventListener("click", () => referenceInput.click());
  referenceInput.addEventListener("change", async () => {
    try {
      if (!referenceApproved.checked) throw new Error("Hãy xác nhận ảnh đã được giáo viên kiểm duyệt.");
      const available = 3 - customReferenceRecords.length;
      const selected = [...referenceInput.files].slice(0, available);
      if (!selected.length) throw new Error("Bài học đã có đủ 3 ảnh chuẩn.");
      selected.forEach(validateImage);
      for (const file of selected) await saveReferenceImage({ lessonId, file: await prepareImage(file) });
      customReferenceRecords = await listReferenceImages(lessonId);
      referenceRecords = mergeReferenceImages(lesson, customReferenceRecords);
      renderReferenceImages();
      showToast(`Đã lưu ${selected.length} ảnh chuẩn cho bài học.`);
      if (referenceInput.files.length > available) showToast("Mỗi bài học chỉ lưu tối đa 3 ảnh chuẩn.");
    } catch (error) { showToast(error.message, "error"); }
    finally { referenceInput.value = ""; }
  });

  root.querySelector("#open-camera").addEventListener("click", async () => {
    try { cameraDialog.showModal(); await startCamera(cameraVideo); } catch (error) { cameraDialog.close(); showToast(error.message, "error"); }
  });
  const closeCamera = () => { stopCamera(); if (cameraDialog.open) cameraDialog.close(); };
  root.querySelector("#close-camera").addEventListener("click", closeCamera);
  cameraDialog.addEventListener("close", stopCamera);
  root.querySelector("#capture-button").addEventListener("click", async () => { try { await addFiles([await captureFrame(cameraVideo)]); closeCamera(); } catch (error) { showToast(error.message, "error"); } });
  const closeReference = () => { if (referenceDialog.open) referenceDialog.close(); };
  root.querySelector("#close-reference").addEventListener("click", closeReference);
  referenceDialog.addEventListener("click", (event) => { if (event.target === referenceDialog) closeReference(); });
  referenceDialog.addEventListener("close", () => { referenceZoomImage.removeAttribute("src"); });

  analyzeButton.addEventListener("click", async () => {
    if (!files.length || busy || files.some(file => !qualityByFile.has(file))) return;
    const analysisModel = modelSelect.value;
    busy = true; errorBox.hidden = true; loading.hidden = false; analyzeButton.disabled = true;
    modelSelect.disabled = true;
    try {
      const processed = await Promise.all(files.map(prepareImage));
      const referenceFiles = await Promise.all(referenceRecords.map(referenceRecordToFile));
      const result = await analyzeImages({ lessonId, files: processed, referenceFiles, demo, classCode, studentName: student?.name, analysisModel });
      if (!sameStudentGroup(student, getStudent())) return;
      const attempt = saveAttempt({ lessonId, result, demo: result.demo });
      setAttemptImages(attempt.id, processed);
      try { await saveAttemptImages(attempt.id, lessonId, processed); }
      catch { showToast("Kết quả đã lưu nhưng ảnh chưa lưu được vào thư mục lịch sử trên thiết bị.", "error"); }
      try {
        const sync = await publishAttempt(attempt, processed);
        if (sync.synced && sync.imagesSynced) showToast(`Đã gửi kết quả và ${sync.imageCount} ảnh tới lớp ${attempt.classCode}.`, "success");
        else if (sync.synced) showToast("Đã gửi kết quả nhưng ảnh chưa đồng bộ được với giáo viên.", "error");
      } catch {
        showToast("Kết quả vẫn được lưu trên máy nhưng chưa đồng bộ được với giáo viên.", "error");
      }
      if (zone.isConnected && sameStudentGroup(student, getStudent())) {
        sessionStorage.setItem("circuitcoach.latest-result", JSON.stringify(result));
        location.hash = `#/result/${attempt.id}`;
      }
    } catch (error) {
      errorBox.innerHTML = `<strong>Chưa thể phân tích mạch</strong><p>${escapeHtml(error.message)}</p>`;
      errorBox.hidden = false;
    } finally { busy = false; loading.hidden = true; modelSelect.disabled = demo; renderPhotoQuality(); }
  });

  getHealth().then((health) => {
    if (!zone.isConnected) return;
    if (Array.isArray(health.analysisModels) && health.analysisModels.length > 1) {
      modelSelect.replaceChildren(...health.analysisModels.map(model =>
        new Option(model === health.analyzeModel ? `${model} (mặc định)` : model, model)));
      modelSelect.value = health.analyzeModel;
      modelField.hidden = false;
    }
    if (!health.openaiConfigured) {
      setDemo(true);
      showToast("OpenAI chưa được cấu hình; CircuitCoach đã bật chế độ demo.");
    }
  }).catch(() => {
    if (!zone.isConnected) return;
    setDemo(true);
    showToast("Backend chưa kết nối; CircuitCoach đã bật chế độ demo trên trình duyệt.");
  });
  loadReferenceImages();
  loadApprovedReferences();
  void mountLessonAiReminders(root.querySelector(".lesson-ai-reminders"), { lessonId, student });
  mountLessonSampleGallery(root.querySelector("#lesson-sample-gallery"), { lessonId, classCode, student });
}
