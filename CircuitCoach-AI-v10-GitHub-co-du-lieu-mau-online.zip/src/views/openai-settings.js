import { fetchOpenAISettings, getBrowserSession, saveOpenAIKey } from "../services/classroom.js";
import { appShell, emptyState } from "./shared.js";

const sourceLabels = {
  custom: "Đang dùng khóa nhập trong ứng dụng.",
  default: "Đang dùng khóa mặc định.",
  unconfigured: "Chưa có khóa OpenAI.",
};

export function renderOpenAISettings(root) {
  const session = getBrowserSession();
  if (!session?.localOpenAISettings && !session?.browserOpenAISettings) {
    root.innerHTML = appShell(emptyState("Cấu hình OpenAI", "Cấu hình khóa OpenAI hiện chưa khả dụng.",
      '<a class="btn btn-primary" href="#/lessons">Về bài học</a>'), "settings");
    return;
  }
  root.innerHTML = appShell(`<section class="panel openai-settings" aria-labelledby="settings-title">
    <h1 id="settings-title">Cấu hình OpenAI</h1>
    <p class="muted">${session.localOpenAISettings
      ? "Khóa này dùng chung cho CircuitCoach trên máy này."
      : "Khóa riêng áp dụng cho phiên trình duyệt này. Khi chưa lưu khóa riêng hoặc sau khi đăng xuất, ứng dụng dùng khóa mặc định."}</p>
    <p data-openai-source role="status">Đang tải cấu hình…</p>
    <form method="post" autocomplete="off">
      <label>Khóa API OpenAI mới
        <input type="password" maxlength="512" required spellcheck="false" autocapitalize="off" placeholder="sk-…" />
      </label>
      <div class="reference-library-actions">
        <button class="btn btn-primary" type="submit" disabled>Lưu khóa</button>
        <button class="btn btn-secondary" type="button" data-use-default disabled>Dùng khóa mặc định</button>
      </div>
    </form>
    <p data-openai-message role="status"></p>
  </section>`, "settings");
  const section = root.querySelector(".openai-settings");
  const form = section.querySelector("form");
  const input = form.querySelector("input");
  const submit = form.querySelector('[type="submit"]');
  const useDefault = form.querySelector("[data-use-default]");
  const source = section.querySelector("[data-openai-source]");
  const message = section.querySelector("[data-openai-message]");
  let settings;
  let saving = false;

  function updateForm() {
    if (settings) source.textContent = sourceLabels[settings.keySource];
    input.disabled = !settings || saving;
    submit.disabled = !settings || saving;
    useDefault.disabled = settings?.keySource !== "custom" || saving;
  }

  async function save(apiKey) {
    if (!settings || saving) return;
    saving = true;
    updateForm();
    message.textContent = "Đang lưu…";
    try {
      settings = await saveOpenAIKey(apiKey);
      form.reset();
      message.textContent = settings.keySource === "unconfigured"
        ? "Đã bỏ khóa đã nhập. Hãy nhập khóa mới để sử dụng AI."
        : "Đã lưu. Áp dụng từ yêu cầu AI tiếp theo.";
    } catch (error) {
      message.textContent = error.message;
    } finally {
      saving = false;
      updateForm();
    }
  }

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const apiKey = input.value.trim();
    if (apiKey) void save(apiKey);
    else {
      message.textContent = "Hãy nhập khóa API OpenAI.";
      input.focus();
    }
  });
  useDefault.addEventListener("click", () => void save(""));
  updateForm();
  fetchOpenAISettings().then((data) => {
    settings = data;
    updateForm();
  }).catch((error) => {
    source.textContent = error.message;
  });
}
