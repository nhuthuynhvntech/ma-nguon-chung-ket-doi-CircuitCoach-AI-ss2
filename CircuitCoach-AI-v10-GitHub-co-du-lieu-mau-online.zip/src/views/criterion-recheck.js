import { STATUS_LABELS } from "../config.js";
import { circuitAnnotation } from "../../server/ai/annotation-policy.js";
import { AI_ERROR_REASONS } from "../data/ai-error-reasons.js";
import { REFERENCE_ERROR_TYPES } from "../data/reference-cases.js";
import { captureFrame, startCamera, stopCamera } from "../services/camera.js";
import { criterionRecheckPhotoUrl, fetchCriterionRechecks, publishCriterionRecheckReference, saveCriterionRecheckReview, submitCriterionRecheck } from "../services/classroom.js";
import { prepareImage } from "../services/image.js";
import { escapeHtml, icon } from "./shared.js";
import { createPhotoViewer, drawPhotoAnnotations, mountPhotoAnnotationEditor, photoAnnotationEditor } from "./photo-tools.js";

export function renderCriterionRecheck(problem) {
  return `<section class="criterion-recheck" data-criterion-recheck="${escapeHtml(problem.id || problem.criterionId)}" aria-label="Kiểm tra lại ${escapeHtml(problem.label)}">
    <div class="criterion-recheck-actions">
      <button type="button" class="btn btn-secondary" data-recheck-camera>${icon("camera", 17)} Chụp ảnh kiểm tra lại</button>
      <button type="button" class="btn btn-secondary" data-recheck-upload>${icon("upload", 17)} Tải ảnh kiểm tra lại</button>
      <input type="file" accept="image/jpeg,image/png,image/webp" data-recheck-file hidden />
      <button type="button" class="btn btn-ghost" data-recheck-retry hidden>Thử lại ảnh này</button>
    </div>
    <p class="classroom-sync-note" data-recheck-message role="status"></p>
    <div data-recheck-results></div>
  </section>`;
}

function recheckStatus(check) {
  return check.ruleEvidence?.physicalCheckRequired ? "Cần kiểm tra trực tiếp" : STATUS_LABELS[check.status] || "Chưa xác định";
}

function recheckMarker(check) {
  const marker = circuitAnnotation(check, 1);
  if (!marker) return "";
  const { x, y, width, height } = marker.region;
  return `<span class="annotation-box" data-annotation-group="wiring" data-annotation-kind="${marker.kind}" aria-hidden="true"
    style="left:${x}%;top:${y}%;width:${width}%;height:${height}%"></span>`;
}

const recheckVerdictLabels = { correct: "AI đúng", incorrect: "AI sai", uncertain: "Chưa chắc" };
const recheckPhotoLabels = { correct: "Đúng", incorrect: "Có lỗi", uncertain: "Chưa xác định" };

function reviewOptions(labels, selected, placeholder) {
  return `<option value="">${placeholder}</option>` + Object.entries(labels).map(([id, label]) =>
    `<option value="${id}"${id === selected ? " selected" : ""}>${escapeHtml(label)}</option>`).join("");
}

function recheckReviewForm(entry, imageUrl) {
  const review = entry.teacherReview || {};
  return `<details class="criterion-review" data-recheck-review-panel>
    <summary>Đánh giá AI và khoanh vùng${review.aiVerdict ? ` · ${escapeHtml(recheckVerdictLabels[review.aiVerdict])}` : ""}</summary>
    <form class="teacher-comment-form" data-recheck-review="${escapeHtml(entry.id)}" data-image-url="${imageUrl}">
      <fieldset class="criterion-review-fields">
        <label>Đánh giá kết quả AI<select name="aiVerdict" required>${reviewOptions(recheckVerdictLabels, review.aiVerdict, "Chọn đánh giá")}</select></label>
        <label>Thực tế trên ảnh<select name="photoLabel" required>${reviewOptions(recheckPhotoLabels, review.photoLabel, "Chọn nhãn ảnh")}</select></label>
        <label data-ai-error-reason hidden>Lý do AI sai<select name="aiErrorReason">${reviewOptions(AI_ERROR_REASONS, review.aiErrorReason, "Chọn lý do")}</select></label>
        <label data-photo-error-type hidden>Loại lỗi của mạch<select name="errorType">${reviewOptions(REFERENCE_ERROR_TYPES, review.errorType, "Chọn loại lỗi")}</select></label>
        <label>Dấu hiệu để AI đối chiếu<textarea name="evidence" rows="2" maxlength="300" placeholder="Ví dụ: Chén phản xạ của cathode nối về GND.">${escapeHtml(review.evidence || "")}</textarea></label>
        ${photoAnnotationEditor()}
        <div class="criterion-recheck-actions">
          <button type="submit" class="btn btn-secondary" value="save">Lưu đánh giá</button>
          <button type="submit" class="btn btn-primary" value="reference">Đưa vào kho tham chiếu chung</button>
        </div>
      </fieldset>
      <p class="muted" data-recheck-review-status role="status">${entry.referenceId ? "Ảnh đã có trong kho tham chiếu." : ""}</p>
    </form>
  </details>`;
}

function recheckEntryMarkup(entry, attempt, { editable = false } = {}) {
  const { check } = entry;
  const url = escapeHtml(criterionRecheckPhotoUrl(attempt.id, attempt.classCode, entry.id));
  const time = new Date(entry.createdAt).toLocaleString("vi-VN");
  const commentTime = entry.teacherCommentAt ? new Date(entry.teacherCommentAt).toLocaleString("vi-VN") : "";
  const photo = `<img src="${url}" alt="Ảnh kiểm tra lại ${escapeHtml(check.label)}" width="86" height="68" loading="lazy" />`;
  const review = entry.teacherReview || {};
  const marks = review.annotations || [];
  const commentId = `recheck-comment-${escapeHtml(entry.id)}`;
  const comment = editable ? `<form class="teacher-comment-form criterion-recheck-teacher-comment" data-recheck-comment="${escapeHtml(entry.id)}" data-comment-version="${entry.teacherCommentVersion ?? 0}">
    <label for="${commentId}">Nhận xét ảnh này</label>
    <textarea id="${commentId}" name="comment" maxlength="1000" rows="2" placeholder="Ghi nhận xét về chi tiết trong ảnh.">${escapeHtml(entry.teacherComment || "")}</textarea>
    <div><small role="status">${commentTime && entry.teacherComment ? `Đã lưu ${escapeHtml(commentTime)}` : ""}</small>
      <button type="submit" class="btn btn-primary">Lưu nhận xét ảnh</button></div>
  </form>` : entry.teacherComment ? `<div class="criterion-recheck-feedback"><b>Nhận xét của giáo viên</b>
    <p>${escapeHtml(entry.teacherComment)}</p>
    <small>${escapeHtml([entry.teacherCommentBy, commentTime].filter(Boolean).join(" · "))}</small>
  </div>` : "";
  return `<article class="criterion-recheck-entry status-${escapeHtml(check.status)}">
    ${editable ? `<button class="criterion-recheck-photo" type="button" data-recheck-teacher-photo data-recheck-annotations="${escapeHtml(JSON.stringify(marks))}" aria-label="Phóng to ảnh kiểm tra lại">${photo}</button>`
      : marks.length || recheckMarker(check) ? `<button class="criterion-recheck-photo" type="button" data-recheck-student-photo="${escapeHtml(entry.id)}" aria-label="Xem ảnh và vùng đánh dấu">${photo}</button>`
      : `<a class="criterion-recheck-photo" href="${url}" target="_blank" rel="noopener" aria-label="Phóng to ảnh kiểm tra lại">${photo}</a>`}
    <div><strong>${editable ? `${escapeHtml(check.label)} · ` : ""}${escapeHtml(recheckStatus(check))}</strong>
      <small>${escapeHtml(time)}</small>
      <p>${escapeHtml(check.evidence)}</p>
      ${!editable && review.aiVerdict ? `<p><b>Giáo viên đánh giá</b> · ${escapeHtml(recheckVerdictLabels[review.aiVerdict])}
        · Ảnh thực tế ${escapeHtml(recheckPhotoLabels[review.photoLabel])}</p>` : ""}${comment}</div>
    ${editable ? recheckReviewForm(entry, url) : ""}
  </article>`;
}

export function renderTeacherRechecks(entries, attempt) {
  if (!entries.length) return '<p class="muted">Nhóm chưa gửi ảnh kiểm tra lại.</p>';
  return `<div class="criterion-recheck-history">
    ${entries.map(entry => recheckEntryMarkup(entry, attempt, { editable: true })).join("")}
  </div>`;
}

export function mountTeacherRecheckReviews(container, entries, attempt, onEdit) {
  const byId = new Map(entries.map(entry => [entry.id, entry]));
  for (const form of container.querySelectorAll("[data-recheck-review]")) {
    const entry = byId.get(form.dataset.recheckReview);
    const status = form.querySelector("[data-recheck-review-status]");
    const fieldset = form.querySelector("fieldset");
    const details = form.closest("details");
    const editor = mountPhotoAnnotationEditor(form.querySelector("[data-annotation-editor]"));
    const { aiVerdict, photoLabel, aiErrorReason, errorType, evidence } = form.elements;
    let version = entry.teacherReviewVersion || 0;
    function setConditionalSelect(select, visible) {
      select.closest("label").hidden = !visible;
      select.disabled = !visible;
      select.required = visible;
    }
    function updateFields() {
      setConditionalSelect(aiErrorReason, aiVerdict.value === "incorrect");
      setConditionalSelect(errorType, photoLabel.value === "incorrect");
      evidence.required = photoLabel.value === "incorrect" && errorType.value === "other";
    }
    updateFields();
    details.addEventListener("toggle", () => {
      if (!details.open) return;
      void editor.show(form.dataset.imageUrl, { remember: true, marks: entry.teacherReview?.annotations }).catch(() => {
        status.textContent = "Chưa tải được ảnh để đánh dấu.";
      });
    });
    for (const event of ["input", "change", "annotationchange"]) form.addEventListener(event, () => {
      form.dataset.dirty = "";
      updateFields();
      onEdit();
    });
    form.addEventListener("submit", async event => {
      event.preventDefault();
      if (fieldset.disabled) return;
      const publishing = event.submitter?.value === "reference";
      if (publishing && !["correct", "incorrect"].includes(photoLabel.value)) {
        status.textContent = "Ảnh tham chiếu cần nhãn thực tế Đúng hoặc Có lỗi.";
        return;
      }
      const fields = { aiVerdict: aiVerdict.value, photoLabel: photoLabel.value, aiErrorReason: aiErrorReason.value,
        errorType: errorType.value, evidence: evidence.value, annotations: editor.marks() };
      const scope = { attemptId: attempt.id, classCode: attempt.classCode, recheckId: entry.id };
      const changed = form.hasAttribute("data-dirty") || !version;
      form.dataset.dirty = "";
      onEdit();
      fieldset.disabled = true;
      status.textContent = publishing ? "Đang lưu vào kho tham chiếu…" : "Đang lưu đánh giá…";
      try {
        if (changed || !publishing) {
          const saved = await saveCriterionRecheckReview({ ...scope, ...fields, version });
          version = saved.teacherReviewVersion;
          entry.teacherReview = saved.teacherReview;
          const image = form.closest(".criterion-recheck-entry").querySelector("[data-recheck-teacher-photo]");
          image.dataset.recheckAnnotations = JSON.stringify(saved.teacherReview.annotations);
          details.querySelector("summary").textContent = `Đánh giá AI và khoanh vùng · ${recheckVerdictLabels[saved.teacherReview.aiVerdict]}`;
        }
        delete form.dataset.dirty;
        if (publishing) {
          const published = await publishCriterionRecheckReference({ ...scope, version });
          entry.referenceId = published.id;
          status.textContent = "Đã lưu ảnh vào kho tham chiếu chung.";
        } else status.textContent = entry.referenceId
          ? "Đã lưu đánh giá. Bấm Đưa vào kho tham chiếu chung để cập nhật ảnh mẫu."
          : "Đã lưu đánh giá và vùng khoanh.";
      } catch (error) {
        status.textContent = error.message;
      } finally {
        fieldset.disabled = false;
        onEdit();
      }
    });
  }
}

export function mountCriterionRechecks(root, attempt, onChange) {
  const panels = [...root.querySelectorAll("[data-criterion-recheck]")];
  if (!panels.length) return;
  const controller = new AbortController();
  const records = new Map();
  const dialog = document.createElement("dialog");
  dialog.className = "camera-dialog";
  dialog.innerHTML = `<div class="dialog-head"><h2 id="criterion-camera-title">Chụp ảnh kiểm tra lại</h2>
    <button type="button" class="icon-button" data-close-recheck-camera aria-label="Đóng camera">${icon("x", 22)}</button></div>
    <video playsinline muted aria-label="Xem trước ảnh camera"></video>
    <p class="camera-help">Hướng camera vào chi tiết của tiêu chí đang kiểm tra.</p>
    <button type="button" class="btn btn-primary btn-full" data-take-recheck-photo disabled>${icon("camera", 18)} Chụp và kiểm tra</button>`;
  dialog.setAttribute("aria-labelledby", "criterion-camera-title");
  root.append(dialog);
  const video = dialog.querySelector("video");
  const shutter = dialog.querySelector("[data-take-recheck-photo]");
  let camera;
  let photoViewer;
  root.addEventListener("click", event => {
    const button = event.target.closest("[data-recheck-student-photo]");
    const entry = button && records.get(button.dataset.recheckStudentPhoto);
    if (!entry) return;
    if (!photoViewer) {
      photoViewer = createPhotoViewer({ renderOverlay(layer, photoEntry) {
        drawPhotoAnnotations(layer, photoEntry.teacherReview?.annotations || []);
        layer.insertAdjacentHTML("beforeend", recheckMarker(photoEntry.check));
      } });
      root.append(photoViewer.element);
    }
    const image = button.querySelector("img");
    const marker = circuitAnnotation(entry.check, 1);
    const caption = marker?.kind === "review" ? "Nét đứt · Vùng cần xem lại"
      : marker ? "Nét liền · Vùng có dấu hiệu lỗi" : "";
    photoViewer.open(image.src, image.alt, entry, caption);
  }, { signal: controller.signal });

  function closeCamera() {
    camera?.controller.abort();
    camera = undefined;
    stopCamera(video);
    if (dialog.open) dialog.close();
  }
  dialog.querySelector("[data-close-recheck-camera]").addEventListener("click", closeCamera);
  dialog.addEventListener("close", () => { if (!dialog.open) closeCamera(); });
  shutter.addEventListener("click", async () => {
    const selected = camera;
    if (!selected || !video.videoWidth) return;
    shutter.disabled = true;
    try {
      const photo = await captureFrame(video);
      if (camera !== selected) return;
      closeCamera();
      void selected.onPhoto(photo);
    } catch (error) {
      if (camera !== selected) return;
      closeCamera();
      selected.onError(error.message);
    }
  });

  function renderResults(panel) {
    const entries = [...records.values()].filter(entry => entry.criterionId === panel.dataset.criterionRecheck)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt) || b.id.localeCompare(a.id));
    const [latest, ...earlier] = entries;
    if (!latest) return;
    const card = panel.closest(".check-card");
    const original = card?.querySelector("[data-original-check-status]");
    if (original && !original.textContent.startsWith("Ban đầu · ")) original.prepend("Ban đầu · ");
    const badge = card?.querySelector("[data-recheck-badge]");
    if (badge) {
      badge.textContent = `Kiểm tra lại · ${recheckStatus(latest.check)}`;
      badge.dataset.status = latest.check.status;
      badge.hidden = false;
    }
    panel.querySelector("[data-recheck-results]").innerHTML = `<div class="criterion-recheck-history">
      <h3>Kết quả từ ảnh kiểm tra lại</h3>
      ${recheckEntryMarkup(latest, attempt)}
      ${earlier.length ? `<details><summary>Các lần kiểm tra lại trước (${earlier.length})</summary>
        ${earlier.map(entry => recheckEntryMarkup(entry, attempt)).join("")}</details>` : ""}
    </div>`;
  }

  for (const panel of panels) {
    const fileInput = panel.querySelector("[data-recheck-file]");
    const upload = panel.querySelector("[data-recheck-upload]");
    const take = panel.querySelector("[data-recheck-camera]");
    const retry = panel.querySelector("[data-recheck-retry]");
    const message = panel.querySelector("[data-recheck-message]");
    let selectedPhoto;
    let busy = false;
    const showError = text => { message.textContent = text; message.classList.add("warning"); };
    async function analyze(photo) {
      if (!photo || busy || controller.signal.aborted) return;
      selectedPhoto = photo;
      busy = true;
      take.disabled = upload.disabled = true;
      retry.hidden = true;
      message.classList.remove("warning");
      message.textContent = "Đang kiểm tra tiêu chí từ ảnh mới…";
      try {
        const prepared = await prepareImage(photo);
        if (controller.signal.aborted) return;
        const local = ["127.0.0.1", "localhost"].includes(location.hostname);
        const signal = AbortSignal.any([controller.signal, AbortSignal.timeout(local ? 90_000 : 75_000)]);
        const recheck = await submitCriterionRecheck({ attemptId: attempt.id, classCode: attempt.classCode,
          criterionId: panel.dataset.criterionRecheck, photo: prepared, signal });
        if (controller.signal.aborted) return;
        records.set(recheck.id, recheck);
        renderResults(panel);
        onChange([...records.values()]);
        message.textContent = "Đã lưu ảnh và kết quả kiểm tra lại.";
      } catch (error) {
        if (controller.signal.aborted) return;
        showError(error.name === "TimeoutError" ? "AI chưa kịp kiểm tra ảnh. Em có thể thử lại." : error.message);
        retry.hidden = false;
      } finally {
        busy = false;
        take.disabled = upload.disabled = false;
      }
    }
    upload.addEventListener("click", () => fileInput.click());
    fileInput.addEventListener("change", () => {
      const [photo] = fileInput.files;
      fileInput.value = "";
      void analyze(photo);
    });
    retry.addEventListener("click", () => void analyze(selectedPhoto));
    take.addEventListener("click", async () => {
      if (busy || dialog.open) return;
      const selected = { controller: new AbortController(), onPhoto: analyze, onError: showError };
      camera = selected;
      shutter.disabled = true;
      dialog.showModal();
      try {
        await startCamera(video, { signal: selected.controller.signal });
        if (camera === selected) shutter.disabled = false;
      } catch {
        if (camera !== selected) return;
        closeCamera();
        showError("Chưa mở được camera. Em có thể tải ảnh từ thiết bị.");
      }
    });
  }

  void fetchCriterionRechecks(attempt.id, attempt.classCode, controller.signal).then(entries => {
    if (controller.signal.aborted) return;
    for (const entry of entries) records.set(entry.id, entry);
    for (const panel of panels) renderResults(panel);
    onChange([...records.values()]);
  }).catch(() => {});
  return () => { controller.abort(); closeCamera(); dialog.remove(); photoViewer?.element.remove(); };
}
