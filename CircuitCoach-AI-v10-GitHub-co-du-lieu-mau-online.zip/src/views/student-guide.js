function guideDescription({ next }) {
  switch (next.type) {
    case "unsafe":
      return "Giáo viên đã ghi nhận nguy cơ ở lượt gần nhất. Giữ nguồn ngắt và xem phản hồi trước khi sửa.";
    case "safety_review":
      return "Lượt gần nhất còn điểm an toàn cần làm rõ. Giữ nguồn ngắt và nhờ giáo viên kiểm tra lại.";
    case "check":
      return next.source === "teacher"
        ? `Giáo viên đánh dấu tiêu chí “${next.label}” cần sửa. Giữ nguồn ngắt và đối chiếu với hướng dẫn lắp.`
        : `AI gợi ý kiểm tra lại “${next.label}”. Giữ nguồn ngắt và đối chiếu với mạch mẫu.`;
    case "evidence":
      return `Chưa đủ bằng chứng về “${next.label}”. Em có thể chụp cận cảnh để thấy rõ linh kiện và hai đầu dây liên quan.`;
    case "ai_review":
      return "Giáo viên đánh dấu kết quả AI ở lượt gần nhất cần xem lại. Mở phản hồi để biết điểm cần làm rõ.";
    case "teacher_review":
      return "Xem lượt làm gần nhất. Hãy nhờ giáo viên kiểm tra trực tiếp mạch hiện tại trước khi cấp nguồn.";
    default:
      return "Xem lượt làm gần nhất để ôn lại cách lắp. Nếu em lắp hoặc sửa mạch, hãy nhờ giáo viên kiểm tra lại.";
  }
}

function addGuideText(panel, tag, text) {
  const element = document.createElement(tag);
  element.textContent = text;
  panel.append(element);
}

export function renderStudentGuide(panel, { guide, lesson, message, onOpenLink }) {
  panel.replaceChildren();
  addGuideText(panel, "h3", "Bước tiếp theo của nhóm");
  if (message) {
    addGuideText(panel, "p", message);
    return;
  }
  if (guide) {
    addGuideText(panel, "p", `${guide.lessonTitle} · ${guide.attemptCount} lượt gần đây`);
    addGuideText(panel, "p", guideDescription(guide));
    if (guide.next.repeated) addGuideText(panel, "p", `Cùng điểm này cần xem lại ở ${guide.next.repeated} lượt trước.`);
    if (guide.improvedLabel) {
      addGuideText(panel, "p", `Tiến bộ được giáo viên ghi nhận qua nhãn: ${guide.improvedLabel}.`);
    }
    if (guide.teacherComment) {
      const details = document.createElement("details");
      addGuideText(details, "summary", "Nhận xét ở lượt gần nhất");
      addGuideText(details, "p", guide.teacherComment);
      panel.append(details);
    }
  } else {
    addGuideText(panel, "p", lesson
      ? `Chưa có lượt làm thật đã đồng bộ cho bài ${lesson.title}. Em có thể bắt đầu bằng ảnh toàn cảnh mạch.`
      : "Nhóm chưa có lượt làm thật đã đồng bộ. Chọn một bài và gửi ảnh mạch để nhận nhắc nhở theo lịch sử.");
  }

  const link = document.createElement("a");
  link.className = "text-button";
  link.textContent = guide ? "Xem lượt làm gần nhất" : lesson ? "Mở trang gửi ảnh" : "Chọn bài học";
  link.href = guide ? "#/result/" + encodeURIComponent(guide.latestAttemptId)
    : lesson ? "#/analyzer/" + lesson.id : "#/lessons";
  link.addEventListener("click", onOpenLink);
  panel.append(link);
}
