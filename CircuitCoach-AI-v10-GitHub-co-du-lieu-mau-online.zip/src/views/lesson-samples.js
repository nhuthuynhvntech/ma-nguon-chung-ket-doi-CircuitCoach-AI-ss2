import { getLesson, lessons } from "../data/lessons.js";
import {
  fetchLessonSamples, getTeacherClassCode, isValidClassCode, lessonSampleUrl,
  setLessonSampleVisibility, uploadLessonSample,
} from "../services/classroom.js";
import { prepareImage } from "../services/image.js";
import { enterStudentGroup } from "../services/storage.js";
import { appShell, escapeHtml, icon } from "./shared.js";
import { createPhotoViewer } from "./photo-tools.js";

export function mountLessonSampleGallery(section, { classCode, lessonId, manage = false, student }) {
  const scope = { classCode, lessonId, manage };
  section.innerHTML = `
    ${manage ? `
      <form class="lesson-sample-form">
        <fieldset disabled>
          <legend>Tải ảnh mạch thật</legend>
          <label>Tên ảnh<input name="title" maxlength="100" placeholder="Ví dụ: Toàn cảnh mạch LED" required /></label>
          <label>Chú thích <span>(không bắt buộc)</span><textarea name="caption" rows="2" maxlength="280" placeholder="Chi tiết để học sinh quan sát"></textarea></label>
          <label>Chọn tệp ảnh<input name="image" type="file" accept="image/jpeg,image/png,image/webp" required /></label>
          <p>Ảnh xuất hiện khi học sinh trong lớp mở bài. Chọn ảnh rõ và tránh thông tin cá nhân.</p>
          <button class="btn btn-primary" type="submit">${icon("upload", 16)} Tải ảnh mẫu</button>
        </fieldset>
      </form>` : `
      <h2>Thư viện ảnh mẫu</h2>
      <p>Ảnh mạch thật do giáo viên của lớp tải lên. Nhấn vào ảnh để xem chi tiết.</p>`}
    <p class="lesson-sample-status" role="status"></p>
    <button class="btn btn-ghost lesson-sample-retry" type="button" hidden>Thử lại</button>
    <div class="lesson-sample-grid"></div>`;
  const grid = section.querySelector(".lesson-sample-grid");
  const status = section.querySelector(".lesson-sample-status");
  const retry = section.querySelector(".lesson-sample-retry");
  const form = section.querySelector("form");
  const fieldset = form?.querySelector("fieldset");
  const viewer = createPhotoViewer();
  section.append(viewer.element);
  let photos = [];
  let busy = false;
  let authorized = false;
  let reconnect = false;

  function updateControls() {
    if (fieldset) fieldset.disabled = !authorized || busy;
    retry.disabled = busy;
    grid.querySelectorAll("[data-visibility]").forEach((button) => { button.disabled = busy; });
  }

  function renderPhotos() {
    grid.innerHTML = photos.map((photo, index) => `
      <article class="lesson-sample-photo${photo.hiddenAt ? " is-hidden" : ""}">
        <button class="lesson-sample-thumbnail" data-view-photo="${index}" type="button" aria-label="Xem ảnh ${escapeHtml(photo.title)}">
          <img src="${lessonSampleUrl({ classCode, lessonId, photoId: photo.id })}" alt="${escapeHtml(photo.title)}" loading="lazy" decoding="async" />
        </button>
        <div class="lesson-sample-details">
          <strong>${escapeHtml(photo.title)}</strong>
          ${photo.caption ? `<p>${escapeHtml(photo.caption)}</p>` : ""}
          ${manage ? `<button class="text-button" data-visibility="${index}" type="button">${photo.hiddenAt ? "Hiện lại ảnh" : "Ẩn ảnh"}</button>` : ""}
        </div>
      </article>`).join("");
  }

  async function load(message = "") {
    retry.hidden = true;
    reconnect = false;
    try {
      const result = await fetchLessonSamples(scope);
      if (!section.isConnected) return;
      authorized = true;
      photos = result.photos;
      renderPhotos();
      const visibleCount = photos.filter((photo) => !photo.hiddenAt).length;
      const summary = manage
        ? `${visibleCount}/${result.limit} ảnh đang hiển thị`
        : (photos.length ? "" : "Giáo viên chưa tải ảnh mạch thật cho bài này.");
      status.textContent = [message, summary].filter(Boolean).join(" · ");
    } catch (error) {
      authorized = false;
      if (!section.isConnected) return;
      photos = [];
      renderPhotos();
      status.textContent = [message, error.message].filter(Boolean).join(" · ");
      reconnect = Boolean(student && error.status === 401);
      retry.textContent = reconnect ? "Kết nối lại thư viện" : "Thử lại";
      retry.hidden = manage && error.status === 403;
    }
  }

  async function run(action, pendingMessage) {
    if (busy) return;
    busy = true;
    status.textContent = pendingMessage;
    updateControls();
    try {
      await action();
    } catch (error) {
      if (section.isConnected) status.textContent = error.message;
    } finally {
      busy = false;
      if (section.isConnected) updateControls();
    }
  }

  grid.addEventListener("click", (event) => {
    const thumbnail = event.target.closest("[data-view-photo]");
    if (thumbnail) {
      const photo = photos[Number(thumbnail.dataset.viewPhoto)];
      viewer.open(lessonSampleUrl({ classCode, lessonId, photoId: photo.id }), photo.title, [], photo.caption);
    }
    const button = event.target.closest("[data-visibility]");
    if (manage && button) {
      const photo = photos[Number(button.dataset.visibility)];
      const visible = Boolean(photo.hiddenAt);
      void run(async () => {
        await setLessonSampleVisibility(scope, photo.id, visible);
        await load(visible ? "Đã hiện lại ảnh." : "Đã ẩn ảnh với học sinh.");
      }, "Đang lưu…");
    }
  });

  retry.addEventListener("click", () => void run(async () => {
    if (reconnect) await enterStudentGroup(student.name, student.classCode, student.members);
    await load();
  }, "Đang tải ảnh mẫu…"));

  form?.addEventListener("submit", (event) => {
    event.preventDefault();
    if (!authorized || busy) return;
    const data = new FormData(form);
    void run(async () => {
      data.set("image", await prepareImage(data.get("image")));
      await uploadLessonSample(scope, data);
      form.reset();
      await load("Đã tải ảnh mẫu.");
    }, "Đang tải ảnh lên…");
  });

  if (!isValidClassCode(classCode)) {
    status.textContent = manage ? "Mở lớp trong trang Giáo viên để quản lý ảnh." : "Nhập mã lớp trong Hồ sơ để xem ảnh mẫu của lớp.";
    return;
  }
  void run(load, "Đang tải ảnh mẫu…");
}

export function renderLessonSampleManager(root, lessonId) {
  const selected = getLesson(lessonId) || lessons[0];
  const classCode = getTeacherClassCode();
  root.innerHTML = appShell(`
    <section class="lesson-sample-manager">
      <div class="breadcrumb"><a href="#/teacher">Giáo viên</a><span>/</span><strong>Thư viện ảnh mẫu</strong></div>
      <div class="page-head">
        <div><h1>Thư viện ảnh mẫu</h1><p>${classCode ? `Lớp ${escapeHtml(classCode)} · Chọn bài để quản lý ảnh mạch thật.` : "Vào trang Giáo viên và mở lớp để quản lý ảnh."}</p></div>
        <label class="lesson-sample-selector">Bài học
          <select>${lessons.map((lesson) => `<option value="${lesson.id}" ${lesson.id === selected.id ? "selected" : ""}>${escapeHtml(lesson.title)}</option>`).join("")}</select>
        </label>
      </div>
      <section id="lesson-sample-manager-gallery" class="lesson-samples"></section>
    </section>`, "teacher");
  root.querySelector(".lesson-sample-selector select").addEventListener("change", (event) => {
    location.hash = `#/lesson-samples/${event.target.value}`;
  });
  mountLessonSampleGallery(root.querySelector("#lesson-sample-manager-gallery"), { classCode, lessonId: selected.id, manage: true });
}
