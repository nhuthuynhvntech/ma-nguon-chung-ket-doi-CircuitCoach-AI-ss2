import { TEACHER_VERIFICATION_OPTIONS } from "../config.js";
import { STATUS_LABELS } from "../services/teacher-dashboard.js";
import { escapeHtml, icon } from "./shared.js";

const timeFormatter = new Intl.DateTimeFormat("vi-VN", { hour: "2-digit", minute: "2-digit", day: "2-digit", month: "2-digit" });

function barWidth(count, maximum) {
  return `${Math.round((count / Math.max(1, maximum)) * 100)}%`;
}

export function renderTeacherReport({ report, classCode, teacherUsername, refreshedAt }) {
  const generatedAt = report.generatedAt ? timeFormatter.format(new Date(report.generatedAt)) : "";
  const maxStatus = Math.max(1, ...Object.values(report.statusCounts));
  const statusRows = Object.entries(report.statusCounts).map(([id, count]) => `<div class="report-bar-row"><div><span class="status-dot status-${id}"></span><b>${escapeHtml(STATUS_LABELS[id] || id)}</b></div><div class="report-bar"><i style="width:${barWidth(count, maxStatus)}"></i></div><strong>${count}</strong></div>`).join("");
  const verificationCards = Object.entries(TEACHER_VERIFICATION_OPTIONS).map(([id, label]) => `<article class="report-verification-item is-${id}"><span>${escapeHtml(label)}</span><strong>${report.verificationCounts[id] || 0}</strong></article>`).join("");
  const lessonRows = report.lessons.length
    ? report.lessons.map((lesson) => `<tr><td><b>${escapeHtml(lesson.title)}</b></td><td>${lesson.groups}</td><td>${lesson.attempts}</td><td>${lesson.passed}</td><td>${lesson.awaiting}</td><td>${lesson.needsReview}</td><td>${lesson.topError ? `${escapeHtml(lesson.topError.label)} (${lesson.topError.count})` : "—"}</td></tr>`).join("")
    : '<tr><td colspan="7">Chưa có dữ liệu bài học.</td></tr>';
  const errorRows = report.commonErrors.length
    ? report.commonErrors.slice(0, 8).map((error) => `<li><span>${escapeHtml(error.label)}</span><div class="report-bar"><i style="width:${barWidth(error.count, report.commonErrors[0].count)}%"></i></div><b>${error.count} nhóm</b></li>`).join("")
    : '<li class="report-empty-line">Chưa có lỗi nào trong phạm vi báo cáo.</li>';
  const aiErrorRows = report.aiErrors.map(row => `<tr><td>${escapeHtml(row.lesson)}</td><td>${escapeHtml(row.criterion)}</td>
    <td>${escapeHtml(row.reason)}</td><td>${row.count}</td></tr>`).join("") || '<tr><td colspan="4">Chưa có nguyên nhân AI sai đã lưu.</td></tr>';
  const recentRows = report.recentAttempts.length
    ? report.recentAttempts.map((attempt) => `<div class="report-recent-item"><div><b>${escapeHtml(attempt.studentName)}</b><span>${escapeHtml(attempt.lessonTitle)} · ${escapeHtml(timeFormatter.format(new Date(attempt.time)))}</span></div><span>${attempt.teacherVerification ? escapeHtml(TEACHER_VERIFICATION_OPTIONS[attempt.teacherVerification] || "Đã xác nhận") : "Chờ xác nhận"}</span></div>`).join("")
    : '<p class="report-empty-line">Chưa có lượt kiểm tra gần đây.</p>';
  return `<section class="teacher-report" id="teacher-report">
    <header class="report-header">
      <div><p class="eyebrow">BÁO CÁO PHÂN TÍCH · CHỈ GIÁO VIÊN</p><h1>Lớp ${escapeHtml(classCode)}</h1><p>Tổng hợp kết quả AI, mức an toàn và tiến độ của lớp. Báo cáo chỉ hiển thị trong phiên đăng nhập giáo viên.</p></div>
      <div class="report-actions"><span>${escapeHtml(teacherUsername)} · ${escapeHtml(generatedAt)}${refreshedAt ? ` · cập nhật ${timeFormatter.format(refreshedAt)}` : ""}</span><button id="print-teacher-report" class="btn btn-secondary" type="button">${icon("book", 16)} In báo cáo</button></div>
    </header>
    <div class="report-kpis">
      <article><span>${report.totalGroups}</span><small>nhóm đã gửi bài</small></article>
      <article><span>${report.totalAttempts}</span><small>lượt kiểm tra</small></article>
      <article><span>${report.passRate}%</span><small>tỷ lệ nhóm đã đạt</small></article>
      <article><span>${report.verificationRate}%</span><small>nhóm được giáo viên xác nhận</small></article>
    </div>
    <div class="report-grid">
      <section class="report-card"><div class="report-card-head"><div><p class="eyebrow">TRẠNG THÁI LỚP</p><h2>Phân bổ theo trạng thái</h2></div></div><div class="report-bars">${statusRows}</div></section>
      <section class="report-card"><div class="report-card-head"><div><p class="eyebrow">XÁC NHẬN CỦA GIÁO VIÊN</p><h2>Mức độ kiểm chứng</h2></div><span>${report.verificationRate}%</span></div><div class="report-verification-grid">${verificationCards}<article class="report-verification-item is-pending"><span>Chưa xác nhận</span><strong>${report.verificationCounts.pending || 0}</strong></article></div></section>
      <section class="report-card"><div class="report-card-head"><div><p class="eyebrow">AN TOÀN & CHẤT LƯỢNG ẢNH</p><h2>Điểm cần ưu tiên</h2></div></div><div class="report-safety-grid"><article><strong>${report.safety.dangerousGroups}</strong><span>nhóm có lỗi nguy hiểm</span></article><article><strong>${report.safety.safetyIssueGroups}</strong><span>nhóm có tiêu chí an toàn lỗi</span></article><article><strong>${report.safety.unclearGroups}</strong><span>nhóm cần chụp lại</span></article><article><strong>${report.safety.aiErrorsFound}</strong><span>AI bị giáo viên báo sai</span></article></div></section>
      <section class="report-card"><div class="report-card-head"><div><p class="eyebrow">LỖI PHỔ BIẾN</p><h2>Các tiêu chí nhiều nhóm mắc</h2></div></div><ol class="report-error-list">${errorRows}</ol></section>
    </div>
    <section class="report-card report-wide"><div class="report-card-head"><div><p class="eyebrow">HIỆU QUẢ THEO BÀI</p><h2>Tiến độ từng bài học</h2></div></div><div class="report-table-wrap"><table class="report-table"><thead><tr><th>Bài học</th><th>Nhóm</th><th>Lượt</th><th>Đã đạt</th><th>Chờ GV</th><th>Cần xem lại</th><th>Lỗi phổ biến</th></tr></thead><tbody>${lessonRows}</tbody></table></div></section>
    <section class="report-card report-wide"><h2>Nguyên nhân AI sai</h2><div class="report-table-wrap">
      <table class="report-table"><thead><tr><th>Bài học</th><th>Tiêu chí</th><th>Lý do</th><th>Số lượt</th></tr></thead>
      <tbody>${aiErrorRows}</tbody></table></div></section>
    <div class="report-grid">
      <section class="report-card"><div class="report-card-head"><div><p class="eyebrow">HOẠT ĐỘNG GẦN ĐÂY</p><h2>Các lượt kiểm tra mới nhất</h2></div></div><div class="report-recent-list">${recentRows}</div></section>
      <section class="report-card report-note-card"><div class="report-card-head"><div><p class="eyebrow">GHI CHÚ BÁO CÁO</p><h2>Cách đọc số liệu</h2></div></div><p>Tỷ lệ đạt chỉ tính nhóm đã được giáo viên xác nhận AI đúng. Nhóm có lỗi an toàn, ảnh chưa rõ hoặc chờ xác nhận vẫn được tính là chưa đạt.</p><p>Báo cáo sử dụng bộ lọc bài học và thời gian đang chọn. Dữ liệu chỉ tải được bằng tài khoản giáo viên đã đăng nhập.</p><small>Tạo lúc ${escapeHtml(generatedAt)}</small></section>
    </div>
  </section>`;
}
