import { fetchLessonAiReminders } from "../services/classroom.js";
import { escapeHtml } from "./shared.js";

export async function mountLessonAiReminders(section, { lessonId, student, teacherClassCode }) {
  const classCode = student?.classCode || teacherClassCode;
  section.innerHTML = `
    <details open>
      <summary>Lỗi AI cần chú ý</summary>
      <p class="lesson-ai-reminder-status" role="status"></p>
      <ul class="lesson-ai-reminder-list" hidden></ul>
    </details>`;
  const status = section.querySelector(".lesson-ai-reminder-status");
  if (!classCode) {
    status.textContent = "Vào nhóm học sinh hoặc chọn lớp phụ trách để xem phản hồi của giáo viên cho bài này.";
    return;
  }
  status.textContent = "Đang tải phản hồi của giáo viên…";
  try {
    const { reminders } = await fetchLessonAiReminders({ lessonId, classCode, studentName: student?.name });
    if (!section.isConnected) return;
    if (!reminders.length) {
      status.textContent = `Lớp ${classCode} chưa có lỗi AI được giáo viên ghi nhận cho bài này.`;
      return;
    }
    status.textContent = `Lớp ${classCode} · AI sẽ dùng các lời nhắc dưới đây khi phân tích ảnh mới của bài này.`;
    const list = section.querySelector(".lesson-ai-reminder-list");
    list.innerHTML = reminders.map(({ criterionLabel, reasonLabel, reports, guidance }) => `
      <li>
        <div><strong>${escapeHtml(criterionLabel)}</strong><small>${escapeHtml(reports)} lượt báo sai</small></div>
        <p><b>${escapeHtml(reasonLabel)}.</b> ${escapeHtml(guidance)}</p>
      </li>`).join("");
    list.hidden = false;
  } catch (error) {
    if (!section.isConnected) return;
    status.textContent = error.status === 403
      ? "Phiên lớp chưa xác thực. Hãy mở lại nhóm hoặc lớp để xem phản hồi."
      : "Chưa tải được phản hồi cho bài này. Hãy thử mở lại bài.";
  }
}
