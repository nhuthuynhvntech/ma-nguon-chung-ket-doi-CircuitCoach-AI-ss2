import { getStudent } from "../services/storage.js";
import { getLearningAnalytics } from "../services/analytics.js";
import { getRecommendation } from "../services/recommendation.js";
import { appShell, escapeHtml, icon } from "./shared.js";

export function renderProfile(root) {
  const student = getStudent();
  const analytics = getLearningAnalytics();
  const recommendation = getRecommendation();
  const topics = analytics.topicCounts.length ? analytics.topicCounts.map(([topic, count], index) => `<div class="topic-row"><span><b>${String(index + 1).padStart(2, "0")}</b>${escapeHtml(topic)}</span><strong>${count} lần</strong></div>`).join("") : '<p class="muted">Chưa có vấn đề lặp lại.</p>';
  root.innerHTML = appShell(`
    <section class="profile-page">
      <header class="page-head compact-head"><div><p class="eyebrow">HỒ SƠ HỌC TẬP</p><h1>${escapeHtml(student?.name || "Học sinh")}</h1><p>Xem lịch sử và tiến độ của nhóm đang vào lớp.</p></div><div class="avatar-large">${escapeHtml((student?.name || "H").slice(0, 1).toUpperCase())}</div></header>
      <section class="panel classroom-profile"><div><h2>Nhóm của bạn</h2><p>Để đổi nhóm hoặc lớp, đăng xuất rồi vào lớp bằng tên nhóm và mã lớp tương ứng.</p></div>
      <dl class="profile-group-info"><div><dt>Tên nhóm</dt><dd>${escapeHtml(student?.name || "")}</dd></div><div><dt>Mã lớp</dt><dd>${escapeHtml(student?.classCode || "—")}</dd></div></dl></section>
      <section class="stats-grid"><article><small>Bài đã trải nghiệm</small><strong>${analytics.completedLessons}<span>/${analytics.totalLessons}</span></strong></article><article><small>Số lần kiểm tra</small><strong>${analytics.attempts.length}</strong></article><article><small>Kết quả đã xác nhận</small><strong>${analytics.verification.total}</strong></article><article><small>Accuracy thử nghiệm</small><strong>${analytics.verification.accuracy === null ? "—" : `${analytics.verification.accuracy}%`}</strong><p>${analytics.verification.total ? `${analytics.verification.correct}/${analytics.verification.total} xác nhận đúng` : "Cần dữ liệu giáo viên"}</p></article></section>
      <div class="profile-columns"><section class="panel"><p class="eyebrow">VẤN ĐỀ THƯỜNG GẶP</p><h2>Chủ đề nên chú ý</h2><div class="topic-list">${topics}</div></section><section class="panel focus-panel">${icon("spark", 28)}<p class="eyebrow">GỢI Ý CÁ NHÂN</p><h2>${escapeHtml(recommendation.title)}</h2><p>${escapeHtml(recommendation.detail)}</p><a class="btn btn-primary" href="#/lessons">Chọn bài để luyện ${icon("arrow", 18)}</a></section></div>
    </section>
  `, "profile");
}
