import { clearStudentSession, getStudent, STUDENT_SESSION_KEY } from "./services/storage.js";
import { applyTeacherSession, CLASSROOM_SESSION_CHANGE, fetchBrowserSession, fetchTeacherSession, getBrowserSession, setBrowserSession } from "./services/classroom.js";
import { SESSION_ROLES } from "./data/session-roles.js";
import { renderAbout } from "./views/about.js";
import { renderAdmin } from "./views/admin.js";
import { renderTeacherLearningReport } from "./views/admin-learning.js";
import { renderAiTracking } from "./views/ai-tracking.js";
import { renderAnalyzer } from "./views/analyzer.js";
import { renderAssembly } from "./views/assembly.js";
import { renderHistory } from "./views/history.js";
import { renderLessonHistory } from "./views/lesson-history.js";
import { renderLessonPrompts } from "./views/lesson-prompts.js";
import { renderLessonSampleManager } from "./views/lesson-samples.js";
import { renderOpenAISettings } from "./views/openai-settings.js";
import { renderHome } from "./views/home.js";
import { renderLessons } from "./views/lessons.js";
import { renderProfile } from "./views/profile.js";
import { renderReferences } from "./views/references.js";
import { renderReferenceUpload } from "./views/reference-upload.js";
import { renderResult } from "./views/result.js";
import { renderTeacher } from "./views/teacher.js";
import { appShell, emptyState } from "./views/shared.js";

const teacherPages = new Set(["teacher", "teacher-reports", "references", "reference-upload", "ai-tracking", "lesson-samples"]);
const studentPages = new Set(["result", "history", "lesson-history", "profile"]);

export function createRouter(root) {
  let routeVersion = 0;
  let disposeView;
  let sessionExpiry;

  async function route() {
    const version = ++routeVersion;
    disposeView?.();
    disposeView = undefined;
    const hash = location.hash;
    const [path, id] = hash.replace(/^#\/?/, "").split("/");
    if (path === "admin" && id === "config") {
      location.replace("#/settings");
      return;
    }
    const session = await fetchBrowserSession().catch(() => getBrowserSession());
    if (version !== routeVersion || hash !== location.hash) return;
    setBrowserSession(session);
    clearTimeout(sessionExpiry);
    const remaining = Date.parse(session?.expiresAt) - Date.now();
    if (remaining > 0) sessionExpiry = setTimeout(route, remaining + 200);
    if (session && session.role !== "student" && getStudent()) clearStudentSession();
    const student = getStudent();
    let teacherClassCode = "";
    let teacherSession;
    if (session) {
      teacherSession = session.role === "teacher" ? session : null;
      teacherClassCode = applyTeacherSession(teacherSession);
      const requiredRole = path === "admin" ? "admin" : teacherPages.has(path) && path !== "references" ? "teacher"
        : studentPages.has(path) ? "student" : "";
      if (requiredRole && session.role && session.role !== requiredRole) {
        const active = SESSION_ROLES[session.role];
        root.innerHTML = appShell(emptyState(
          `Trang dành cho ${SESSION_ROLES[requiredRole].label}`,
          `Bạn đang đăng nhập với vai trò ${active.label}. Hãy đăng xuất ở đầu trang để đổi vai trò.`,
          `<a class="btn btn-primary" href="${active.home}">Về trang của bạn</a>`,
        ), path);
        return;
      }
      if (requiredRole && requiredRole !== "student" && !session.role) return renderHome(root, { initialRole: requiredRole, refresh: route });
    } else if (teacherPages.has(path) || (path === "analyzer" && !student)) {
      teacherSession = await fetchTeacherSession().catch(() => undefined);
      if (version !== routeVersion || hash !== location.hash) return;
      if (teacherSession !== undefined) teacherClassCode = applyTeacherSession(teacherSession);
    }
    if (!student && studentPages.has(path)) {
      root.innerHTML = appShell(emptyState(
        "Cần vào nhóm học sinh",
        "Mở nhóm bằng tên và mã lớp để xem lịch sử, kết quả và hồ sơ của nhóm.",
        '<a class="btn btn-primary" href="#/home">Vào nhóm</a>',
      ), path);
      return;
    }
    if (path === "home") return renderHome(root, { refresh: route });
    if (!path) return student ? renderLessons(root) : renderHome(root, { refresh: route });
    if (path === "lessons") return renderLessons(root);
    if (path === "lesson-prompts") return renderLessonPrompts(root, id, { teacherClassCode });
    if (path === "references") {
      const [lessonId, search] = (id || "").split("?");
      const params = new URLSearchParams(search);
      return renderReferences(root, lessonId, {
        manage: ["manage", "class"].includes(params.get("view")),
        role: session?.role || (teacherSession ? "teacher" : null),
        errorType: params.get("error"),
      });
    }
    if (path === "reference-upload") {
      const [lessonId, search] = (id || "").split("?");
      return renderReferenceUpload(root, lessonId, {
        canUpload: session?.role === "teacher" || Boolean(teacherSession),
        presetError: new URLSearchParams(search).get("error"),
      });
    }
    if (path === "analyzer") return renderAnalyzer(root, id, { teacherClassCode });
    if (path === "assembly") {
      disposeView = renderAssembly(root, id);
      return;
    }
    if (path === "result") {
      const isCurrent = () => version === routeVersion && hash === location.hash;
      const dispose = await renderResult(root, id, isCurrent);
      if (isCurrent()) disposeView = dispose;
      else dispose?.();
      return;
    }
    if (path === "history") return renderHistory(root);
    if (path === "lesson-history") return renderLessonHistory(root, id);
    if (path === "profile") return renderProfile(root);
    if (path === "teacher") return renderTeacher(root, teacherSession);
    if (path === "teacher-reports") return renderTeacherLearningReport(root);
    if (path === "lesson-samples") return renderLessonSampleManager(root, id);
    if (path === "ai-tracking" || path === "ai-progress") {
      const [lessonId, search] = (id || "").split("?");
      const days = new URLSearchParams(search).get("days");
      return renderAiTracking(root, { publicView: path === "ai-progress", lessonId, days });
    }
    if (path === "admin") return renderAdmin(root);
    if (path === "settings") return renderOpenAISettings(root);
    if (path === "reviewer") {
      location.replace("#/teacher");
      return;
    }
    if (path === "about") return renderAbout(root);
    location.hash = "#/lessons";
  }
  window.addEventListener("hashchange", route);
  window.addEventListener("focus", async () => {
    const known = getBrowserSession();
    const current = await fetchBrowserSession().catch(() => known);
    if (current?.role !== known?.role || current?.username !== known?.username) void route();
  });
  window.addEventListener("storage", event => {
    const [path] = location.hash.replace(/^#\/?/, "").split("/");
    if (event.key === CLASSROOM_SESSION_CHANGE ||
        (event.key === STUDENT_SESSION_KEY && (studentPages.has(path) || ["home", "lessons", "lesson-prompts", "analyzer"].includes(path)))) void route();
  });
  void route();
  return route;
}
