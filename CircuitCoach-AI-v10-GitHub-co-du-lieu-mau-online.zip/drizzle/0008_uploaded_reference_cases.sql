CREATE TABLE platform_uploaded_reference_cases (
  id TEXT PRIMARY KEY,
  class_code TEXT NOT NULL,
  lesson_id TEXT NOT NULL,
  criterion_id TEXT NOT NULL,
  label TEXT NOT NULL CHECK(label IN ('correct','incorrect')),
  error_type TEXT,
  evidence TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL CHECK(status IN ('pending','approved','rejected','retired')),
  created_by TEXT NOT NULL REFERENCES platform_users(id),
  created_at TEXT NOT NULL,
  reviewed_by TEXT REFERENCES platform_users(id),
  reviewed_at TEXT,
  source_key TEXT NOT NULL,
  CHECK((label='correct' AND error_type IS NULL) OR (label='incorrect' AND error_type IS NOT NULL))
);
--> statement-breakpoint
CREATE INDEX platform_uploaded_reference_cases_scope_idx
  ON platform_uploaded_reference_cases(lesson_id, class_code, status, created_at DESC);
--> statement-breakpoint
CREATE UNIQUE INDEX platform_uploaded_reference_cases_source_idx
  ON platform_uploaded_reference_cases(source_key)
  WHERE status IN ('pending','approved');
--> statement-breakpoint
CREATE VIEW platform_reference_case_catalog AS
SELECT e.id,a.class_code,e.lesson_id,e.attempt_id,e.photo_index,
       l.criterion_id,l.status AS label,l.error_type,l.evidence,l.image_quality,
       e.status,e.created_at,e.reviewed_at,e.source_key,'attempt' AS source
FROM platform_reference_examples e
JOIN classroom_attempts a ON a.id=e.attempt_id
JOIN platform_label_revisions l ON l.id=e.label_revision_id
UNION ALL
SELECT id,class_code,lesson_id,NULL,NULL,criterion_id,label,error_type,evidence,NULL,
       status,created_at,reviewed_at,source_key,'upload'
FROM platform_uploaded_reference_cases;
