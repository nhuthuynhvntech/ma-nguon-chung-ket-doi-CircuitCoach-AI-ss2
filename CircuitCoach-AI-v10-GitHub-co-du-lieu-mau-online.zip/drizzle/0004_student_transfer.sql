CREATE TABLE platform_student_transfers (
 code_hash TEXT PRIMARY KEY,
 owner_hash TEXT NOT NULL UNIQUE,
 expires_at INTEGER NOT NULL
);
