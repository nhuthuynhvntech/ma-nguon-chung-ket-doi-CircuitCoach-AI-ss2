ALTER TABLE classroom_attempts ADD COLUMN local_owner_hash TEXT;
