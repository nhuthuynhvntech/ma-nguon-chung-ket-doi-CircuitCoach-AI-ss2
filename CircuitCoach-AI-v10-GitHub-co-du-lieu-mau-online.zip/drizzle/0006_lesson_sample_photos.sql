CREATE TABLE IF NOT EXISTS platform_lesson_sample_photos (
  id TEXT PRIMARY KEY,
  class_code TEXT NOT NULL,
  lesson_id TEXT NOT NULL,
  title TEXT NOT NULL,
  caption TEXT NOT NULL DEFAULT '',
  created_by TEXT NOT NULL REFERENCES platform_users(id),
  created_at TEXT NOT NULL,
  hidden_at TEXT
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS platform_lesson_sample_photos_scope_idx
  ON platform_lesson_sample_photos(class_code, lesson_id, created_at DESC);
