CREATE TABLE platform_criterion_rechecks (
  id TEXT PRIMARY KEY NOT NULL,
  attempt_id TEXT NOT NULL REFERENCES classroom_attempts(id) ON DELETE CASCADE,
  criterion_id TEXT NOT NULL,
  check_json TEXT NOT NULL CHECK(json_valid(check_json)),
  model TEXT NOT NULL,
  created_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE INDEX platform_criterion_rechecks_attempt_time_idx
  ON platform_criterion_rechecks(attempt_id, created_at DESC, id DESC);
