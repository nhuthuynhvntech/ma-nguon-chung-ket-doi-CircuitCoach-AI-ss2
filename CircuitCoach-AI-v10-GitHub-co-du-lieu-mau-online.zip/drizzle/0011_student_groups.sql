CREATE TABLE platform_student_groups (
  class_code TEXT NOT NULL REFERENCES platform_classes(code),
  group_key TEXT NOT NULL,
  display_name TEXT NOT NULL,
  first_seen_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  PRIMARY KEY(class_code,group_key)
);
