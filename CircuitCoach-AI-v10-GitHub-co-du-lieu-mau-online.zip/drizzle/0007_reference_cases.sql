ALTER TABLE platform_reference_examples ADD COLUMN photo_index INTEGER NOT NULL DEFAULT 0 CHECK(photo_index BETWEEN 0 AND 2);
--> statement-breakpoint
ALTER TABLE platform_reference_examples ADD COLUMN source_key TEXT;
--> statement-breakpoint
CREATE UNIQUE INDEX platform_reference_examples_source_idx
  ON platform_reference_examples(source_key)
  WHERE status IN ('pending', 'approved') AND source_key IS NOT NULL;
--> statement-breakpoint
CREATE INDEX platform_reference_examples_lesson_status_idx
  ON platform_reference_examples(lesson_id, status, created_at DESC);
