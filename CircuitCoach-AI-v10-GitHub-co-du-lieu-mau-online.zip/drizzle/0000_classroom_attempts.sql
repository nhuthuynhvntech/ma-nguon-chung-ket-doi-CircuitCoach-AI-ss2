CREATE TABLE `classroom_attempts` (
  `id` text PRIMARY KEY NOT NULL,
  `class_code` text NOT NULL,
  `student_id` text NOT NULL,
  `student_name` text NOT NULL,
  `created_at` text NOT NULL,
  `payload_json` text NOT NULL,
  `updated_at` text NOT NULL
);
CREATE INDEX `classroom_attempts_class_time_idx` ON `classroom_attempts` (`class_code`, `created_at`);
