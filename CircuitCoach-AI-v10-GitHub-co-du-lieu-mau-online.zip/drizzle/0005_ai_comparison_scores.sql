CREATE TABLE platform_ai_comparison_scores (
 reference_run_id TEXT PRIMARY KEY NOT NULL REFERENCES platform_ai_runs(id),
 labels_json TEXT NOT NULL,
 labels_at TEXT,
 paired INTEGER NOT NULL,
 correct_a INTEGER NOT NULL,
 correct_b INTEGER NOT NULL,
 safety_errors INTEGER NOT NULL,
 missed_a INTEGER NOT NULL,
 missed_b INTEGER NOT NULL
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS platform_ai_runs_comparison_date_idx
 ON platform_ai_runs(lane, completed_at);
