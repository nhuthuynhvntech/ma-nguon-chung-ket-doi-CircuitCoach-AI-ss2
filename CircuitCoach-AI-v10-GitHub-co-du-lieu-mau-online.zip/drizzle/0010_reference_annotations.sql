ALTER TABLE platform_reference_examples
  ADD COLUMN annotations_json TEXT NOT NULL DEFAULT '[]' CHECK(json_valid(annotations_json));
--> statement-breakpoint
ALTER TABLE platform_uploaded_reference_cases
  ADD COLUMN annotations_json TEXT NOT NULL DEFAULT '[]' CHECK(json_valid(annotations_json));
--> statement-breakpoint
DROP VIEW platform_reference_case_catalog;
--> statement-breakpoint
CREATE VIEW platform_reference_case_catalog AS
SELECT e.id,a.class_code,e.lesson_id,e.attempt_id,e.photo_index,
       l.criterion_id,l.status AS label,l.error_type,l.evidence,l.image_quality,
       e.status,e.created_at,e.reviewed_at,e.source_key,'attempt' AS source,e.annotations_json
FROM platform_reference_examples e
JOIN classroom_attempts a ON a.id=e.attempt_id
JOIN platform_label_revisions l ON l.id=e.label_revision_id
UNION ALL
SELECT id,class_code,lesson_id,NULL,NULL,criterion_id,label,error_type,evidence,NULL,
       status,created_at,reviewed_at,source_key,'upload',annotations_json
FROM platform_uploaded_reference_cases;
