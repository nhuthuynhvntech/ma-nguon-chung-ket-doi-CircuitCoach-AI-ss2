ALTER TABLE platform_ai_comparison_scores
  ADD COLUMN metrics_json TEXT CHECK(metrics_json IS NULL OR json_valid(metrics_json));
