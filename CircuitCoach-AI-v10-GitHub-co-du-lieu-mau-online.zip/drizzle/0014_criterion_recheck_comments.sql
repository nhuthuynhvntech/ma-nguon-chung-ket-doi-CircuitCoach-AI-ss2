ALTER TABLE platform_criterion_rechecks ADD COLUMN teacher_comment TEXT NOT NULL DEFAULT '' CHECK(length(teacher_comment) <= 1000);
--> statement-breakpoint
ALTER TABLE platform_criterion_rechecks ADD COLUMN teacher_comment_at TEXT;
--> statement-breakpoint
ALTER TABLE platform_criterion_rechecks ADD COLUMN teacher_comment_by TEXT;
--> statement-breakpoint
ALTER TABLE platform_criterion_rechecks ADD COLUMN teacher_comment_version INTEGER NOT NULL DEFAULT 0;
