CREATE TABLE IF NOT EXISTS platform_users (
 id TEXT PRIMARY KEY, username TEXT NOT NULL COLLATE NOCASE UNIQUE,
 password_hash TEXT NOT NULL, disabled INTEGER NOT NULL DEFAULT 0 CHECK(disabled IN (0,1)),
 created_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS platform_roles (
 user_id TEXT NOT NULL REFERENCES platform_users(id),
 role TEXT NOT NULL CHECK(role IN ('admin','teacher','reviewer','student')),
 PRIMARY KEY(user_id,role)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS platform_sessions (
 token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES platform_users(id),
 expires_at TEXT NOT NULL, created_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS platform_sessions_user_idx ON platform_sessions(user_id);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS platform_class_members (
 class_code TEXT NOT NULL, user_id TEXT NOT NULL REFERENCES platform_users(id),
 membership TEXT NOT NULL CHECK(membership IN ('teacher','student')),
 PRIMARY KEY(class_code,user_id)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS platform_lesson_reviewers (
 lesson_id TEXT NOT NULL, user_id TEXT NOT NULL REFERENCES platform_users(id),
 PRIMARY KEY(lesson_id,user_id)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS platform_lesson_versions (
 id TEXT PRIMARY KEY, lesson_id TEXT NOT NULL, snapshot_json TEXT NOT NULL,
 created_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS platform_label_revisions (
 id TEXT PRIMARY KEY, attempt_id TEXT NOT NULL REFERENCES classroom_attempts(id),
 criterion_id TEXT NOT NULL, author_id TEXT REFERENCES platform_users(id),
 status TEXT NOT NULL CHECK(status IN ('correct','incorrect','uncertain')),
 evidence TEXT NOT NULL DEFAULT '', error_type TEXT, image_quality TEXT,
 confirmation_source TEXT CHECK(confirmation_source IN ('image','physical','legacy')),
 previous_revision_id TEXT REFERENCES platform_label_revisions(id), created_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS platform_labels_attempt_idx ON platform_label_revisions(attempt_id,criterion_id,created_at);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS platform_reference_examples (
 id TEXT PRIMARY KEY, attempt_id TEXT NOT NULL REFERENCES classroom_attempts(id),
 lesson_id TEXT NOT NULL, label_revision_id TEXT NOT NULL REFERENCES platform_label_revisions(id),
 status TEXT NOT NULL CHECK(status IN ('pending','approved','rejected','retired')),
 reviewed_by TEXT REFERENCES platform_users(id), reviewed_at TEXT, created_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS platform_evaluation_sets (
 id TEXT PRIMARY KEY, title TEXT NOT NULL, created_at TEXT NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS platform_evaluation_members (
 set_id TEXT NOT NULL REFERENCES platform_evaluation_sets(id),
 attempt_id TEXT NOT NULL REFERENCES classroom_attempts(id), PRIMARY KEY(set_id,attempt_id)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS platform_ai_runs (
 id TEXT PRIMARY KEY, attempt_id TEXT NOT NULL REFERENCES classroom_attempts(id),
 lane TEXT NOT NULL CHECK(lane IN ('A','B')), configuration_version TEXT NOT NULL,
 retry_key TEXT NOT NULL UNIQUE, status TEXT NOT NULL CHECK(status IN ('pending','running','succeeded','failed')),
 model TEXT NOT NULL, prompt_version TEXT NOT NULL, lesson_version_id TEXT REFERENCES platform_lesson_versions(id),
 result_json TEXT, reference_ids_json TEXT NOT NULL DEFAULT '[]',
 input_tokens INTEGER, output_tokens INTEGER, estimated_cost REAL, duration_ms INTEGER,
 error_code TEXT, created_at TEXT NOT NULL, completed_at TEXT
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS platform_runs_attempt_idx ON platform_ai_runs(attempt_id,lane);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS platform_audit_events (
 id TEXT PRIMARY KEY, actor_id TEXT REFERENCES platform_users(id),
 action TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL,
 before_json TEXT, after_json TEXT, created_at TEXT NOT NULL
);
