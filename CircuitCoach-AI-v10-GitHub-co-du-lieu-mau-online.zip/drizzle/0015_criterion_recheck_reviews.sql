ALTER TABLE platform_criterion_rechecks
  ADD COLUMN teacher_review_json TEXT NOT NULL DEFAULT '{}' CHECK(json_valid(teacher_review_json));
--> statement-breakpoint
ALTER TABLE platform_criterion_rechecks
  ADD COLUMN teacher_review_version INTEGER NOT NULL DEFAULT 0;
--> statement-breakpoint
ALTER TABLE platform_uploaded_reference_cases
  ADD COLUMN source_recheck_id TEXT REFERENCES platform_criterion_rechecks(id);
--> statement-breakpoint
ALTER TABLE platform_uploaded_reference_cases ADD COLUMN ai_error_reason TEXT;
--> statement-breakpoint
CREATE INDEX platform_uploaded_reference_cases_recheck_idx
  ON platform_uploaded_reference_cases(source_recheck_id, status);
--> statement-breakpoint
DROP VIEW platform_reference_case_catalog;
--> statement-breakpoint
CREATE VIEW platform_reference_case_catalog AS
SELECT e.id,a.class_code,e.lesson_id,e.attempt_id,e.photo_index,
       l.criterion_id,l.status AS label,l.error_type,l.evidence,l.image_quality,
       e.status,e.created_at,e.reviewed_at,e.source_key,'attempt' AS source,e.annotations_json,
       NULL AS source_recheck_id,NULL AS ai_error_reason
FROM platform_reference_examples e
JOIN classroom_attempts a ON a.id=e.attempt_id
JOIN platform_label_revisions l ON l.id=e.label_revision_id
UNION ALL
SELECT u.id,u.class_code,u.lesson_id,r.attempt_id,NULL,u.criterion_id,u.label,u.error_type,u.evidence,NULL,
       u.status,u.created_at,u.reviewed_at,u.source_key,'upload',u.annotations_json,u.source_recheck_id,u.ai_error_reason
FROM platform_uploaded_reference_cases u
LEFT JOIN platform_criterion_rechecks r ON r.id=u.source_recheck_id;
