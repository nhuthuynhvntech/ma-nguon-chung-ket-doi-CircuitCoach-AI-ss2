CREATE TABLE platform_classes (
  code TEXT PRIMARY KEY NOT NULL CHECK(length(code) BETWEEN 4 AND 12 AND code NOT GLOB '*[^A-Z0-9]*'),
  created_by TEXT REFERENCES platform_users(id),
  created_at TEXT NOT NULL
);
--> statement-breakpoint
INSERT INTO platform_classes (code, created_at)
SELECT class_code, COALESCE(MIN(created_at), strftime('%Y-%m-%dT%H:%M:%fZ','now'))
FROM (
  SELECT class_code, NULL AS created_at FROM platform_class_members WHERE membership='teacher'
  UNION ALL SELECT class_code, created_at FROM classroom_attempts
  UNION ALL SELECT class_code, created_at FROM platform_lesson_sample_photos
  UNION ALL SELECT class_code, created_at FROM platform_uploaded_reference_cases
)
WHERE length(class_code) BETWEEN 4 AND 12 AND class_code NOT GLOB '*[^A-Z0-9]*'
GROUP BY class_code;
