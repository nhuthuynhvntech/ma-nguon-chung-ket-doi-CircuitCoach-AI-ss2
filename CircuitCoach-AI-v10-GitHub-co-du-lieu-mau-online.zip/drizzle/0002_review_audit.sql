CREATE INDEX IF NOT EXISTS platform_audit_entity_idx
 ON platform_audit_events(entity_type, entity_id, created_at);
--> statement-breakpoint
CREATE TRIGGER IF NOT EXISTS classroom_review_audit
AFTER UPDATE OF payload_json ON classroom_attempts
WHEN json_extract(OLD.payload_json, '$.teacherComment') IS NOT json_extract(NEW.payload_json, '$.teacherComment')
 OR json_extract(OLD.payload_json, '$.teacherLabelsAt') IS NOT json_extract(NEW.payload_json, '$.teacherLabelsAt')
 OR json_extract(OLD.payload_json, '$.teacherVerifiedAt') IS NOT json_extract(NEW.payload_json, '$.teacherVerifiedAt')
 OR json_extract(OLD.payload_json, '$.teacherSafetyCheckedAt') IS NOT json_extract(NEW.payload_json, '$.teacherSafetyCheckedAt')
 OR json_extract(OLD.payload_json, '$.teacherSafetyCheck') IS NOT json_extract(NEW.payload_json, '$.teacherSafetyCheck')
BEGIN
 INSERT INTO platform_audit_events
  (id, action, entity_type, entity_id, before_json, after_json, created_at)
 VALUES (lower(hex(randomblob(16))), 'teacher_review_updated', 'classroom_attempt', NEW.id,
  OLD.payload_json, NEW.payload_json, NEW.updated_at);
END;
