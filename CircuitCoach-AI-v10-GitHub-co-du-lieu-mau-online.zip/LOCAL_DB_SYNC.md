# Local database sync

The server records an image count only after upload. The result screen
waits for the server to confirm class feedback and offers a retry using
the local photo archive. Attempts without a class code remain local to
the browser. Existing database rows are preserved.
