@echo off
setlocal
cd /d "%~dp0"
set "CC_NODE=node.exe"
where node.exe >nul 2>nul
if errorlevel 1 set "CC_NODE=C:\Program Files\WindowsApps\OpenAI.CodexPrimaryRuntime.v26-1123-915-0_26.1123.915.0_x64__3k8sg7r9htsxt\dependencies\node\bin\node.exe"
"%CC_NODE%" --version >nul 2>nul
if errorlevel 1 (echo Can cai Node.js 24 de chay CircuitCoach. & pause & exit /b 1)
"%CC_NODE%" scripts\backup-local.mjs
pause
