# Local sign-in

The welcome screen offers Student, Teacher and Admin and opens the
matching sign-in fields in place. Students enter a group name and class
code. Local teachers and admins enter account credentials. A successful
sign-in opens lessons, the assigned class, or administration.

The role selector stays visible while the shared form is open.
Open /#/home to choose a different role.

The local admin and teacher accounts are listed in
.data/local-sign-in.txt. That file is outside the source backups.
The teacher account is assigned to DEMO921.
The current local usernames are gv and admin. These two local accounts
support a five-character password. The normal account creation rules
still apply to other accounts.
