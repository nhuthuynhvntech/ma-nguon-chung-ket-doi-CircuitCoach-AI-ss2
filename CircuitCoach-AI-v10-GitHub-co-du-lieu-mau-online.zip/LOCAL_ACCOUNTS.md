# Tai khoan giao vien local

Chay bang Node 22.13 tro len. Tu thu muc du an, dat bien moi truong
`CIRCUITCOACH_NEW_PASSWORD` bang mat khau 12-128 ky tu, sau do chay:

```powershell
node scripts/local-worker.mjs create-account ten-giao-vien teacher DEMO921
Remove-Item Env:CIRCUITCOACH_NEW_PASSWORD
```

Mo http://127.0.0.1:3187/#/teacher va dang nhap voi dung ma lop duoc gan.
Mat khau duoc bam trong SQLite. Phien cookie het han sau 30 phut va duoc
thu hoi khi dang xuat. Luong tai khoan rieng chi bat trong may chu local.

Tao admin voi `node scripts/local-worker.mjs create-account ten-admin admin`
va kiem duyet vien voi `node scripts/local-worker.mjs create-account ten-kiem-duyet reviewer led`.
Dung bien mat khau rieng cho moi lan tao. Admin dang nhap o /#/admin.
Kiem duyet vien dang nhap o /#/reviewer va xem hang cho theo bai hoc.
Phien dung chung tren cung trinh duyet; dang xuat truoc khi doi tai khoan.

Build Worker va kiem tra API phan tach quyen admin/kiem duyet da qua.
Con thieu giao dien quan ly tai khoan, bao ve day du anh/hoc sinh,
luong gui va duyet vi du, phan tich A/B va bao cao.
