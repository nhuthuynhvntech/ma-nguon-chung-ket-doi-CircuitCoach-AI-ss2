import { createCipheriv, createDecipheriv, randomBytes, randomUUID } from "node:crypto";
import { createReadStream, createWriteStream, constants } from "node:fs";
import { access, copyFile, open, readFile, unlink, writeFile } from "node:fs/promises";
import { pipeline } from "node:stream/promises";

const signature = Buffer.from("CCBACKUP1");
const nonceSize = 12;
const tagSize = 16;
const headerSize = signature.length + nonceSize;

async function requireNewFile(path) {
  try {
    await access(path);
  } catch (error) {
    if (error.code === "ENOENT") return;
    throw error;
  }
  throw new Error("Tệp đích đã tồn tại. Hãy chọn tên tệp mới.");
}

async function encryptBackup(input, output, keyFile) {
  await requireNewFile(output);
  const key = randomBytes(32);
  const nonce = randomBytes(nonceSize);
  const header = Buffer.concat([signature, nonce]);
  const cipher = createCipheriv("aes-256-gcm", key, nonce);
  cipher.setAAD(header);
  const pending = output + "." + randomUUID() + ".pending";
  await writeFile(keyFile, key.toString("hex") + "\n", { flag: "wx", mode: 0o600 });
  try {
    await writeFile(pending, header, { flag: "wx", mode: 0o600 });
    await pipeline(createReadStream(input), cipher, createWriteStream(pending, { flags: "a" }));
    await writeFile(pending, cipher.getAuthTag(), { flag: "a" });
    await copyFile(pending, output, constants.COPYFILE_EXCL);
  } catch (error) {
    await unlink(keyFile).catch(() => {});
    throw error;
  } finally {
    await unlink(pending).catch(() => {});
  }
}

async function decryptBackup(input, output, keyFile) {
  await requireNewFile(output);
  const encoded = (await readFile(keyFile, "utf8")).trim();
  if (!/^[0-9a-f]{64}$/i.test(encoded)) throw new Error("Tệp khóa khôi phục không hợp lệ.");
  const source = await open(input, "r");
  const pending = output + "." + randomUUID() + ".pending";
  try {
    const { size } = await source.stat();
    if (size <= headerSize + tagSize) throw new Error("Tệp sao lưu bị thiếu dữ liệu.");
    const header = Buffer.alloc(headerSize);
    const tag = Buffer.alloc(tagSize);
    await source.read(header, 0, header.length, 0);
    await source.read(tag, 0, tag.length, size - tag.length);
    if (!header.subarray(0, signature.length).equals(signature)) throw new Error("Tệp sao lưu không đúng định dạng CircuitCoach.");
    const nonce = header.subarray(signature.length);
    const decipher = createDecipheriv("aes-256-gcm", Buffer.from(encoded, "hex"), nonce);
    decipher.setAAD(header);
    decipher.setAuthTag(tag);
    await pipeline(source.createReadStream({ start: headerSize, end: size - tagSize - 1, autoClose: false }),
      decipher, createWriteStream(pending, { flags: "wx", mode: 0o600 }));
    await copyFile(pending, output, constants.COPYFILE_EXCL);
  } finally {
    await source.close();
    await unlink(pending).catch(() => {});
  }
}

const [operation, input, output, keyFile, ...extra] = process.argv.slice(2);
try {
  if (!["encrypt", "decrypt"].includes(operation) || !input || !output || !keyFile || extra.length) {
    throw new Error("Dùng node scripts/protected-backup.mjs encrypt|decrypt <tệp nguồn> <tệp đích mới> <tệp khóa>.");
  }
  await (operation === "encrypt" ? encryptBackup : decryptBackup)(input, output, keyFile);
  console.log("Hoàn tất. Giữ tệp khóa ở nơi lưu riêng.");
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
