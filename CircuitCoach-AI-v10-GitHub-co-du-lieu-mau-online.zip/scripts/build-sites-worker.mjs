import { cp, mkdir, readFile, readdir, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";
import { build as buildLibrary } from "vite";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const vite = path.join(root, "node_modules", "vite", "bin", "vite.js");
const build = spawnSync(process.execPath, [vite, "build", "--configLoader", "runner"], { cwd: root, stdio: "inherit" });
if (build.status !== 0) process.exit(build.status || 1);

const dist = path.join(root, "dist");
const assets = {};

async function collect(directory, prefix = "") {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const absolute = path.join(directory, entry.name);
    const relative = path.posix.join(prefix, entry.name);
    if (entry.isDirectory()) await collect(absolute, relative);
    else assets[`/${relative}`] = (await readFile(absolute)).toString("base64");
  }
}

await collect(dist);

function inlineModule(source) {
  return source
    .replace(/^import .*;\r?\n/gm, "")
    .replace(/^export\s+(?=(const|(?:async )?function)\s)/gm, "");
}

const inlineFiles = [
  "src/data/knowledge-base.js",
  "src/data/circuit-rules.js",
  "src/data/lessons.js",
  "src/data/local-hints.js",
  "src/data/reference-cases.js",
  "src/data/capture-tips.js",
  "src/data/ai-error-reasons.js",
  "src/data/session-roles.js",
  "src/data/assembly-guides.js",
  "src/data/guide-chat.js",
  "server/ai/annotation-policy.js",
  "server/ai/arduino-pin-geometry.js",
  "server/ai/circuit-proof.js",
  "server/ai/circuit-observations.js",
  "server/ai/analyze-prompt.js",
  "server/ai/tutor-prompt.js",
  "server/ai/student-guide.js",
  "server/ai/guide-chat.js",
  "server/ai/safety-policy.js",
  "server/ai/finalize-analysis.js",
  "server/ai/region-review-prompt.js",
  "server/ai/region-refinement.js",
];
const inlineSource = (await Promise.all(inlineFiles.map((file) => readFile(path.join(root, file), "utf8"))))
  .map(inlineModule)
  .join("\n");
const runtime = await readFile(path.join(root, "worker", "runtime.js"), "utf8");
const jpegEntry = import.meta.resolve("jpeg-js");
const [jpegBuild] = await buildLibrary({
  configFile: false,
  logLevel: "warn",
  build: {
    write: false,
    minify: false,
    lib: { entry: fileURLToPath(jpegEntry), name: "jpegLibrary", formats: ["iife"] },
  },
});
const jpegLicense = await readFile(new URL("./LICENSE", jpegEntry), "utf8");
const jpegSource = `/* jpeg-js\n${jpegLicense}\n*/
const regionJpegCodec = (() => {
  const Buffer = { from: values => Uint8Array.from(values) };
  ${jpegBuild.output.find(item => item.type === "chunk").code}
  return jpegLibrary;
})();`;
const generated = `${jpegSource}\n${inlineSource}\n${runtime.replace(/^import .*;\r?\n/gm, "")}`
  .replace("/*__ASSET_MAP__*/ {}", JSON.stringify(assets));

await rm(dist, { recursive: true, force: true });
await mkdir(path.join(dist, "server"), { recursive: true });
await mkdir(path.join(dist, ".openai"), { recursive: true });
await writeFile(path.join(dist, "server", "index.js"), generated);
await cp(path.join(root, ".openai", "hosting.json"), path.join(dist, ".openai", "hosting.json"));
await cp(path.join(root, "drizzle"), path.join(dist, ".openai", "drizzle"), { recursive: true });
console.log(`Built Sites Worker with ${Object.keys(assets).length} embedded assets.`);
