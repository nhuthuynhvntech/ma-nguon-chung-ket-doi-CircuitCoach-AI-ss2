import http from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { mkdir, readFile, writeFile, rename, unlink, readdir } from 'node:fs/promises';
import path from 'node:path';
import { pbkdf2Sync, randomBytes, randomUUID } from 'node:crypto';
import { parseEnv } from 'node:util';
import { seedOnlineLibrary } from './seed-online-library.mjs';

const root = path.resolve(import.meta.dirname, '..');
process.chdir(root);
const onlineDemo = process.env.CIRCUITCOACH_ONLINE_DEMO === '1';
const directory = onlineDemo ? path.join(root, '.data', 'online-demo') : path.join(root, '.data');
const demoConfigPath = path.join(root, '.circuitcoach-demo.env');
const localPort = Number(process.env.LOCAL_PORT || 3187);
const configDirectory = onlineDemo ? directory : process.env.LOCALAPPDATA
  ? path.join(process.env.LOCALAPPDATA, 'CircuitCoach', `local-${localPort}`)
  : null;
await mkdir(path.join(directory, 'images'), { recursive: true });
const db = new DatabaseSync(path.join(directory, 'circuitcoach.sqlite'));
db.exec('PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; CREATE TABLE IF NOT EXISTS local_migrations(name TEXT PRIMARY KEY);');
for (const name of (await readdir('drizzle')).filter(name => name.endsWith('.sql')).sort()) {
  if (db.prepare('SELECT name FROM local_migrations WHERE name=?').get(name)) continue;
  db.exec('BEGIN');
  try {
    db.exec(await readFile(path.join('drizzle', name), 'utf8'));
    db.prepare('INSERT INTO local_migrations VALUES(?)').run(name);
    db.exec('COMMIT');
  } catch (error) { db.exec('ROLLBACK'); throw error; }
}
function statement(sql, values = []) {
  return {
    bind: (...args) => statement(sql, args),
    first: async () => db.prepare(sql).get(...values) || null,
    all: async () => ({ results: db.prepare(sql).all(...values) }),
    run: () => ({ success: true, meta: db.prepare(sql).run(...values) }),
  };
}
const imagePath = key => path.join(directory, 'images', Buffer.from(key).toString('hex'));
const env = {
  ...process.env,
  DB: { prepare: statement, batch: async items => {
    db.exec('BEGIN');
    try { const results = items.map(item => item.run()); db.exec('COMMIT'); return results; }
    catch (error) { db.exec('ROLLBACK'); throw error; }
  } },
  BUCKET: {
    put: async (key, body, options = {}) => {
      const bytes = await new Response(body).arrayBuffer();
      await writeFile(imagePath(key), Buffer.from(bytes));
      await writeFile(imagePath(key) + '.json', JSON.stringify(options));
    },
    get: async key => {
      try { return { body: await readFile(imagePath(key)), ...JSON.parse(await readFile(imagePath(key) + '.json', 'utf8')) }; }
      catch (error) { if (error.code === 'ENOENT') return null; throw error; }
    },
    delete: async key => { for (const file of [imagePath(key), imagePath(key) + '.json']) await unlink(file).catch(error => { if (error.code !== 'ENOENT') throw error; }); },
  },
};
const credentialsPath = path.join(directory, 'local-credentials.json');
let credentials;
try { credentials = JSON.parse(await readFile(credentialsPath, 'utf8')); }
catch (error) {
  if (error.code !== 'ENOENT') throw error;
  credentials = { ADMIN_USERNAME: 'ADMIN', ADMIN_PASSWORD: randomBytes(18).toString('base64url'), ADMIN_SESSION_SECRET: randomBytes(36).toString('base64url'), TEACHER_USERNAME: 'GV', TEACHER_PASSWORD: randomBytes(18).toString('base64url') };
  await writeFile(credentialsPath, JSON.stringify(credentials, null, 2), { mode: 0o600 });
}
Object.assign(env, credentials);
env.LOCAL_PERSONAL_ACCOUNTS = true;

async function readOptionalConfig(file) {
  try {
    return await readFile(file, 'utf8');
  } catch (error) {
    if (error.code === 'ENOENT') return '';
    throw error;
  }
}

function localPasswordHash(password, salt, iterations = 600_000) {
  return pbkdf2Sync(password, salt, iterations, 32, 'sha256').toString('base64url');
}

function newLocalPasswordHash(password) {
  const salt = randomBytes(16);
  return salt.toString('base64url') + '.' + localPasswordHash(password, salt);
}

function applyStaffConfig(config) {
  const entries = ['teacher', 'admin'].map(role => ({
    role,
    username: config[role.toUpperCase() + '_USERNAME']?.trim(),
    password: config[role.toUpperCase() + '_PASSWORD'],
  })).filter(({ username, password }) => username !== undefined || password !== undefined);
  if (!entries.length) return;

  const managed = new Set();
  const findUser = db.prepare('SELECT id,password_hash,disabled FROM platform_users WHERE username=?');
  const findRole = db.prepare('SELECT 1 FROM platform_roles WHERE user_id=? AND role=?');
  db.exec('BEGIN IMMEDIATE');
  try {
    for (const { role, username, password } of entries) {
      if (!username || !/^[\w.-]{2,40}$/.test(username) || !password?.trim() || password.length < 5 || password.length > 128) {
        throw new Error('Kiểm tra tên và mật khẩu (5–128 ký tự) của vai trò ' + role + ' trong tệp .env.');
      }
      const account = findUser.get(username);
      if (!account) {
        const id = randomUUID();
        db.prepare('INSERT INTO platform_users (id,username,password_hash,created_at) VALUES (?,?,?,?)')
          .run(id, username, newLocalPasswordHash(password), new Date().toISOString());
        db.prepare('INSERT INTO platform_roles (user_id,role) VALUES (?,?)').run(id, role);
        managed.add(id);
        continue;
      }
      if (account.disabled || !findRole.get(account.id, role) || managed.has(account.id)) {
        throw new Error('Tên trong tệp .env cần thuộc một tài khoản đang hoạt động riêng cho vai trò ' + role + '.');
      }
      const parts = account.password_hash.split('.');
      const legacy = parts[0] === 'p100';
      const [salt, hash] = legacy ? parts.slice(1) : parts;
      const matches = salt && hash && localPasswordHash(password, Buffer.from(salt, 'base64url'), legacy ? 100_000 : 600_000) === hash;
      if (!matches) {
        db.prepare('UPDATE platform_users SET password_hash=? WHERE id=?').run(newLocalPasswordHash(password), account.id);
        db.prepare('DELETE FROM platform_sessions WHERE user_id=?').run(account.id);
      }
      managed.add(account.id);
    }
    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
  env.LOCAL_FILE_STAFF_IDS = managed;
}

if (configDirectory) {
  const defaultPath = onlineDemo ? demoConfigPath : path.join(configDirectory, '.env');
  const overridePath = path.join(configDirectory, 'openai-key.override');
  if (!process.argv[2]) {
    const config = parseEnv((await readOptionalConfig(defaultPath)).trimStart());
    if (onlineDemo) {
      const staff = { ...credentials, ...config };
      applyStaffConfig(staff);
      const classCode = (config.DEMO_CLASS_CODE || 'DEMO920').trim().toUpperCase();
      await seedOnlineLibrary(db, env.BUCKET, { classCode, teacherUsername: staff.TEACHER_USERNAME });
      console.log(`Lớp dùng thử ${classCode} · Học sinh ${config.DEMO_STUDENT_NAME || 'nhom-mau'}`);
      console.log(`Đọc thông tin tài khoản trong ${demoConfigPath} nếu có, hoặc ${credentialsPath}.`);
    } else {
      applyStaffConfig(config);
    }
  }
  env.LOCAL_OPENAI_SETTINGS = {
    async read() {
      const [defaults, override] = await Promise.all([readOptionalConfig(defaultPath), readOptionalConfig(overridePath)]);
      return {
        defaultKey: parseEnv(defaults.trimStart()).OPENAI_API_KEY?.trim() || env.OPENAI_API_KEY || '',
        overrideKey: override.trim(),
      };
    },
    async write(apiKey) {
      await mkdir(configDirectory, { recursive: true, mode: 0o700 });
      const pending = path.join(configDirectory, `openai-key-${randomUUID()}.tmp`);
      try {
        await writeFile(pending, apiKey, { mode: 0o600, flag: 'wx' });
        await rename(pending, overridePath);
      } catch (error) {
        await unlink(pending).catch(() => {});
        throw error;
      }
    },
  };
}

const [, , command, username, role, scope] = process.argv;
if (command === 'create-account') {
  const password = process.env.CIRCUITCOACH_NEW_PASSWORD || '';
  if (!/^[\w.-]{3,40}$/.test(username || '') || !['teacher', 'admin'].includes(role)
    || password.length < 12 || password.length > 128
    || (role === 'teacher' && scope && !/^[A-Z0-9]{4,12}$/.test(scope))) {
    throw new Error('Use create-account USERNAME teacher|admin [CLASS_CODE] with CIRCUITCOACH_NEW_PASSWORD (12-128 characters). Teachers can create classes after login.');
  }
  const id = randomUUID();
  db.exec('BEGIN');
  try {
    db.prepare('INSERT INTO platform_users (id, username, password_hash, created_at) VALUES (?, ?, ?, ?)').run(id, username, newLocalPasswordHash(password), new Date().toISOString());
    db.prepare('INSERT INTO platform_roles VALUES (?, ?)').run(id, role);
    if (role === 'teacher' && scope) {
      db.prepare('INSERT OR IGNORE INTO platform_classes (code,created_by,created_at) VALUES (?,?,?)').run(scope, id, new Date().toISOString());
      db.prepare("INSERT INTO platform_class_members VALUES (?, ?, 'teacher')").run(scope, id);
    }
    db.exec('COMMIT');
  } catch (error) { db.exec('ROLLBACK'); throw error; }
  console.log('Account created.');
  process.exit(0);
}
const { default: worker } = await import('../dist/server/index.js');
const server = http.createServer(async (incoming, outgoing) => {
  try {
    const chunks = []; let size = 0;
    for await (const chunk of incoming) { size += chunk.length; if (size > 20_000_000) { outgoing.writeHead(413); outgoing.end(); return; } chunks.push(chunk); }
    const origin = `http://127.0.0.1:${server.address().port}`;
    const url = new URL(incoming.url, origin);
    const request = new Request(url, { method: incoming.method, headers: incoming.headers, ...(!['GET', 'HEAD'].includes(incoming.method) ? { body: Buffer.concat(chunks) } : {}) });
    const response = await worker.fetch(request, env);
    const headers = Object.fromEntries(response.headers);
    const cookies = response.headers.getSetCookie();
    if (cookies.length) headers["set-cookie"] = cookies;
    outgoing.writeHead(response.status, headers);
    outgoing.end(Buffer.from(await response.arrayBuffer()));
  } catch (error) { console.error(error); outgoing.writeHead(500); outgoing.end('Local server error'); }
});
server.listen(localPort, '127.0.0.1', () => console.log(`CircuitCoach local: http://127.0.0.1:${server.address().port}\nCredentials: ${credentialsPath}\nDatabase: ${path.join(directory, 'circuitcoach.sqlite')}`));
