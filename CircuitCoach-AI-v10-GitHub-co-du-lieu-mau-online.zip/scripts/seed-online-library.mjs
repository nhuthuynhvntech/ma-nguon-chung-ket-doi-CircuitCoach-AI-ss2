import path from 'node:path';
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';

const lessons = new Set(['led', 'hcsr04', 'servo', 'battery-led-switch', 'soil-moisture']);
const referencesPath = path.resolve(import.meta.dirname, '../du-lieu-mau-online');

export async function seedOnlineLibrary(db, bucket, { classCode, teacherUsername }) {
  if (!/^[A-Z0-9]{4,12}$/.test(classCode)) {
    throw new Error('Mã lớp dùng thử cần có từ 4 đến 12 chữ cái hoặc chữ số.');
  }
  const teacher = db.prepare(`SELECT u.id FROM platform_users u JOIN platform_roles r ON r.user_id=u.id
    WHERE u.username=? AND r.role='teacher' AND u.disabled=0`).get(teacherUsername);
  if (!teacher) throw new Error('Chưa tạo được tài khoản giáo viên dùng thử.');

  const manifest = JSON.parse(await readFile(path.join(referencesPath, 'manifest.json'), 'utf8'));
  if (manifest.formatVersion !== 1 || !Array.isArray(manifest.references)) {
    throw new Error('Danh mục ảnh dùng thử không hợp lệ.');
  }
  const imported = db.prepare('SELECT id FROM platform_uploaded_reference_cases WHERE id=?');
  const insert = db.prepare(`INSERT INTO platform_uploaded_reference_cases
    (id,class_code,lesson_id,criterion_id,label,error_type,status,created_by,created_at,reviewed_by,reviewed_at,source_key,annotations_json)
    VALUES (?,'',?,?,?,?,'approved',?,?,?,?,?,?)`);
  const date = new Date(manifest.downloadedAt).toISOString();
  db.exec('BEGIN IMMEDIATE');
  try {
    db.prepare('INSERT OR IGNORE INTO platform_classes(code,created_by,created_at) VALUES (?,?,?)')
      .run(classCode, teacher.id, date);
    db.prepare("INSERT OR IGNORE INTO platform_class_members(class_code,user_id,membership) VALUES (?,?,'teacher')")
      .run(classCode, teacher.id);
    for (const row of manifest.references) {
      const { publicCaseId, lessonId, criterionId, label, errorType, annotations, photo, sha256 } = row;
      if (!/^[a-f0-9-]{36}$/.test(publicCaseId) || !lessons.has(lessonId)
          || !/^[a-z][a-z0-9_]+$/.test(criterionId) || !['correct','incorrect'].includes(label)
          || (label === 'incorrect' && !/^[a-z0-9_-]{1,60}$/.test(errorType ?? ''))
          || !Array.isArray(annotations) || !new RegExp(`^${lessonId}/[0-9]{2}[.]jpg$`).test(photo)) {
        throw new Error('Thông tin ảnh tham chiếu dùng thử không hợp lệ.');
      }
      const id = publicCaseId;
      if (imported.get(id)) continue;

      const bytes = await readFile(path.join(referencesPath, photo));
      if (createHash('sha256').update(bytes).digest('hex') !== sha256) {
        throw new Error('Ảnh tham chiếu dùng thử không khớp mã kiểm tra.');
      }
      await bucket.put('reviewed-examples/' + id, bytes, { httpMetadata: { contentType: 'image/jpeg' } });
      insert.run(id, lessonId, criterionId, label, label === 'correct' ? null : errorType, teacher.id, date,
        teacher.id, date, 'github-v10:' + id, JSON.stringify(annotations));
    }
    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
}
