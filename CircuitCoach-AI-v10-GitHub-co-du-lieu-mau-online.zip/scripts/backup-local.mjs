
import { backup, DatabaseSync } from "node:sqlite";
import { existsSync } from "node:fs";
import { copyFile, mkdir, mkdtemp, readFile, readdir, realpath, rename, rm, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import path from "node:path";
import { pathToFileURL } from "node:url";

const databaseName = "circuitcoach.sqlite";
const measuredTables = [
  "classroom_attempts", "platform_classes", "platform_users", "platform_student_groups",
  "platform_lesson_sample_photos", "platform_reference_examples", "platform_uploaded_reference_cases",
  "platform_ai_runs", "platform_ai_comparison_scores", "platform_criterion_rechecks",
];

function rowCount(db, table) {
  return db.prepare("SELECT COUNT(*) AS count FROM " + table).get().count;
}

async function imageInventory(folder) {
  const out = [];
  for (const entry of (await readdir(folder, { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name))) {
    if (!entry.isFile()) throw new Error("Kho ảnh chứa mục không phải tệp thường.");
    const contents = await readFile(path.join(folder, entry.name));
    out.push({ name: entry.name, bytes: contents.length, sha256: createHash("sha256").update(contents).digest("hex") });
  }
  return out;
}

function imageKeys(db) {
  const known = new Set();
  for (const { id, class_code, payload_json } of db.prepare("SELECT id,class_code,payload_json FROM classroom_attempts").all()) {
    const { imageCount } = JSON.parse(payload_json);
    for (let index = 0; index < Number(imageCount || 0); index += 1) known.add(class_code + "/" + encodeURIComponent(id) + "/" + index);
  }
  for (const { id } of db.prepare("SELECT id FROM platform_lesson_sample_photos").all()) known.add("lesson-samples/" + id);
  for (const { id } of db.prepare("SELECT id FROM platform_criterion_rechecks").all()) known.add("criterion-rechecks/" + id);
  for (const table of ["platform_reference_examples", "platform_uploaded_reference_cases"]) {
    for (const { id } of db.prepare("SELECT id FROM " + table).all()) known.add("reviewed-examples/" + id);
  }
  return [...known];
}

export async function snapshotLocalData(source, target) {
  source = path.resolve(source);
  target = path.resolve(target);
  if (source === target) throw new Error("Thư mục nguồn và bản sao cần khác nhau.");
  if (existsSync(target)) throw new Error("Đã có thư mục sao lưu ở vị trí này.");
  const parent = await realpath(path.dirname(target));
  const sourceImages = path.join(source, "images");
  const sourceDb = new DatabaseSync(path.join(source, databaseName), { readOnly: true, timeout: 5000 });
  let destinationDb;
  let work;
  try {
    const version = sourceDb.prepare("PRAGMA data_version").get().data_version;
    const initial = await imageInventory(sourceImages);
    work = await mkdtemp(path.join(parent, ".backup-pending-"));
    const targetImages = path.join(work, "images");
    const backupDatabase = path.join(work, databaseName);
    await mkdir(targetImages);
    await backup(sourceDb, backupDatabase);
    for (const entry of initial) await copyFile(path.join(sourceImages, entry.name), path.join(targetImages, entry.name));
    const [originalAfter, copied] = await Promise.all([imageInventory(sourceImages), imageInventory(targetImages)]);
    if (JSON.stringify(initial) !== JSON.stringify(originalAfter)
        || JSON.stringify(initial) !== JSON.stringify(copied)
        || version !== sourceDb.prepare("PRAGMA data_version").get().data_version) {
      throw new Error("Dữ liệu nguồn vừa thay đổi khi sao lưu. Hãy chạy lại sau khi ngừng các thao tác lưu.");
    }

    destinationDb = new DatabaseSync(backupDatabase, { readOnly: true });
    const integrity = destinationDb.prepare("PRAGMA integrity_check").get().integrity_check;
    if (integrity !== "ok" || destinationDb.prepare("PRAGMA foreign_key_check").all().length) {
      throw new Error("Kiểm tra SQLite hoặc liên kết dữ liệu không đạt.");
    }
    const tables = Object.fromEntries(measuredTables.map(table => [table, rowCount(destinationDb, table)]));
    const names = new Set(copied.map(item => item.name));
    const expected = imageKeys(destinationDb);
    const missing = expected.filter(key => {
      const file = Buffer.from(key).toString("hex");
      return !names.has(file) || !names.has(file + ".json");
    });
    const result = {
      capturedAt: new Date().toISOString(),
      integrity,
      tables,
      imageFiles: copied.filter(item => !item.name.endsWith(".json")).length,
      metadataFiles: copied.filter(item => item.name.endsWith(".json")).length,
      linkedObjects: expected.length,
      missingImageObjects: missing.length,
      databaseSha256: createHash("sha256").update(await readFile(backupDatabase)).digest("hex"),
      files: copied,
    };
    await writeFile(path.join(work, "manifest.json"), JSON.stringify(result, null, 2) + "\n", { flag: "wx" });
    destinationDb.close();
    destinationDb = undefined;
    await rename(work, target);
    work = undefined;
    return result;
  } finally {
    destinationDb?.close();
    sourceDb.close();
    if (work) {
      const staging = await realpath(work);
      if (path.dirname(staging) === parent && path.basename(staging).startsWith(".backup-pending-")) {
        await rm(staging, { recursive: true, force: true });
      }
    }
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  const root = path.resolve(import.meta.dirname, "..");
  const snapshots = path.join(root, "backups", "du-lieu-local");
  const stamp = new Date().toISOString().replaceAll(":", "-");
  await mkdir(snapshots, { recursive: true });
  const folder = path.join(snapshots, stamp);
  const data = await snapshotLocalData(path.join(root, ".data"), folder);
  console.log("Bản sao lưu: " + folder);
  console.log("Lượt làm: " + data.tables.classroom_attempts + ". Ảnh: " + data.imageFiles + ". SQLite: " + data.integrity + ".");
  if (data.missingImageObjects) console.log("Số ảnh được ghi trong cơ sở dữ liệu nhưng thiếu tệp: " + data.missingImageObjects + ".");
}
