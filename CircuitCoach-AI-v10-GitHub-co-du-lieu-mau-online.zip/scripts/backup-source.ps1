param(
    [string]$OutputDirectory = (Join-Path (Split-Path -Parent $PSScriptRoot) 'backups')
)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$resolvedRoot = (Resolve-Path -LiteralPath $projectRoot).Path
$resolvedOutput = [System.IO.Path]::GetFullPath($OutputDirectory)

if (-not (Test-Path -LiteralPath $resolvedOutput)) {
    New-Item -ItemType Directory -Path $resolvedOutput | Out-Null
}
$resolvedOutput = (Resolve-Path -LiteralPath $resolvedOutput).Path

$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$zipPath = Join-Path $resolvedOutput "circuitcoach-source-$timestamp.zip"
$stagePath = Join-Path ([System.IO.Path]::GetTempPath()) "circuitcoach-source-$timestamp"

$include = @(
    '.env.example', 'CHANGELOG.md', 'DESIGN.md', 'DEVELOPMENT_LOG.md',
    'HUONG_DAN_TRIEN_KHAI.md', 'PROJECT_HISTORY.md', 'PROMPT_LOG.md',
    'README.md', 'TESTING.md', 'index.html', 'package.json',
    'package-lock.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml', 'vite.config.js',
    'public', 'scripts', 'server', 'src', 'test', 'worker', 'drizzle', '.openai'
)

try {
    New-Item -ItemType Directory -Path $stagePath | Out-Null
    foreach ($item in $include) {
        $sourcePath = Join-Path $resolvedRoot $item
        if (Test-Path -LiteralPath $sourcePath) {
            Copy-Item -LiteralPath $sourcePath -Destination $stagePath -Recurse -Force
        }
    }
    Compress-Archive -Path (Join-Path $stagePath '*') -DestinationPath $zipPath -CompressionLevel Optimal
    Write-Output "Source backup created: $zipPath"
} finally {
    if (Test-Path -LiteralPath $stagePath) {
        Remove-Item -LiteralPath $stagePath -Recurse -Force
    }
}
