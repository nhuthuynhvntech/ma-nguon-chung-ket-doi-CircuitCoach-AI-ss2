import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { dataDirectory, loadClassroomStore, persistAttemptImages, persistAttempts } from "../server/storage/classroom-store.js";

const projectDirectory = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const now = Date.now();
const isoMinutesAgo = (minutes) => new Date(now - minutes * 60_000).toISOString();
const verifiedAt = isoMinutesAgo(2);

function attempt({ id, studentId, studentName, lessonId, minutes, verdict, problems = [], teacherVerification = null, note = "", imageCount = 0 }) {
  const verified = Boolean(teacherVerification);
  return {
    id,
    studentId,
    studentName,
    classCode: "DEMO921",
    lessonId,
    time: isoMinutesAgo(minutes),
    analysisStatus: "ok",
    summary: `Kết quả mẫu cho ${studentName}.`,
    verdict,
    safety: null,
    captureAdvice: [],
    demo: true,
    problems,
    verification: null,
    teacherStatus: teacherVerification === "correct" ? "approved" : null,
    teacherComment: "",
    teacherCommentAt: null,
    teacherVerification,
    teacherVerificationNote: note,
    teacherVerifiedBy: verified ? "GV" : null,
    teacherVerifiedAt: verified ? verifiedAt : null,
    imageCount,
  };
}

const demoAttempts = [
  attempt({ id: "report-demo-a1", studentId: "report-a1", studentName: "Nhóm A1", lessonId: "led", minutes: 8, verdict: "pass", teacherVerification: "correct", note: "Đã kiểm tra trực tiếp, mạch đúng.", imageCount: 1 }),
  attempt({ id: "report-demo-a2", studentId: "report-a2", studentName: "Nhóm A2", lessonId: "hcsr04", minutes: 15, verdict: "review", problems: [{ id: "trig_connection", label: "Kết nối TRIG", status: "possible_error", category: "standard", safetyKind: null }], teacherVerification: "incorrect", note: "Chân TRIG nối lỏng, cần sửa lại.", imageCount: 1 }),
  attempt({ id: "report-demo-a3", studentId: "report-a3", studentName: "Nhóm A3", lessonId: "servo", minutes: 22, verdict: "review", problems: [{ id: "signal_connection", label: "Kết nối Signal", status: "uncertain", category: "standard", safetyKind: null }], teacherVerification: "uncertain", note: "Cần chụp cận cảnh chân tín hiệu." }),
  attempt({ id: "report-demo-a4", studentId: "report-a4", studentName: "Nhóm A4", lessonId: "battery-led-switch", minutes: 31, verdict: "review", problems: [{ id: "no_short_circuit", label: "Không có dấu hiệu chập mạch", status: "possible_error", category: "safety", safetyKind: "short_circuit" }] }),
  attempt({ id: "report-demo-a5", studentId: "report-a5", studentName: "Nhóm A5", lessonId: "led", minutes: 44, verdict: "pass", teacherVerification: "correct", note: "Mạch đúng và đã đối chiếu sơ đồ." }),
  attempt({ id: "report-demo-a6", studentId: "report-a6", studentName: "Nhóm A6", lessonId: "hcsr04", minutes: 58, verdict: "review", problems: [{ id: "power_voltage", label: "Mức nguồn phù hợp", status: "uncertain", category: "safety", safetyKind: "voltage" }] }),
];

const store = loadClassroomStore();
demoAttempts.forEach((demo) => store.attempts.set(demo.id, demo));
persistAttempts(store.attempts);

const demoImages = [
  { attemptId: "report-demo-a1", file: "lesson1-reference-overview.jpg" },
  { attemptId: "report-demo-a2", file: "lesson2-reference-overview.jpg" },
];
demoImages.forEach(({ attemptId, file }) => {
  const buffer = readFileSync(path.join(projectDirectory, "public", "images", file));
  persistAttemptImages(attemptId, [{ buffer, type: "image/jpeg" }]);
});

console.log(`Đã lưu ${demoAttempts.length} lượt kiểm tra mẫu vào ${dataDirectory}`);
